// Protractor configuration file, see link for more information
// https://github.com/angular/protractor/blob/master/lib/config.ts
const domain = process.env.BDD_TEST_ENV;
const prefix = (domain.indexOf('localhost') === -1) ? 'https' : 'http';
const bddTestUrl = prefix + '://' + domain;
exports.config = {
  allScriptsTimeout: 30000,
  getPageTimeout: 20000,
  jasmineNodeOpts: {
    defaultTimeoutInterval: 20000,
    showColors: true,
  },

  suites: {
    sanity:
      ['./test/test-suites/sanity-test-suite/sanity-tests.feature'],
    regression:
      [
        './test/test-suites/sanity-test-suite/sanity-tests.feature',
        './test/test-suites/regression-test-suite/quote-and-buy.feature',
        './test/test-suites/regression-test-suite/quote-edit-buy.feature',
        './test/test-suites/regression-test-suite/indicative-quotes.feature',
        './test/test-suites/regression-test-suite/decline-scenarios.feature',
        './test/test-suites/regression-test-suite/business-validations.feature'
      ],
    r1c:
      ['./test/test-suites/1b-features/1b-features.feature']
  },

  'commonCapabilities': {
    'shardTestFiles': true,
    'maxInstances': 1,
    'elementScrollBehavior': 1
  },

  'multiCapabilities': [{
    'browserName': 'chrome',
    'chromeOptions': { args: ['no-sandbox', '--disable-infobars', '--disable-popup'] },
  }
  ],

  directConnect: true,
  baseUrl: bddTestUrl,
  resultJsonOutputFile: './test/report/cucumber-report.json',
  framework: 'custom',
  frameworkPath: require.resolve('protractor-cucumber-framework'),
  ignoreUncaughtExceptions: true,
  disableChecks: true,
  disableEnvironmentOverrides: false,
  debug: false,

  cucumberOpts: {
    require: [
      'test/step_definitions/support/env.js',
      'test/step_definitions/support/hooks.ts',
      'test/step_definitions/common/*.ts',
      'test/step_definitions/*.ts'],
    tags: '@smoke,@regression,@sanity,@e2e',
    profile: false,
    strict: true,
    'no-source': true,
    keepAlive: false,
    format: 'json:./test/report/results.json'
  },
  plugins: [{
    package: 'protractor-multiple-cucumber-html-reporter-plugin',
    options: {
      automaticallyGenerateReport: true,
      removeExistingJsonReportFile: false
    }
  }],
  SELENIUM_PROMISE_MANAGER: true,
  onPrepare() {
    require('ts-node').register({
      project: './test/tsconfig.e2e.json'
    });
  }
};