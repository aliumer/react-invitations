# B4C-UI

## Contents
- Project introduction
- Project environments
- Prerequisites
- Instructions: Build setup
- Build commands
- Deployment
- Unit tests
- Automated/e2e tests
- Useful information
    - Build assets for different brands
    - SVG tool
    - Localhost proxy config
    - Typescript linting
    - SASS linting
- Libraries
- Author
___

### Project introduction
Angular cli built website for the b4c motor quote and buy journey.
___

### Project environments
| Environment        | URL                                  		| HOST  |
| ------------------ | ---------------------------------------------| ----- |
| Local              | localhost:4200                      			| N/A   |
| CI                 | https://ci-web.b4c-dev.dlgdigitalapi.com/   	| AWS   |
| INT                | https://int-web.b4c-qa.dlgdigitalapi.com/   	| AWS   |
| SIT                | https://sit-web.b4c-qa.dlgdigitalapi.com/   	| AWS   |
| E2E                | https://e2e-web.b4c-qa.dlgdigitalapi.com/   	| AWS   |
| UAT                | https://uat-web.b4c-qa.dlgdigitalapi.com/	| AWS   |
| NFT                | https://nft-web.b4c-qa.dlgdigitalapi.com/	| AWS   |
| Staging            | tbc                          				| tbc  
| Production         | tbc                          				| tbc   |

Environment variables can be configured in associated files in ./src/environments/

CI, INT and QA are only accessible when connected to the vpn through pritunl app which can be installed via dlg self service.
___

### Prerequisites
- node (8.9.3)
- npm (5.5.1)
- angular cli (1.7.4)
- nvm (0.33.9) - requires admin access on mac, which the sys eng team can provide temporarily
___

### Instructions: Build setup
In order to install all the required dependencies and libraries for the project run the following commands...

Install dependencies
```
brew install nvm
mkdir ~/.nvm
nano ~/.bash_profile
export NVM_DIR=~/.nvm
source $(brew --prefix nvm)/nvm.sh

### Instructions: Activate NVM

source ~/.bash_profile
echo $NVM_DIR

nvm install 8.9.3

npm install -g @angular/cli@1.7.4

```
Install the application package dependencies
```
npm install

```
Run the site locally
```
ng serve
```

Run the site locally with proxy to make ajax requests to ci environment api's
```
ng serve --proxy-config proxy.conf.json
```
___

### Build commands

The pipeline runs the following command, however this can also be ran on your local machine to see the package which would be deployed:
```
npm run build -- --env=$environment --app=$brand --output-hashing=all --prod
```
$brand: privilege|churchill|directline
$env: ci|qa|prod
___

### Deployment

Instructions for manual CI/QA environment deployments

The jenkins b4c area can be found here - http://dev-jenkins.dev.dlgdigitalapi.com/view/B4C/

To build - http://dev-jenkins.dev.dlgdigitalapi.com/view/B4C/job/B4C-Build/job/ui-build/build?delay=0sec

Then enter/select build parameters required such as brand or environment and click on build.

To deploy - go to http://dev-jenkins.dev.dlgdigitalapi.com/view/B4C/job/B4C-Build/job/ui-build/

Then click on your build from the build history section and then click on "console ouput"

Locate "dockerVersion" parameter and copy this value

Then go to http://dev-jenkins.dev.dlgdigitalapi.com/view/B4C/job/B4C-Deploy/job/ui-deploy/build?delay=0sec

Enter the "dockerVersion" value copied in the previous step into the dockerVersion input field and then click on build

Instructions for auto CI/QA deployments

CI/QA builds will run automatically at 7:20am every day, so any code checked in the previous day will be deployed to those environments.

To trigger this job manually, go to http://dev-jenkins.dev.dlgdigitalapi.com/view/B4C/job/B4C-Auto/job/ui-build-deploy/build?delay=0sec

Then click on the "build" button
___

### Unit tests

Karma is used as the test runner and we use jasmine as the assertion language.

Unit tests can be run with the following command;
```
ng test
```
This will run a watch process, which will run the test when any .ts files are edited.

To generate the code coverage report, run this command;
```
ng test --code-coverage
```
This will generate a folder ./coverage, and the report can be accessed by opening ./coverage/index.html in a browser.

The configuration for the tests can be found in ./karma.config.js.

We currently use chrome as the test browser for local and phantomjs for ci/qa environments.

Tests can be located with a '.spec.ts' suffix throught the application folders.

This test build step should be run automatically as part of the jenkins build and deploy pipleline.
___

### Automated/e2e Tests

We have Page Object Model implemented for UI application automation and use protractor to run the tests, cucumber for BDD features and chai as the assertion language.

Protractor has a dependency on chrome driver, so run the following command to install the latest driver version;
npm run pre-e2e

e2e tests can be run with the following command against your local environment;
npm run e2e:local

And also against specific environmnents
npm run e2e:ci
npm run e2e:qa

or to run just one of the e2e test as a sanity check as part of PR review, please run 
npm run e2e:local:sanity

And sanity, smoke, regression & e2e test suites can also be used to run against the other environments like below;

npm run e2e:int:smoke
npm run e2e:qa:sanity
npm run e2e:sit:regresssion

The configuration for the tests can be found in ./protractor.config.js. This conf file is used to run the tests as part of the jenkins build/deploy  pipeline and the tests will run on remoter browserStack servers.

And for local testing, ./protractordev.config.js configurations will be used which drive the various test suits based on the cucumber feature files and scenarios tags maintained on them.

We currently use chrome as the test browser for all environments.

The feature files can be found in ./src/test/feature
The POM(Page Object  Model) files can be found in ./src/test/pages
The step definitions can be found in ./src/test/step_definitions
___

### Useful information
In this section details are provided on various helpers and methods which have been built to help maintain the site:

#### Build assets for different brands
The static assets for each brand can be found in ./src/assets/<brand-directory>

During the build process, these assets will be exported to the dist folder based on the brand specified in the --app parameter.

To add additional brands, add another section to the ./.angular-cli.json config file.

#### SVG tool
This process will embed svg images inline into the index.html file.

Images within the following folder will be processed ./src/assets/<brand-directory>/icons

Run the following line to process the images.
```
npm run svg -- --app=$brand
```
$brand: privilege|churchill|directline

#### Localhost proxy config
In order to access the ci/qa environment api's on localhost, you will need to be connected to the vpn through pritunl.

This is required to prevent CORS access issues when the app is trying to make cross domain ajax requests.

To use this feature, run the following command;
```
npm run start
```
The configuration for this content can be found in ./proxy.conf.json

#### Typescript linting
To use this feature, run the following command;
```
npm lint
```
The configuration for this can be found in ./tslint.json

#### SASS linting

To use this feature, run the following command;

```bash
npm lint:sass
```

#### BrowserStack Local run

To use this feature, run the following command;

```bash
./browser-stack-binaries/mac-os-binary --key jyqWz2ErhB3GYhM35wKp
```
```bash
npm run e2e:local
```

### Libraries

Run `npm run get:libs` in order to grab the latest versions of the packages below.

* [Wells](https://bitbucket.org/dlgdigitalservices/dlg-wells-css) - 1.0.2
* [Angular Components](https://bitbucket.org/dlgdigitalservices/dlg-angular-components) - 1.0.0

### nvm default version
Run the following command in terminal to default node version to 8.9.3
```
nvm alias default 8.9.3
```
### Jenkins build

In the package.json file swap string 

git+ssh

For string 

https://dlgjenkinsuser:<password>

In the package.json file.

The above credentials are in the Syn Eng 1Password vault.

In order for SSH to work locally, you need to setup a Bitbutcket SSH key, follow this article - 
https://confluence.atlassian.com/bitbucket/set-up-an-ssh-key-728138079.html

### Author

Written by:
**DS UI and DevOps  Engineering team**

Version:
**1.0**
