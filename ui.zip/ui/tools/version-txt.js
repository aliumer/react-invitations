const hcVersionTxt = require('hc-version-txt');

hcVersionTxt.buildFile();