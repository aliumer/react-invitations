const args              = process.argv;
const argBrand          = '--app';
const fs                = require('fs');
const validBrands       = ['privilege', 'churchill', 'directline'];

function getBrand() {
    let argIndex = 0;
    let brand = '';
    let brandRegExp = new RegExp(`${argBrand}=`);

    args.forEach((value, index) => {
        if (value.search(brandRegExp) >=0) {
            argIndex = index;
            process.stdout.write('index found, '+ index);
        }
    });
    brand = args[argIndex].replace(brandRegExp, '');
    return brand;
}

let brand = getBrand();

const isValidBrand = validBrands.some((value) => {
    if (brand.indexOf(value) >= 0) {
        brand = value;
        return true;
    }
});

if (!isValidBrand) {
    return false;
};

const brandDirectory   = 'src/assets/' + brand + '/icons/';

// svg sprite
const svgSpriteStart = '<svg xmlns="http://www.w3.org/2000/svg" style="visibility: hidden; z-index: -1; position: absolute;">';
const svgSpriteEnd = '\n\t</svg>';
let svgSprite = svgSpriteStart;

function readFiles(dirname, symbol, onError) {
    fs.readdir(dirname, function(err, filenames) {
        if (err) {
            onError(err);
            return;
        }

        let itemsProcessed = 0;

        // loop through files
        filenames.forEach(function(filename) {

            // read content from each svg file
            fs.readFile(dirname + filename, 'utf-8', function(error, content) {
                if (error) {
                    onError(error);
                    return;
                }
                // track number of files in directory
                itemsProcessed++;

                // skip over none '.svg' file types
                if (filename.indexOf('.svg') > 0) {

                    // strip file type
                    filename = filename.replace(/.svg/g, '');

                    // clean up svg file
                    content = content.replace(/<title.*?>.*?<\/title>/g, '');
                    content = content.replace(/<svg.*?>.*?/g, '');
                    content = content.replace(/<\/svg>/g, '');
                    content = content.replace(/style="(.*?)"/g, '');
                    content = content.replace(/[ \n\t]+$/, '');

                    // build new symbol with svg path
                    // add in file name as symbol 'ID'
                    const buildSymbol = '\n\t<symbol id="' + filename.toLowerCase() + '" viewBox="0 0 24 24">' + content + '</symbol>';

                    // return svg symbol
                    symbol(buildSymbol);
                }

                // let me know when all files have been processed
                if (itemsProcessed === filenames.length) {
                    // close sprite
                    svgSprite += svgSpriteEnd;

                    writeToIndex();
                }
            });
        });
    });
}

readFiles(brandDirectory, function(svgSymbol) {
    // add svg file contents to new svg sprite
    svgSprite += svgSymbol;
}, function(err) {
    throw err;
});

function writeToIndex() {
    fs.readFile('src/index.html', 'utf-8', function(error, content) {
        if (error) {
            onError(error);
            return;
        }

        content = content.replace(/<svg.*?>(.|\n|\t)*?<\/svg>/, '<!-- INSERT: SVG -->');
        content = content.replace(/<!-- INSERT: SVG -->/, svgSprite);
        fs.writeFile('src/index.html', content, 'utf8', function (error) {
            if (error) return console.error(error);
        });
    });
}
