export class Utils {
    email: string;
    day: number;
    month: number;
    year: number;
    currentDate: Date;
    defaultPolicyStartDate: Date = new Date();

    constructor() {
        this.defaultPolicyStartDate.setDate(this.defaultPolicyStartDate.getDate() + 15);
    }

    setUniqueNewEmail(): string {
        this.email = 'success+' + Math.random().toString(36).substring(3) + '@simulator.amazonses.com';
        return this.email;
    }

    setDay(): number {
        this.day = this.defaultPolicyStartDate.getDate();
        return this.day;
    }

    setMonth(): number {
        this.month = this.defaultPolicyStartDate.getUTCMonth() + 1;
        return this.month;
    }

    setYear(): number {
        this.year = this.defaultPolicyStartDate.getUTCFullYear();
        return this.year;
    }

    cardExpiryYear(): string {
        this.year = this.defaultPolicyStartDate.getUTCFullYear() + 1;
        return this.year.toString().slice(2, 4);
    }

    numberToString(counter: number): string {
        switch (counter) {
            case 1: {
                return 'one';
            }
            case 2: {
                return 'two';
            }
            case 3: {
                return 'three';
            }
            case 4: {
                return 'four';
            }
            case 5: {
                return 'five';
            }
        }
    }

    formatPrices(price: string): number {
        price = price.replace('£', '');
        price = price.replace(',', '');
        price = price.replace(/'/g, '');
        return parseFloat(price);
    }

    roundDownPrice(price: number, decimals: number): number {
        decimals = decimals || 0;
        return ( Math.round( price * Math.pow(10, decimals) ) / Math.pow(10, decimals) );
    }

    getAddOnFormatted(addOn): string {
        switch (addOn) {
            case 'GuaranteedHireCarPlus': {
                return 'Guaranteed Hire Car Plus';
            }
            case 'LegalCover': {
                return 'Motor Legal Cover';
            }
            case 'ProtectedNoClaimDiscount': {
                return 'Protected No Claim Discount';
            }
            case 'FullUK': {
                return 'Breakdown Cover';
            }
            case 'RoadsideHome': {
                return 'Breakdown Cover';
            }
            case 'euroBreakDownCover-Yes' || 'euroBreakDownCover-No': {
                return 'European Breakdown Cover';
            }
            default: {
                return addOn;
            }
        }
    }
}
