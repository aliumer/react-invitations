// Global variables, getters & setters to control the flow of end2end test scenarios

let driverCount = 0;
let premiumCompPrice = 0.00;
let premiumCompPlusPrice = 0.00;
let premiumTpftPrice = 0.00;
let premiumDriveXpertPrice = 0.00;
let expectedPremiumPrice = 0.00;
let firstName = '';
let lastName = '';
let edit = false;
let submission = false;
let selectedPremiumType = '';
let isCompPresent = false;
let isCompPlusPresent = false;
let isTpftPresent = false;
let isdrivexpertPresent = false;
let indicativeQuote = false;
let addOnOperation = false;
let isYearlyPayment = false;
let cardHolderName = '';
let policyHolderAge = 0;

export const incrementDriverCount = () => driverCount++;
export const getDriverCount = () => (driverCount);

export const setEdit = () => (edit = true);
export const getEdit = () => (edit);

export const setIndicativeQuote = () => (indicativeQuote = true);
export const isIndicative = () => (indicativeQuote);

export const setIsYearlyPayment = () => (isYearlyPayment = true);
export const getIsYearlyPayment = () => (isYearlyPayment);

export const setSubmission = () => (submission = true);
export const getSubmission = () => (submission);

export const setPolicyHolderAge = (age: number) => (policyHolderAge = age);
export const getPolicyHolderAge = () => (policyHolderAge);

export const setAddOnOperation = (flag: boolean) => (addOnOperation = flag);
export const getAddOnOperation = () => (addOnOperation);

export const setPremiumCompPrice = (price: number) => (premiumCompPrice = price);
export const getPremiumCompPrice = () => (premiumCompPrice);

export const setPremiumCompPlusPrice = (price: number) => (premiumCompPlusPrice = price);
export const getPremiumCompPlusPrice = () => (premiumCompPlusPrice);

export const setExpectedPremiumPrice = (price: number) => (expectedPremiumPrice = price);
export const getExpectedPremiumPrice = () => (expectedPremiumPrice);

export const setPremiumTpftPrice = (price: number) => (premiumTpftPrice = price);
export const getPremiumTpftPrice = () => (premiumTpftPrice);

export const setDriveXpertPrice = (price: number) => (premiumDriveXpertPrice = price);
export const getDriveXpertPrice = () => (premiumDriveXpertPrice);

export const getFirstName = () => (firstName);
export const getSurname = () => (lastName);

export const setFirstName = (fName: string) => (firstName = fName);
export const setSurname = (lName: string) => (lastName = lName);

export const setSelectedPremiumType = (premiumType: string) => (selectedPremiumType = premiumType);
export const getSelectedPremiumType = () => (selectedPremiumType);

export const setIsCompPresent = (comp: boolean) => (isCompPresent = comp);
export const getIsCompPresent = () => (isCompPresent);

export const setIsCompPlusPresent = (comp: boolean) => (isCompPlusPresent = comp);
export const getIsCompPlusPresent = () => (isCompPlusPresent);

export const setIsTpftPresent = (tpft: boolean) => (isTpftPresent = tpft);
export const getIsTpftPresent = () => (isTpftPresent);

export const setIsdrivexpertPresent = (telematics: boolean) => (isdrivexpertPresent = telematics);
export const getIsdrivexpertPresent = () => (isdrivexpertPresent);

export const setCardHolderName = (fName: string, sName: string) => (cardHolderName = (fName + ' ' + sName));
export const getCardHolderName = () => (cardHolderName);

export const resetGlobals = () => (
    driverCount = 0,
    premiumCompPrice = 0.00,
    premiumCompPlusPrice = 0.00,
    premiumTpftPrice = 0.00,
    premiumDriveXpertPrice = 0.00,
    expectedPremiumPrice = 0.00,
    policyHolderAge = 0,
    firstName = '',
    lastName = '',
    selectedPremiumType = '',
    cardHolderName = '',
    edit = false,
    submission = false,
    isCompPresent = false,
    isCompPlusPresent = false,
    isdrivexpertPresent = false,
    isYearlyPayment = false,
    isTpftPresent = false,
    indicativeQuote = false,
    addOnOperation = false
);
