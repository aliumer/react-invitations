import { Given, When} from 'cucumber';
import { expect } from 'chai';
import { browser, by, element, ExpectedConditions } from 'protractor';
import {BasePage} from '../../pages/base-page';

const basePage = new BasePage;
const EC = ExpectedConditions;

Given(/^I go to "([^"]*)"$/, async (site: string) => {
    await browser.get(browser.baseUrl + site);
    await browser.waitForAngularEnabled(true);
    expect(await browser.wait(EC.elementToBeClickable(element(by.css('.cookie__close'))), 6000, 'Sorry, timed out. Cookie info banner is not displayed..')).to.equal(true);
    await element(by.css('.cookie__close')).click();
    });

When(/^I move back to the previous page$/, async () => {
        await basePage.navigateBack();
    });

When(/^I move to the next page$/, async () => {
        await basePage.navigateNext();
    });
