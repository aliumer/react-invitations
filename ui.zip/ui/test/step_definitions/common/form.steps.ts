import { Then, When } from 'cucumber';
import { browser, by, element, ExpectedConditions } from 'protractor';
const fs = require('fs');
const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;
const EC = ExpectedConditions;
const elementWait = 10000;

function writeScreenShot(data, filename) {

    const stream = fs.createWriteStream(filename);

    stream.write(new Buffer(data, 'base64'));
    stream.end();
}

When(/^I select "([^"]*)" in the "([^"]*)" field$/, async (answer: string, field: string) => {
    const fieldName = field;
    await browser.wait(EC.presenceOf(element(by.id(field))), elementWait);
    await element(by.id(fieldName)).element(by.xpath('.//*[.="' + answer + '"]')).click();
});

When(/^I check the "([^"]*)" checkbox/, async (field: string) => {
    await browser.wait(EC.presenceOf(element(by.id(field))), elementWait);
    await element(by.css('label[for="' + field + '"]')).click();
});

Then(/^display a form field "([^"]*)" with value "([^"]*)"$/, async (field: string, value: string) => {
    await browser.wait(EC.presenceOf(element(by.id(field))), elementWait);
    const inputValue = await element(by.id(field));
    expect(await inputValue.getAttribute('value')).to.equal(value);
});

Then(/^display a form field "([^"]*)" with option selected value "([^"]*)"$/, async (field: string, value: any) => {
    await browser.wait(EC.presenceOf(element(by.id(field))), elementWait);
    const selectedValue = await element(by.id(field)).$('option:checked').getText();
    expect(selectedValue).to.equal(value);
});

Then(/^display a tick in checkbox "([^"]*)" with value "([^"]*)"$/, async (field: string, value: string) => {
    await browser.wait(EC.presenceOf(element(by.id(field))), elementWait);
    const inputValue = await element(by.id(field));
    await expect(await inputValue.isSelected()).to.be.true;
});

Then(/^display an element "([^"]*)" with text "([^"]*)"$/, async (field: string, value: string) => {
    await browser.wait(EC.presenceOf(element(by.id(field))), elementWait);
    await expect(await element(by.id(field)).getText()).to.equal(value);
});

Then(/^display an element of class "([^"]*)" with text "([^"]*)"$/, async (field: string, value: string) => {
    await browser.waitForAngular();
    await browser.wait(EC.presenceOf(element(by.className(field))), elementWait);
    await expect(await element(by.cssContainingText(`.${field}`, value)).isPresent()).to.equal(true);
});

Then(/^do not display an element of class "([^"]*)" with text "([^"]*)"$/, async (field: string, value: string) => {
    await browser.waitForAngular();
    await expect(await element(by.cssContainingText(`.${field}`, value)).isPresent()).to.equal(false);
});

Then('I hide the {string} field', async (field: string) => {
    const isDisplayed = await element(by.id(field)).isDisplayed();
    expect(isDisplayed).to.equal(false);
});

Then('I disable the {string} field', async (field: string) => {
    const enabled = await element(by.id(field)).isEnabled();
    expect(enabled).to.equal(false);
});

Then('I enable the {string} field', async (field: string) => {
    const enabled = await element(by.id(field)).isEnabled();
    expect(enabled).to.equal(true);
});

Then('I do not display any field validation error on the page', async() => {
    const elementExists = await element(by.className('dlg-field__error')).isPresent();
    expect(await elementExists).to.equal(false);
});

When(/^I click the element of class "([^"]*)"$/, async (field: string) => {
    await browser.wait(EC.presenceOf(element(by.className(field))), elementWait);
    await element(by.className(field)).click();
});

