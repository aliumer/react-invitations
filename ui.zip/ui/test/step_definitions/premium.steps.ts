import { Then, When } from 'cucumber';
import { PremiumPage } from '../pages/premium-page';
import { BasePage } from '../pages/base-page';
import { YourCarPage } from '../pages/your-car-page';
import { PolicyDetailsPage } from '../pages/policy-details-page';
import { YourDetailsPage } from '../pages/your-details-page';
import { YourDrivingHistoryPage } from '../pages/your-driving-history-page';
import { DiscountsPage } from '../pages/discounts-page';
const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;
const premiumPage = new PremiumPage();
const basePage = new BasePage();
const yourCarPage = new YourCarPage;
const policyDetailsPage = new PolicyDetailsPage;
const yourDetailsPage = new YourDetailsPage;
const yourDrivingHistoryPage = new YourDrivingHistoryPage;
const discountsPage = new DiscountsPage;

Then(/^I should see premium page with personal greeting and appropriate quote details displayed$/, async () => {
    await basePage.checkURLfterPremium('premium');
    await premiumPage.verifyDisplayOfDifferentQuotesOnPremiumPage();
    await premiumPage.verifyPersonalGreeting();
});

Then(/^I should see the (.*) correctly applied on the premium page$/, async (promoCode: string) => {
    await premiumPage.verifyDisplayOfPromoCode(promoCode);
});

Then(/^it should display information regarding the indicative quote$/, async () => {
    await premiumPage.displayIndicativeQuoteWarning();
});

When(/^I (.*) (.*) add on$/, async (action: string, addOn: string) => {
    await premiumPage.closeChat();
    await premiumPage.addOrRemoveAddOn(action, addOn);
});

Then(/^I should see the premium total and summary updated after (.*)$/, async (action: string) => {
    await premiumPage.verifyPremiumPricesAfterAddOnOperation(action);
});

When(/^I generate quote with (.*), (.*), (.*), (.*) and land on premium page$/, async(vehicleDetails, yourDetails, drivingDetails, ncdYears) => {
    const vehicleInfo = vehicleDetails.split(',');
    const yourInfo = yourDetails.split(',');
    const drivingInfo = drivingDetails.split(',');
    await yourCarPage.checkPageTitle('Your car');
    await yourCarPage.vehicleLookup(vehicleInfo[0]);
    await yourCarPage.addVehicleDetailsWithNoModeAndPurchaseDate(vehicleInfo[1]);
    await yourCarPage.navigateNext();
    await yourDetailsPage.checkPageTitle('All about you');
    await yourDetailsPage.addPersonalDetails(yourInfo[0], yourInfo[1], yourInfo[2], yourInfo[3], yourInfo[4], yourInfo[5], yourInfo[6], yourInfo[7], yourInfo[8], yourInfo[9]);
    await yourDetailsPage.navigateNext();
    await yourDetailsPage.checkPageTitle('Driver details');
    await yourDrivingHistoryPage.addDrivingHistoryWithConvictionsAndClaims(drivingInfo[0], drivingInfo[1], drivingInfo[2]);
    await yourDrivingHistoryPage.addAdditionalDriversNoConvictionAndClaims(drivingInfo[2], yourInfo[4], drivingInfo[4]);
    await yourDrivingHistoryPage.addAdditionalDriverWithConvictionAndClaims(drivingInfo[3], drivingInfo[5], drivingInfo[6], yourInfo[3], drivingInfo[4]);
    await yourDrivingHistoryPage.navigateNext();
    await discountsPage.checkPageTitle('Driving and discounts');
    await discountsPage.addDiscountDetails();
    await discountsPage.checkAndSetNCDDriverNames();
    await discountsPage.verifyAndSetNCDYearsAndMonths(ncdYears);
    await discountsPage.navigateNext();
    await policyDetailsPage.checkPageTitle('Almost there');
    await policyDetailsPage.addPolicyDetails();
    await policyDetailsPage.captchaCheck();
    await policyDetailsPage.getQuote();
    await policyDetailsPage.checkURLfterPremium('/premium');
});

Then(/^I should land on the premium page$/, async () => {
    await premiumPage.verifyPersonalGreeting();
});

Then(/^there should be no option to move to Review & Confirm page$/, async () => {
    await expect(await basePage.continueButton.isPresent()).to.be.false;
});

Then(/^I should land on vehicle details page on clicking Amend my details$/, async () => {
    await premiumPage.amendVehicleDetails();
});

When(/^I choose to amend the vehicle details$/, async () => {
    await premiumPage.amendVehicleDetails();
});

Then(/^I should see correct excess details being diaplyed for all users after selecting (.*)$/, async (volExcess: number) => {
    await premiumPage.verifyExcessNamesAndPrices(volExcess);
});

When(/^I change the Voluntary Excess$/, async () => {
    await premiumPage.changeExcess();
});

Then(/^I should be able to select the (.*)$/, async (premiumType: string) => {
    await premiumPage.selectRequiredPremium(premiumType);
});


