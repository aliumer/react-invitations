import {When, Then} from 'cucumber';
import {YourCarPage} from '../pages/your-car-page';
import {BasePage} from '../pages/base-page';
const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;
const yourCarPage = new YourCarPage;
const basePage = new BasePage;

When(/^I fill in the vehicle details for (.*),(.*) and continue$/, async (carReg: string, regKeeper: string) => {
    await yourCarPage.checkPageTitle('Your car');
    await yourCarPage.vehicleLookup(carReg.trim());
    await yourCarPage.addVehicleDetailsWithNoModeAndPurchaseDate(regKeeper.trim());
    await yourCarPage.navigateNext();
    await yourCarPage.checkPageTitle('about you');
});

When(/^I fill in the vehicle details for (.*) and (.*) with no purchase date and continue$/, async (carReg: string, regKeeper: string) => {
    await yourCarPage.checkPageTitle('Your car');
    await yourCarPage.vehicleLookup(carReg.trim());
    await yourCarPage.addVehicleDetailsWithNoModeAndNoPurchaseDate(regKeeper.trim());
    await yourCarPage.navigateNext();
    await yourCarPage.checkPageTitle('about you');
});

When(/^I fill in the vehicle details for (.*) and (.*) with all options and continue$/, async (carReg: string, regKeeper: string) => {
    await yourCarPage.checkPageTitle('Your car');
    await yourCarPage.vehicleLookup(carReg.trim());
    await yourCarPage.addVehicleDetailsWithModeAndPurchaseDate(regKeeper.trim());
    await yourCarPage.navigateNext();
    await yourCarPage.checkPageTitle('about you');
});

Then(/^I should land on the vehicle details page$/, async () => {
    await yourCarPage.checkPageTitle('Your car');
});

When(/^I modify the vehicle details and continue$/, async () => {
    await yourCarPage.changeCarMileage();
    await yourCarPage.navigateNext();
    await yourCarPage.checkPageTitle('about you');
});


When(/^I do a manual vehicle search to select a car and continue$/, async () => {
    await yourCarPage.vehicleManualSearch();
    await yourCarPage.navigateNext();
    await yourCarPage.checkPageTitle('about you');
});

When(/^I do a manual vehicle search with no purchase date and continue$/, async () => {
    await yourCarPage.vehicleManualSearch();
    await yourCarPage.addNoPurchaseDetails();
    await yourCarPage.navigateNext();
    await yourCarPage.checkPageTitle('about you');
});

When(/^I change the vehicle by a (.*) vehicle lookup and review other details$/, async (newCarReg: string) => {
    await yourCarPage.vehicleLookup(newCarReg.trim());
    await yourCarPage.navigateNext();
    await basePage.checkPageTitle('about you');
    await basePage.navigateNext();
    await basePage.checkPageTitle('Driver details');
    await basePage.navigateNext();
    await basePage.checkPageTitle('Driving and discounts');
    await basePage.navigateNext();
});

When(/^I change the vehicle by manual search$/, async () => {
    await basePage.checkPageError();
    await yourCarPage.vehicleManualSearch();
    await yourCarPage.navigateNext();
    await expect (await basePage.checkPageTitle('about you'));
    await basePage.navigateNext();
    await expect (await basePage.checkPageTitle('Driver details'));
    await basePage.navigateNext();
    await expect (await basePage.checkPageTitle('Driving and discounts'));
    await basePage.navigateNext();
});
