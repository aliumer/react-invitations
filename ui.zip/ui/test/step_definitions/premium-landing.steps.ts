import { Then } from 'cucumber';
import { PremiumLandingPage } from '../pages/premium-landing-page';
import {setSelectedPremiumType, getIsCompPresent, getIsTpftPresent, getEdit, isIndicative, getPremiumCompPlusPrice, setExpectedPremiumPrice, getPremiumCompPrice} from '../utils/globals';
import { PremiumPage } from '../pages/premium-page';
const premiumPage = new PremiumPage();
const premiumLandingPage = new PremiumLandingPage();
let isCompPlusPresent = false;
let isInterstitial = false;

Then(/^I select the Third party fire & theft policy option$/, async () => {
    if (isCompPlusPresent) {
        await premiumLandingPage.selectTPFTPolicy();
    }
});

Then(/^I should see the quote declined page and message$/, async () => {
    await premiumLandingPage.checkURL('declined');
});

Then(/^I should see the premium interstitial page if CompPlus is offered$/, async () => {
    if (!getEdit() || !isIndicative()) {
        isInterstitial = await premiumLandingPage.isInterstitialPageDisplayed();
        if (isInterstitial) {
            await premiumLandingPage.checkURLfterPremium('quote/premium');
            isCompPlusPresent = await premiumPage.getPremiumBrowserSessionDetails();
            await premiumLandingPage.verifyGreeting();
            await premiumLandingPage.verifyOfferings();
        }
    }
});

Then(/^I select the (.*) option if applicable$/, async (premiumType: string) => {
    if (isInterstitial) {
        if (isCompPlusPresent && premiumType === 'ComprehensivePlus') {
            setSelectedPremiumType('compplus');
            setExpectedPremiumPrice(getPremiumCompPlusPrice());
            await premiumLandingPage.selectCompPlusPolicy();
        } else if (isCompPlusPresent && premiumType === 'Comprehensive') {
            setSelectedPremiumType('comp');
            setExpectedPremiumPrice(getPremiumCompPrice());
            await premiumLandingPage.selectCompPolicy();
        } else if (isCompPlusPresent && premiumType === 'TPFT') {
            setSelectedPremiumType('TPFT');
            await premiumLandingPage.selectTPFTPolicy();
        } else if (!(isCompPlusPresent) && getIsCompPresent()) {
            setSelectedPremiumType('comp');
        } else if (!(isCompPlusPresent) && !getIsCompPresent() && getIsTpftPresent()) {
            setSelectedPremiumType('tpft');
        }
    }
});
