import {When } from 'cucumber';
import {YourDetailsPage} from '../pages/your-details-page';
const yourDetailsPage = new YourDetailsPage;

When(/^I fill in the personal details with (.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*) and continue$/, async (fName, sName, DOB: string, relStatus, empStatus, jobTitle, mobNumber, userType, email, postCode) => {
    await yourDetailsPage.addPersonalDetails(fName, sName, DOB, relStatus, empStatus, jobTitle, mobNumber, userType, email, postCode);
    await yourDetailsPage.navigateNext();
    await yourDetailsPage.checkPageTitle('Driver details');
});

When(/^I review the personal details and continue$/, async () => {
    await yourDetailsPage.navigateNext();
    await yourDetailsPage.checkPageTitle('Driver details');
});

When(/^I should land on the personal details page$/, async () => {
    await yourDetailsPage.checkPageTitle('All about you');
});

When(/^I modify the personal details and continue$/, async () => {
    await yourDetailsPage.changeYourDetails();
    await yourDetailsPage.navigateNext();
    await yourDetailsPage.checkPageTitle('Driver details');
});
