import { Then } from 'cucumber';
import { ConfirmationPage } from '../pages/confirmation-page';

const confirmationPage = new ConfirmationPage;

Then(/^I should see the Policy Purchase confiramtion details$/, async () => {
    await confirmationPage.checkURLfterPremium('/confirm');
    await confirmationPage.checkPolicyDetails();
});
