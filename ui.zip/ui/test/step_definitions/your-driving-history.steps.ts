import { When } from 'cucumber';
import {YourDrivingHistoryPage} from '../pages/your-driving-history-page';

const yourDrivingHistoryPage = new YourDrivingHistoryPage;

When(/^I fill in the driving history with (.*), (.*) convictions and (.*) claims$/, async (livedSince: string, noOfConvictions: number, noOfClaims: number) => {
    await yourDrivingHistoryPage.addDrivingHistoryWithConvictionsAndClaims(livedSince.trim(), noOfConvictions, noOfClaims);
});

When(/^I add (.*) drivers with no convictions and claims where policy holder is (.*) and aged (.*)$/, async (noOfDriversWithNoClaims: number, relationshipStatus, driverAge: number) => {
    await yourDrivingHistoryPage.addAdditionalDriversNoConvictionAndClaims(noOfDriversWithNoClaims, relationshipStatus, driverAge);
});

When(/^I add (.*) drivers with (.*) convictions and (.*) claims where policy holder is (.*) and aged (.*)$/, async (noOfDriversWithClaims: number, noOfConvictions: number, noOfClaims: number, relationshipStatus, driverAge: number) => {
    await yourDrivingHistoryPage.addAdditionalDriverWithConvictionAndClaims(noOfDriversWithClaims, noOfConvictions, noOfClaims, relationshipStatus, driverAge);
});

When(/^I review driving history details and continue$/, async () => {
    await yourDrivingHistoryPage.navigateNext();
});

When(/^I should land on the driving details page$/, async () => {
    await yourDrivingHistoryPage.checkPageTitle('Driver details');
});

When(/^I modify the driving details and continue$/, async () => {
    await yourDrivingHistoryPage.changeDrivingDetails();
    await yourDrivingHistoryPage.navigateNext();
    await yourDrivingHistoryPage.checkPageTitle('Driving and discounts');
});

When(/^I should see the license held years field reflects (.*) and (.*)$/, async (policyHolderAge: number, driverAge: number) => {
    await yourDrivingHistoryPage.checkAndSetLicenseHeldYearsForPolicyHolder(policyHolderAge);
    await yourDrivingHistoryPage.checkAndSetLicenseHeldYearsForDrivers(driverAge, 0, 'verifyDrivers');
});
