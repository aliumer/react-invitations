import { When } from 'cucumber';
import { ReviewPage } from '../pages/review-page';
import {setEdit} from '../utils/globals';

const reviewPage = new ReviewPage;

When(/^I move on to the Review & Confirm page and continue$/, async () => {
    await reviewPage.navigateNext();
    await reviewPage.checkPageTitle('Final check');
    await reviewPage.confirmDetailsAndMakePayment();
    await reviewPage.checkPageTitle('How to pay');
    await reviewPage.checkURLfterPremium('/payment');
});

When(/^I move on to the Review page and choose to edit the (.*) details$/, async (Feature: string) => {
    await reviewPage.navigateNext();
    await reviewPage.checkPageTitle('Final check');
    await setEdit();
    await reviewPage.editJourney(Feature);
});

When(/^I move on to the Review & Confirm page and choose to buy the policy$/, async () => {
    await reviewPage.navigateNext();
    await reviewPage.checkPageTitle('Final check');
    await reviewPage.checkURLfterPremium('/review');
    await reviewPage.confirmDetailsAndMakePayment();
});
