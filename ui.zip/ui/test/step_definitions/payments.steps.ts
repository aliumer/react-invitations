import { Then } from 'cucumber';
import { PaymentsPage } from '../pages/payments-page';

const paymentsPage = new PaymentsPage;

Then(/^I should land on the Payment page which displays correct premium amount$/, async () => {
    await paymentsPage.checkURLfterPremium('/payments');
    await paymentsPage.verifyPremiumPricesOnPayment();
});

Then(/^I should be able to make (.*) payment with (.*) card, (.*),(.*),(.*),(.*),(.*),(.*) and (.*) address on (.*) and (.*)$/, async (paymentType, cardOwnership, sortCode, accountNumber, cardType, cardNumber: number, cardHolderName, cvc, billingAddressType, billingAddress, autoRenewal) => {
    await paymentsPage.makePayment(paymentType, cardOwnership, sortCode, accountNumber, cardType, cardNumber, cardHolderName, cvc, billingAddressType, billingAddress, autoRenewal);
});

Then(/^I should be able to make payment with (.*)$/, async (paymentDetails) => {
    const paymentInfo = paymentDetails.split(',');
    await paymentsPage.makePayment(paymentInfo[0], paymentInfo[1], paymentInfo[2], paymentInfo[3], paymentInfo[4], paymentInfo[5], paymentInfo[6], paymentInfo[7], paymentInfo[8], paymentInfo[9], paymentInfo[10]);
});

Then(/^I set the auto renewal option (.*)$/, async (autoRenew: string) => {
    await paymentsPage.setAutoRenewal(autoRenew);
});
