var { setDefaultTimeout } = require('cucumber');

setDefaultTimeout(240 * 1000);