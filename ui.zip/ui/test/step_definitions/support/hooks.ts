import { browser } from 'protractor';
import { resetGlobals } from '../../utils/globals';

const { Before, After, AfterAll, Status} = require('cucumber');

AfterAll({timeout: 240 * 1000}, async () => {
    await browser.quit();
});

Before({timeout: 240 * 1000}, async (scenario) => {
    let realMobile = false;
    const configData = await browser.getProcessedConfig();
    realMobile = configData.capabilities.real_mobile;
    if (realMobile) {
        console.log('Device Name : ' + configData.capabilities.device);
        } else {
            await browser.driver.manage().window().maximize();
        }
    console.log('Starting the scenario : ' + scenario.pickle.name);
    console.log('Browser : ' + configData.capabilities.browserName);
    console.log('When : ' + Date());
    console.log('****************************');
});

After({timeout: 240 * 1000}, async () => {
    resetGlobals();
    await browser.executeScript('window.sessionStorage.clear();');
    await browser.executeScript('window.localStorage.clear();');
    await browser.driver.manage().deleteAllCookies();
    console.log('End of test scenario..');
    console.log('****************************');
});

After(async function(scenario) {
    if (scenario.result.status === Status.FAILED) {
        // screenShot is a base-64 encoded PNG
         const screenShot = await browser.takeScreenshot();
         this.attach(screenShot, 'image/png');
    }
});
