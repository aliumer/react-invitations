import { When, Then } from 'cucumber';
import { DiscountsPage } from '../pages/discounts-page';
import { getEdit } from '../utils/globals';

const discountsPage = new DiscountsPage;

When(/^I fill in the discount details with a different parking location$/, async () => {
    await discountsPage.addWhereYouParkYourCarDetails();
});

When(/^I fill in details on the discount page$/, async () => {
    await discountsPage.addDiscountDetails();
});

Then(/^Based on their relationship, I should see Main and NCD driver names on discount page$/, async () => {
    await discountsPage.checkAndSetNCDDriverNames();
});

Then(/^I should see appropriate NCD Years and Months displayed based on driver age before selecting (.*) and continue$/, async (ncdYears: string) => {
    if (!getEdit()) {
        await discountsPage.verifyAndSetNCDYearsAndMonths(ncdYears);
     }
    await discountsPage.navigateNext();
});

When(/^I should land on the discount details page$/, async () => {
    await discountsPage.checkPageTitle('Driving and discounts');
});

When(/^I modify the discount details and continue$/, async () => {
    await discountsPage.changeDiscountDetails();
    await discountsPage.navigateNext();
    await discountsPage.checkPageTitle('Almost there...');
});

When(/^I should see NCD options reflects license held years for policy holder and additional driver$/, async () => {
    await discountsPage.checkPageTitle('Driving and discounts');
});

