import { Then, When } from 'cucumber';
import { PolicyDetailsPage } from '../pages/policy-details-page';
import { BasePage } from '../pages/base-page';
import { YourCarPage } from '../pages/your-car-page';
const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;
const policyDetailsPage = new PolicyDetailsPage();
const basePage = new BasePage;
const yourCarPage = new YourCarPage;


When(/^I fill in the policy details$/, async () => {
    await policyDetailsPage.checkPageTitle('Almost there');
    await policyDetailsPage.addPolicyDetails();
    await policyDetailsPage.captchaCheck();
});

When(/^I enter a (.*)$/, async (promoCode: string) => {
    await policyDetailsPage.applyPromoCode(promoCode);
});

When(/^I fill in the policy details with all options$/, async () => {
    await policyDetailsPage.checkPageTitle('Almost there');
    await policyDetailsPage.addPolicyDetailsExtra();
    await policyDetailsPage.captchaCheck();
});

When(/^I fill in the policy details with declined policy$/, async () => {
    await policyDetailsPage.checkPageTitle('Almost there');
    await policyDetailsPage.addPolicyDetailsExtra();
    await policyDetailsPage.cancelledPolicyYes();
    await policyDetailsPage.captchaCheck();
});

Then(/^I should land on policy details page$/, async () => {
    await policyDetailsPage.checkPageTitle('Almost there');
});

When(/^I review the policy details$/, async () => {
    await policyDetailsPage.checkPageTitle('Almost there');
    await policyDetailsPage.checkConfirmation();
    await policyDetailsPage.captchaCheck();
});

When(/^I click on the Get quote button$/, async () => {
    // *If you want to stop the browser from completing the test and manually click the 'get Quote' button, uncomment the below step and exceute the test command : "npm run e2e:local:sanity"
    // process.abort();
    await policyDetailsPage.getQuote();
});

When(/^I go back and change the vehicle by a new vehicle lookup$/, async () => {
    await basePage.navigateBack();
    await expect (basePage.checkPageTitle('Driving and discounts'));
    await basePage.navigateBack();
    await expect (basePage.checkPageTitle('Driver details'));
    await basePage.navigateBack();
    await expect (basePage.checkPageTitle('All about you'));
    await basePage.navigateBack();
    await expect (basePage.checkPageTitle('Your car'));
    await yourCarPage.vehicleLookup('KW18NLZ');
    await yourCarPage.navigateNext();
    await expect (basePage.checkPageTitle('All about you'));
    await basePage.navigateNext();
    await expect (basePage.checkPageTitle('Driver details'));
    await basePage.navigateNext();
    await expect (basePage.checkPageTitle('Driving and discounts'));
    await basePage.navigateNext();
    await policyDetailsPage.checkPageTitle('Almost there');
});

When(/^I change the vehicle by manual search$/, async () => {
    await basePage.navigateBack();
    await expect (basePage.checkPageTitle('Driving and discounts'));
    await basePage.navigateBack();
    await expect (basePage.checkPageTitle('Driver details'));
    await basePage.navigateBack();
    await expect (basePage.checkPageTitle('All about you'));
    await basePage.navigateBack();
    await expect (basePage.checkPageTitle('Your car'));
    await basePage.checkPageError();
    await yourCarPage.vehicleManualSearch();
    await yourCarPage.navigateNext();
    await expect (basePage.checkPageTitle('All about you'));
    await basePage.navigateNext();
    await expect (basePage.checkPageTitle('Driver details'));
    await basePage.navigateNext();
    await expect (basePage.checkPageTitle('Driving and discounts'));
    await basePage.navigateNext();
    await policyDetailsPage.checkPageTitle('Almost there');
});
