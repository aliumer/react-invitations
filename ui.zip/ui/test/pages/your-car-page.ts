import { by, element, ExpectedConditions } from 'protractor';
import { Utils } from '../utils/utils';
import { BasePage } from './base-page';
const EC = ExpectedConditions;
const utils = new Utils;

export class YourCarPage extends BasePage {

    private vrnInput = element(by.id('regSearch'));
    private findButton = element(by.id('find-reg'));
    private isVehicleModifiedNo = element(by.css('label[for="' + 'vehicleModified-No' + '"]'));
    private isVehicleModifiedYes = element(by.css('label[for="' + 'vehicleModified-Yes' + '"]'));
    private isVehiclePurchasedYes = element(by.css('label[for="' + 'vehiclePurchased-Yes' + '"]'));
    private isVehiclePurchasedNo = element(by.css('label[for="' + 'vehiclePurchased-No' + '"]'));
    private purchasedMonth = element(by.id('vehiclePurchasedDate-month'));
    private purchasedYear = element(by.id('vehiclePurchasedDate-year'));
    private mileage = element(by.id('mileage'));
    private registeredKeeper = element(by.id('registeredKeeper'));
    private policyStartDateDay = element(by.id('policyStartDate-day'));
    private policyStartDateMonth = element(by.id('policyStartDate-month'));
    private policyStartDateYear = element(by.id('policyStartDate-year'));
    private manualEntryButton = element(by.id('enterManually'));
    private makeList = element(by.id('make'));
    private modelList = element(by.id('model'));
    private manufactureYear = element(by.id('manufactureYear'));
    private fuelType = element(by.id('fuelType'));
    private vehicleVariant = element(by.id('vehicleVariant'));
    private engineSize = element(by.id('engineSize'));
    private numberOfDoors4 = element(by.css('label[for="' + 'numberOfDoors-4' + '"]'));
    private bodyType = element(by.id('bodyType'));
    private transmissionManual = element(by.css('label[for="' + 'transmissionType-MANUAL' + '"]'));
    private carValue = element(by.id('carValue'));
    private notYourCar = element(by.id('regKnown-No'));
    private accessoriesModCategory = element(by.id('accessories-list'));
    private accessoriesSaveButton = element(by.id('accessories-save'));
    private engineModCategory = element(by.id('enginesNtransmission-list'));
    private engineSaveButton = element(by.id('enginesNtransmission-save'));
    private accessoriesModOne = element(by.css('label[for="' + 'accessories-A Frame - For Towing' + '"]'));
    private accessoriesModTwo = element(by.css('label[for="' + 'accessories-Bicycle Rack' + '"]'));
    private accessoriesModThree = element(by.css('label[for="' + 'accessories-Dog Cage/Dog Guard (securely fastened)' + '"]'));
    private accessoriesModFour = element(by.css('label[for="' + 'accessories-Wheel Trims' + '"]'));
    private engineModOne = element(by.css('label[for="' + 'enginesNtransmission-Air Filter' + '"]'));
    private engineModTwo = element(by.css('label[for="' + 'enginesNtransmission-Balanced & Lightened Flywheel' + '"]'));
    private engineModThree = element(by.css('label[for="' + 'enginesNtransmission-Blue Printed' + '"]'));
    private engineModFour = element(by.css('label[for="' + 'enginesNtransmission-Engine Chip (11-25% inc BHP)' + '"]'));
    private lightModTwo = element(by.id('L4'));
    private modPanelList = element.all(by.css('.accordion__title'));

    async selectLightModes() {
        const modCount = await this.modPanelList.count();
        for (let i = 0; i < modCount; i++) {
            const modText = await this.modPanelList.get(i).getText();
            if (modText === 'Lights') {
                await this.modPanelList.get(i).click();
                await this.elementAction('click', this.lightModTwo);
            }
        }
    }

    async vehicleLookup(vrn?: string) {
        const isElementPresent = await this.notYourCar.isPresent();
        if (isElementPresent) {
            await this.elementAction('click', this.notYourCar);
        }
        if (!await this.vrnInput.isPresent()) {
            this.vrnInput = element(by.id('reg'));
        }
        await this.elementAction('sendKeys', this.vrnInput, vrn);
        await this.elementAction('click', this.findButton);
    }

    async addVehicleDetailsWithNoModeAndNoPurchaseDate(regKeeper) {
        await this.elementAction('click', this.isVehicleModifiedNo);
        await this.elementAction('click', this.isVehiclePurchasedNo);
        await this.addVehicleBasicDetails(regKeeper);
    }

    async addVehicleDetailsWithNoModeAndPurchaseDate(regKeeper) {
        await this.elementAction('click', this.isVehicleModifiedNo);
        await this.addPurchaseDetails();
        await this.addVehicleBasicDetails(regKeeper);
    }

    async addVehicleDetailsWithModeAndPurchaseDate(regKeeper) {
        await this.elementAction('click', this.isVehicleModifiedYes);
        await this.selectLightModes();
        await this.addPurchaseDetails();
        await this.addVehicleBasicDetails(regKeeper);
    }

    async addVehicleBasicDetails(regKeeper) {
        const isElementPresent = await this.carValue.isPresent();
        if (isElementPresent) {
            await this.elementAction('sendKeys', this.carValue, '10000');
        }
        await this.elementAction('sendKeys', this.mileage, '10000');
        await this.elementAction('selectByXpath', this.registeredKeeper, regKeeper);
        await this.elementAction('sendKeys', this.policyStartDateDay, utils.setDay());
        await this.elementAction('sendKeys', this.policyStartDateMonth, utils.setMonth());
        await this.elementAction('sendKeys', this.policyStartDateYear, utils.setYear());
    }

    async vehicleManualSearch() {
        const isElementPresent = await this.notYourCar.isPresent();
        if (isElementPresent) { // To do manual search on an edit journey
            await this.elementAction('click', this.notYourCar);
        }
        await this.elementAction('click', this.manualEntryButton);
        await this.elementAction('selectByXpath', this.makeList, 'FORD');
        await this.elementAction('selectOptionByCssContainingText', this.modelList, 'FOCUS');
        await this.elementAction('selectOptionByCssContainingText', this.manufactureYear, '2017');
        await this.elementAction('selectOptionByCssContainingText', this.fuelType, 'DIESEL');
        await this.elementAction('selectOptionByCssContainingText', this.vehicleVariant, 'GHIA D');
        await this.elementAction('selectOptionByCssContainingText', this.engineSize, '2');
        await this.elementAction('click', this.numberOfDoors4);
        await this.elementAction('selectOptionByCssContainingText', this.bodyType, 'SALOON');
        await this.elementAction('click', this.transmissionManual);
        await element(by.xpath('.//*[.="' + 'Select' + '"]')).click();
        await this.elementWait();
        await this.elementAction('click', this.isVehicleModifiedNo);
        await this.addPurchaseDetails();
        await this.elementAction('sendKeys', this.carValue, 10000);
        await this.elementAction('sendKeys', this.mileage, 9999);
        await this.elementAction('selectOptionByCssContainingText', this.registeredKeeper, 'You (proposer)');
        await this.elementAction('sendKeys', this.policyStartDateDay, utils.setDay());
        await this.elementAction('sendKeys', this.policyStartDateMonth, utils.setMonth());
        await this.elementAction('sendKeys', this.policyStartDateYear, utils.setYear());
    }

    async addPurchaseDetails() {
        await this.elementAction('click', this.isVehiclePurchasedYes);
        await this.elementAction('selectByOption', this.purchasedMonth);
        await this.elementAction('selectByOption', this.purchasedYear);
    }

    async addNoPurchaseDetails() {
        await this.elementAction('click', this.isVehiclePurchasedNo);
    }

    async changeCarMileage() {
        await this.elementAction('sendKeys', this.mileage, 35000);
    }

    async selectAccessoriesModes() {
        await this.elementAction('click', this.accessoriesModCategory);
        await this.elementAction('click', this.accessoriesModOne);
        await this.elementAction('click', this.accessoriesModTwo);
        await this.elementAction('click', this.accessoriesModThree);
        await this.elementAction('click', this.accessoriesModFour);
        await this.elementAction('click', this.accessoriesSaveButton);
    }

    async selectEngineModes() {
        await this.elementAction('click', this.engineModCategory);
        await this.elementAction('click', this.engineModOne);
        await this.elementAction('click', this.engineModTwo);
        await this.elementAction('click', this.engineModThree);
        await this.elementAction('click', this.engineModFour);
        await this.elementAction('click', this.engineSaveButton);
    }
}
