import { BasePage } from './base-page';
import { by, element } from 'protractor';

export class ConfirmationPage extends BasePage {
    private policyNumber = element.all(by.css('.payments__policy-value')).first();
    async checkPolicyDetails() {
        const policyNumberDisplayed = await this.policyNumber.getText();
    }

}
