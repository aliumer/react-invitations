import { browser, by, element, ElementFinder, ExpectedConditions } from 'protractor';
import {Utils} from '../utils/utils';
import { BasePage } from './base-page';
import { getDriverCount, getPolicyHolderAge } from '../utils/globals';
import {getFirstName, getSurname} from '../utils/globals';
const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;
const EC = ExpectedConditions;
const utils = new Utils;

export class DiscountsPage extends BasePage {

    private vehicleUsage = element(by.id('vehicleUsage'));
    private vehicleOvernightLocationYes = element(by.css('label[for="' + 'vehicleOvernightLocation-Yes' + '"]'));
    private vehicleOvernightLocationNo = element(by.css('label[for="' + 'vehicleOvernightLocation-No' + '"]'));
    private overNightPostcode = element(by.id('vehicleOvernightPostcode'));
    private verifyPostcodeButton = element(by.id('verify-postcode'));
    private overNightLocation = element(by.id('vehicleOvernightWhere'));
    private ncd9PlusYears = element(by.css('label[for="' + 'hasNoClaimsDiscount-9+' + '"]'));
    private ncdEarnThisVehicle = element(by.css('label[for="' + 'earnNcd-On this or a previous vehicle' + '"]'));
    private ncdEarnCompanyVehicle = element(by.css('label[for="' + 'earnNcd-With a company vehicle' + '"]'));
    private locationVerified = element(by.css('.section__verified'));

    async checkAndSetNCDDriverNames() {
        const additonalDriverCount = getDriverCount();
            let mainDriverAdditionalDriver: ElementFinder;
            let ncdDriverAdditionalDriver: ElementFinder;
            if (additonalDriverCount > 0) {
                let mainDriverPolicyHolder = element(by.css('label[for="' + 'mainDriver-Me (' + getFirstName() + ' ' + getSurname() + ')"]'));
                let ncdDriverPolicyHolder = element(by.css('label[for="' + 'ncdDriver-Me (' + getFirstName() + ' ' + getSurname() + ')"]'));
                // The bewlow two if checks are to cater for 1B & 1C envs on a 1C spcific change where a 'Me ()' is introduced for Main & NCD policy holder user..'
                if (!await mainDriverPolicyHolder.isPresent()) {
                    mainDriverPolicyHolder = element(by.css('label[for="' + 'mainDriver-' + getFirstName() + ' ' + getSurname() + '"]'));
                }
                await this.elementAction('click', mainDriverPolicyHolder);
                if (!await ncdDriverPolicyHolder.isPresent()) {
                    ncdDriverPolicyHolder = element(by.css('label[for="' + 'ncdDriver-' + getFirstName() + ' ' + getSurname() + '"]'));
                }
                // Check the display of all additional drivers as Main driver and NCD driver
                if (await mainDriverPolicyHolder.isPresent()) {
                    await this.elementAction('click', mainDriverPolicyHolder);
                    expect(await browser.wait(EC.visibilityOf(ncdDriverPolicyHolder), 5000, 'ncdDriver PolicyHolder not displayed..')).to.equal(true);
                    for (let i = 1; i <= additonalDriverCount; i++) {
                        mainDriverAdditionalDriver = element(by.css('label[for="' + 'mainDriver-Additional Driver' + utils.numberToString(i) + '"]'));
                        ncdDriverAdditionalDriver = element(by.css('label[for="' + 'ncdDriver-Additional Driver' + utils.numberToString(i) + '"]'));
                        expect(await browser.wait(EC.visibilityOf(mainDriverAdditionalDriver), 5000, 'mainDriver-Additional Driver not displayed')).to.equal(true);
                        expect(await mainDriverAdditionalDriver.getText()).to.equal('Additional Driver' + utils.numberToString(i));
                        await this.elementAction('click', mainDriverAdditionalDriver);
                        expect(await browser.wait(EC.visibilityOf(ncdDriverAdditionalDriver), 5000, 'ncdDriver-Additional Driver not displayed')).to.equal(true);
                        expect(await ncdDriverAdditionalDriver.getText()).to.equal('Additional Driver' + utils.numberToString(i));
                        await this.elementAction('click', ncdDriverAdditionalDriver);
                    }
                }
            await this.elementAction('click', mainDriverPolicyHolder);
            await this.elementAction('click', ncdDriverPolicyHolder);
        }
    }

    async verifyAndSetNCDYearsAndMonths(ncdYears: string) {
        const policyHolderAge = getPolicyHolderAge();
        // tslint:disable-next-line:triple-equals
        if (policyHolderAge == 16) {
            await this.elementAction('selectByCss', null,  'hasNoClaimsDiscount-Under 1 year');
            await this.elementAction('selectByCss', null,  'hasNoClaimsDiscountMonths-Less than 1 month');
        } else {
            if (policyHolderAge > 16 && policyHolderAge < 21) {
                expect(await (element(by.css('label[for="' + 'hasNoClaimsDiscount-5' + '"]')).isPresent())).to.equal(false);
                await this.elementAction('selectByCss', null,  'hasNoClaimsDiscount-' + ncdYears);
            } else if (policyHolderAge > 20 && policyHolderAge < 25) {
                expect(await element(by.css('label[for="' + 'hasNoClaimsDiscount-9+' + '"]')).isPresent()).to.equal(false);
                await this.elementAction('selectByCss', null,  'hasNoClaimsDiscount-' + ncdYears);
            } else {
                await this.elementAction('selectByCss', null,  'hasNoClaimsDiscount-' + ncdYears);
            }
        }
        await this.elementAction('click', this.ncdEarnThisVehicle);
    }

    async addDiscountDetails() {
        await this.elementAction('selectByOption', this.vehicleUsage);
        await this.elementAction('click', this.vehicleOvernightLocationYes);
    }

    async changeDiscountDetails() {
        await this.elementAction('selectByXpath', this.vehicleUsage, 'Social, Domestic and Pleasure plus Business use for policy holder only');
        await this.elementAction('click', this.vehicleOvernightLocationYes);
        await this.elementAction('click', this.ncd9PlusYears);
        await this.elementAction('click', this.ncdEarnCompanyVehicle);
    }

    async addWhereYouParkYourCarDetails() {
        await this.elementAction('selectByXpath', this.vehicleUsage, 'Social, Domestic and Pleasure including commuting');
        await this.elementAction('click', this.vehicleOvernightLocationNo);
        await this.elementAction('sendKeys', this.overNightPostcode, 'bs44lq');
        await this.elementAction('click', this.verifyPostcodeButton);
        expect(await browser.wait(EC.visibilityOf(this.locationVerified)), 2000).to.equal(true);
        await this.elementAction('selectByOption', this.overNightLocation);
    }
}
