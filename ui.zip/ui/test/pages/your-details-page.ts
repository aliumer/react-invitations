import { by, element, protractor, ExpectedConditions, ElementFinder} from 'protractor';
import {Utils} from '../utils/utils';
import {setFirstName, setSurname, setPolicyHolderAge} from '../utils/globals';
import {BasePage} from './base-page';
import * as faker from 'faker';
const EC = ExpectedConditions;
const utils = new Utils;

export class YourDetailsPage extends BasePage {

    private personTitleMr = element(by.css('label[for="' + 'title-Mr' + '"]'));
    private personTitleDr = element(by.css('label[for="' + 'title-Dr' + '"]'));
    private genderMale = element(by.css('label[for="' + 'gender-Male' + '"]'));
    private firstName = element(by.id('firstName'));
    private lastName = element(by.id('lastName'));
    private dateOfBirthDay = element(by.id('dateOfBirth-day'));
    private dateOfBirthMonth = element(by.id('dateOfBirth-month'));
    private dateOfBirthYear = element(by.id('dateOfBirth-year'));
    private maritalStatusMarried = element(by.css('label[for="' + 'maritalStatus-Married' + '"]'));
    private maritalStatusCivil = element(by.css('label[for="' + 'maritalStatus-Civil partnership' + '"]'));
    private employmentStatus = element(by.id('employmentStatus'));
    private jobTitle = element(by.id('occupation'));
    private Industry = element(by.id('industry'));
    private contactPhoneNumber = element(by.id('contactPhoneNumber'));
    private emailAddress = element(by.id('emailAddress'));
    private hasChildrenYes = element(by.css('label[for="' + 'hasChildren-Yes' + '"]'));
    private hasChildrenNo = element(by.css('label[for="' + 'hasChildren-No' + '"]'));
    private postCode = element(by.id('postcode_search'));
    private findAddressButton = element(by.id('find-address'));
    private addressDropDown = element(by.id('addressDetails'));
    private commsOnline = element(by.css('label[for="' + 'communicationPreference-My online account' + '"]'));
    private commsPost = element(by.css('label[for="' + 'communicationPreference-Post to me' + '"]'));
    private preferredFormat = element(by.css('label[for="' + 'audioTape-Audio Tape' + '"]'));

    async addPersonalDetails(fName, sName, DOB: string, relStatus, empStatus, jobTitle: string, mobNumber, userType, email, postCode) {
        const s = 0;
        await this.elementAction('click', this.personTitleMr);
        if (userType === 'New') { // for new users generate randon names, unique email Id and set DOB to 1st Jan of required age year
                email = utils.setUniqueNewEmail();
                fName = faker.name.firstName();
                while (s === 0) {
                    sName = faker.name.lastName();
                    if (!sName.includes('Mc' || 'Du' || '\'')) {
                        break;
                    }
                }
        }
        if (DOB.length < 4) { // if age was passed in instead of DOB, DOB will be set to '<currentDate>/<currentMonth>/<currentYear-Age>'.
            const date = new Date();
            DOB =  date.getDate() + '/' + (date.getUTCMonth() + 1) + '/' + (date.getUTCFullYear() - parseInt(DOB, 10));
        }
        await this.elementAction('sendKeys', this.firstName, fName);
        await setFirstName(await this.firstName.getAttribute('value'));
        await this.elementAction('sendKeys', this.lastName, sName);
        await setSurname(await this.lastName.getAttribute('value'));
        const dateArray = DOB.split('/');
        await this.elementAction('sendKeys', this.dateOfBirthDay, dateArray[0]);
        await this.elementAction('sendKeys', this.dateOfBirthMonth, dateArray[1]);
        await this.elementAction('sendKeys', this.dateOfBirthYear, dateArray[2]);
        const policyHolderAge = utils.setYear() - parseInt(dateArray[2], 10);
        setPolicyHolderAge(policyHolderAge);
        const relationship: ElementFinder = element(by.css('label[for="' + 'maritalStatus-' + relStatus + '"]'));
        await this.elementAction('click', relationship);
        await this.elementAction('selectByXpath', this.employmentStatus, empStatus);
        await this.elementWait();
        if (await this.jobTitle.isPresent()) {
            await this.typeAheadSelect(jobTitle.trim());
            // For DL brand, the Industry DDL is discarded so making it optional.
            if (await this.Industry.isPresent()) {
                await this.elementAction('selectByXpath', this.Industry, 'Consultancy');
            }
        }
        await this.elementAction('sendKeys', this.contactPhoneNumber, mobNumber);
        await this.elementAction('sendKeys', this.emailAddress, email);
        await this.elementAction('click', this.hasChildrenYes);
        await this.elementAction('sendKeys', this.postCode, postCode);
        await this.elementAction('click', this.findAddressButton);
        if (EC.invisibilityOf(this.addressDropDown)) {
            await this.elementAction('click', this.findAddressButton);
        }
        await this.elementAction('selectByOption', this.addressDropDown);
        await this.addCommunicationPreferences();
    }

    async addCommunicationPreferences() {
        if (await this.commsOnline.isPresent()) {
            await this.commsOnline.click();
            await this.elementAction('click', this.preferredFormat);
        }
    }

    async typeAheadSelect(jobTitle: string) {
        await this.elementAction('sendKeys', this.jobTitle, jobTitle.substr(0, 1));
        await this.jobTitle.sendKeys(jobTitle.substr(1, 1));
        await this.jobTitle.sendKeys(jobTitle.substr(2, 1));
        await this.jobTitle.sendKeys(jobTitle.substr(3, 1));
        await this.elementWait();
        await this.jobTitle.sendKeys(protractor.Key.ARROW_DOWN);
        await this.jobTitle.sendKeys(protractor.Key.ENTER);
        await this.jobTitle.sendKeys(protractor.Key.TAB);
        await this.elementWait();
    }

    async addExtraPersonalDetails() {
        await this.elementAction('click', this.personTitleDr);
        await this.elementAction('click', this.genderMale);
        await this.elementAction('click', this.hasChildrenYes);
    }

    async changeYourDetails() {
        await this.elementAction('click', this.maritalStatusCivil);
        await this.elementAction('selectByXpath', this.employmentStatus, 'Employed (part-time)');
        await this.elementAction('sendKeys', this.jobTitle, 'P');
        await this.jobTitle.sendKeys('r');
        await this.jobTitle.sendKeys('o');
        await this.elementWait();
        await this.jobTitle.sendKeys(protractor.Key.ARROW_DOWN);
        await this.jobTitle.sendKeys(protractor.Key.ENTER);
        await this.jobTitle.sendKeys(protractor.Key.TAB);
        await this.elementWait();
        await this.elementAction('selectByXpath', this.Industry, 'Engineering');
        await this.elementWait();
    }
}
