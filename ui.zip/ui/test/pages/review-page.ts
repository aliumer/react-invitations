import { browser, by, element } from 'protractor';
import { BasePage } from './base-page';

export class ReviewPage extends BasePage {

    private makePaymentButton = element(by.id('makePayment'));
    private editYourCarButton = element(by.id('editYourCar'));
    private editYourDetailsButton = element(by.id('editYourDetails'));
    private editYourDrivingHistoryButton = element(by.id('editYourDrivingHistory'));
    private editDiscountsButton = element(by.id('editDiscounts'));
    private editCoverButton = element(by.id('editCoverDetails'));

    async confirmDetailsAndMakePayment() {
        await this.closeChat();
        await this.makePaymentButton.click();
        await browser.waitForAngular();
    }

    async editJourney(Feature: string) {
        await this.closeChat();
        switch (Feature) {
            case 'vehicle': {
                await this.elementAction('click', this.editYourCarButton);
                break;
            }
            case 'personal': {
                await this.elementAction('click', this.editYourDetailsButton);
                break;
            }
            case 'driving': {
                await this.elementAction('click', this.editYourDrivingHistoryButton);
                break;
            }
            case 'discount': {
                await this.elementAction('click', this.editDiscountsButton);
                break;
            }
            case 'cover': {
                await this.elementAction('click', this.editCoverButton);
                break;
            }
        }
    }
}
