import { browser, by, element, ElementFinder, ExpectedConditions } from 'protractor';
import {getEdit} from '../utils/globals';
const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;
const should = chai.should();
const EC = ExpectedConditions;

export class BasePage {

    public continueButton: ElementFinder;
    public saveButton: ElementFinder;
    public backButton: ElementFinder;
    protected chatClose = element(by.className('LPMcloseButton'));
    protected errorText: ElementFinder;
    protected title: ElementFinder;
    protected header: ElementFinder;
    protected elementWaitTime = 200;
    protected lookupWaitTime = 2000;
    protected navigationWaitWithQuote = 3000;
    protected navigationWaitWithoutQuote = 4000;
    protected urlChangeWaitTime = 3000;
    protected editNavigationTime = 1000;

    constructor () {
        this.continueButton = element(by.id('continue'));
        this.saveButton = element(by.id('save'));
        this.backButton = element(by.id('back'));
        this.errorText = element(by.className('dlg-field__error'));
        this.title = element.all(by.css('.section__title')).first();
        this.header = element(by.css('.section__heading'));
    }

    async closeChat() {
        const isChatPresent = await this.chatClose.isPresent();
        if (isChatPresent) {
            await this.chatClose.click();
        }
    }

    async navigateNext() {
        await this.closeChat();
        expect(await browser.wait(EC.elementToBeClickable(this.continueButton), 5000, 'Sorry, timed out. Forward Navigation broken..')).to.equal(true);
        await this.elementAction('click', this.continueButton);
        await this.elementWait();
    }

    async navigateBack() {
        await this.closeChat();
        expect(await browser.wait(EC.elementToBeClickable(this.backButton), 5200, 'Sorry, timed out. Backward Navigation broken..')).to.equal(true);
        await this.elementAction('click', this.backButton);
    }

    async saveQuote() {
        await this.closeChat();
        expect(await browser.wait(EC.elementToBeClickable(this.saveButton), 5400, 'Sorry, timed out. Save Quote broken..')).to.equal(true);
        await this.elementAction('click', this.saveButton);
    }

    async checkPageTitle(title: string) {
        await browser.waitForAngular();
        await browser.wait(EC.visibilityOf(this.header), 6000, 'Sorry, timed out, page title : ' + title + ' not visible');
        expect((await this.header.getText()).toLowerCase()).to.include(title.trim().toLowerCase());
    }

    async checkURL(URL: string) {
        await browser.waitForAngular();
        if (!getEdit()) {
            expect(await browser.wait(EC.urlContains(URL), this.navigationWaitWithoutQuote, 'URL does not contain : ' + URL)).to.equal(true);
        } else {
            expect(await browser.wait(EC.urlContains(URL + '/edit'), this.navigationWaitWithQuote, 'URL does not contain : ' + URL)).to.equal(true);
        }
    }

    async checkURLfterPremium(URL: string) {
        await browser.waitForAngular();
        expect(await browser.wait(EC.urlContains(URL), this.navigationWaitWithQuote, 'URL does not contain : ' + URL)).to.equal(true);
    }

    async elementWait() {
        await browser.sleep(this.elementWaitTime);
    }

    async lookupWait() {
        await browser.sleep(this.lookupWaitTime);
    }

    async urlChangeWait() {
        await browser.sleep(this.urlChangeWaitTime);
    }

    async checkPageError() {
        expect(await this.errorText.isPresent()).to.equal(false);
    }

    async checkElementPresense(pageElement: any) {
        expect(await browser.wait(EC.presenceOf(pageElement), 1000));
    }

    // the below funtion is designed to perform all webElement actions after confirming the presense/visibility of the element
    // Only the element action is mandatory. WebElement, selector & className arguments are optional.
    async elementAction(action: string, webElement?: ElementFinder, selector?: any, className?: string, ddlIndex?: number) {
        let elementName: string;
        if (webElement) {
            elementName = await webElement.getWebElement().getTagName();
            await browser.wait(EC.visibilityOf(webElement), 5000, 'Sorry, ' + elementName + ': not visible on the page..');
            await browser.executeScript('arguments[0].scrollIntoView();', webElement.getWebElement());
        }
        switch (action) {
            case 'sendKeys': {
                await webElement.clear();
                await webElement.sendKeys(selector);
                break;
            }
            case 'click': {
                await webElement.click();
                break;
            }
            case 'selectByOption': {
                (!ddlIndex) ? await webElement.$$('select option').get(1).click() : await webElement.$$('select option').get(ddlIndex).click();
                break;
            }
            case 'selectByXpath': {
                await webElement.element(by.xpath('.//*[.="' + selector + '"]')).click();
                break;
            }
            case 'selectByCss': {
                await browser.wait(EC.visibilityOf(element(by.css('label[for="' + selector + '"]'))), 5000, selector + ': Sorry, css selector not clickable..');
                await element(by.css('label[for="' + selector + '"]')).click();
                break;
            }
            case 'selectOptionByCssContainingText': {
                await webElement.all(by.cssContainingText('option', selector.toString())).first().click();
                break;
            }
            case 'selectByCssContainingTextAndClass': {
                await webElement.element(by.cssContainingText(className, selector)).click();
                break;
            }
        }
        await browser.waitForAngular();
    }
}
