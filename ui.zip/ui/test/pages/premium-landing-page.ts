import { browser, by, element, ExpectedConditions } from 'protractor';
import { BasePage } from './base-page';
import {getFirstName} from '../utils/globals';
const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;
const EC = ExpectedConditions;

export class PremiumLandingPage extends BasePage {

    private greetingTitle = element(by.tagName('h1'));
    private compPlusButton = element(by.id('quote-type-comp-plus'));
    private compButton = element.all(by.id('quote-type-comp')).last();
    private tpftLink = element(by.cssContainingText('.summary__link section-premium__copy', 'only looking for Third Party'));

    async selectCompPlusPolicy() {
        await this.compPlusButton.click();
        await browser.waitForAngular();
    }

    async selectCompPolicy() {
        await this.compButton.click();
        await browser.waitForAngular();
    }

    async selectTPFTPolicy() {
        await this.tpftLink.click();
        await browser.waitForAngular();
    }

    async verifyOfferings() {
        expect(await browser.wait(EC.presenceOf(this.compButton), 2000)).to.equal(true);
        expect(await browser.wait(EC.presenceOf(this.compPlusButton), 2000)).to.equal(true);
    }

    async verifyGreeting() {
        const gteetingText = 'Great news, ' + getFirstName() + '!';
        await expect(gteetingText).to.equal(await this.greetingTitle.getText());
    }

    async isInterstitialPageDisplayed(): Promise<boolean> {
        if (await this.compButton.isPresent()) {
            return await Promise.resolve(true);
        }
    }
}
