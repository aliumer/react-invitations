import { browser, by, element, until, ExpectedConditions } from 'protractor';
import {Utils} from '../utils/utils';
import { BasePage } from './base-page';
import {getFirstName, getSurname, setCardHolderName, getCardHolderName, getExpectedPremiumPrice, getIsYearlyPayment} from '../utils/globals';
const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;
const EC = ExpectedConditions;
const utils = new Utils;

export class PaymentsPage extends BasePage {

    private monthlyPayment = element(by.css('label[for="' + 'paymentPlan-monthly' + '"]'));
    private ownCardYes = element(by.css('label[for="' + 'cardInName-Yes' + '"]'));
    private ownCardNo = element(by.css('label[for="' + 'cardInName-No' + '"]'));
    private cardPermissionNo = element(by.css('label[for="' + 'permissionToUse-No' + '"]'));
    private sortCodeFirst = element(by.id('bankSortCode-first'));
    private sortCodeSecond = element(by.id('bankSortCode-second'));
    private sortCodeThird = element(by.id('bankSortCode-last'));
    private accountNumber = element(by.id('bankAccountNumber'));
    private verifyAccountButton = element(by.id('verify'));
    private nextButton = element(by.id('next'));
    private cardHolderTitleMrs = element(by.css('label[for="' + 'prefix-Mrs' + '"]'));
    private cardHolderFirstName = element(by.id('firstName'));
    private cardHolderLastName = element(by.id('lastName'));
    private sameBillingAddressYes = element(by.css('label[for="' + 'isPolicyAddress-Yes' + '"]'));
    private sameBillingAddressNo = element(by.css('label[for="' + 'isPolicyAddress-No' + '"]'));
    private cardTypeVisaDebit = element(by.css('label[for="' + 'cardType-Visa Debit' + '"]'));
    private cardTypeVisaCredit = element(by.css('label[for="' + 'cardType-Visa Credit' + '"]'));
    private cardTypeMasterCard = element(by.css('label[for="' + 'cardType-Mastercard' + '"]'));
    private cardTypeAmex = element(by.css('label[for="' + 'cardType-American Express' + '"]'));
    private cardTypeMeastro = element(by.css('label[for="' + 'cardType-Meastro' + '"]'));
    private cardTypeVisaElectron = element(by.css('label[for="' + 'cardType-Visa Electron' + '"]'));
    private postCode = element(by.id('postcode_search'));
    private findAddressButton = element(by.id('find-address'));
    private addressDropDown = element(by.id('addressDetails'));
    private cannotProceedMsg = element(by.cssContainingText(`.${'dlg-field__error'}`, 'You can not proceed without the permission of the card holder'));
    private confirmationCheck = element.all(by.css('.dlg-checkbox')).last();
    private enterCardDetailsButton = element(by.id('cardDetails'));
    private cardNumber = element(by.id('cardNumber'));
    private cardHolderName = element(by.id('cardholderName'));
    private expiryMonth = element(by.id('expiryMonth'));
    private expiryYear = element(by.id('expiryYear'));
    private securityCode = element(by.id('securityCode'));
    private submitButton = element(by.id('submitButton'));
    private confirmButton = element(by.id('confirmDetails'));
    private policyTotalElement = element(by.css('.payments__amount'));
    private autoRenewCheck = element.all(by.css('.dlg-checkbox')).first();

    async makeAnnualPaymentNoPermissionToUseCard() {
        await this.elementAction('click', this.ownCardNo);
        await this.elementAction('click', this.cardPermissionNo);
        expect(await browser.wait(EC.visibilityOf(element(this.cannotProceedMsg)), 5000)).to.equal(true);
    }

    async enterCardHolderDetails(cardHolderName: string) {
        await this.elementAction('click', this.cardHolderTitleMrs);
        if (cardHolderName === '3D') {
            await setCardHolderName(cardHolderName, cardHolderName);
            await this.elementAction('sendKeys', this.cardHolderFirstName, cardHolderName);
            await this.elementAction('sendKeys', this.cardHolderLastName, cardHolderName);
        } else {
            const cardHolderNames = cardHolderName.split('-');
            await setCardHolderName(cardHolderNames[0], cardHolderNames[1]);
            await this.elementAction('sendKeys', this.cardHolderFirstName, cardHolderNames[0]);
            await this.elementAction('sendKeys', this.cardHolderLastName, cardHolderNames[1]);
        }
    }

    async enterBillingAddress(postCode: string) {
        await this.elementAction('sendKeys', this.postCode, postCode);
        await this.closeChat();
        await this.elementAction('click', this.findAddressButton);
        await this.addressDropDown.$$('select option').get(1).click();
        await this.elementWait();
    }

    async makePayment(paymentType, cardOwnership, sortCode, accountNumber, cardType, bankCardNumber, cardHolderName, cvc, billingAddressType, billingAddress, autoRenewal) {
        if (getIsYearlyPayment()) { // If monthly payment option was not provided by GuideWire
            paymentType = 'Yearly';
        }
        if (paymentType === 'Monthly') {
            await this.monthlyPaymentStageOne(sortCode, accountNumber, autoRenewal);
            await this.monthlyPaymentStageTwo();
        }
        if (cardOwnership === 'Own') {
            await this.elementAction('click', this.ownCardYes);
            await setCardHolderName(getFirstName(), getSurname());
        } else {
            await this.elementAction('click', this.ownCardNo);
            await this.enterCardHolderDetails(cardHolderName);
        }
        if (billingAddressType === 'Same') {
            await this.elementAction('click', this.sameBillingAddressYes);
        } else {
            await this.elementAction('click', this.sameBillingAddressNo);
            await this.enterBillingAddress(billingAddress);
        }
        await this.paymentOniFrame(paymentType, cardType, bankCardNumber, cardHolderName, cvc);
    }

    async setAutoRenewal(autoRenew: string) {
        if (autoRenew === 'No') {
            await this.elementAction('click', this.autoRenewCheck);
        }
    }

    async paymentOniFrame(paymentType, cardType, bankCardNumber, cardHolderName, cvc) {
        await this.closeChat();
        switch (cardType) {
            case 'VisaDebit': {
                await this.elementAction('click', this.cardTypeVisaDebit);
                break;
            }
            case 'VisaCredit': {
                await this.elementAction('click', this.cardTypeVisaCredit);
                break;
            }
            case 'Amex': {
                await this.elementAction('click', this.cardTypeAmex);
                break;
            }
            case 'Meastro': {
                await this.elementAction('click', this.cardTypeMeastro);
                break;
            }
            case 'Mastercard': {
                await this.elementAction('click', this.cardTypeMasterCard);
                break;
            }
            case 'VisaElectron': {
                await this.elementAction('click', this.cardTypeVisaElectron);
                break;
            }
        }
        await this.closeChat();
        await this.elementAction('click', this.enterCardDetailsButton);
        await browser.waitForAngularEnabled(false);
        try {
            await browser.wait(until.elementLocated(by.id('wp-cl-worldpayContainer-iframe')), 40000, 'Sorry, timed out, Payment iFrame not detected..;');
            await browser.wait(browser.switchTo().frame(await browser.driver.findElement(by.id('wp-cl-worldpayContainer-iframe'))), 20000, 'Unable to switch to payment iFrame..');
            browser.sleep(2000);
            await this.payWithCardDetails(bankCardNumber, cvc);
        } catch (error) {
            console.error('Sorry, something gone wrong with WorldPay payment iFrame..');
        }
        if (cardHolderName === '3D') {
            await this.verifyPayment3DCheck();
        }
        await browser.switchTo().defaultContent();
        await browser.waitForAngularEnabled(true);
    }

    async payWithCardDetails(bankCardNumber, cvc) {
        await browser.wait(EC.visibilityOf(this.cardNumber), 25000, 'Cant detect card number field..');
        await this.cardNumber.click();
        await this.elementAction('sendKeys', this.cardNumber, bankCardNumber);
        await this.verifyCardHolderName();
        await this.elementAction('sendKeys', this.expiryMonth, 2);
        await this.elementAction('sendKeys', this.expiryYear, utils.cardExpiryYear());
        await this.elementAction('sendKeys', this.securityCode, cvc);
        await this.elementAction('click', this.submitButton);
    }

    async verifyPayment3DCheck() {
        expect(await this.cardHolderName.getAttribute('value')).to.equal(getCardHolderName());
    }

    async verifyCardHolderName() {
        expect(await this.cardHolderName.getAttribute('value')).to.equal(getCardHolderName());
    }

    async monthlyPaymentStageOne(sortCode: string, accountNumber, autoRenewal?) {
        await this.elementAction('click', this.monthlyPayment);
        if (autoRenewal === 'No') {
            await this.elementAction('click', this.autoRenewCheck);
        }
        const sortCodeArray = sortCode.split('-');
        await this.elementAction('sendKeys', this.sortCodeFirst, sortCodeArray[0]);
        await this.elementAction('sendKeys', this.sortCodeSecond, sortCodeArray[1]);
        await this.elementAction('sendKeys', this.sortCodeThird, sortCodeArray[2]);
        await this.elementAction('sendKeys', this.accountNumber, accountNumber);
        await this.elementAction('click', this.verifyAccountButton);
        await this.elementAction('click', this.confirmationCheck);
        await this.elementAction('click', this.nextButton);
    }

    async monthlyPaymentStageTwo() {
        await this.elementWait();
        expect(await browser.wait(until.elementLocated(by.id('confirmDetails')), 5000, 'Sorry, timed out, Confirm button not found..;'));
        await this.elementAction('click', this.confirmButton);
    }

    async verifyPremiumPricesOnPayment() {
        let premiumTotal: number;
        let premiumTotalToPay: number;
            premiumTotal = getExpectedPremiumPrice();
            const displayedTotal = await this.policyTotalElement.getText();
            premiumTotalToPay = utils.formatPrices(displayedTotal);
            await expect(premiumTotalToPay).to.equal(premiumTotal);
    }
}
