import { browser, by, element, protractor, ExpectedConditions } from 'protractor';
import { Utils } from '../utils/utils';
import { BasePage } from './base-page';
import { incrementDriverCount, getPolicyHolderAge } from '../utils/globals';
const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;
const EC = ExpectedConditions;
const utils = new Utils;

export class YourDrivingHistoryPage extends BasePage {

    private licenseTypeFullUK = element(by.css('label[for="' + 'licenceType-Full UK' + '"]'));
    private licenseTypeFullEU = element(by.css('label[for="' + 'licenceType-Full EU' + '"]'));
    private licenseTypeProvisionalUK = element(by.css('label[for="' + 'licenceType-Provisional UK' + '"]'));
    private licenseTypeInternational = element(by.css('label[for="' + 'licenceType-International' + '"]'));
    private licenseHeldForMore = element(by.css('label[for="' + 'licenceHeldFor-Yes' + '"]'));
    private licenseHeldForYears8 = element(by.css('label[for="' + 'licenceHeldForYears-8' + '"]'));
    private licenseHeldForYears9Plus = element(by.css('label[for="' + 'licenceHeldForYears-9+' + '"]'));
    private livedInUkSinceBirthYes = element(by.css('label[for="' + 'livedSinceBirth-Yes' + '"]'));
    private livedInUkSinceBirthNo = element(by.css('label[for="' + 'livedSinceBirth-No' + '"]'));
    private hasConvictionsNo = element(by.css('label[for="' + 'hasConvictions-No' + '"]'));
    private hasConvictionsYes = element(by.css('label[for="' + 'hasConvictions-Yes' + '"]'));
    private hasClaimsNo = element(by.css('label[for="' + 'hasClaims-No' + '"]'));
    private hasClaimsYes = element(by.css('label[for="' + 'hasClaims-Yes' + '"]'));
    private addThisDriverButton = element(by.id('add-additional-driver'));
    private addAnotherConvictionButton = element.all(by.id('add-another-conviction')).last();
    private addAnotherClaimButton = element.all(by.id('add-another-claims')).last();
    private addDriverButton = element(by.id('add-driver'));

    async addDirvingHistoryCommon(livedSince: string) {
        await this.elementAction('click', this.licenseTypeFullUK);
        const policyHolderAge = getPolicyHolderAge();
        await this.checkAndSetLicenseHeldYearsForPolicyHolder(policyHolderAge);
        livedSince === 'Birth' ? await this.elementAction('click', this.livedInUkSinceBirthYes) : await this.userNotBornInUK(livedSince);
    }

    async addDrivingHistoryWithConvictionsAndClaims(livedSince: string, noOfConvictions: number, noOfClaims: number) {
        await browser.waitForAngular();
        await this.addDirvingHistoryCommon(livedSince);
        if (noOfConvictions > 0) {
            await this.elementAction('click', this.hasConvictionsYes);
            await this.addConvictions(99, noOfConvictions);
        } else {
            await this.elementAction('click', this.hasConvictionsNo);
        }
        if (noOfClaims > 0) {
            await this.elementAction('click', this.hasClaimsYes);
            await this.addClaims(99, noOfClaims);
        } else {
            await this.elementAction('click', this.hasClaimsNo);
        }
    }

    async addAdditionalDriversNoConvictionAndClaims(noOfDrivers: number, policyHolderStatus, driverAge) {
        await browser.waitForAngular();
        for (let i = 0; i < noOfDrivers; i++) {
            await this.addDriverButton.isPresent().then(async addingDriver => {
                const addDriverCounter = incrementDriverCount();
                if (addingDriver && addDriverCounter < (addDriverCounter + noOfDrivers)) {
                    await this.additionalDriverCommon(addDriverCounter, policyHolderStatus, driverAge);
                    await this.elementAction('selectByCss', null,  'hasConvictions' + (addDriverCounter) + '-No');
                    await this.elementAction('selectByCss', null,  'hasClaims' + (addDriverCounter) + '-No');
                    await this.elementAction('click', this.addThisDriverButton);
                }
                return null;
            }).catch((err) => {
            });
        }
    }

    async addAdditionalDriverWithConvictionAndClaims(noOfDrivers: number, noOfConvictions: number, noOfClaims: number, policyHolderStatus, driverAge) {
        await browser.waitForAngular();
        for (let i = 0; i < noOfDrivers; i++) {
            await this.addDriverButton.isPresent().then(async addingDriver => {
                const addDriverCounter = incrementDriverCount();
                if (addingDriver && addDriverCounter < (addDriverCounter + noOfDrivers)) {
                    await this.additionalDriverCommon(addDriverCounter, policyHolderStatus, driverAge);
                    if (noOfConvictions > 0) {
                        await this.elementAction('selectByCss', null, 'hasConvictions' + (addDriverCounter) + '-Yes');
                        await this.addConvictions(addDriverCounter, noOfConvictions);
                    } else {
                        await this.elementAction('selectByCss', null, 'hasConvictions' + (addDriverCounter) + '-No');
                    }
                    if (noOfClaims > 0) {
                        await this.elementAction('selectByCss', null, 'hasClaims' + (addDriverCounter) + '-Yes');
                        await this.addClaims(addDriverCounter, noOfClaims);
                    } else {
                        await this.elementAction('selectByCss', null, 'hasClaims' + (addDriverCounter) + '-No');
                    }
                    await this.elementAction('click', this.addThisDriverButton);
                }
                return null;
            }).catch((err) => {
            });
        }
    }

    async addConvictions(addDriverCounter: number, noOfConvictions: number) {
        await browser.waitForAngular();
        for (let i = 0; i < noOfConvictions; i++) {
            await this.addAdditionalConviction();
            await this.elementWait();
            if (i === 1) { // Add Mobile usage as second conviction type
                await this.elementAction('selectByCss', null, 'commonConviction' + i + ' ' + (addDriverCounter) + '-CU80 - Driving whilst using a mobile phone');
            } else if (i === 2) { // Add Defective Steering as third conviction type
                await this.elementAction('selectByCss', null, 'commonConviction' + i + ' ' + (addDriverCounter) + '-CU40 - Defective steering');
            } else { // All other conviction type is set to Speeding
                await this.elementAction('selectByCss', null, 'commonConviction' + i + ' ' + (addDriverCounter) + '-SP30 - Exceeding statutory speed limit');
            }
            await this.elementAction('selectByOption', element(by.id('convictionDate' + i + ' ' + (addDriverCounter) + '-month')));
            await this.elementAction('selectOptionByCssContainingText', element(by.id('convictionDate' + i + ' ' + (addDriverCounter) + '-year')), (utils.setYear() - 4));
            await this.elementAction('selectOptionByCssContainingText', element(by.id('penaltyPoints' + i + ' ' + (addDriverCounter))), 2);
            await this.elementAction('sendKeys', element(by.id('lengthOfBan' + i + ' ' + (addDriverCounter))), (i + 1));
            await this.elementAction('click', element.all(by.id('save-conviction')).last());
        }
    }

    async addClaims(addDriverCounter: number, noOfClaims: number) {
        await browser.waitForAngular();
        for (let i = 0; i < noOfClaims; i++) {
            await this.addAdditionalClaim();
            await this.elementAction('selectOptionByCssContainingText', element(by.id('incidentDate' + i + ' ' + (addDriverCounter) + '-month')), 'May');
            await this.elementAction('selectOptionByCssContainingText', element(by.id('incidentDate' + i + ' ' + (addDriverCounter) + '-year')), (utils.setYear() - 4));
            if (i === 1) { // Add theft as second claim type
                await this.elementAction('selectByCss', null, 'claimsType' + i + ' ' + (addDriverCounter) + '-Theft');
                await this.elementAction('selectByCss', null, 'theftList' + i + ' ' + (addDriverCounter) + '-Theft related Damage');
            } else if (i === 2) { // Add Other as third claim type
                await this.elementAction('selectByCss', null, 'claimsType' + i + ' ' + (addDriverCounter) + '-Other');
                await this.elementAction('selectByCss', null, 'otherList' + i + ' ' + (addDriverCounter) + '-Fire');
            } else { // All other claim type is set to Accident
                await this.elementAction('selectByCss', null, 'claimsType' + i + ' ' + (addDriverCounter) + '-Accident');
                await this.elementAction('selectByCss', null, 'accidentList' + i + ' ' + (addDriverCounter) + '-No other vehicle involved');
                await this.elementAction('selectByCss', null, 'claimMade' + i + ' ' + (addDriverCounter) + '-No');
            }
            await this.elementAction('click', element.all(by.id('save-claims')).last());
        }
    }

    async userNotBornInUK(livedSince: string) {
        const dateArray = livedSince.split('/');
        await this.elementAction('click', this.livedInUkSinceBirthNo);
        await this.elementAction('click', element(by.xpath('.//*[.="' + dateArray[0].trim() + '"]')));
        await this.elementAction('click', element(by.xpath('.//*[.="' + dateArray[1].trim() + '"]')));
    }

    async additionalDriverCommon(addDriverCounter: number, policyHolderStatus: string, driverAge: number) {
        await this.elementAction('click', this.addDriverButton);
        await this.elementAction('selectByCss', null, 'title' + (addDriverCounter) + '-Mr');
        await this.elementAction('sendKeys', element(by.id('firstName' + (addDriverCounter))), 'Additional');
        await this.elementAction('sendKeys', element(by.id('lastName' + (addDriverCounter))), ('Driver' + utils.numberToString((addDriverCounter + 1))));
        // DOB is set to the same day of required age year for all additional drivers
        const date = new Date();
        await this.elementWait();
        await this.elementAction('sendKeys', element(by.id('dateOfBirth' + (addDriverCounter) + '-day')), date.getDate());
        await this.elementAction('sendKeys', element(by.id('dateOfBirth' + (addDriverCounter) + '-month')), (date.getUTCMonth() + 1));
        await this.elementAction('sendKeys', element(by.id('dateOfBirth' + (addDriverCounter) + '-year')), (date.getUTCFullYear() - driverAge));

        await this.elementAction('selectByCss', null, 'maritalStatus' + (addDriverCounter) + '-Married');
        await this.elementAction('click', element(by.id('employmentStatus' + (addDriverCounter))).element(by.xpath('.//*[.="' + 'Employed (full-time)' + '"]')));
        await element(by.id('occupation' + (addDriverCounter))).clear();
        await element(by.id('occupation' + (addDriverCounter))).sendKeys('A');
        await element(by.id('occupation' + (addDriverCounter))).sendKeys('c');
        await element(by.id('occupation' + (addDriverCounter))).sendKeys('c');
        await this.elementWait();
        await browser.waitForAngular();
        await element(by.id('occupation' + (addDriverCounter))).sendKeys(protractor.Key.ARROW_DOWN);
        await element(by.id('occupation' + (addDriverCounter))).sendKeys(protractor.Key.ENTER);
        await element(by.id('occupation' + (addDriverCounter))).sendKeys(protractor.Key.TAB);
        await this.elementWait();
        await browser.waitForAngular();
        // Industry is not being supported for DL brand so making it optional.
        if (await element(by.id('industry' + (addDriverCounter))).isPresent()) {
            await this.elementAction('click', element(by.id('industry' + (addDriverCounter))).element(by.xpath('.//*[.="' + 'Aviation' + '"]')));
        }
        if (addDriverCounter === 0 && policyHolderStatus !== 'Single') {
            await this.elementAction('click', element(by.id('relationship' + (addDriverCounter))).element(by.xpath('.//*[.="' + 'Spouse (husband/wife)' + '"]')));
        } else {
            await this.elementAction('click', element(by.id('relationship' + (addDriverCounter))).element(by.xpath('.//*[.="' + 'Other family' + '"]')));
        }
        switch (addDriverCounter) {
            case 0: {
                await this.elementAction('selectByCss', null, 'licenceType' + (addDriverCounter) + '-Full UK');
                break;
            }
            case 1: {
                await this.elementAction('selectByCss', null, 'licenceType' + (addDriverCounter) + '-Full EU');
                break;
            }
            case 2: {
                await this.elementAction('selectByCss', null, 'licenceType' + (addDriverCounter) + '-Provisional UK');
                break;
            }
            case 3: {
                await this.elementAction('selectByCss', null, 'licenceType' + (addDriverCounter) + '-Provisional EU');
                break;
            }
            case 4: {
                await this.elementAction('selectByCss', null, 'licenceType' + (addDriverCounter) + '-International');
                break;
            }
            default: {
                await this.elementAction('selectByCss', null, 'licenceType' + (addDriverCounter) + '-Full EU');
                break;
            }
        }
        await this.checkAndSetLicenseHeldYearsForDrivers(driverAge, addDriverCounter);
        await this.elementAction('selectByCss', null, 'livedSinceBirth' + (addDriverCounter) + '-Yes');
    }

    async addAdditionalConviction() {
        await this.addAnotherConvictionButton.isPresent().then(async add => {
            if (add) {
                await this.elementAction('click', this.addAnotherConvictionButton);
            }
            return null;
        }).catch((err) => {
        });
    }

    async addAdditionalClaim() {
        await this.addAnotherClaimButton.isPresent().then(async add => {
            if (add) {
                await this.elementAction('click', this.addAnotherClaimButton);
            }
            return null;
        }).catch((err) => {
        });
    }

    async changeDrivingDetails() {
        await this.elementAction('click', this.licenseTypeFullUK);
        await this.elementAction('click', this.licenseHeldForYears8);
        await this.elementAction('click', this.livedInUkSinceBirthYes);
    }

    async checkAndSetLicenseHeldYearsForPolicyHolder(policyHolderAge: number) {
        // tslint:disable-next-line:triple-equals
        if (policyHolderAge == 16) {
            await this.elementAction('selectByCss', null, 'licenceHeldForMonths-Less than 1 month');
        } else {
            await this.licenseHeldForMore.click();
            if (policyHolderAge > 16 && policyHolderAge < 21) {
                expect(await element(by.css('label[for="' + 'licenceHeldForYears-5' + '"]')).isPresent()).to.equal(false);
                await this.elementAction('selectByCss', null, 'licenceHeldForYears-1');
            } else if (policyHolderAge > 20 && policyHolderAge < 25) {
                expect(await element(by.css('label[for="' + 'licenceHeldForYears-9+' + '"]')).isPresent()).to.equal(false);
                await this.elementAction('selectByCss', null, 'licenceHeldForYears-4');
            } else if (policyHolderAge > 24 && policyHolderAge < 28) {
                await this.elementAction('selectByCss', null, 'licenceHeldForYears-7');
            } else {
                await this.elementAction('selectByCss', null, 'licenceHeldForYears-9+');
            }
        }
    }

    async checkAndSetLicenseHeldYearsForDrivers(driverAge: number, addDriverCounter: number, verifyDrivers?: string) {
        if (verifyDrivers) {
            await this.elementAction('click', element(by.id('driverEdit' + addDriverCounter)));
        }
        // tslint:disable-next-line:triple-equals
        if (driverAge == 16) {
            await this.elementAction('selectByCss', null, 'licenceHeldForMonths' + addDriverCounter + '-Less than 1 month');
        } else {
            await this.elementAction('selectByCss', null, 'licenceHeldFor' + addDriverCounter + '-Yes');
            if (driverAge > 16 && driverAge < 21) {
                expect(await element(by.css('label[for="' + 'licenceHeldForYears' + addDriverCounter + '-5' + '"]')).isPresent()).to.equal(false);
                await this.elementAction('selectByCss', null, 'licenceHeldForYears' + addDriverCounter + '-1');
            } else if (driverAge > 20 && driverAge < 25) {
                expect(await element(by.css('label[for="' + 'licenceHeldForYears' + addDriverCounter + '-9+' + '"]')).isPresent()).to.equal(false);
                await this.elementAction('selectByCss', null, 'licenceHeldForYears' + addDriverCounter + '-4');
            } else if (driverAge > 24 && driverAge < 28) {
                await this.elementAction('selectByCss', null, 'licenceHeldForYears' + addDriverCounter + '-7');
            } else {
                await this.elementAction('selectByCss', null, 'licenceHeldForYears' + addDriverCounter + '-9+');
            }
        }
        // tslint:disable-next-line:triple-equals
        if (addDriverCounter == 2 || addDriverCounter == 3) {
            await this.elementAction('selectByCss', null, 'licenceHeldFor' + addDriverCounter + '-No');
            await this.elementAction('selectByCss', null, 'licenceHeldForMonths' + addDriverCounter + '-10');
        }
        if (verifyDrivers) {
            await this.elementAction('click', element(by.id('save-additional-driver')));
        }
    }
}
