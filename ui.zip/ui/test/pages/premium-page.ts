import { browser, by, element, $$, $, ExpectedConditions } from 'protractor';
import { BasePage } from './base-page';
import { Utils } from '../utils/utils';
import { setPremiumCompPrice, setPremiumCompPlusPrice, setPremiumTpftPrice, setIndicativeQuote, setAddOnOperation, getAddOnOperation, getPremiumTpftPrice, setIsYearlyPayment, getEdit, isIndicative, getIsdrivexpertPresent} from '../utils/globals';
import { getSurname, setIsTpftPresent, resetGlobals, setIsCompPlusPresent, getDriverCount, getIsCompPlusPresent, setSelectedPremiumType, setIsdrivexpertPresent, setIsCompPresent} from '../utils/globals';
import { getSelectedPremiumType, getFirstName, getPremiumCompPrice, getPremiumCompPlusPrice, setExpectedPremiumPrice, getExpectedPremiumPrice, getDriveXpertPrice, setDriveXpertPrice } from '../utils/globals';
const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;
const EC = ExpectedConditions;
const utils = new Utils;

export class PremiumPage extends BasePage {

    private premiumSession: any;
    private titleGreeting = element(by.tagName('app-greeting')).element(by.tagName('h2'));
    private summaryTabTotalPart1 = element.all(by.css('.summary__info-price')).first();
    private summaryTabTotalPart2 = element.all(by.css('.summary__info-price-penny')).first();
    private addOnTitle = element.all(by.css('.panel__heading'));
    private addOnPriceText = element.all(by.css('.panel__price'));
    private quoteWarning = element.all(by.css('.panel__warning-copy')).first();
    private mothlyPaymentWarning = element.all(by.css('.summary__warning')).first();
    private amendDetailsButton = element(by.id('amend-details'));
    private pncdYearlyOnLightBox = element.all(by.css('.modal__ncd')).first();
    private ncdLightBoxAddToPolicyButton = element(by.id('modal-addon'));
    private excessDropdown = element(by.id('excessDropdown'));
    private breakDownPrice = element.all(by.css('.breakdown-table__amount'));
    private backBtnTelematics = element(by.id('back-button-telematics'));
    private driveXSelection = element.all(by.css('.summary__sub-title-text')).first();
    private compSelection = element.all(by.css('.summary__sub-title-text')).last();
    private compPlusSelection = element(by.css('.summary__telematics-link'));
    private quoteDetailsPrinted = false;

    async verifyDisplayOfPromoCode(promoCode: string) {
        expect(await browser.wait(EC.visibilityOf(element(by.cssContainingText('span', promoCode))), 5000, 'Sorry, timed out. Applied promoCode not found on premium page..')).to.equal(true);
    }

    async selectRequiredPremium(premiumType: string) {
        const configData = await browser.getProcessedConfig();
        if (!getIsdrivexpertPresent()) {
            this.compSelection = element.all(by.css('.summary__sub-title-text')).first();
            this.compPlusSelection = element(by.css('.summary__show-md'));
        }
        if (configData.capabilities.real_mobile) {
            this.compPlusSelection = element(by.css('.summary__show-xs'));
        }
        switch (premiumType) {
            case 'CompPlus': {
                await this.elementAction('click', this.compPlusSelection);
                setSelectedPremiumType('compplus');
                setExpectedPremiumPrice(getPremiumCompPlusPrice());
                break;
            }
            case 'Comp': {
                await this.elementAction('click', this.compSelection);
                setSelectedPremiumType('comp');
                setExpectedPremiumPrice(getPremiumCompPrice());
                break;
            }
            case 'DriveX': {
                if (!getIsdrivexpertPresent()) {
                    await this.elementAction('click', this.compPlusSelection);
                    setSelectedPremiumType('compplus');
                    setExpectedPremiumPrice(getPremiumCompPlusPrice());
                } else {
                    await this.elementAction('click', this.driveXSelection);
                    setSelectedPremiumType('drivexpert');
                }
                break;
            }
            case 'TPFT': {
                await this.elementAction('click', this.compSelection);
                setSelectedPremiumType('TPFT');
                setExpectedPremiumPrice(getPremiumTpftPrice());
                break;
            }
        }
    }

    async verifyExcessNamesAndPrices(volExcess: number) {
        let driversVerified = 0;
        let policyHolderVerified = false;
        const additonalDriverCount = getDriverCount();
        if (volExcess) {
            await this.changeExcess(volExcess);
            await this.getPremiumBrowserSessionDetails();
        }
        if (additonalDriverCount > 0) {
        }
        const policyHolderName = getFirstName() + ' ' + getSurname();
        // Select the displayed value from the excess drop down
        const selectedVoluntaryExcess = utils.formatPrices(await this.excessDropdown.$('option:checked').getText());
        // Extract all required excess values from local session entries for the selected premium type.
        const premiumSessionEntry = await browser.driver.executeScript('return window.sessionStorage.getItem("app-session-premium");');
        const premiumSession = JSON.parse(premiumSessionEntry.toString());
        if (premiumSession) {
            // offerings[0] will be current selected offer from the UI
            const offer = premiumSession.result.lobData.mOTLine_Ext.offerings[0];
            if (offer.offeringCode_dlg.trim() === getSelectedPremiumType()) {
                for (let i = 0; i <= additonalDriverCount; i++) {
                    if (offer.driverExcess_dlg[i].name === policyHolderName && !(policyHolderVerified)) {
                        await this.assertExcessDetails(policyHolderName, (offer.driverExcess_dlg[i].compulsoryExcess + offer.driverExcess_dlg[i].driverExcess), offer.driverExcess_dlg[i].voluntaryExcess, offer.driverExcess_dlg[i].totalExcess);
                        policyHolderVerified = true;
                    }
                    if (additonalDriverCount !== 0) {
                        // Setting driver index to One to start driver names assertion from first additional driver
                        let driverIndex = additonalDriverCount - (additonalDriverCount - 1);
                        // If there are additional drivers added in, check each of them against the current table column text and assert all the excess values
                        while (driverIndex <= additonalDriverCount) {
                            const addnlDriverName = 'Additional Driver' + utils.numberToString(driverIndex);
                            if (offer.driverExcess_dlg[i].name === addnlDriverName) {
                                await this.assertExcessDetails(addnlDriverName, (offer.driverExcess_dlg[i].compulsoryExcess + offer.driverExcess_dlg[i].driverExcess), offer.driverExcess_dlg[i].voluntaryExcess, offer.driverExcess_dlg[i].totalExcess);
                                driversVerified += 1;
                                break;
                            } else {
                            }
                            driverIndex += 1;
                        }
                    }
                }
            }
        }
    }

    async assertExcessDetails(driverName: string, compulsoryExcess: number, voluntaryExcess: number, totalExcess: number) {
        let excessRecordsCount = 0;
        // Get all the values from the excess table on premium page
        const excessRecords = $$('.table-excess__body tr').$$('td');
        excessRecordsCount = await excessRecords.count();
        // Loop through all the names displayed against names keyed in and then assert the excess values
        for (let i = 4; i < excessRecordsCount; i++) {
            const excessText = (await excessRecords.get(i).getText()).trim();
            // To avoid checking against all the values in the excess table, asses the length.
            if (excessText.length > 3) {
                if (excessText === driverName) {
                    expect(utils.formatPrices(await excessRecords.get(i + 1).getText())).to.equal(compulsoryExcess);
                    expect(utils.formatPrices(await excessRecords.get(i + 2).getText())).to.equal(voluntaryExcess);
                    expect(utils.formatPrices(await excessRecords.get(i + 3).getText())).to.equal(totalExcess);
                    i += 3;
                    continue;
                }
            }
        }
    }

    async changeExcess(volExcess?: number) {
        if (!volExcess) {
            await this.elementAction('selectByOption', this.excessDropdown, 2);
        } else {
            await this.elementAction('selectOptionByCssContainingText', this.excessDropdown, volExcess);
        }
    }

    async amendVehicleDetails() {
        await this.amendDetailsButton.click();
        await browser.waitForAngular();
    }

    async addOrRemoveAddOn(action: string, addOn: string) {
        let addOnFound = false;
        let addOnIndex: number;
        let newExpectedAnnualPremiumPrice: number;
        let addOnAnnualPrice: number;
        let addOnIdText: string;
        let addOnIdTextNext: string;
        setAddOnOperation(false);
        // addOn which comes from the feature file cannot have spaces so needs to be formatted to check against the addOn names displayed
        const addOnFormattedName = utils.getAddOnFormatted(addOn);
        // Once you click 'Add', the 'Remove' button will be enabled.
        let otherAction = 'remove';
        if (action === 'remove') {
            otherAction = 'add';
        }
        if (addOn === 'FullUK') {
            addOnIdText = 'breakdown-cover-' + action + '-1';
            addOnIdTextNext = 'breakdown-cover-' + otherAction + '-1';
        } else if (addOn === 'RoadsideHome') {
            addOnIdText = 'breakdown-cover-' + action + '-2';
            addOnIdTextNext = 'breakdown-cover-' + otherAction + '-2';
        } else if (addOn === 'Roadside') {
            addOnIdText = 'breakdown-cover-' + action + '-3';
            addOnIdTextNext = 'breakdown-cover-' + otherAction + '-3';
        } else if (addOn.substr(0, 4) === 'euro') {
            addOnIdText = 'eu-breakdown-' + action;
            addOnIdTextNext = 'eu-breakdown-' + otherAction;
        } else if (addOn === 'ProtectedNoClaimDiscount') {
            addOnIdText = action + '-policy-' + 'MOTNoClaimDisc' + 'Cov';
            addOnIdTextNext = otherAction + '-policy-' + 'MOTNoClaimDisc' + 'Cov';
        } else {
            addOnIdText = action + '-policy-MOT' + addOn + 'Cov';
            addOnIdTextNext = otherAction + '-policy-MOT' + addOn + 'Cov';
        }
        const addOnCount = await this.addOnTitle.count();
        for (let i = 0; i < addOnCount; i++) {
            const addOnName = await this.addOnTitle.get(i).getText();
            if ((addOnName === addOnFormattedName) && !(addOnFound)) {
                addOnIndex = i;
                addOnFound = true;
                addOnAnnualPrice = await this.getAddOnPrice(addOnIndex, addOn);
                if (action === 'add') {
                    newExpectedAnnualPremiumPrice = utils.roundDownPrice((await this.getDisplayedPremiumPrices() + addOnAnnualPrice), 2);
                } else {
                    newExpectedAnnualPremiumPrice = utils.roundDownPrice((await this.getDisplayedPremiumPrices() - addOnAnnualPrice), 2);
                }
                setExpectedPremiumPrice(newExpectedAnnualPremiumPrice);
                await browser.executeScript('window.scrollTo(0,10);');
                await browser.sleep(500);
                await this.closeChat();
                await browser.wait(EC.elementToBeClickable(element(by.id(addOnIdText))), 5000, 'AddOn element Not located..');
                await element(by.id(addOnIdText)).click();
                await browser.sleep(6000);
                await browser.waitForAngular();
                if (addOn === 'ProtectedNoClaimDiscount' && action === 'add' && await (this.pncdYearlyOnLightBox.isPresent()) === true) {
                    await this.addPNCD(addOnAnnualPrice);
                }
                await browser.wait(EC.elementToBeClickable(element(by.id(addOnIdTextNext))), 5000, 'Button label not changed..');
                setAddOnOperation(true);
                break;
            }
        }
    }

    async addPNCD(addOnAnnualPrice: any) {
        await browser.wait(EC.visibilityOf(this.pncdYearlyOnLightBox), 10000, 'Timed out, Cant locate the PNCD value on NCD LightBox..');
        expect(utils.formatPrices(await this.pncdYearlyOnLightBox.getText())).to.equal(addOnAnnualPrice);
        await this.closeChat();
        await this.elementAction('click', this.ncdLightBoxAddToPolicyButton);
    }

    async getAddOnPrice(addOnIndex: number, addOnName: string): Promise<number> {
        let addOnAnnualPrice = 0.00;
        let annualIndex = 0;
        let monthlyIndex = 0;
        // setting indexes for annual & monthly price of the selected addOn based on the index of addOn.
        if (addOnIndex === 0) {
            annualIndex = 0;
            monthlyIndex = 1;
        } else if (addOnIndex === 1) {
            annualIndex = 2;
            monthlyIndex = 3;
        } else if (addOnIndex === 2) {
            annualIndex = 4;
            monthlyIndex = 5;
        } else if (addOnIndex === 4) {
            annualIndex = 8;
            monthlyIndex = 9;
        }
        if (addOnName === 'FullUK') {
            addOnAnnualPrice = utils.formatPrices(await this.breakDownPrice.get(0).getText());
        } else if (addOnName === 'RoadsideHome') {
            addOnAnnualPrice = utils.formatPrices(await this.breakDownPrice.get(1).getText());
        } else if (addOnName === 'Roadside') {
            addOnAnnualPrice = utils.formatPrices(await this.breakDownPrice.get(2).getText());
        } else {
            addOnAnnualPrice = utils.formatPrices(await this.addOnPriceText.get(annualIndex).getText());
        }
        return await Promise.resolve(addOnAnnualPrice);
    }

    async getPremiumBrowserSessionDetails(): Promise<boolean> {
        let isCompPlusPresent = false;
        let premiumSession = null;
        premiumSession = await browser.driver.executeScript('return window.sessionStorage.getItem("app-session-premium");');
        if (premiumSession) {
            this.premiumSession = JSON.parse(premiumSession.toString());
            if (!getEdit() && !isIndicative() && !this.quoteDetailsPrinted) {
                this.quoteDetailsPrinted = true;
            }
            this.premiumSession.result.quoteData.offeredQuotes.forEach(offering => {
                if (offering.branchCode === 'comp') {
                    setPremiumCompPrice(offering.premium.total.amount);
                    if (!getIsdrivexpertPresent()) {
                        setSelectedPremiumType('comp');
                        setExpectedPremiumPrice(offering.premium.total.amount);
                    }
                } else if (offering.branchCode === 'compplus') {
                    isCompPlusPresent = true;
                    setIsCompPlusPresent(true);
                    setIsCompPresent(true);
                    setPremiumCompPlusPrice(offering.premium.total.amount);
                } else if (offering.branchCode === 'tpft') {
                    setIsTpftPresent(true);
                    setPremiumTpftPrice(offering.premium.total.amount);
                } else if (offering.branchCode === 'drivexpert') {
                    setSelectedPremiumType('drivexpert');
                    setIsdrivexpertPresent(true);
                    setDriveXpertPrice(offering.premium.total.amount);
                    setExpectedPremiumPrice(offering.premium.total.amount);
                }
            });
            this.setExpectedQuotePrices();
            await this.checkAndSetPaymentOptions();
        } else {
            resetGlobals();
            console.error('Quote request failed.. Aborting the test..');
            await browser.quit();
            process.abort();
        }
        return await Promise.resolve(isCompPlusPresent);
    }

    async verifyPremiumPricesAfterAddOnOperation(action: string) {
        if (getAddOnOperation()) {
            await this.assertQuoteValues('addOn', action);
        }
    }

    async assertQuoteValues(addOn?: string, action?: string) {
        const summaryTabTotal = await this.getDisplayedPremiumPrices();
        if (action === 'adding' || action === 'removing') {
            const expectedPrice = getExpectedPremiumPrice();
            await expect(summaryTabTotal).to.equal(expectedPrice);
        } else {
            const expectedPrice = getExpectedPremiumPrice();
            await expect(summaryTabTotal).to.equal(expectedPrice);
        }
    }

    async verifyPersonalGreeting() {
        let greetingName: string;
        const fName = getFirstName().trim();
        await browser.wait((EC.visibilityOf(this.titleGreeting)), 5000, 'Timed out, greeting not displayed on premium page..');
        greetingName = await this.titleGreeting.getText();
        greetingName = greetingName.toString().trim().substring(4);
        await expect(greetingName).to.equal(fName);
    }

    async displayIndicativeQuoteWarning() {
        await browser.wait((EC.visibilityOf(this.quoteWarning)), 5000, 'Timed out, Indicative Quote Warning not displayed..');
        setIndicativeQuote();
    }

    private async checkAndSetPaymentOptions() {
        if (await this.mothlyPaymentWarning.isPresent()) {
            setIsYearlyPayment();
        }
    }

    async verifyDisplayOfDifferentQuotesOnPremiumPage() {
        let text_to_compare: string;
        const configData = await browser.getProcessedConfig();
        const premium = await this.getPremiumBrowserSessionDetails();
        switch (getSelectedPremiumType()) {
            case 'drivexpert': {
                await this.assertPremiumStickyTabPrices('DriveXpert', getDriveXpertPrice());
                // If CompPlus available, Click on the hyperlink to open up CompPlus and assert the prices
                if (getIsCompPlusPresent()) {
                    await this.compPlusSelection.click();
                    await browser.waitForAngular();
                    text_to_compare = 'Comprehensive Plus';
                    // Check if it is a mobile device. The Premium Types are shortened for mobile devices.
                    if (configData.capabilities.real_mobile) {
                        text_to_compare = 'Comp Plus';
                    }
                    await this.assertPremiumStickyTabPrices(text_to_compare, getPremiumCompPlusPrice());
                    // Move back to Drive Xpert and assert the prices
                    await this.backBtnTelematics.click();
                    await this.assertPremiumStickyTabPrices('DriveXpert', getDriveXpertPrice());
                    // TODO: Click on Comp and assert description and premium price
                }
                return;
            }
            case 'comp': {
                await this.assertPremiumStickyTabPrices('Comprehensive', getPremiumCompPrice());
                // TODO: Click on Comp Plus and assert description and premium price
                return;
            }
            case 'compplus': {
                text_to_compare = 'Comprehensive Plus';
                // Check if it is a mobile device. The Premium Types are shortened for mobile devices.
                if (configData.capabilities.real_mobile) {
                    text_to_compare = 'Comp Plus';
                }
                await this.assertPremiumStickyTabPrices(text_to_compare, getPremiumCompPlusPrice());
                return;
            }
            case 'default': {
                expect(getSelectedPremiumType()).to.not.equal('');
                return;
            }
        }
    }

    async getDisplayedPremiumPrices(): Promise<number> {
        let summaryTabTotal: string;
        let summaryTabTotalFormatted: number;
        summaryTabTotal = await this.summaryTabTotalPart1.getText();
        summaryTabTotal += await this.summaryTabTotalPart2.getText();
        summaryTabTotalFormatted = utils.formatPrices(summaryTabTotal);
        return await Promise.resolve(summaryTabTotalFormatted);
    }

    async assertPremiumStickyTabPrices(quoteDescription: string, quoteTotal: number) {
        let premiumDescription: string;
        await browser.waitForAngular();
        const summaryTabTotal = await this.getDisplayedPremiumPrices();
        if (await $$('.tab-selected').first().$('.summary__item-container').$('.summary__sub-title-text').isPresent()) {
            premiumDescription = await $$('.tab-selected').first().$('.summary__item-container').$('.summary__sub-title-text').getText();
        } else if (await $('.summary__telematics-with-btn').isPresent()) {
            premiumDescription = await $('.summary__telematics-with-btn').getText();
        }
        expect(premiumDescription).to.equal(quoteDescription);
        expect(summaryTabTotal).to.equal(quoteTotal);
    }

    private setExpectedQuotePrices() {
        switch (getSelectedPremiumType()) {
            case 'comp': {
                setExpectedPremiumPrice(getPremiumCompPrice());
                break;
            }
            case 'compplus': {
                setExpectedPremiumPrice(getPremiumCompPlusPrice());
                break;
            }
            case 'drivexpert': {
                setExpectedPremiumPrice(getDriveXpertPrice());
                break;
            }
            case 'tpft': {
                setExpectedPremiumPrice(getPremiumTpftPrice());
            }
        }
    }
}
