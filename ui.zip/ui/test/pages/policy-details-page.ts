import { browser, by, element, ExpectedConditions } from 'protractor';
import { BasePage } from './base-page';
const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;
const EC = ExpectedConditions;

export class PolicyDetailsPage extends BasePage {

    private ownHomeYes = element(by.css('label[for="' + 'ownHome-Yes' + '"]'));
    private ownHomeNo = element(by.css('label[for="' + 'ownHome-No' + '"]'));
    private vehiclesAtHomeOne = element(by.css('label[for="' + 'totalVehicles-1' + '"]'));
    private vehiclesAtHomeThree = element(by.css('label[for="' + 'totalVehicles-3' + '"]'));
    private policyPaidMonthly = element(by.css('label[for="' + 'isPolicyPaidMonthly-Monthly' + '"]'));
    private otherPoliciesNo = element(by.css('label[for="' + 'hasHouseholdOtherPolicy-No' + '"]'));
    private otherPoliciesYes = element(by.css('label[for="' + 'hasHouseholdOtherPolicy-Yes' + '"]'));
    private cancelledPoliciesYes = element(by.css('label[for="' + 'cancelByInsurerInd-Yes' + '"]'));
    private cancelledPoliciesNo = element(by.css('label[for="' + 'cancelByInsurerInd-No' + '"]'));
    private getQuoteButton = element(by.id('getQuote'));
    private confirmation = element(by.css('.dlg-checkbox'));
    private captchaCheckBox = element(by.css('.recaptcha-checkbox-border'));
    private reCaptchaIframe = element(by.tagName('re-captcha')).element(by.tagName('iframe'));
    private promoCode = element(by.id('promoCode'));

    async applyPromoCode(promoCode: string) {
        await this.elementAction('sendKeys', this.promoCode, promoCode);
    }

    async addPolicyDetails() {
        await this.elementAction('click', this.ownHomeNo);
        await this.elementAction('click', this.vehiclesAtHomeOne);
        await this.elementAction('click', this.policyPaidMonthly);
        await this.elementAction('click', this.confirmation);
        await this.elementAction('click', this.otherPoliciesNo);
        await this.elementAction('click', this.cancelledPoliciesNo);
    }

    async addPolicyDetailsExtra() {
        await this.elementAction('click', this.ownHomeNo);
        await this.elementAction('click', this.vehiclesAtHomeThree);
        await this.elementAction('click', this.policyPaidMonthly);
        await this.elementAction('click', this.confirmation);
        await this.elementAction('click', this.otherPoliciesYes);
        await this.elementAction('click', this.cancelledPoliciesYes);
    }

    async cancelledPolicyYes() {
        await this.cancelledPoliciesYes.click();
    }

    async captchaCheck() {
        await browser.waitForAngularEnabled(false);
        await browser.wait(EC.presenceOf(this.reCaptchaIframe), 5000, 'Captcha iFrame not present..');
        await browser.wait(browser.switchTo().frame(await this.reCaptchaIframe.getWebElement()), 5000, 'Sorry, timed out, could not switch to captcha iframe..');
        await browser.wait(EC.presenceOf(this.captchaCheckBox), 5000, 'Captcha checkbox not present..');
        await this.elementAction('click', this.captchaCheckBox);
        await browser.sleep(4000);
        await browser.waitForAngularEnabled(true);
        await browser.switchTo().defaultContent();
    }

    async checkConfirmation() {
        await this.elementAction('click', this.confirmation);
    }

    async getQuote() {
        await this.elementAction('click', this.getQuoteButton);
    }
}
