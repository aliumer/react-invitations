import { enableProdMode, Injector } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { MainModule } from '@app/main/main.module';

import { EnvService } from '@app/core/services/configs/env.service';
import { EnvServiceProvider } from '@app/core/services/providers/env.service.provider';
import { environment } from '@env/environment';
import {Brand} from '@app/core/enum/brand-type';

const injector = Injector.create({ providers: [EnvServiceProvider] });
const envService = injector.get(EnvService);

if (envService.production) {
  enableProdMode();
}

const script = document.createElement('script');
script.src = envService.analyticsScript;
script.async = true;
document.head.appendChild(script);

// if (environment.brand_dlg === Brand.Privilege && envService.optimizerScript) {
//   const optimizelyScript = document.createElement('script');
//   optimizelyScript.src = envService.optimizerScript;
//   optimizelyScript.async = true;
//   optimizelyScript.id = 'optimizely';
//   document.head.appendChild(optimizelyScript);
// }

if (environment.brand_dlg === Brand.DirectLine) {
  const trustpilotScript = document.createElement('script');
  trustpilotScript.src = '//widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js';
  trustpilotScript.async = true;
  trustpilotScript.id = 'trustpilot';
  document.head.appendChild(trustpilotScript);
}

if (window.dlg_dolphin) {
  window.dlg_dolphin.brand = environment.brand_copy.brand;
  window.dlg_dolphin.architecture = 'SPA';
  window.dlg_dolphin.type = 'Quote And Buy';
}

if (envService.tealiumSyncScript) {
  const tealiumSyncScript = document.createElement('script');
  tealiumSyncScript.src = envService.tealiumSyncScript;
  document.head.appendChild(tealiumSyncScript);
}

if (envService.tealiumScript) {
  const tealiumScriptSettings = document.createElement('script');
  tealiumScriptSettings.innerText = 'window.utag_cfg_ovrd = { noview : true };';
  document.body.appendChild(tealiumScriptSettings);
  const tealiumScript = document.createElement('script');
  tealiumScript.src = envService.tealiumScript;
  document.body.appendChild(tealiumScript);
}

platformBrowserDynamic().bootstrapModule(MainModule)
.catch(err => console.error(err));
