export const copy = {
  brand: 'Churchill',
  brandSimple: 'churchill',
  brandCAPCode: 'CHU',
  url: 'https://www.churchill.com/',
  phoneNumber: '0345 877 6244',
  serviceUserNumber: '290695',
  cookieUrl: 'https://www.churchill.com/about-us/cookies-notice',
  footer: [
    {
      label: 'Accessibility',
      url: 'https://www.churchill.com/accessibility',
      ariaLabel: 'Our accessibility information opens in a new window'
    },
    {
      label: 'About us',
      url: 'https://www.churchill.com/about-us',
      ariaLabel: 'Our about us information opens in a new window'
    },
    {
      label: 'Privacy',
      url: 'https://u-k-insurance.co.uk/brands-policy.html',
      ariaLabel: 'Our privacy information opens in a new window'
    },
    {
      label: 'Telematics privacy',
      url: 'https://www.churchill.com/car-insurance/black-box-original/privacy',
      ariaLabel: 'Our telematics privacy information opens in a new window'
    },
    {
      label: 'DriveSure app privacy',
      url: 'https://www.churchill.com/car-insurance/drivesure-telematics/privacy',
      ariaLabel: 'Our DriveSure app privacy information opens in a new window'
    },
    {
      label: 'Site map',
      url: 'https://www.churchill.com/site-map',
      ariaLabel: 'Our site map opens in a new window'
    },
    {
      label: 'Contact us',
      url: 'https://www.churchill.com/contact-us',
      ariaLabel: 'Our Contact us information opens in a new window'
    }
  ],
  telematics: {
    selfInstalledText: `We will send you a telematics 'black box' device for you to install in your vehicle once you have purchased your policy.`,
    hardwiredText: `We will arrange installation of your telematics 'black box' by our technicians once you have purchased your policy.`,
    link: `www.myDriveSure.com`,
    url: `http://www.mydrivesure.com`,
    coverTypeName: `DriveSure`,
    privacyPolicyLinks: {
      app: {
        url: 'https://www.churchill.com/car-insurance/drivesure-telematics/privacy',
      },
      box: {
        url: 'https://www.churchill.com/car-insurance/black-box-original/privacy',
      }
    }
  },
  saveQuoteModal: {
    singleCar: `Already got an account? Find your partial quote in your Dashboard. If you're new to Churchill, we've emailed you details on how to activate your account.`,
    multiCar: `Already got an account? Find your unfinished quote in your Dashboard. If you're new to Churchill, we've emailed you details on how to activate your account. View all your Multicar quotes now in your Multicar summary.`
  },
  vehicleNotPurchased: {
    type: 'vehicleNotPurchased',
    heading: 'Will you own your car by the time your policy starts?',
    copy: `As you haven’t bought your car yet please confirm you will be the owner of the car by the time the policy starts.`
  },
  review: {
    midTermAdjustment: 'Mid-term adjustments to your policy made through your Digital Account do not incur an administration fee. However, an additional premium may apply as a result of the amendment. Mid-term adjustments to your policy made through our contact centre, or requests for duplicate documents of your car insurance policy, may result in an administration fee of up to £26.88 (including IPT where applicable). An additional premium may also apply as a result of the amendment.',
    link: {
      pidBaseUrl: 'https://assets.churchill.com/motor-docs/',
      pidBaseUrlQA: 'https://b4csassets-qa-ch.qa.dlgdigitalapi.com/motor-docs/',
      policyDocumentLink: 'policy-booklet',
      breakdownCoverLink: 'rescue-booklet',
      letusknowLink: 'https://www.churchill.com/contact-us/complaints'
    },
    cancellations: {
      line1: 'If you cancel your policy before it starts, you’ll get a full refund for both the car insurance and breakdown cover, where selected.',
      line2: 'If you cancel within 14 days of cover starting (or receiving your documents – whichever is later) we’ll return any premium or breakdown cover paid, less a charge for the number of days your policy has been active, on the condition that no claim has been made.',
      line3: 'If you cancel after 14 days of cover, we’ll return any premium paid (less a charge for the number of days your policy has been active), in addition to an administration fee of £53.76 for car insurance and £11.20 for breakdown cover. All payments include Insurance Premium Tax where applicable.'
    }
  },
  premium: {
    coverTypeName: `DriveSure`,
    excess: {
      accidentalDamageCopy: `Excess for accidental damage varies from driver to driver, depending on age and driving experience.`
    },
    extras: {
      legalPhoneNumber: `0345 246 2408`
    }
  },
  yourCar: {
    pageTitle: 'About the car',
    carDetailsButton : `Enter your car details`,
    manualSearchCopy: `	We can give you a quote based on information you give us, but please remember, the price we quote for your insurance policy is subject to change until you confirm your registration number.`,
    vanInsuranceLink: `https://www.churchill.com/car-insurance/van-insurance`
  },
  yourDetails: {
    pageTitle: 'About you',
    amendDetails: 'Update your address details.',
    updateAddressDetails: 'Update your address details',
    correctDetailsCopy: `Please check that you’ve entered all your information correctly and
    you haven’t missed anything. We’ll use your contact details to create your online account where you
    can find all your saved quotes, policies and documents. It’ll be harder to change these details after you
    click ‘Next’ or ‘Save’.`
  },
  discounts: {
    whereYouPark: 'Where do you park it?',
    yourNoClaimDiscountCopy: 'Tell us how many years (or months) No Claim Discount (NCD) you have built up as it may reduce the cost of your insurance. But first, tell us:'
  },
  summary: {
    pageTitle: 'Running summary',
  }
};
