export const copy = {
  brand: 'Direct Line',
  brandSimple: 'directline',
  brandCAPCode: 'DLI',
  url: 'https://www.directline.com/',
  phoneNumber: '0345 878 5578',
  serviceUserNumber: '290696',
  cookieUrl: 'https://www.directline.com/cookies-notice',
  footer: [
    {
      label: 'Accessibility',
      url: 'https://www.directline.com/accessibility',
      ariaLabel: 'Our accessibility information opens in a new window'
    },
    {
      label: 'About us',
      url: 'https://www.directline.com/about-us',
      ariaLabel: 'Our about us information opens in a new window'
    },
    {
      label: 'Privacy',
      url: 'https://u-k-insurance.co.uk/brands-policy.html',
      ariaLabel: 'Our privacy information opens in a new window'
    },
    {
      label: 'Telematics privacy',
      url: 'https://www.directline.com/car-insurance/telematics/black-box/privacy',
      ariaLabel: 'Our telematics privacy information opens in a new window'
    },
    {
      label: 'Legal',
      url: 'https://www.directline.com/legal/terms',
      ariaLabel: 'Our legal information opens in a new window'
    },
    {
      label: 'Site map',
      url: 'https://www.directline.com/site-map',
      ariaLabel: 'Our site map opens in a new window'
    },
    {
      label: 'Contact us',
      url: 'https://www.directline.com/contact-us',
      ariaLabel: 'Our Contact us information opens in a new window'
    }
  ],
  telematics: {
    selfInstalledText: `We will send you a telematics 'black box' device for you to install in your vehicle once you have purchased your policy.`,
    hardwiredText: `We will arrange installation of your telematics 'black box' by our technicians once you have purchased your policy.`,
    link: `www.myDrivePlus.com`,
    url: `http://www.mydriveplus.com`,
    coverTypeName: `DrivePlus`,
    privacyPolicyLinks: {
      app: {
        url: 'https://www.directline.com/car-insurance/driveplus-telematics/privacy',
      },
      box: {
        url: 'https://www.directline.com/car-insurance/telematics/black-box/privacy',
      }
    }
  },
  saveQuoteModal: {
    singleCar: `Already got an account? Find your partial quote in your Dashboard. If you're new to Direct Line, we've emailed you details on how to activate your account.`,
    multiCar: `Already got an account? Find your unfinished quote in your Dashboard. If you're new to Direct Line, we've emailed you details on how to activate your account. View all your Multicar quotes now in your Multicar summary.`
  },
  review: {
    midTermAdjustment: `Mid-term adjustments to, or requests for duplicate documents of your car insurance policy do not incur an administration fee. However, an additional premium may apply as a result of the amendment.`,
    link: {
      pidBaseUrl: 'https://assets.directline.com/motor-docs/',
      pidBaseUrlQA: 'https://b4csassets-qa-dl.qa.dlgdigitalapi.com/motor-docs/',
      policyDocumentLink: 'policy-booklet',
      breakdownCoverLink: 'rescue-booklet',
      letusknowLink: 'https://www.directline.com/complaints'
    },
    cancellations: {
      line1: 'If you cancel your policy before it starts, you’ll get a full refund for both the car insurance and breakdown cover, where selected.',
      line2: 'If you cancel within 14 days of your cover starting (or receiving your documents – whichever is later) we’ll return any premium paid for your car insurance (less a charge for the number of days your policy has been active) and a full refund for the breakdown cover on the condition that no claim has been made.',
      line3: 'If you cancel after 14 days of cover, we’ll return any premium paid (less a charge for the number of days your policy has been active), in addition to an administration fee of £48.16 for car insurance. All payments include Insurance Premium Tax where applicable.'
    }
  },
  premium: {
    coverTypeName: `DrivePlus`,
    excess: {
      accidentalDamageCopy: `Excess for accidental damage varies from driver to driver, depending on age and driving experience.`
    },
    extras: {
      legalPhoneNumber: `0345 877 6371`
    }
  },
  yourCar: {
    pageTitle: 'About the car',
    carDetailsButton : 'Enter my car details',
    manualSearchCopy: `We can give you a quote based on information you give us, but please remember, the price we quote for your insurance policy is subject to change until you confirm your registration number.`,
    vanInsuranceLink: `https://www.directlineforbusiness.co.uk/van-insurance`
  },
  yourDetails: {
    pageTitle: 'About you',
    amendDetails: 'Update your address details.',
    updateAddressDetails: 'Update your address details',
    correctDetailsCopy: `Please check that you’ve entered all your information correctly and
    you haven’t missed anything. We’ll use your contact details to create your online account where you
    can find all your saved quotes, policies and documents. It’ll be harder to change these details after you
    click ‘Next’ or ‘Save’.`
  },
  discounts: {
    whereYouPark: 'Where do you park it?',
    yourNoClaimDiscountCopy: 'Built up No Claim Discount (NCD) may reduce the cost of your car insurance and reduce the cost of your premiums in the future.'
  },
  summary: {
    pageTitle: 'Multicar summary',
  }
};
