import { DlgData } from 'dlg-dolphin/dist/lib/interfaces/dlg-data';
import { DlgDolphin } from 'dlg-dolphin/dist/lib/dolphin/dlg-dolphin';

declare global {
  interface Window {
    dlg_dolphin: DlgDolphin;
    dlg_data: DlgData;
    // embedded_svc: any;
    utag?: any;
  }
}
