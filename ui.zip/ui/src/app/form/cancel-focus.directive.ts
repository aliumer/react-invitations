import { Directive, ElementRef, HostListener } from '@angular/core';

/**
 * TODO: consider removing this from templates as it can cause issues with accessibility
 * Used to remove focus from html elements upon click
 */
@Directive({
    selector: '[appCancelFocus]'
})
export class CancelFocusDirective {
    /**
         * Constructor for directive
         * @param {ElementRef} private el - the current element
         */
    constructor(private el: ElementRef) {

    }

    /**
     * Removes focus from element
     * @param {[type]} 'click') onclick - the event to bind to
     */
    @HostListener('click') onclick() {
        this.el.nativeElement.blur();
    }
}
