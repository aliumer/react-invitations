import { TestBed, inject } from '@angular/core/testing';
import { FormBuilder, Validators } from '@angular/forms';

import { FormService } from './form.service';

import { ControlType } from '@app/core/enum/control-type';

describe('FormService tests', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [FormService]
        });
    });

    it('Should map all controls within object to the form object',
        inject([FormService], (service: FormService<any>) => {
            const formProperties = {
                occupation: {
                    name: 'occupation',
                    label: 'Enter the first 3 letters of your job title and select your title from the list',
                },
                industry: {
                    name: 'industry',
                    label: 'industry',
                }
            };
            const fb = new FormBuilder();
            const form = service.mapForm(fb.group({}), formProperties);
            expect(form.get('occupation')).not.toBe(null);
            expect(form.get('industry')).not.toBe(null);
        })
    );

    it('Should map an object controlType DateArray to the form object',
        inject([FormService], (service: FormService<any>) => {
            const formProperties = {
                policyStartDate: {
                    name: 'policyStartDate',
                    label: 'When do you want your policy to start?',
                    controlType: ControlType.DateArray,
                }
            };
            const fb = new FormBuilder();
            const form = service.mapForm(fb.group({}), formProperties);
            expect(form.get('policyStartDate').constructor.name).toBe('FormArray');
        })
    );

    it('Should map an object controlType FormArray to the form object',
        inject([FormService], (service: FormService<any>) => {
            const formProperties = {
                occupation: {
                    name: 'occupation',
                    label: 'Enter the first 3 letters of your job title and select your title from the list',
                    controlType: ControlType.Array,
                },
                industry: {
                    name: 'industry',
                    label: 'industry',
                }
            };
            const fb = new FormBuilder();
            const form = service.mapForm(fb.group({}), formProperties);
            expect(form.get('occupation').constructor.name).toBe('FormArray');
        })
    );

    it('Should map an object controlType of Control to the form object',
        inject([FormService], (service: FormService<any>) => {
            const formProperties = {
                occupation: {
                    name: 'occupation',
                    label: 'Enter the first 3 letters of your job title and select your title from the list',
                    controlType: ControlType.Array,
                },
                industry: {
                    name: 'industry',
                    label: 'industry',
                    controlType: ControlType.Control
                }
            };
            const fb = new FormBuilder();
            const form = service.mapForm(fb.group({}), formProperties);
            expect(form.get('industry').constructor.name).toBe('FormControl');
        })
        );

    it('Should map an object with controlType of Control as default',
        inject([FormService], (service: FormService<any>) => {
            const formProperties = {
                occupation: {
                    name: 'occupation',
                    label: 'Enter the first 3 letters of your job title and select your title from the list',
                    controlType: ControlType.Array,
                },
                industry: {
                    name: 'industry',
                    label: 'industry'
                }
            };
            const fb = new FormBuilder();
            const form = service.mapForm(fb.group({}), formProperties);
            expect(form.get('industry').constructor.name).toBe('FormControl');
        })
    );

    it('Should map an object controlType of FormGroup to the form object',
        inject([FormService], (service: FormService<any>) => {
            const formProperties = {
                regKnown: {
                    name: 'regKnown',
                    label: 'Do you know the registration number?',
                    options: ['Yes', 'No'],
                    displayValue: 'value',
                    validation: [Validators.required]
                },
                vehicle: {
                    controlType: ControlType.FormGroup,
                    reg: {
                        name: 'reg',
                        validation: [Validators.required]
                    },
                    make: {
                        name: 'make',
                        validation: [Validators.required]
                    },
                    model: {
                        name: 'model',
                        validation: [Validators.required]
                    }
                }
            };

            const fb = new FormBuilder();
            const form = service.mapForm(fb.group({}), formProperties);
            expect(form.get('vehicle').constructor.name).toBe('FormGroup');
        })
    );

    it('Should update the form controls validity',
        inject([FormService], (service: FormService<any>) => {
            const formProperties = {
                regKnown: {
                    name: 'regKnown',
                    label: 'Do you know the registration number?',
                    options: ['Yes', 'No'],
                    displayValue: 'value',
                    validation: [Validators.required]
                },
                vehicle: {
                    controlType: ControlType.FormGroup,
                    reg: {
                        name: 'reg',
                        validation: [Validators.required]
                    },
                    make: {
                        name: 'make',
                        validation: [Validators.required]
                    },
                    model: {
                        name: 'model',
                        validation: [Validators.required]
                    }
                }
            };

            const fb = new FormBuilder();
            const form = service.mapForm(fb.group({}), formProperties);
            expect(form.get('regKnown').dirty).toBe(false);
            expect(form.get('regKnown').touched).toBe(false);
            service.updateControlValidity(form);
            expect(form.get('regKnown').dirty).toBe(true);
            expect(form.get('regKnown').touched).toBe(true);
        })
    );

    it('Should set data to form controls',
        inject([FormService], (service: FormService<any>) => {
            const formProperties = {
                regKnown: {
                    name: 'regKnown',
                    label: 'Do you know the registration number?',
                    options: ['Yes', 'No'],
                    displayValue: 'value',
                    validation: [Validators.required]
                }
            };

            const formData = {
                regKnown: 'Yes'
            };

            const fb = new FormBuilder();
            const form = service.mapForm(fb.group({}), formProperties);
            service.setFormControlValues(form, formData);
            expect(form.get('regKnown').value).toBe('Yes');
        })
        );

    it('Should reset a form control',
        inject([FormService], (service: FormService<any>) => {
            const formProperties = {
                regKnown: {
                    name: 'regKnown',
                    label: 'Do you know the registration number?',
                    options: ['Yes', 'No'],
                    displayValue: 'value',
                    validation: [Validators.required]
                }
            };

            const fb = new FormBuilder();
            const form = service.mapForm(fb.group({}), formProperties);

            form.get('regKnown').setValue('Yes');
            expect(form.get('regKnown').value).toBe('Yes');

            service.resetFormControl(form, 'regKnown');
            expect(form.get('regKnown').value).toBe(null);
            expect(form.get('regKnown').touched).toBe(false);
            expect(form.get('regKnown').dirty).toBe(false);
        })
    );
});
