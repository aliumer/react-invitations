import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { TestComponent } from '../shared/test-helper/test.component';
import { CancelFocusDirective } from './cancel-focus.directive';

describe('Cancel focus directive', () => {
    let component: TestComponent;
    let fixture: ComponentFixture<TestComponent>;
    let inputEl: any;

    beforeEach(async(() => {
        TestBed.overrideComponent(TestComponent, {
            set: {
                template: '<button class="dlg-button" appCancelFocus>'
            }
        });
        TestBed.configureTestingModule({
            declarations: [CancelFocusDirective, TestComponent]
        })
        .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(TestComponent);
        component = fixture.componentInstance;
        inputEl = fixture.debugElement.query(By.directive(CancelFocusDirective));
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should cancel focus', () => {
        inputEl.triggerEventHandler('click', null);
        fixture.detectChanges();
        const focusedElement = inputEl.query(By.css(':focus'));
        expect(focusedElement).toBe(null);
    });
});
