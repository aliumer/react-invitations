import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, FormArray } from '@angular/forms';

import { ControlType } from '@app/core/enum/control-type';

/**
 * Generic class to allow controlling formgroups
 */
@Injectable()
export class FormService<T> {

     /**
     * Method sets and clears validators.
     */
    clearValidators(form: FormGroup, field: string): void {
        form.get(field).setErrors(null);
        form.get(field).clearValidators();
        form.updateValueAndValidity();
    }

    /**
     * Maps formgroup configuration object to a formgroup control
     * Does this by iterating over an object which contains ModelControl types
     * @param  {FormGroup} form - the form group
     * @param  {T} formProperties  - the type
     * @return {FormGroup} the mapped formgroup
     */
    mapForm(form: FormGroup, formProperties: T): FormGroup {
        Object.keys(formProperties).forEach((key) => {
            switch (formProperties[key].controlType) {
                case ControlType.DateArray:
                    form.addControl(key, new FormArray([new FormControl(''), new FormControl(''), new FormControl('')], Validators.compose(formProperties[key].validation)));
                    break;
                case ControlType.Array:
                    form.addControl(key, new FormArray([], Validators.compose(formProperties[key].validation)));
                    break;
                case ControlType.FormGroup:
                    const fb = new FormBuilder();
                    const formGroup = this.mapForm(fb.group({}), formProperties[key]);
                    form.addControl(key, formGroup);
                    break;
                default:
                    form.addControl(key, new FormControl('', formProperties[key].validation));
                    break;
            }
        });

        return form;
    }

    /**
     * Forces update of formgroup validity
     * @param {FormGroup} form - the current formgroup
     */
    updateControlValidity (form: FormGroup): void {
        for (const i in form.controls) {
            if (form.controls[i] !== null) {
                const control = form.controls[i];
                control.markAsTouched();
                control.markAsDirty();
                control.updateValueAndValidity();
            }
        }
    }

    /**
     * Patches data to associated formgroup controls
     * Basic method, currently does not map complex objects to form controls
     * @param {FormGroup} form - current formgroup
     * @param {any}       data - the data to patch to the form
     */
    setFormControlValues (form: FormGroup, data: any): void {
        Object.keys(form.controls).forEach((key) => {
            if (data[key] || data[key] === 0) {
                form.get(key).patchValue(data[key]);
                form.get(key).markAsDirty();
            }
        });
    }

  /**
   * resets a form controls value and state
   * @param form
   * @param control - the name of the form control
   * @param value - value to set the control to, by default null
   */
   resetFormControl(form: FormGroup, control: string, value = null): void {
     form.get(control).setValue(value);
     form.get(control).markAsPristine();
     form.get(control).markAsUntouched();
   }

   getValidatorList(form: FormGroup): any {
     const validatorList = {};
      Object.keys(form.controls).forEach((key) => {
        if (form.get(key).validator && form.get(key).validator.length > 0 && form.get(key).status === 'INVALID' && form.get(key).hasError) {
          validatorList[key] = form.get(key).errors;
        }
      });
      return validatorList;
   }
}
