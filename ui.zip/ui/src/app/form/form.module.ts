import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { CancelFocusDirective } from './cancel-focus.directive';
import { FormService } from './form.service';

@NgModule({
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    declarations: [
        CancelFocusDirective,
    ],
    exports: [
        CancelFocusDirective
    ],
    providers: [
        FormService
    ]
})
export class FormModule { }
