import { ModelControl } from './model-control';

/**
 * Represents a form group
 */
export interface ModelGroup {
   name: string;
   // Any subgroups of the group
   groups?: ModelGroup[];
   // Any form controls of the group
   controls?: ModelControl[];
}
