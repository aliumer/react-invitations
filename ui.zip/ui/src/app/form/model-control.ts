import { ValidatorFn } from '@angular/forms';
import { ControlType } from '@app/core/enum/control-type';

/**
 * Represents a form control within a form group
 */
export interface ModelControl {
    name: string;
    label?: string;
    options?: Array<any>;
    displayValue?: string;
    validation?: ValidatorFn[];
    validationMessages?: any;
    dynamicValidation?: boolean;
    hint?: any;
    placeholder?: string;
    controlType?: ControlType;
    display?: any;
    value?: any;
    ariaLive?: string;
    attrs?: any;
}
