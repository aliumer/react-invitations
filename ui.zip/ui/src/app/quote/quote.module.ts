import { NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { QuoteDataService } from '@app/shared/services/quote/quote.data.service';
import { throwIfAlreadyLoaded } from '@app/shared/utilities/module-import-guard';

@NgModule({
    imports: [
        CommonModule,
        HttpClientModule
    ],
    providers: [
        QuoteDataService,
    ]
})
export class QuoteModule {
    constructor(@Optional() @SkipSelf() parentModule: QuoteModule) {
        throwIfAlreadyLoaded(parentModule, 'QuoteModule Services');
    }
}
