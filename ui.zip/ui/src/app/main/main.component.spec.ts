
import { NavigationEnd } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs/observable/of';
import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { interval } from 'rxjs/observable/interval';
import { map, take } from 'rxjs/operators';

import { MainComponent } from './main.component';
import { HeaderComponent } from '@app/main/header/header.component';
import { FooterComponent } from '@app/main/footer/footer.component';
import { CookieComponent } from '@app/shared/components/cookie/cookie.component';
import { TrustPilotComponent } from '@app/main/trust-pilot/trust-pilot.component';
import { CustomerRatingComponent } from './customer-rating/customer-rating.component';

import { AnalyticsService } from '@app/core/services/analytics/analytics.service';
import { WebchatService } from 'dlg-angular-analytics';
import { JourneyConfigService } from '@app/core/services/configs/journey-config.service';
import { CookieService } from '@app/core/services/cookie/cookie.service';
import { LocationService } from '@app/journey/location/location.service';
import { StorageService } from '@app/core/services/storage/storage.service';
import { SalesforceWebchatService } from '@app/core/services/salesforce-webchat/salesforce-webchat.service';
import { SalesforceWebchatCodeSnippetsService } from '@app/core/services/salesforce-webchat/salesforce-webchat-code-snippets.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ProgressBarComponent } from '@app/main/progress-bar/progress-bar.component';
import { QuoteDataService } from '@app/shared/services/quote/quote.data.service';
import { QuoteService } from '@app/shared/services/quote/quote.service';
import { QuoteMapRequestService } from '@app/shared/services/quote/quote.map-request.service';
import { PremiumDataService } from '@app/core/services/data-services/premium-data.service';
import { QuoteMapResponseService } from '@app/shared/services/quote/quote.map-response.service';
import { OccupationService } from '@app/shared/services/occupation/occupation.service';
import { EnvService } from '@app/core/services/configs/env.service';
import { LoadingIndicatorModule } from '@app/shared/components/loading-indicator/loading-indicator.module';

import { PcwResponse } from '@app/quote/mock-data/mock-pcw-response';

describe('MainComponent', () => {
  let component: MainComponent;
  let fixture: ComponentFixture<MainComponent>;
  class MockRouterNavigationEnd {
    public events = of(new NavigationEnd(0, '/your-details', '/your-details'));
    public url = '/your-details';
  }

  class MockRouterNavigationEndWithEdit {
    public events = of(new NavigationEnd(0, '/your-details/edit', '/your-details/edit'));
    public url = '/your-details/edit';
  }
  class MockRouterNavigationEndForReviewPage {
    public events = of(new NavigationEnd(0, '/review', '/review'));
    public url = '/review';
  }
  class MockRouterNavigationEndPremiumPage {
    public events = of(new NavigationEnd(0, '/premium', '/premium'));
    public url = '/premium';
  }
  class MockRouterNavigationEndForPaymentsPage {
    public events = of(new NavigationEnd(0, '/payments', '/payments'));
    public url = '/payments';
  }

  const mockAnalyticsService = jasmine.createSpyObj('AnalyticsService', ['trackFeature', 'trackPage', 'mapAndTrack', 'setMotorQbOnLoad', 'trackPolicyOrQuote', 'setQuoteSubmissionData']);
  const mockWebchatService = jasmine.createSpyObj('WebchatService', ['setSection', 'routeChange', 'init']);
  const mockStorageService = jasmine.createSpyObj('StorageService', ['setJson', 'getJson']);

  beforeEach(async(() => {
    mockStorageService.getJson.and.returnValue(of(true));
    mockWebchatService.routeChange.and.returnValue(of({
      segments: 'testSegment',
    }));
    mockWebchatService.init.and.returnValue({
      brand: 'Privilege',
      product: 'Motor Q&B'
    });
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, LoadingIndicatorModule],
      declarations: [MainComponent, HeaderComponent, FooterComponent, CookieComponent, ProgressBarComponent, TrustPilotComponent, CustomerRatingComponent],
      providers: [
        JourneyConfigService,
        CookieService,
        { provide: WebchatService, useValue: mockWebchatService },
        { provide: AnalyticsService, useValue: mockAnalyticsService },
        { provide: StorageService, useValue: mockStorageService },
        LocationService,
        SalesforceWebchatService,
        SalesforceWebchatCodeSnippetsService,
        QuoteDataService,
        QuoteService,
        QuoteMapRequestService,
        QuoteMapRequestService,
        PremiumDataService,
        QuoteMapResponseService,
        OccupationService,
        EnvService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainComponent);
    component = fixture.componentInstance;
    component['scriptUrl'] = '';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should track page when a navigation ends', () => {
    component['router'] = <any>new MockRouterNavigationEnd();
    component['trackPage']();
    expect(component['analyticsService'].trackPage).toHaveBeenCalled();
  });

  it('should call WebChat Service Set section method', () => {
    component.ngOnInit();
    expect(mockWebchatService['setSection']).toHaveBeenCalled();
  });

  it('should call view method if there is a utag object available on window', () => {
    component['router'] = <any>new MockRouterNavigationEnd();
    window.utag = {
      view: () => { }
    };
    component['trackPage']();
    expect(mockAnalyticsService.trackPage).toHaveBeenCalled();
  });

  it('should update the active array on route change', () => {
    component['router'] = <any>new MockRouterNavigationEnd();
    component['progressBar']();
    expect(component.active.length).toEqual(2);
  });


  it('should set dynamic web page titles', () => {
    const spy = spyOn(component['platformBrowserTitle'], 'setTitle');
    component['activatedRoute'] = <any>{
      firstChild: {
        firstChild: {
          outlet: 'primary',
          data: of({ title: 'Your Details' })
        }
      }
    };
    component['router'] = <any>new MockRouterNavigationEnd();
    component['setPageTitle']();
    expect(spy).toHaveBeenCalledWith('Your Details');
  });

  it('should reduce number of page to track by one when multicar journey is found ', () => {
    component['router'] = <any>new MockRouterNavigationEnd();
    const spy = spyOn(component['quoteService'], 'isMulticarQuote');
    spy.and.returnValue(true);

    fixture.detectChanges();
    expect(component.routeArrayForSelectedPages.length).toBe(6);
  });

  it('should update the active array on route change on Edit', () => {
    component['router'] = <any>new MockRouterNavigationEndWithEdit();
    component['progressBar']();
    expect(component.active.length).toEqual(2);
  });

  it('show show trust pilot banner for premium, review and payments page (pcw only)', () => {
    component.brandCopy.brandSimple = 'churchill';
    const spy = spyOn(component['quoteService'], 'getStorageSession');
    spy.and.returnValue(PcwResponse);
    component['router'] = <any>new MockRouterNavigationEndPremiumPage();
    component['checkAndAddTrustPilotBanner']();
    expect(component.showTrustPilot).toBe(true);
    component['router'] = <any>new MockRouterNavigationEndForReviewPage();
    component['checkAndAddTrustPilotBanner']();
    expect(component.showTrustPilot).toBe(true);
    component['router'] = <any>new MockRouterNavigationEndForPaymentsPage();
    component['checkAndAddTrustPilotBanner']();
    expect(component.showTrustPilot).toBe(true);
    component['router'] = <any>new MockRouterNavigationEndWithEdit();
    component['checkAndAddTrustPilotBanner']();
    expect(component.showTrustPilot).toBe(false);
  });

});
