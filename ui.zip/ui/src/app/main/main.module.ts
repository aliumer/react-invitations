import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';

import { MainComponent } from './main.component';
import { MainRoutingModule } from './main-routing.module';
import { HttpClientModule } from '@angular/common/http';

import { AnalyticsService } from '@app/core/services/analytics/analytics.service';
import { WebchatService } from 'dlg-angular-analytics';
import { CookieService } from '@app/core/services/cookie/cookie.service';
import { StorageService } from '@app/core/services/storage/storage.service';
import { SalesforceWebchatService } from '@app/core/services/salesforce-webchat/salesforce-webchat.service';
import { SalesforceWebchatCodeSnippetsService } from '@app/core/services/salesforce-webchat/salesforce-webchat-code-snippets.service';

import { FooterComponent } from '@app/main/footer/footer.component';
import { HeaderComponent } from '@app/main/header/header.component';
import { CookieComponent } from '@app/shared/components/cookie/cookie.component';
import { LocationService } from '@app/journey/location/location.service';
import { AppConfigService, appConfigServiceFactory } from '@app/core/services/configs/app-config.service';
import { ProgressBarComponent } from '@app/main/progress-bar/progress-bar.component';
import { TrustPilotComponent } from '@app/main/trust-pilot/trust-pilot.component';
import { QuoteDataService } from '@app/shared/services/quote/quote.data.service';
import { QuoteService } from '@app/shared/services/quote/quote.service';
import { QuoteMapRequestService } from '@app/shared/services/quote/quote.map-request.service';
import { PremiumDataService } from '@app/core/services/data-services/premium-data.service';
import { QuoteMapResponseService } from '@app/shared/services/quote/quote.map-response.service';
import { OccupationService } from '@app/shared/services/occupation/occupation.service';
import { EnvService } from '@app/core/services/configs/env.service';
import { SharedModule } from '@app/shared/shared.module';
import { LoadingIndicatorModule } from '@app/shared/components/loading-indicator/loading-indicator.module';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {CustomerRatingComponent} from '@app/main/customer-rating/customer-rating.component';

@NgModule({
  imports: [
    BrowserModule,
    MainRoutingModule,
    HttpClientModule,
    SharedModule,
    LoadingIndicatorModule,
    NgbModule.forRoot()
  ],
  declarations: [
    FooterComponent,
    HeaderComponent,
    MainComponent,
    CookieComponent,
    ProgressBarComponent,
    TrustPilotComponent,
    CustomerRatingComponent
  ],
  providers: [
    AnalyticsService,
    WebchatService,
    SalesforceWebchatService,
    SalesforceWebchatCodeSnippetsService,
    LocationService,
    StorageService,
    Title,
    CookieService,
    AppConfigService,
    QuoteDataService,
    QuoteService,
    QuoteMapRequestService,
    QuoteMapRequestService,
    PremiumDataService,
    QuoteMapResponseService,
    OccupationService,
    EnvService,
    {
        provide: APP_INITIALIZER,
        useFactory: appConfigServiceFactory,
        multi: true,
        deps: [
          AppConfigService,
        ]
    }
  ],
  bootstrap: [MainComponent]
})
export class MainModule {
}
