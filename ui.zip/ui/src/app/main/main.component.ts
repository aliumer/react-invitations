import { Component, OnInit, Renderer2, AfterContentChecked } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router, NavigationEnd, ActivatedRoute, Data } from '@angular/router';
import { filter, map, mergeMap, take, switchMap, shareReplay } from 'rxjs/operators';
import { timer } from 'rxjs/observable/timer';

import { AnalyticsService } from '@app/core/services/analytics/analytics.service';
import { WebchatService } from 'dlg-angular-analytics';

import { SubCollector } from '@app/shared/utilities/sub-collector/subcollector';
import { LocationService } from '@app/journey/location/location.service';
import { SalesforceWebchatService } from '@app/core/services/salesforce-webchat/salesforce-webchat.service';
import { QuoteService } from '@app/shared/services/quote/quote.service';
import { FeatureType } from '@app/core/enum/feature-type';
import { CoverageType } from '@app/core/enum/coverage-type';
import { Brand } from '@app/core/enum/brand-type';
import { ChannelDlg } from '@app/core/enum/channel-dlg';

import { environment } from '@env/environment';
import { Observable } from 'rxjs/Observable';
import { CustomUtility } from '@app/shared/utilities/custom-utility';

/** Component for Progress bar */
@Component({
  selector: 'app-root',
  templateUrl: './main.component.html'
})
export class MainComponent implements OnInit, AfterContentChecked {

  /** Holds declared subscriptions */
  @SubCollector() subs;

  /** Array of routes for progress bar component */
  routeArray: Array<string> = [];

  routeArrayForSelectedPages: Array<string> = [];

  /** number to hold the position of route found in array */
  active: Array<number> = [];

  featureType = FeatureType;

  edit: any;

  pageUlr: string;

  brandCopy = environment.brand_copy;

  currentFeature: string;

  showTrustPilot = false;

  brand = Brand;

  showCustomerRating = false;

  loaded = false;

  private readonly maxAppStepsToShowMultiCar = 4;
  private readonly maxAppStepsToShow = 5;

  /**
   * Constructor for the component.
   * @param router Router
   * @param webchatService Webchat service
   * @param analyticsService Analytics Service
   * @param locationService LocationService
   * @param activatedRoute
   * @param platformBrowserTitle For Dynamic Page Titiles
   */

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private webchatService: WebchatService,
    private analyticsService: AnalyticsService,
    private locationService: LocationService,
    private platformBrowserTitle: Title,
    private salesforceService: SalesforceWebchatService,
    private renderer: Renderer2,
    private quoteService: QuoteService
  ) {
    this.salesforceService.renderer = this.renderer;
  }

  /** Called after the constructor */
  ngOnInit() {
    this.webchatHandler();
    this.trackPage();
    this.buildRouteArray();
    this.progressBar();
    this.setPageTitle();
    this.hidePageTrackerFromPage();
    this.checkAndAddTrustPilotBanner();

    /*
      Temporarily hide SF widget
    */
    // this.salesforceService.setBrand(this.brand);
    // if ( environment.brand_dlg === 'privilege' ) {
    //   this.initSalesforceWebchat();
    // }
  }

  ngAfterContentChecked(): void {
    if (this.quoteService.isMulticarQuote()) {
      const excludeYourDetails = [this.featureType.YourDetails] as Array<String>;
      this.routeArrayForSelectedPages = this.routeArrayForSelectedPages.filter((option) => excludeYourDetails.indexOf(option) === -1);
    }
  }

  /** Obserbable with the data relative of the routing NavigationEnd events related to the primary RouterOutlet */
  private get routerPrimaryNavigationEndEvents$(): Observable<Data> {
    return this.routeEventsNavigationEnd$.pipe(
      map(() => this.activatedRoute),
      map((route) => {
        while (route.firstChild) { route = route.firstChild; }
        return route;
      }),
      filter((route) => route.outlet === 'primary'),
      mergeMap((route) => route.data)
    );
  }

  /** Function that returns NavigationEnd observable, publishing it to the rest of the component */
  private get routeEventsNavigationEnd$(): Observable<NavigationEnd> {
    return this.router.events.pipe(

      filter((event) => event instanceof NavigationEnd),

      shareReplay()

    ) as Observable<NavigationEnd>;

  }


  /** Function that checks if journey is PCW; current pagge is premium/review/payments; brand is churchill and sets flag to show Trustpilot banner */
  private checkAndAddTrustPilotBanner() {
    this.routeEventsNavigationEnd$.subscribe((event: NavigationEnd) => {
      this.currentFeature = event.urlAfterRedirects.split('/')[1];
      const isPCW = !!CustomUtility.getSafe(() => this.quoteService.getStorageSession(FeatureType.Premium).result.baseData.channel_dlg === ChannelDlg.Pcw);
      const trustPilotFeatureIndex = [];
      const validFeatures = [FeatureType.Premium, FeatureType.ReviewAndConfirm, FeatureType.Payments];
      this.routeArray.forEach((featureName, index) => {
        if (validFeatures.includes(featureName as FeatureType)) {
          trustPilotFeatureIndex.push(index);
        }
      });
      const matchIndex = trustPilotFeatureIndex.find((t) => t === (this.routeArray.indexOf(this.currentFeature)));
      this.showTrustPilot = isPCW && (matchIndex !== undefined) && (this.brandCopy.brandSimple === this.brand.Churchill);
    });
  }

  /** Dynamic Page Titles */
  private setPageTitle(): void {
    this.routerPrimaryNavigationEndEvents$.subscribe(event =>
      this.platformBrowserTitle.setTitle(event['title'])
    );
  }

  /** Handler for webchat */
  private webchatHandler(): void {
    this.webchatService.init({
      brand: this.brandCopy.brand,
      product: 'Motor Q&B'
    });

    this.subs = this.webchatService.routeChange().subscribe((segments) => {
      const journey = 'B4C';
      const pageName: string = segments[0];

      this.webchatService.setSection(journey, pageName);
    });
  }

  /** Track page user is on */
  private trackPage(): void {
    this.routeEventsNavigationEnd$
      .subscribe((event: NavigationEnd) => {
        this.analyticsService.trackPage();
      });
  }

  private buildRouteArray() {
    Object.keys(this.locationService.getJourneyLocations()).forEach((key) => {
      this.routeArray.push(key);
    });
  }

  /** Tracks route url and compares ot routeArray */
  private progressBar(): void {
    this.routeEventsNavigationEnd$
      .subscribe((event) => {
        const urlWithEdit = event.urlAfterRedirects.split('/').pop();
        let index: number;
        this.editPageUlr(urlWithEdit);

        if (urlWithEdit === this.pageUlr) {
          index = this.routeArrayForSelectedPages.findIndex((url) => `/${url}/${this.pageUlr}` === event.urlAfterRedirects);
        } else {
          index = this.routeArrayForSelectedPages.findIndex((url) => `/${url}` === event.urlAfterRedirects);
        }

        this.active = Array.from({ length: index + 1 }, (x, k) => k);
        this.showCustomerRating = (environment.brand_dlg === Brand.DirectLine && this.active.length > 0 && ((this.quoteService.isMulticarQuote() && this.active.length <= this.maxAppStepsToShowMultiCar) || (!this.quoteService.isMulticarQuote() && this.active.length <= this.maxAppStepsToShow)));

        this.appLoaded();
      });
  }

  private hidePageTrackerFromPage(): void {
    const excludePages = [this.featureType.Payments, this.featureType.Confirm, this.featureType.Summary] as Array<String>;
    this.routeArrayForSelectedPages = this.routeArray.filter((option) => excludePages.indexOf(option) === -1);
  }

  private appLoaded(): void {
    this.loaded = true;
  }

  private editPageUlr(url: string): void {
    for (const item in CoverageType) {
      if (url === CoverageType[item] || url === 'edit') {
        this.pageUlr = url;
      }
    }
  }
}
