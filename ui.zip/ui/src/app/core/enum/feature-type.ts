/**
 * Specifies the features of the journey
 */
export enum FeatureType {
  YourCar = 'your-car',
  YourDetails = 'your-details',
  YourDrivingHistory = 'your-driving-history',
  Discounts = 'discounts',
  PolicyDetails = 'policy-details',
  Premium = 'premium',
  Confirm = 'confirm',
  Terms = 'terms-conditions',
  ReviewAndConfirm = 'review',
  Summary = 'summary',
  UpdateQuotedSubmission = 'update-quoted-submission',
  Payments = 'payments',
  Declined = 'declined',
  MisMatch = 'mismatch',
  ErroredOut = 'error',
  SessionTimeout = 'session-timeout',
  TransactionFailed = 'transaction-failed',
  PaymentEntryFailed = 'payment-entry-failed',
  PaymentContactCentre = 'payment-contact-centre'
}
