export enum DrivingDetailsOptions {
  quickCheck = 'quickCheck',
  manual = 'manual'
}

export const DrivingDetailsValues = {
  [DrivingDetailsOptions.quickCheck] : { 'code': 'quickCheck', 'value': 'Enter my driving licence number (quick check)'},
  [DrivingDetailsOptions.manual]: {'code': 'manual', 'value': 'Enter my driving history details (manual)'}
};

export const AdditionalDrivingDetailsValues = {
  [DrivingDetailsOptions.quickCheck] : { 'code': 'quickCheck', 'value': 'Enter their driving licence number (quick check)'},
  [DrivingDetailsOptions.manual]: {'code': 'manual', 'value': 'Enter their driving history details (manual)'}
};
