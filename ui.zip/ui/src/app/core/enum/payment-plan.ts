/**
 * Specifies the types of payment plans
 */
export enum PaymentPlan {
  monthly = 'monthly',
  annually = 'annually',
}
