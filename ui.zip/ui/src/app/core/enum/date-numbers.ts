/**
 * Specifies numbers for date and time calculations
 */
export enum DateNumbers {
    hoursPerDay = 24,
    minutesPerHour = 60,
    secondsPerMinute = 60,
    millisecondsPerSecond = 1000
}
