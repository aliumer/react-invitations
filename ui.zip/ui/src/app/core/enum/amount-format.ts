/**
 * Specifies the amount format
 */
export enum AmountFormat {
    Simple = 'simple',
    Split = 'split'
}
