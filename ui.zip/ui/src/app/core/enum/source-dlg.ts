/**
 * Specifies the type of source
 */

export enum SourceDlg {
  DirectDigital = 'directdigital',
  ContactCentre = 'contactcentre',
  GoCompare = 'gocompare',
  MoneySuperMarket = 'moneysupermarket',
  CompareTheMarket = 'comparethemarket',
  Confused = 'confused',
  Tesla = 'tesla',
  Prudential = 'prudential'
}
