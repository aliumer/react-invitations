export enum BrandPartner {
    Prudential = 'prudential',
    Tesla = 'tesla'
}
