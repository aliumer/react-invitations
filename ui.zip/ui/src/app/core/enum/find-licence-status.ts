export enum FindLicenceStatus {
  FindLicence = 'FindLicence',
  FindLicenceSuccess = 'FindLicenceSuccess',
  FindLicenceSuccessNoData = 'FindLicenceSuccessNoData',
  EnterDetailsManually = 'EnterDetailsManually',
  Reset = 'reset'
}
