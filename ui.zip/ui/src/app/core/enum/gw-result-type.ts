/**
 * Specifies the result types from gwide wire.
 */
export enum GwResultType {
    Timeout = 'timeout',
    Success = 'success',
    Error = 'error',
    Decline = 'decline',
    Mismatch = 'mismatch',
    None = 'none'
}
