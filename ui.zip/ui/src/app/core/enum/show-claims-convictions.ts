/**
 * To show hide parts of app-claims-convictions component
 */
export enum ShowClaimsConvictionsEnum {
  ShowAll = 'ShowAll',
  ShowConvictionsOnly = 'ShowConvictionsOnly',
  ShowClaimsOnly = 'ShowClaimsOnly',
}
