export enum ControlType {
    FormGroup = 'FormGroup',
    Array = 'Array',
    DateArray = 'DateArray',
    Control = 'Control'
}
