/**
 * Specifies the types of on-page errors
 */
export enum OnPageErrorType {
  InvalidPromoCode = 'invalidPromoCode'
}
