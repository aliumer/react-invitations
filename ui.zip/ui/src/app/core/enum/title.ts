export enum Title {
    mr = 'Mr',
    mrs = 'Mrs',
    miss_dlg = 'Miss',
    ms = 'Ms',
    dr = 'Dr'
}
