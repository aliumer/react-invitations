
/**
 * Specifies the type of channel
 */

export enum ChannelDlg {
  Pcw = 'pcw',
  Digital = 'digital',
  ContactCentre = 'contactcentre'
}
