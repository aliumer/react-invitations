export const MulticarSessionsToKeep = [
  'app-session-your-details',
  'app-session-your-driving-history',
  'app-session-quote-list',
  'app-session-policy-details',
  'app-session-obj',
  'app-session-pcw-landing',
  'lpTabId',
  'app-session-occupations',
  'dlg_data_visittime'
];
