export enum QuoteStatus {
  Quoted = 'Quoted',                // set when user has a completed quote
  QuotedSaved = 'QuotedSaved',      // set when user saves and navigates to summary page from premium page
  Cancelled = 'Cancelled',          // set when user cancels their subsequent quote
  Saved = 'Saved'                   // set when user saves and navigates to summary page before the premium page
}
