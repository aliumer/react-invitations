export enum UpdateQuoteSubmissionAction {
    OnTabChange = 'onTabChange',
    OnPromoFullFilement = 'onPromoFullFilement'
}
