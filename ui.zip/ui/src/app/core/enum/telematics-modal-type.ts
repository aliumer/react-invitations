export enum TelematicsModalType {
    Info = 'info',
    TermsAndConditions = 'termsAndConditions'
}
