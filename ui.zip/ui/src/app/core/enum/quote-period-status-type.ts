export enum QuotePeriodStatus {
    Draft = 'Draft',
    Quoted = 'Quoted'
}
