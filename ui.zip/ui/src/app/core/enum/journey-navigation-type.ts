export enum JourneyNavigationType {
  Update = 'Update',
  Continue = 'Next',
  Save = 'Save',
  Back = 'Back',
  FirstPage = 'FirstPage',
  SummaryPage = 'SummaryPage'
}
