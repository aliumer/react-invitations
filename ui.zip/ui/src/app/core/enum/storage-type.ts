/**
 * Specifies the session key of the journey
 */
export enum StorageType {
    Premium = 'premium',
    Submission = 'submission',
    Breakdown = 'breakdown',
    MarketingPreferences = 'marketing-prefs'
}
