/**
 * Specifies the features of the journey
 */
export enum AdditionalDrivers {
    moreDrivers = 'additionalDriver'
}
