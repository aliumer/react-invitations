export enum TelematicsType {
    Device = 'MOTTelematicsCovTelematicsDevice',
    App = 'MOTTelematicsCovTelematicsApp',
    HardWired = 'MOTTelematicsCovTelematicsHardWired',
    SelfInstalled = 'MOTTelematicsCovTelematicsSelfInstalled'
}
