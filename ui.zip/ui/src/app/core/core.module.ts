import { NgModule, Optional, SkipSelf } from '@angular/core';
import { Location } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';

import { LibraryModule } from 'dlg-angular-components';
import { WebchatModule } from 'dlg-angular-analytics';
import { QuoteModule } from '@app/quote/quote.module';

import { OccupationsResolverService } from '@app/core/services/resolvers/occupations-resolver.service';

import { ProgressingInterceptor } from '@app/core/services/interceptors/progressing.interceptor.service';
import { SessionInterceptor } from '@app/core/services/session/session.interceptor';

import { AnalyticsService } from './services/analytics/analytics.service';
import { AppStateService } from '@app/core/services/app-state/app-state.service';
import { CookieService } from './services/cookie/cookie.service';
import { PremiumDataService } from './services/data-services/premium-data.service';
import { StorageService } from './services/storage/storage.service';
import { JourneyConfigService } from '@app/core/services/configs/journey-config.service';
import { OccupationService } from '@app/shared/services/occupation/occupation.service';
import { SessionService } from '@app/core/services/session/session.service';
import { SalesforceWebchatService } from './services/salesforce-webchat/salesforce-webchat.service';
import { SalesforceWebchatCodeSnippetsService } from './services/salesforce-webchat/salesforce-webchat-code-snippets.service';

import { throwIfAlreadyLoaded } from '@app/shared/utilities/module-import-guard';

import { EnvServiceProvider } from '@app/core/services/providers/env.service.provider';
import { QuoteService } from '@app/shared/services/quote/quote.service';
import { QuoteDataService } from '@app/shared/services/quote/quote.data.service';
import { EnvService } from './services/configs/env.service';
import { ChurchillQuoteMapRequestService } from '@app/quote/services/churchill/churchill-quote.map-request.service';
import { DirectLineQuoteMapRequestService } from '@app/quote/services/directline/directline-quote.map-request.service';
import { PrivilegeQuoteMapRequestService } from '@app/quote/services/privilege/privilege-quote.map-request.service';
import { ChurchillQuoteMapResponseService } from '@app/quote/services/churchill/churchill-quote.map-response.service';
import { DirectLineQuoteMapResponseService } from '@app/quote/services/directline/directline-quote.map-response.service';
import { PrivilegeQuoteMapResponseService } from '@app/quote/services/privilege/privilege-quote.map-response.service';
import { QuoteFactory } from '@app/main/quote/quote.factory';
import { LocationService } from '@app/journey/location/location.service';


@NgModule({
    imports: [
        LibraryModule,
        QuoteModule,
        WebchatModule
    ],
    providers: [
        JourneyConfigService,
        AnalyticsService,
        SalesforceWebchatService,
        SalesforceWebchatCodeSnippetsService,
        AppStateService,
        CookieService,
        PremiumDataService,
        StorageService,
        OccupationService,
        OccupationsResolverService,
        EnvServiceProvider,
        SessionService,
        ChurchillQuoteMapRequestService,
        DirectLineQuoteMapRequestService,
        PrivilegeQuoteMapRequestService,
        ChurchillQuoteMapResponseService,
        DirectLineQuoteMapResponseService,
        PrivilegeQuoteMapResponseService,

        {provide: HTTP_INTERCEPTORS, useClass: SessionInterceptor, multi: true},
        {provide: HTTP_INTERCEPTORS, useClass: ProgressingInterceptor, multi: true},
        {provide: QuoteService, useFactory: QuoteFactory, deps: [
            HttpClient,
            StorageService,
            LocationService,
            ChurchillQuoteMapRequestService,
            DirectLineQuoteMapRequestService,
            PrivilegeQuoteMapRequestService,
            QuoteDataService,
            PremiumDataService,
            ChurchillQuoteMapResponseService,
            DirectLineQuoteMapResponseService,
            PrivilegeQuoteMapResponseService,
            EnvService
        ]},
        Location
    ]
})
export class CoreModule {
    constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
        throwIfAlreadyLoaded(parentModule, 'CoreModule');
    }
}
