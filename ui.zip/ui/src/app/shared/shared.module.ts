import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { FormModule } from '@app/form/form.module';

import { LibraryModule } from 'dlg-angular-components';
import { ModalSaveComponent } from '@app/shared/modals/save-modals/save-modal.component';
import { ModalCancelComponent } from '@app/shared/modals/cancel-modal/cancel-modal.component';
import { SaveFailModalComponent } from '@app/shared/modals/save-modals/save-fail-modal.component';
import { TelematicsModalsComponent } from './modals/telematics-modals/telematics-modals.component';
import { TelematicsAppComponent } from './modals/telematics-modals/telematics-app/telematics-app.component';
import { TelematicsHardWiredComponent } from './modals/telematics-modals/telematics-hard-wired/telematics-hard-wired.component';
import { TelematicsSelfInstalledComponent } from './modals/telematics-modals/telematics-self-installed/telematics-self-installed.component';
import { AutoRenewalComponent } from '@app/shared/components/auto-renewal/auto-renewal.component';
import { SingleAlertComponent } from '@app/shared/components/single-alert/single-alert.component';
import { DirectDebitThirdPartyComponent } from '@app/shared/components/direct-debit-third-party/direct-debit-third-party.component';
import { TelematicsChurchillCopyComponent } from './modals/telematics-modals/telematics-info-terms/telematics-churchill-copy/telematics-churchill-copy.component';
import { TelematicsPrivilegeCopyComponent } from './modals/telematics-modals/telematics-info-terms/telematics-privilege-copy/telematics-privilege-copy.component';
import { TelematicsDirectlineCopyComponent } from './modals/telematics-modals/telematics-info-terms/telematics-directline-copy/telematics-directline-copy.component';
import { LicenceNumberComponent } from '@app/shared/components/licence-number/licence-number.component';
import { LicenceModalComponent } from '@app/shared/modals/licence-modal/licence-modal.component';
import { AccidentalDamageComponent } from '@app/shared/components/accidental-damage/accidental-damage.component';
import { FocusTrapDirective } from '@app/shared/directives/focus-trap.directive';
import { SessionWarningModalComponent } from './modals/session-warning-modal/session-warning-modal.component';
import { BackdatedModalComponent } from './modals/backdated-modal/backdated-modal.component';
import { SaveTimeoutModalComponent } from './modals/save-timeout-modal/save-timeout-modal.component';
import { PoundsA11yDirective } from './directives/pounds-a11y.directive';
import {DateCalendarComponent} from '@app/shared/components/date-calendar/date-calendar.component';
import {NgbDatepickerModule} from '@ng-bootstrap/ng-bootstrap';
import {PremiumPaymentTypeComponent} from '@app/shared/components/premiun-payment-type/premium-payment-type.component';


@NgModule({
  imports: [
    CommonModule,
    LibraryModule,
    ReactiveFormsModule,
    FormModule,
    FormsModule,
    NgbDatepickerModule
  ],
    declarations: [
        ModalSaveComponent,
        ModalCancelComponent,
        SaveFailModalComponent,
        TelematicsAppComponent,
        TelematicsHardWiredComponent,
        TelematicsSelfInstalledComponent,
        TelematicsModalsComponent,
        AutoRenewalComponent,
        SingleAlertComponent,
        DirectDebitThirdPartyComponent,
        TelematicsChurchillCopyComponent,
        TelematicsPrivilegeCopyComponent,
        TelematicsDirectlineCopyComponent,
        LicenceNumberComponent,
        LicenceModalComponent,
        SessionWarningModalComponent,
        AccidentalDamageComponent,
        FocusTrapDirective,
        BackdatedModalComponent,
        SaveTimeoutModalComponent,
        PoundsA11yDirective,
        DateCalendarComponent,
        PremiumPaymentTypeComponent
    ],
    exports: [
        CommonModule,
        LibraryModule,
        ReactiveFormsModule,
        ModalSaveComponent,
        ModalCancelComponent,
        SaveFailModalComponent,
        AutoRenewalComponent,
        SingleAlertComponent,
        DirectDebitThirdPartyComponent,
        LicenceNumberComponent,
        LicenceModalComponent,
        SessionWarningModalComponent,
        AccidentalDamageComponent,
        FocusTrapDirective,
        BackdatedModalComponent,
        SaveTimeoutModalComponent,
        PoundsA11yDirective,
        DateCalendarComponent,
        PremiumPaymentTypeComponent
    ],
    entryComponents: [
        ModalSaveComponent,
        ModalCancelComponent,
        SaveFailModalComponent,
        TelematicsModalsComponent,
        LicenceModalComponent,
        SessionWarningModalComponent,
        BackdatedModalComponent,
        SaveTimeoutModalComponent
    ]
})
export class SharedModule { }
