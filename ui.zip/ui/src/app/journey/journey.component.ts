import { Component, HostBinding } from '@angular/core';

@Component({
    selector: 'app-journey',
    templateUrl: './journey.component.html'
})
export class JourneyComponent {
    @HostBinding('class.journey') journeyClass = true;
    @HostBinding('class.journey--loading') journeyLoading = false;
}
