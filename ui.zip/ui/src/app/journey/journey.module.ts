import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LibraryModule } from 'dlg-angular-components';


import { JourneyComponent } from './journey.component';

import { FormModule } from '@app/form/form.module';


@NgModule({
    imports: [
        CommonModule,
        LibraryModule,
        FormModule
    ],
    declarations: [
        JourneyComponent,
    ],
    exports: [
        JourneyComponent,
    ]
})
export class JourneyModule { }
