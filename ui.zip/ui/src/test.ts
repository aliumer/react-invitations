// This file is required by karma.conf.js and loads recursively all the .spec and framework files

import 'zone.js/dist/zone-testing';
import { getTestBed } from '@angular/core/testing';
import {
  BrowserDynamicTestingModule,
  platformBrowserDynamicTesting
} from '@angular/platform-browser-dynamic/testing';

declare const require: any;

// First, initialize the Angular testing environment.
getTestBed().initTestEnvironment(
  BrowserDynamicTestingModule,
  platformBrowserDynamicTesting()
);
// Then we find all the tests.
// const context = require.context('./', true, /\.spec\.ts$/);
// // And load the modules.
// context.keys().map(context);

const context2 = require.context('./app/core', true, /\.spec\.ts$/);
context2.keys().map(context2);

const context3 = require.context('./app/form', true, /\.spec\.ts$/);
context3.keys().map(context3);

const context4 = require.context('./app/journey', true, /\.spec\.ts$/);
context4.keys().map(context4);

const context5 = require.context('./app/main', true, /\.spec\.ts$/);
context5.keys().map(context5);

const context6 = require.context('./app/privilege', true, /\.spec\.ts$/);
context6.keys().map(context6);

const context7 = require.context('./app/quote', true, /\.spec\.ts$/);
context7.keys().map(context7);

const context8 = require.context('./app/shared', true, /\.spec\.ts$/);
context8.keys().map(context8);
