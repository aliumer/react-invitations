
import { Brand } from '@app/core/enum/brand-type';
import { copy } from './../assets/privilege/copy';

export const environment = {
  production: true,
  apiRouting: '',
  apiUrl: 'https://e2e-web.b4c-qa.dlgdigitalapi.com/live',
  apiKey: 'CwYPaUVJc6aWmTxlz1b1xaAQoWFP44QR7L0CqbgU',
  brand_dlg:  Brand.Privilege,
  brand_copy: copy
};
