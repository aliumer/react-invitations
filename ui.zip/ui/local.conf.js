var browserstack = require('browserstack-local');

exports.config = {

  specs: [
    './test/**/*.feature'
  ],
  'seleniumAddress': 'http://hub-cloud.browserstack.com/wd/hub',

  'capabilities': {
    'browserstack.user': 'hannes29',
    'browserstack.key': 'jyqWz2ErhB3GYhM35wKp',
    'os': 'Windows',
    'os_version': '10',
    'browserName': 'Chrome',
    'browser_version': '62.0',
    'resolution': '1024x768',
    'build': 'Sprint33',
    'project': 'B4C',
    'browserstack.local':'false'
  },

// Code to start browserstack local before start of test
beforeLaunch: function(){
console.log("Connecting local");
return new Promise(function(resolve, reject){
exports.bs_local = new browserstack.Local();
exports.bs_local.start({'key': exports.config.capabilities['browserstack.key'] }, function(error) {
if (error) return reject(error);
console.log('Connected. Now testing...');

resolve();
});
});
},

// Code to stop browserstack local after end of test
afterLaunch: function(){
return new Promise(function(resolve, reject){
exports.bs_local.stop(resolve);
});
}
};
