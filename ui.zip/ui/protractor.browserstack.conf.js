// Protractor configuration file, see link for more information
// https://github.com/angular/protractor/blob/master/lib/config.ts
const {
  SpecReporter
} = require('jasmine-spec-reporter');
var browserstack = require('browserstack-local');
const domain = process.env.BDD_TEST_ENV;
const prefix = (domain.indexOf('localhost') === -1) ? 'https' : 'http';
const bddTestUrl = prefix + '://' + process.env.BDD_TEST_ENV;

exports.config = {
  allScriptsTimeout: 20000,
  getPageTimeout: 20000,
  jasmineNodeOpts: {
    defaultTimeoutInterval: 20000,
    showColors: false
  },
  
  suites: {
    sanity: 
    ['./test/test-suites/sanity-test-suite/bStack-sanity-tests.feature'],
    regression: 
    [
      './test/test-suites/regression-test-suite/quote-and-buy.feature',
      './test/test-suites/regression-test-suite/quote-edit-buy.feature',
       './test/test-suites/regression-test-suite/indicative-quotes.feature',
       './test/test-suites/regression-test-suite/decline-scenarios.feature'
    ]
  },

  'browserstackUser': 'kristo10' || 'BROWSERSTACK_USERNAME',
  'browserstackKey': 'K7LP9nyza15vA2VSCQU5' || 'BROWSERSTACK_ACCESS_KEY',

  'seleniumAddress': 'http://hub-cloud.browserstack.com/wd/hub',
  'HubURL': 'https://kristo10:K7LP9nyza15vA2VSCQU5:@hub-cloud.browserstack.com/wd/hub',

  'commonCapabilities': {
    'browserstack.user': 'kristo10',
    'browserstack.key': 'K7LP9nyza15vA2VSCQU5',
    'project': 'B4C-UI',
    'browserstack.local': true,
    'browserstack.networkLogs': false,
    'browserstack.debug': false,
    'acceptSslCert': true,
    'elementScrollBehavior': 1
  },

  'multiCapabilities': [

// ********* BROWSERS ********

    // {
    //   'browserName': 'Chrome',
    //   'chromeOptions': {
    //     'args':['no-sandbox'],
    //   },
    //   'os': 'OS X',
    //   'os_version': 'Mojave',
    //   'browser_version': '75.0'
    // },    
    // {
    //   'browserName': 'Chrome',
    //   'chromeOptions': {
    //     'args':['no-sandbox'],
    //   },
    //   'os': 'Windows',
    //   'osVersion': '10'
    // },
    {
      'os': 'Windows',
      'osVersion': '10',
      'browserName': 'IE',
      'browserVersion': '11.0',
    },
    // {
    //   'browserName': 'Firefox',
    //   'os': 'OS X',
    //   'os_version': 'Mojave',
    //   'browser_version': '68.0',
    // },
    {
      'browserName': 'Firefox',
      'os': 'Windows',
      'osVersion': '10',
      'browserVersion': '68.0',
    },
    // {
    //   'browserName': 'Safari',
    //   'os': 'OS X',
    //   'os_version': 'Mojave',
    //   'browser_version': '12.1',
    // },
    // {
    //   'browserName': 'Edge',
    //   'os': 'Windows',
    //   'osVersion': '10',
    //   'browserVersion': '18.0'
    // },

    // // *************************** DEVICES ********

    // // ******** Apple Devices *********** 

  //   {
  //     'browserName': 'Safari',
  //     'os_version': '12',
  //     'device': 'iPhone XS',
  //     'real_mobile': 'true',
  //   },
  //   {
  //     'browserName': 'Safari',
  //     'os_version': '12',
  //     'device': 'iPad Pro 12.9 2018',
  //     'real_mobile': 'true',
  //   },
  //   {
  //     'browserName': 'Safari',
  //     'os_version': '10',
  //     'device': 'iPhone 7',
  //     'real_mobile': 'true',
  //   },
  //   // ******** Android Devices *********** 
    {
      'os_version' : '9.0',
      'device' : 'Samsung Galaxy S8 Plus',
      'real_mobile' : 'true',
      'browserName': 'Chrome'
    },
    // {
    //   'device': 'Samsung Galaxy Tab S4',
    //   'browserName': 'Chrome',
    //   'os_version': '8.1',
    //   'real_mobile': 'true',
    //   'automationName': 'selendroid'
    // },
    {
      'os_version' : '7.1',
      'device' : 'Google Pixel',
      'real_mobile': 'true',
      'browserName': 'Chrome'
    },
    // {
    //   'os_version': '9.0',
    //   'browserName': 'Chrome',
    //   'device': 'Google Pixel 3 XL',
    //   'real_mobile': 'true'
    // }
  ],

  directConnect: false,
  baseUrl: bddTestUrl,
  resultJsonOutputFile: './test/report/cucumber-report.json',
  framework: 'custom',
  frameworkPath: require.resolve('protractor-cucumber-framework'),
  cucumberOpts: {
    require: [
      'test/step_definitions/support/env.js',
      'test/step_definitions/support/hooks.ts',
      'test/step_definitions/common/*.ts',
      'test/step_definitions/*.ts'
    ],
    tags: '@sanity',
    profile: false,
    strict: true,
    'no-source': true,
    keepAlive: false,
    format: 'json:./test/report/results.json',
  },
  plugins: [{
    package: 'protractor-multiple-cucumber-html-reporter-plugin',
    options: {
      automaticallyGenerateReport: true,
      removeExistingJsonReportFile: false
    }
  }],
  SELENIUM_PROMISE_MANAGER: true,
  async onPrepare() {
    browser.resetUrl = 'about:blank';
    require('ts-node').register({
      project: './test/tsconfig.e2e.json'
    });
  },

  // Code to start browserstack local before start of test
  beforeLaunch: function () {
    console.log("Connecting local");
    return new Promise(function (resolve, reject) {
      exports.bs_local = new browserstack.Local();
      exports.bs_local.start({
        'key': exports.config['browserstackKey'], 'forceLocal': true, 'force': true, 'verbose': 'true'
      }, function (error) {
        if (error) return reject(error);
        console.log('Connected. Now testing...');
        resolve();
      });
    });
  },

  // Code to stop browserstack local after end of test
  afterLaunch: function () {
    return new Promise(function (resolve, reject) {
      exports.bs_local.stop(resolve);
    });
  }
}

exports.config.multiCapabilities.forEach(function (caps) {
  for (var i in exports.config.commonCapabilities) caps[i] = caps[i] || exports.config.commonCapabilities[i];
});
