# B4C-UI Privilege styleguides

## Initial Setup

```bash
npm install
```

**Don't install KSS-node globally, it will cause problems in the long run when you have multiple projects using KSS-node.*

## Compiling Style Guide

```bash
npm run priv-style-guide
```

## Create and Document a Simple Component

```bash
// Post Title (this will be the title of your component)
//
// Large, **in charge**, and centered. (this is the description of your component. you can use markdown in here.)
//
// Markup (define the markup to be used in your styleguide):
// <h1 class="post-title">A Post Title</h1>
//
// Styleguide Components.article.post-title
// (ꜛ this controls the organization of your style guide. Here, I'm filing this component inside Components / Article / Post Title)

.post-title {
    font-size: 3em;
    text-align: center;
    font-family: fantasy;
}
```

## Reference

For futher informattion see link below:
**<https://css-tricks.com/build-style-guide-straight-sass/>

**To get familiar with the documentation syntax read through [the annotated copy of the official KSS spec on the KSS-node repository](https://github.com/kss-node/kss/blob/spec/SPEC.md).*