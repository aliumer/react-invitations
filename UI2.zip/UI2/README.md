# B4C-UI (STP | Renewal)

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.0.3 (*current 9.1.1*).

## node version
10.16.0


## Development server
* Run `npm run start:stp:<env>` for stp dev server. Navigate to `http://localhost:4300/car/amend-policy/load/<token>`.
* Run `npm run start:renew:<env>` for renewal dev server. Navigate to `http://localhost:4500/car/renew-policy/retrieve/<token>`.

## Further help

Follow the below steps to create a new feature

*e.g creating a feature called `your-feature`*

__N.B__ for `--project` flag either use `amend-policy` or `renew-policy` depending on which project you working on.


## 1. create module
`ng g m --project (amend-policy|renew-policy) features/your-feature --routing -m main.module`

## 2.create feature store
`ng g st --project (amend-policy|renew-policy) your-feature --statePath features/your-feature/state/reducers -m features/your-feature/your-feature.module.ts`

## 3.created rest of the store features
`ng g f --project (amend-policy|renew-policy) features/your-feature/state/your-feature -c -g --reducers reducers/index.ts`

## 4. create reducer
`ng g r --project (amend-policy|renew-policy) feature/your-feature/state/reducer-name -c -g -r reducers/index.ts`

## Components

### Import order
* Angular libs
* 3rd party libs
* Our Modules
* Our services
* Components
* NGRX Actions
* NGRX Reducers
* NGRX Selectors
* Variables & Interfaces
* Constants
* Generic Imports
 
### Component parts order
Inputs variables
Outputs
Uninitialised Public variables
Initialised Public Variables
Uninitialised Private Variables
Initialised Private Variables
Constructor
Public Methods
Lifecycle Hooks
Private Methods

