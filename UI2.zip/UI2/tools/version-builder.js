const fs       = require('fs-extra'),
      gitState = require('git-state'),
      path     = require('path'),
      moment   = require('moment');

const appVersion = require('../app-version.json');
const argv = require('yargs').argv;
const app = argv.app;
const brand = argv.brand;
const projectPath = process.cwd();

const projectConfig = {
  "projectName": "b4c-ui-stp",
  "version": {
    "stp": appVersion.stp,
    "renew": appVersion.renew,
  },
  "directory": {
    "stp": "dist/car/amend-policy",
    "renew": "dist/car/renew-policy",
  },
  "distFilename": "version",
  "distFiletypes": ["json", "txt"]
}

const versionBuilder = {
  getDate: () => {
    return moment().format('DD/MM/YYYY HH:mmA').toString();
  },
  getVersion: () => {
    let versionNumber;

    if (app === 'stp') {
      versionNumber = projectConfig.version.stp;
    }

    if (app === 'renew') {
      versionNumber = projectConfig.version.renew;
    }

    return versionNumber;
  },
  getAppDirectory: () => {
    let appDirectory;

    if (app === 'stp') {
      appDirectory = projectConfig.directory.stp;
    }

    if (app === 'renew') {
      appDirectory = projectConfig.directory.renew;
    }

    return appDirectory;
  },
  getHash: () => {
    let hash;

    if (gitState.isGitSync(projectPath)) {
      hash = gitState.commitSync();
    } else {
      hash = 'Unavailable';
    }

    return hash;
  },
  getBranch: () => {
    let branch;

    if (gitState.isGitSync(projectPath)) {
      branch = gitState.branchSync();
    } else {
      branch = 'Unavailable';
    }

    return branch;
  },
  getTemplate: (fileType) => {
    return path.join(__dirname, `version-template.${fileType}`);
  },
  getFileDist: (fileType) => {
    return `${path.join(projectPath, versionBuilder.getAppDirectory())}/${projectConfig.distFilename}.${fileType}`;
  },
  buildFile: () => {
    try {
      let data;

      projectConfig.distFiletypes.forEach((fileType) => {
        data = fs.readFileSync(versionBuilder.getTemplate(fileType), 'utf8');

        data = data.replace('{{site}}', projectConfig.projectName);
        data = data.replace('{{date}}', versionBuilder.getDate());
        data = data.replace('{{hash}}', versionBuilder.getHash());
        data = data.replace('{{branch}}', versionBuilder.getBranch());
        data = data.replace('{{app}}', app);
        data = data.replace('{{brand}}', brand);
        data = data.replace('{{version}}', versionBuilder.getVersion());

        fs.outputFileSync(versionBuilder.getFileDist(fileType), data, encoding = 'utf8');
      });
    } catch (ex) {
      console.error(ex);
    }
  }
}

versionBuilder.buildFile();
