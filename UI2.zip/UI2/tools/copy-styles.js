// temp hack to move dlg walrus files so single scss repo works with stp and b4c
const vfs = require('vinyl-fs');

const src = './node_modules/dlg-angular-components/dist/dlg-walrus/lib/';
const dest = './node_modules/dlg-angular-components/dist/src/';

vfs
  .src([`${src}/**/*.scss`])
  .pipe(vfs.dest(`${dest}`));
