/* ---------- Dependencies */

const argv              = require('yargs').argv;
const fs                = require('fs');

/* ---------- Parameters */

const env = argv.env;
const proxy = argv.proxy;

/* ---------- Main Script */

fs.readFile(`projects/amend-policy/src/proxies/${env}-proxy.conf.json`, 'utf8', (error, content) => {
  if (error) { return console.error(error); }
  content = content.replace(/[:][\/]{2}[a-z0-9-]*/g, `://${proxy}`);
  fs.writeFileSync(`projects/amend-policy/src/proxies/${env}-proxy.conf.json`, content, 'utf8');
});
