export const defaultCopy = {
  brand: 'Privilege',
  brandSimple: 'privilege',
  dvlaSearchCode: 'PRV',
  phoneNumber: '0345 878 5573',
  serviceUserNumber: '290688',
  drivexpert: 'DriveXpert',
  drivexpertSimple: 'drivexpert',
  cookieUrl: 'https://www.privilege.com/legal/cookies',
  premium: {
    benefitsList: {
      comp: {
        courtesyCar: 'Courtesy car'
      }
    }
  },
  review: {
    cancellationsFee: '53.76',
    mta: 'Mid-term adjustments to your policy made through your Digital Account may result in an administration fee of up to £10.08 (including IPT where applicable). Mid-term adjustments to your policy made through our contact centre, or requests for duplicate documents of your car insurance policy, may result in an administration fee of up to £26.88 (including IPT where applicable). An additional premium may also apply as a result of the amendment.',
    policyDocument: 'policy-booklet.PDF',
    rescueCoverDocument: 'rescue-booklet.PDF'
  },
  telematics: {
    selfInstalledText: `We will send you a telematics 'black box' device for you to install in your vehicle once you have purchased your policy.`,
    hardwiredText: `We will arrange installation of your telematics 'black box' by our technicians once you have purchased your policy.`
  },
  footer: [
    {
      label: 'Accessibility',
      url: 'https://www.privilege.com/accessibility',
      ariaLabel: 'Our accessibility information opens in a new window'
    },
    {
      label: 'About us',
      url: 'https://www.privilege.com/about-us',
      ariaLabel: 'Our about us information opens in a new window'
    },
    {
      label: 'Legal',
      url: 'https://www.privilege.com/legal',
      ariaLabel: 'Our legal information opens in a new window'
    },
    {
      label: 'Privacy',
      url: 'https://www.privilege.com/legal/privacy',
      ariaLabel: 'Our security and privacy information opens in a new window'
    },
    {
      label: 'Telematics privacy',
      url: 'https://www.privilege.com/car-insurance/black-box/privacy',
      ariaLabel: 'Our telematics privacy information opens in a new window'
    },
    {
      label: 'Site map',
      url: 'https://www.privilege.com/site-map',
      ariaLabel: 'Our site map opens in a new window'
    }
  ]
};
