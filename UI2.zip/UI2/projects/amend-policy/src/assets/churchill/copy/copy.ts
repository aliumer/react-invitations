export const brandCopy = {
  brand: 'Churchill',
  brandSimple: 'churchill',
  dvlaSearchCode: 'CHU',
  phoneNumber: '0345 877 6244',
  serviceUserNumber: '290695',
  drivexpert: 'DriveSure',
  drivexpertSimple: 'drivesure',
  cookieUrl: 'https://www.churchill.com/about-us/cookies-notice',
  premium: {
    benefitsList: {
      comp: {
        courtesyCar: 'Courtesy car'
      }
    }
  },
  review: {
    cancellationsFee: '53.76',
    mta: 'Mid-term adjustments to, or requests for duplicate documents of your car insurance policy do not incur an administration fee. However, an additional premium may apply as a result of the amendment.',
    policyDocument: 'policy-booklet-0720.pdf',
    rescueCoverDocument: 'rescue-booklet-0320.pdf'
  },
  telematics: {
    selfInstalledText: `We will send you a telematics 'black box' device for you to install in your vehicle once you have purchased your policy.`,
    hardwiredText: `We will arrange installation of your telematics 'black box' by our technicians once you have purchased your policy.`
  },
  footer: [
    {
      label: 'Accessibility',
      url: 'https://www.churchill.com/accessibility',
      ariaLabel: 'Our accessibility information opens in a new window'
    },
    {
      label: 'About us',
      url: 'https://www.churchill.com/about-us',
      ariaLabel: 'Our about us information opens in a new window'
    },
    {
      label: 'Legal',
      url: 'https://www.churchill.com/about-us/legal-and-regulatory',
      ariaLabel: 'Our legal information opens in a new window'
    },
    {
      label: 'Security and privacy',
      url: 'https://u-k-insurance.co.uk/brands-policy.html',
      ariaLabel: 'Our security and privacy information opens in a new window'
    },
    {
      label: 'Telematics privacy',
      url: 'https://www.churchill.com/car-insurance/black-box-original/privacy',
      ariaLabel: 'Our telematics privacy information opens in a new window'
    },
    {
      label: 'Site map',
      url: 'https://www.churchill.com/site-map',
      ariaLabel: 'Our site map opens in a new window'
    }
  ]
};
