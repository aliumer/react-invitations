import { enableProdMode, Injector } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { MainModule } from '@app/main/main.module';

import { Environment } from '@app/core/models/environment';
import { EnvironmentProviderService } from '@app/core/services/environment/environment-provider.service';
import { environment as env } from '@env/environment';

const injector = Injector.create({ providers: [ EnvironmentProviderService ]});
const environment = injector.get(Environment);

if (environment.production) {
  enableProdMode();
}

if(environment.analyticsScript) {
  const analyticsScript = document.createElement('script');
  analyticsScript.src = environment.analyticsScript;
  analyticsScript.async = true;
  document.head.appendChild(analyticsScript);
}

if (window.dlg_dolphin) {
  window.dlg_dolphin.brand = env.brand_copy.brand;
  window.dlg_dolphin.architecture = 'SPA';
  window.dlg_dolphin.type = 'Quote And Buy';
}

// TODO: need to add the following script back commenting it cause of DCJA-368

// if (environment.tealiumSync) {
//   const utagSync = document.createElement('script');
//   utagSync.src = environment.tealiumSync;
//   document.head.appendChild(utagSync);
// }

// if(environment.tealiumScript) {
//   const tealiumSetting = document.createElement('script');
//   tealiumSetting.innerText = 'window.utag_cfg_ovrd = { noview : true };';
//   document.body.appendChild(tealiumSetting);

//   const scriptTealium = document.createElement('script');
//   scriptTealium.src = environment.tealiumScript;
//   document.body.appendChild(scriptTealium);

// }

if (environment.tealiumSync) {
  const utagSync = document.createElement('script');
  utagSync.src = environment.tealiumSync;
  document.head.appendChild(utagSync);
}

if(environment.tealiumScript) {

  const tealiumSetting = document.createElement('script');
  tealiumSetting.innerText = 'window.utag_cfg_ovrd = { noview : true };';
  document.body.appendChild(tealiumSetting);

  const scriptTealium = document.createElement('script');
  scriptTealium.src = environment.tealiumScript;
  document.body.appendChild(scriptTealium);
}

platformBrowserDynamic().bootstrapModule(MainModule)
  .catch(err => console.error(err));
