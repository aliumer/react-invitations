export interface PanelState {
  isVisible: boolean;
  isNotification?: boolean;
  isShowPolicyNumber?: boolean;
  icon?: string;
  mainTitle?: string;
  subTitle?: string;
  breadcrumbFeatureName?: string;
  pageTitle?: string;
}
