import { Component, OnInit, AfterViewChecked, ChangeDetectorRef } from '@angular/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { select, Store } from '@ngrx/store';

import { State as StpState } from '@app/stp/state/reducers';

import {
  selectJourneyPath,
  selectNavigationDetails,
  selectPanelConfig,
  selectPolicyId,
  selectProgressbarDisplayStatus,
  selectPolicyChangeDate
} from '@app/stp/state/selectors';

import { ButtonState } from '@app/stp/interfaces/button-state';
import { PanelState } from '@app/stp/interfaces/panel-state';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-stp-container',
  templateUrl: './stp-container.component.html'
})
export class StpContainerComponent implements OnInit, AfterViewChecked {

  navigationDetails$: Observable<ButtonState[]>;
  panelConfig$: Observable<PanelState>;
  isShowProgressBar$: Observable<boolean>;
  policyId$: Observable<string>;
  policyChangeDate$: Observable<Date>;
  journeyPath$: Observable<any>;

  constructor(
    private stpStore: Store<StpState>,
    private cd: ChangeDetectorRef,
    private title: Title
  ) {}

  ngOnInit() {
    this.navigationDetails$ = this.stpStore.pipe(select(selectNavigationDetails));
    this.panelConfig$ = this.stpStore.pipe(select(selectPanelConfig),
      tap(config => {
        if (config?.pageTitle) {
          this.title.setTitle(config.pageTitle);
        }
      })
    );
    this.policyId$ = this.stpStore.pipe(select(selectPolicyId));
    this.policyChangeDate$ = this.stpStore.pipe(select(selectPolicyChangeDate));
    this.journeyPath$ = this.stpStore.pipe(select(selectJourneyPath));

    this.isShowProgressBar$ = this.stpStore.pipe(select(selectProgressbarDisplayStatus));
  }

  ngAfterViewChecked(): void {
      this.cd.detectChanges();
  }

}
