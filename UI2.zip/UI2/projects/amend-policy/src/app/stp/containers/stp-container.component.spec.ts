import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';

import { StpContainerComponent } from './stp-container.component';
import { JourneyNavigationComponent } from '@app/stp/components/journey-navigation/journey-navigation.component';
import { FeatureWrapperComponent } from '@app/stp/components/feature-wrapper/feature-wrapper.component';
import { LoadingIndicatorComponent } from '@app/stp/components/loading-indicator/loading-indicator.component';

import { reducers as stpReducers } from '@app/stp/state/reducers';


describe('StpContainerComponent', () => {
  let component: StpContainerComponent;
  let fixture: ComponentFixture<StpContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        SharedModule,
        StoreModule.forRoot({}),
        StoreModule.forFeature('stpStore', stpReducers)
      ],
      declarations: [
        StpContainerComponent,
        JourneyNavigationComponent,
        FeatureWrapperComponent,
        LoadingIndicatorComponent
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StpContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
