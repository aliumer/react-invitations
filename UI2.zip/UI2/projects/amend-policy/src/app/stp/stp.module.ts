import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';

import { StpRoutingModule } from './stp-routing.module';
import { SharedModule } from '@app/shared/shared.module';
import { StpServicesModule } from './services/stp-services.module';

import { SessionInterceptor } from './services/session/session.interceptor';
import { LoaderInterceptor } from './services/loader/loader.interceptor';
import { SessionService } from './services/session/session.service';

import { JourneyNavigationEffects } from './state/effects/journey-navigation.effects';

import { JourneyNavigationComponent } from './components/journey-navigation/journey-navigation.component';
import { StpContainerComponent } from './containers/stp-container.component';
import { FeatureWrapperComponent } from './components/feature-wrapper/feature-wrapper.component';
import { LoadingIndicatorComponent } from './components/loading-indicator/loading-indicator.component';

import * as fromStp from './state/reducers';

@NgModule({
  declarations: [
    JourneyNavigationComponent,
    StpContainerComponent,
    FeatureWrapperComponent,
    LoadingIndicatorComponent
  ],
  imports: [
    HttpClientModule,
    SharedModule,
    StpRoutingModule,
    StpServicesModule,
    StoreModule.forFeature('stpStore', fromStp.reducers),
    EffectsModule.forFeature([JourneyNavigationEffects])
  ],
  providers: [
    SessionService,
    { provide: HTTP_INTERCEPTORS, useClass: SessionInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true }
  ]
})
export class StpModule {
}
