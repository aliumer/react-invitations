import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { StpContainerComponent } from './containers/stp-container.component';
import { DashboardActivateGuard } from '@app/features/dashboard/services/guard/dashboard-guard.service'

import { JourneyFeatures } from '@app/infrastructure/data/journey-features';

const routes: Routes = [
  {
    path: '',
    component: StpContainerComponent,
    pathMatch: 'prefix',
    children: [
      {
        path: `${JourneyFeatures.loadPolicy.path}/:token`,
        loadChildren: () => import('../features/load-policy/load-policy.module').then(m => m.LoadPolicyModule)
      },
      {
        path: `${JourneyFeatures.billing.path}/:token`,
        loadChildren: () => import('../features/billing/billing.module').then(m => m.BillingModule)
      },
      {
        path: `${JourneyFeatures.retrieveQuote.path}/:token`,
        loadChildren: () => import('../features/retrieve-quote/retrieve-quote.module').then(m => m.RetrieveQuoteModule)
      },
      {
        path: JourneyFeatures.dashboard.path,
        loadChildren: () => import('../features/dashboard/dashboard.module').then(m => m.DashboardModule),
        canActivate: [DashboardActivateGuard]
      },
      {
        path: JourneyFeatures.yourCar.path,
        loadChildren: () => import('../features/your-car/your-car.module').then(m => m.YourCarModule)
      },
      {
        path: JourneyFeatures.yourMileage.path,
        loadChildren: () => import('../features/your-mileage/your-mileage.module').then(m => m.YourMileageModule)
      },
      {
        path: JourneyFeatures.yourDetails.path,
        loadChildren: () => import('../features/your-details/your-details.module').then(m => m.YourDetailsModule)
      },
      {
        path: JourneyFeatures.yourTemporaryEuropeanCover.path,
        loadChildren: () => import('../features/your-temporary-european-cover/your-temporary-european-cover.module').then(m => m.YourTemporaryEuropeanCoverModule)
      },
      {
        path: JourneyFeatures.yourRegistration.path,
        loadChildren: () => import('../features/your-registration/your-registration.module').then(m => m.YourRegistrationModule)
      },
      {
        path: JourneyFeatures.yourAddress.path,
        loadChildren: () => import('../features/your-address/your-address.module').then(m => m.YourAddressModule)
      },
      {
        path: JourneyFeatures.yourDrivers.path,
        loadChildren: () => import('../features/your-drivers/your-drivers.module').then(m => m.YourDriversModule)
      },
      {
        path: JourneyFeatures.allocate.path,
        loadChildren: () => import('../features/allocate/allocate.module').then(m => m.AllocateModule)
      },
      {
        path: JourneyFeatures.premium.path,
        loadChildren: () => import('../features/premium/premium.module').then(m => m.PremiumModule)
      },
      {
        path: JourneyFeatures.review.path,
        loadChildren: () => import('../features/review/review.module').then(m => m.ReviewModule)
      },
      {
        path: JourneyFeatures.payment.path,
        loadChildren: () => import('../features/payment/payment.module').then(m => m.PaymentModule)
      },
      {
        path: JourneyFeatures.refund.path,
        loadChildren: () => import('../features/refund/refund.module').then(m => m.RefundModule)
      },
      {
        path: JourneyFeatures.confirm.path,
        loadChildren: () => import('../features/confirm/confirm.module').then(m => m.ConfirmModule)
      },
      {
        path: JourneyFeatures.yourCorrespondenceAddress.path,
        loadChildren: () => import('../features/your-correspondence-address/your-correspondence-address.module').then(m => m.YourCorrespondenceAddressModule)
      },
      {
        path: JourneyFeatures.yourConvictions.path,
        loadChildren: () => import('../features/your-convictions/your-convictions.module').then(m => m.YourConvictionsModule)
      },
      {
        path: JourneyFeatures.errors.path,
        loadChildren: () => import('../features/errors/errors.module').then(m => m.ErrorsModule)
      }
    ]
  },
  {
    path: '**',
    redirectTo: ''
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [DashboardActivateGuard]
})
export class StpRoutingModule {
}
