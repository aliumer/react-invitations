import { Component, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { AnalyticsService } from '@app/core/services/analytics/analytics.service';
import { WebchatService } from '@app/main/services/webchat/webchat.service';

import { selectPolicyId } from '@app/stp/state/selectors';

import { projectTitle } from '@app/infrastructure/constants/titles';
import { environment } from '@env/environment';

@Component({
  selector: 'app-main-container',
  templateUrl: './main-container.component.html'
})
export class MainContainerComponent implements OnInit, OnDestroy {

  active: Array<number> = [];
  keepTracking$: Subject<boolean> = new Subject<boolean>();
  policyId: string;
  brandName = environment.brand_copy.brand;

  constructor(
    private router: Router,
    private analyticsService: AnalyticsService,
    private webchatService: WebchatService,
    private store: Store<{}>
  ) {
  }

  setSection(journey, page) {
    if (journey && page) {
      window.lpTag.newPage(window.location.href);
      window.lpTag.section = [this.brandName, journey, page];
    }
  }

  ngOnInit() {
    this.store.pipe(select(selectPolicyId)).subscribe(r => this.policyId = r);
    this.trackPage();
  }

  ngOnDestroy() {
    this.keepTracking$.next(false);
    this.keepTracking$.unsubscribe();
  }

  private trackPage(): void {
    this.router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        takeUntil(this.keepTracking$)
      ).subscribe((event: NavigationEnd) => {
        this.analyticsService.trackPage();
        if (window.location.pathname.split('/').indexOf('premium') === -1) {
          window.utag.view();
        }
        this.webchatTrackSection(event);
      }
    );
  }

  private webchatTrackSection(event): void {
    const interval = setInterval(() => {
      if (window.lpTag && window.lpTag.loaded) {
        clearInterval(interval);
        const journey = projectTitle;
        const pageName: string = this.normaliseRoute(event.url)[0];
        this.setSection(journey, pageName);
        this.webchatService.setCustomerPolicyIdSDES(this.policyId);
      }
    }, 2000);
  }

  private normaliseRoute(route) {
    const pathSegments = route.split('/');
    pathSegments.forEach((segment, index) => {
      if (segment === '') {
        pathSegments.splice(index, 1);
      }
    });
    return pathSegments;
  }
}
