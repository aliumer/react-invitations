import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { EffectsModule } from '@ngrx/effects';
import { StoreRouterConnectingModule } from '@ngrx/router-store';

import { CoreModule } from '@app/core/core.module';
import { MainRoutingModule } from '@app/main/main-routing.module';
import { MainServicesModule } from '@app/main/services/main-services.module';
import { CookieBannerModule } from '@app/shared/cookie-banner/cookie-banner.module';

import { MainContainerComponent } from './containers/main-container.component';

import { environment } from '@env/environment';
import { metaReducers } from '@app/main/state/reducers';

@NgModule({
  declarations: [
    MainContainerComponent
  ],
  imports: [
    BrowserModule,
    CoreModule,
    MainRoutingModule,
    MainServicesModule,
    CookieBannerModule,
    StoreModule.forRoot({}, {
      metaReducers,
      runtimeChecks: {
        strictStateImmutability: true,
        strictActionImmutability: true
      }
    }),
    StoreDevtoolsModule.instrument({maxAge: 25, logOnly: environment.production}),
    EffectsModule.forRoot([]),
    StoreRouterConnectingModule.forRoot(),
  ],
  bootstrap: [
    MainContainerComponent
  ]
})
export class MainModule {
}
