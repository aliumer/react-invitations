import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';
import { YourDetailsServicesModule } from '@app/features/your-details/services/your-details-services.module';
import { YourDetailsRoutingModule } from './your-details-routing.module';

import { YourDetailsContainerComponent } from './containers/your-details-container.component';
import { DetailsDisplayComponent } from './components/details-display/details-display.component';

import * as fromYourDetails from './state/reducers';


@NgModule({
  declarations: [YourDetailsContainerComponent, DetailsDisplayComponent],
  imports: [
    SharedModule,
    YourDetailsRoutingModule,
    YourDetailsServicesModule,
    StoreModule.forFeature('yourDetailsStore', fromYourDetails.reducers)
  ]
})
export class YourDetailsModule {
}
