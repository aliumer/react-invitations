import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { YourDetailsResolverService } from '@app/features/your-details/services/resolvers/your-details-resolver.service';

import { YourDetailsContainerComponent } from '@app/features/your-details/containers/your-details-container.component';

const routes: Routes = [
  {
    path: '',
    component: YourDetailsContainerComponent,
    resolve: {
      occupations: YourDetailsResolverService
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YourDetailsRoutingModule { }
