import { NgModule } from '@angular/core';

import { SharedModule } from '@app/shared/shared.module';
import { ErrorsRoutingModule } from './errors-routing.module';

import { ErrorsContainerComponent } from './containers/errors-container.component';
import { LoadPolicyFailedComponent } from './components/load-policy-failed/load-policy-failed.component';
import { SessionTimeoutComponent } from './components/session-timeout/session-timeout.component';
import { MtaDeclinedComponent } from './components/mta-declined/mta-declined.component';
import { TransactionFailedComponent } from './components/transaction-failed/transaction-failed.component';
import { ConfirmationFailedComponent } from './components/confirmation-failed/confirmation-failed.component';
import { PaymentContactCentreComponent } from '@app/features/errors/components/payment-contact-centre/payment-contact-centre.component';
import { PolicyOutsideValidDurationComponent } from './components/policy-outside-valid-duration/policy-outside-valid-duration.component';
import { RefundFailedComponent } from './components/refund-failed/refund-failed.component';
import { TransactionRefusedComponent } from './components/transaction-refused/transaction-refused.component';
import { QuoteErrorComponent } from './components/quote-error/quote-error.component';
import { SuspendedVehicleComponent } from './components/suspended-vehicle/suspended-vehicle.component';


@NgModule({
  declarations: [
    ErrorsContainerComponent,
    LoadPolicyFailedComponent,
    SessionTimeoutComponent,
    MtaDeclinedComponent,
    TransactionFailedComponent,
    ConfirmationFailedComponent,
    PolicyOutsideValidDurationComponent,
    PaymentContactCentreComponent,
    RefundFailedComponent,
    TransactionRefusedComponent,
    QuoteErrorComponent,
    SuspendedVehicleComponent
  ],
  imports: [
    SharedModule,
    ErrorsRoutingModule
  ]
})
export class ErrorsModule { }
