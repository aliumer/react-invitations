import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ErrorsContainerComponent } from '@app/features/errors/containers/errors-container.component';
import { LoadPolicyFailedComponent } from '@app/features/errors/components/load-policy-failed/load-policy-failed.component';
import { SessionTimeoutComponent } from '@app/features/errors/components/session-timeout/session-timeout.component';
import { MtaDeclinedComponent } from '@app/features/errors/components/mta-declined/mta-declined.component';
import { TransactionFailedComponent } from '@app/features/errors/components/transaction-failed/transaction-failed.component';
import { ConfirmationFailedComponent } from '@app/features/errors/components/confirmation-failed/confirmation-failed.component';
import { PolicyOutsideValidDurationComponent } from '@app/features/errors/components/policy-outside-valid-duration/policy-outside-valid-duration.component';
import { PaymentContactCentreComponent } from '@app/features/errors/components/payment-contact-centre/payment-contact-centre.component';
import { RefundFailedComponent } from '@app/features/errors/components/refund-failed/refund-failed.component';
import { TransactionRefusedComponent } from '@app/features/errors/components/transaction-refused/transaction-refused.component';
import { QuoteErrorComponent } from '@app/features/errors/components/quote-error/quote-error.component';
import { SuspendedVehicleComponent } from '@app/features/errors/components/suspended-vehicle/suspended-vehicle.component';

const routes: Routes = [
  {
    path: '',
    component: ErrorsContainerComponent,
    children: [
      { path: 'load-policy-failed', component: LoadPolicyFailedComponent },
      { path: 'session-timeout', component: SessionTimeoutComponent },
      { path: 'declined', component: MtaDeclinedComponent },
      { path: 'transaction-failed', component: TransactionFailedComponent },
      { path: 'transaction-refused', component: TransactionRefusedComponent },
      { path: 'confirmation-failed', component: ConfirmationFailedComponent },
      { path: 'policy-outside-valid-duration', component: PolicyOutsideValidDurationComponent },
      { path: 'payment-contact-centre/:errorCode', component: PaymentContactCentreComponent },
      { path: 'refund-failed', component: RefundFailedComponent },
      { path: 'quote-error', component: QuoteErrorComponent },
      { path: 'suspended-vehicle', component: SuspendedVehicleComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ErrorsRoutingModule { }
