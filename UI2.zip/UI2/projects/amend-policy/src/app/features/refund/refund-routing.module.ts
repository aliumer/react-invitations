import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RefundResolverService } from '@app/features/refund/services/resolvers/refund-resolver.service';

import { RefundContainerComponent } from '@app/features/refund/containers/refund-container.component';



const routes: Routes = [
  {
    path: '',
    component: RefundContainerComponent,
    resolve: {
      _: RefundResolverService
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RefundRoutingModule {
}
