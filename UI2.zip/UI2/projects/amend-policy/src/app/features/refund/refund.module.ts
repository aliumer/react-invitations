import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';
import { RefundRoutingModule } from '@app/features/refund/refund-routing.module';
import { RefundServicesModule } from '@app/features/refund/services/refund-services.module';

import { RefundContainerComponent } from './containers/refund-container.component';
import { RefundDetailsComponent } from './components/refund-details.component';

import * as fromRefund from './state/reducers';



@NgModule({
  declarations: [RefundContainerComponent, RefundDetailsComponent],
  imports: [
    RefundServicesModule,
    RefundRoutingModule,
    SharedModule,
    StoreModule.forFeature('refundStore', fromRefund.reducers)
  ]
})
export class RefundModule { }
