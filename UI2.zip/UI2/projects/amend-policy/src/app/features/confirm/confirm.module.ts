import { NgModule } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { StoreModule } from '@ngrx/store';

import { ConfirmRoutingModule } from './confirm-routing.module';
import { ConfirmServicesModule } from '@app/features/confirm/services/confirm-services.module';
import { SharedModule } from '@app/shared/shared.module';

import { ConfirmContainerComponent } from './containers/confirm-container.component';
import { ConfirmFullContainerComponent } from './containers/full/confirm-full-container.component';
import { ConfirmDirectDebitContainerComponent } from './containers/direct-debit/confirm-direct-debit-container.component';
import { ConfirmFullComponent } from './components/full/confirm-full.component';
import { ConfirmDirectDebitComponent } from './components/direct-debit/confirm-direct-debit.component';

import * as fromConfirm from './state/reducers';

@NgModule({
  declarations: [
    ConfirmFullComponent,
    ConfirmDirectDebitComponent,
    ConfirmContainerComponent,
    ConfirmFullContainerComponent,
    ConfirmDirectDebitContainerComponent
  ],
  imports: [
    ConfirmServicesModule,
    ConfirmRoutingModule,
    StoreModule.forFeature('confirmStore', fromConfirm.reducers),
    SharedModule
  ],
  providers: [DecimalPipe]
})
export class ConfirmModule { }
