import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ConfirmContainerComponent } from './containers/confirm-container.component';
import { ConfirmFullContainerComponent } from './containers/full/confirm-full-container.component';
import { ConfirmDirectDebitContainerComponent } from './containers/direct-debit/confirm-direct-debit-container.component';

import { ConfirmFullResolverService } from '@app/features/confirm/services/resolvers/full/confirm-full-resolver.service';
import { ConfirmDirectDebitResolverService } from '@app/features/confirm/services/resolvers/direct-debit/confirm-direct-debit-resolver.service';

const routes: Routes = [
  {
    path: '',
    component: ConfirmContainerComponent,
    children: [
      {
        path: 'full',
        component: ConfirmFullContainerComponent,
        resolve: {
          confirmData: ConfirmFullResolverService
        }
      },
      {
        path: 'direct-debit',
        component: ConfirmDirectDebitContainerComponent,
        resolve: {
          confirmData: ConfirmDirectDebitResolverService
        }
      }
    ],
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfirmRoutingModule { }
