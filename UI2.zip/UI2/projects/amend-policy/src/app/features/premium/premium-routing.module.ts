import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PremiumResolverService } from '@app/features/premium/services/resolvers/premium-resolver.service';

import { PremiumContainerComponent } from './containers/premium-container.component';

const routes: Routes = [
  {
    path: '',
    component: PremiumContainerComponent,
    resolve: {
      prem: PremiumResolverService
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PremiumRoutingModule {
}
