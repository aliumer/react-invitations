import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { SharedModule } from '@app/shared/shared.module';
import { TabsModule } from '@app/shared/tabs/tabs.module';
import { PremiumRoutingModule } from '@app/features/premium/premium-routing.module';
import { PremiumServicesModule } from '@app/features/premium/services/premium-services.module';

import { PremiumContainerComponent } from '@app/features/premium/containers/premium-container.component';
import { PremiumHeaderComponent } from '@app/features/premium/components/premium-header/premium-header.component';
import { MonthlyRepresentativeComponent } from '@app/features/premium/components/premium-header/monthly-representative/monthly-representative.component';
import { ExtrasPriceComponent } from '@app/features/premium/components/extras-price/extras-price.component';
import { ExtrasListComponent } from '@app/features/premium/components/extras-list/extras-list.component';
import { ExtrasListItemComponent } from '@app/features/premium/components/extras-list-item/extras-list-item.component';
import { BreakdownCoverListComponent } from '@app/features/premium/components/breakdown-cover-list/breakdown-cover-list.component';
import { EuBreakdownCoverComponent } from '@app/features/premium/components/eu-breakdown-cover/eu-breakdown-cover.component';
import { CoverSelectComponent } from '@app/features/premium/components/cover-select/cover-select.component';
import { QuoteSummaryComponent } from '@app/features/premium/components/quote-summary/quote-summary.component';
import { BreakdownDetailsComponent } from '@app/features/premium/components/breakdown-details/breakdown-details.component';
import { ModalNcdComponent } from '@app/features/premium/modals/ncd-modal/ncd-modal.component';
import { ModalBreakdownComponent } from '@app/features/premium/modals/breakdown-modal/breakdown-modal.component';
import { SummaryTabsComponent } from '@app/features/premium/components/summary-tabs/summary-tabs.component';
import { SummaryTabComponent } from '@app/features/premium/components/summary-tab/summary-tab.component';
import { SummaryNoTabComponent } from '@app/features/premium/components/summary-no-tab/summary-no-tab.component';
import { SummaryInfoComponent } from '@app/features/premium/components/summary-info/summary-info.component';
import { SummaryContentComponent } from '@app/features/premium/components/summary-content/summary-content.component';
import { BenefitsComponent } from '@app/features/premium/components/benefits/benefits.component';
import { BenefitsItemComponent } from '@app/features/premium/components/benefits-item/benefits-item.component';
import { PromosDiscountsComponent } from '@app/features/premium/components/promos-discounts/promos-discounts.component';
import { PersonalCoverComponent } from './components/personal-cover/personal-cover.component';
import { ErrorComponent } from '@app/shared/components/errors/error/error.component';

import { PremiumEffects } from '@app/features/premium/state/effects/premium.effects';

import * as fromPremium from '@app/features/premium/state/reducers';


@NgModule({
  declarations: [
    PremiumContainerComponent,
    PremiumHeaderComponent,
    MonthlyRepresentativeComponent,
    ExtrasListComponent,
    ExtrasListItemComponent,
    ExtrasPriceComponent,
    BreakdownCoverListComponent,
    EuBreakdownCoverComponent,
    CoverSelectComponent,
    QuoteSummaryComponent,
    BreakdownDetailsComponent,
    ModalNcdComponent,
    ModalBreakdownComponent,
    SummaryTabsComponent,
    SummaryTabComponent,
    SummaryNoTabComponent,
    SummaryInfoComponent,
    SummaryContentComponent,
    BenefitsComponent,
    BenefitsItemComponent,
    PromosDiscountsComponent,
    PersonalCoverComponent
  ],
  imports: [
    SharedModule,
    TabsModule,
    PremiumRoutingModule,
    PremiumServicesModule,
    StoreModule.forFeature('premiumStore', fromPremium.reducers),
    EffectsModule.forFeature([PremiumEffects]),
    SharedModule
  ],
  providers: [],
  entryComponents: [
    ErrorComponent,
    ModalNcdComponent,
    ModalBreakdownComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PremiumModule {
}
