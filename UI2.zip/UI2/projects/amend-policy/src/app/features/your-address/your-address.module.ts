import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { AddressModule } from '@app/shared/address/address.module';
import { SharedModule } from '@app/shared/shared.module';
import { YourAddressRoutingModule } from './your-address-routing.module';

import { YourAddressContainerComponent } from './containers/your-address-container.component';
import { AddressOvernightComponent } from './components/address-overnight/address-overnight.component';

import * as fromYourAddress from './state/reducers';


@NgModule({
  declarations: [
    YourAddressContainerComponent,
    AddressOvernightComponent,
  ],
  imports: [
    SharedModule,
    AddressModule,
    YourAddressRoutingModule,
    StoreModule.forFeature('yourAddressStore', fromYourAddress.reducers)
  ],
})
export class YourAddressModule {
}
