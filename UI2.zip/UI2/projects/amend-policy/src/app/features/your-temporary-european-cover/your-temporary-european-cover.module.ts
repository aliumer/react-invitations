import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';
import { CarPanelModule } from '@app/shared/car-panel/car-panel.module';
import { YourTemporaryEuropeanCoverRoutingModule } from './your-temporary-european-cover-routing.module';

import { YourTemporaryEuropeanCoverContainerComponent } from './containers/your-temporary-european-cover-container.component';
import { YourTemporaryEuropeanCoverDisplayComponent } from './components/your-temporary-european-cover-display/your-temporary-european-cover-display.component';

import * as fromYourTemporaryEuropeanCover from './state/reducers';


@NgModule({
  declarations: [YourTemporaryEuropeanCoverContainerComponent, YourTemporaryEuropeanCoverDisplayComponent],
  imports: [
    SharedModule,
    CarPanelModule,
    YourTemporaryEuropeanCoverRoutingModule,
    StoreModule.forFeature('yourTemporaryEuropeanCoverStore', fromYourTemporaryEuropeanCover.reducers)
  ]
})
export class YourTemporaryEuropeanCoverModule {
}
