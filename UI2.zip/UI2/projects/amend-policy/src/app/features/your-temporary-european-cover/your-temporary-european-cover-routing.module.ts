import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { YourTemporaryEuropeanCoverContainerComponent } from './containers/your-temporary-european-cover-container.component';

const routes: Routes = [
  {
    path: '',
    component: YourTemporaryEuropeanCoverContainerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YourTemporaryEuropeanCoverRoutingModule { }
