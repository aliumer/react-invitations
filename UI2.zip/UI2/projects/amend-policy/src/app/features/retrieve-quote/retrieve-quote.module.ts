import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';

import { RetrieveQuoteRoutingModule } from './retrieve-quote-routing.module';
import { RetrieveQuoteServicesModule } from '@app/features/retrieve-quote/services/retrieve-quote-services.module';

import { RetrieveQuoteContainerComponent } from './containers/retrieve-quote-container.component';
import { ErrorModalComponent } from '@app/features/retrieve-quote/modals/error-modal/error-modal.component';

import { RetrieveQuoteEffects } from './state/effects/retrieve-quote.effects';

import * as fromPremium from '@app/features/premium/state/reducers';
import * as fromDashboard from '@app/features/dashboard/state/reducers';


@NgModule({
  declarations: [
    RetrieveQuoteContainerComponent,
    ErrorModalComponent
  ],
  imports: [
    SharedModule,
    RetrieveQuoteRoutingModule,
    RetrieveQuoteServicesModule,
    StoreModule.forFeature('dashboardStore', fromDashboard.reducers),
    StoreModule.forFeature('premiumStore', fromPremium.reducers),
    EffectsModule.forFeature([RetrieveQuoteEffects])
  ],
  entryComponents: [
    ErrorModalComponent
  ]
})
export class RetrieveQuoteModule { }
