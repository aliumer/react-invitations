import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';
import { YourDriversServicesModule } from '@app/features/your-drivers/services/your-drivers-services.module';
import { YourDriversRoutingModule } from './your-drivers-routing.module';

import { ManageDriverHoldingContainerComponent } from './containers/manage/manage-driver-holding-container.component';
import { YourDriversHoldingContainerComponent } from './containers/your-drivers-holding-container.component';
import { PermDriverListContainerComponent } from './containers/perm/perm-driver-list-container.component';
import { TempDriverListContainerComponent } from './containers/temp/temp-driver-list-container.component';
import { PersonalDetailsContainerComponent } from './containers/manage/personal-details-container/personal-details-container.component';
import { DrivingLicenseNumberContainerComponent } from '@app/features/your-drivers/containers/manage/driving-license-number-container/driving-license-number-container.component';
import { DrivingHistoryContainerComponent } from '@app/features/your-drivers/containers/manage/driving-history-container/driving-history-container.component';

import { DriverListItemComponent } from './components/driver-list/driver-list-item/driver-list-item.component';
import { ManageClaimComponent } from './components/manage/driver-claims/manage-claim/manage-claim.component';
import { ManageConvictionComponent } from './components/manage/driver-convictions/manage-conviction/manage-conviction.component';
import { AdditionalDetailsComponent } from './components/driver-list/additional-details/additional-details.component';
import { ExistingDriverListComponent } from './components/driver-list/existing-driver-list/existing-driver-list.component';
import { NewDriverListComponent } from './components/driver-list/new-driver-list/new-driver-list.component';
import { DriverConvictionsComponent } from './components/manage/driver-convictions/driver-convictions.component';
import { DriverClaimsComponent } from './components/manage/driver-claims/driver-claims.component';
import { DrivingHistoryComponent } from './components/manage/driving-history/driving-history.component';
import { DrivingLicenseNumberComponent } from './components/manage/driving-license-number/driving-license-number.component';
import { PersonalDetailsComponent } from './components/manage/personal-details/personal-details.component';
import { ClaimConvictionListItemComponent } from './components/manage/claim-conviction-list-item/claim-conviction-list-item.component';
import { LicenceModalComponent } from './modals/licence-modal.component';

import * as fromYourDrivers from './state/reducers';

@NgModule({
  declarations: [
    DriverListItemComponent,
    DrivingHistoryComponent,
    ManageClaimComponent,
    ManageConvictionComponent,
    AdditionalDetailsComponent,
    YourDriversHoldingContainerComponent,
    PermDriverListContainerComponent,
    TempDriverListContainerComponent,
    ExistingDriverListComponent,
    NewDriverListComponent,
    ManageDriverHoldingContainerComponent,
    PersonalDetailsContainerComponent,
    DrivingLicenseNumberContainerComponent,
    DrivingHistoryContainerComponent,
    DriverConvictionsComponent,
    DriverClaimsComponent,
    DrivingLicenseNumberComponent,
    PersonalDetailsComponent,
    ClaimConvictionListItemComponent,
    LicenceModalComponent
  ],
  imports: [
    SharedModule,
    YourDriversRoutingModule,
    YourDriversServicesModule,
    StoreModule.forFeature('yourDriversStore', fromYourDrivers.reducers)
  ],
  exports: [
    DrivingLicenseNumberComponent
  ],
  entryComponents: [
    LicenceModalComponent
  ]
})
export class YourDriversModule { }

