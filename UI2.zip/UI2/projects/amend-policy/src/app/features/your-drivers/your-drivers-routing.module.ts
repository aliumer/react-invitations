import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OccupationResolverService } from '@app/features/your-drivers/services/occupation-resolver/occupation-resolver.service';

import { YourDriversHoldingContainerComponent } from '@app/features/your-drivers/containers/your-drivers-holding-container.component';
import { ManageDriverHoldingContainerComponent } from '@app/features/your-drivers/containers/manage/manage-driver-holding-container.component';

import { PersonalDetailsContainerComponent } from '@app/features/your-drivers/containers/manage/personal-details-container/personal-details-container.component';
import { DrivingLicenseNumberContainerComponent } from '@app/features/your-drivers/containers/manage/driving-license-number-container/driving-license-number-container.component';
import { DrivingHistoryContainerComponent } from '@app/features/your-drivers/containers/manage/driving-history-container/driving-history-container.component';

import { PermDriverListContainerComponent } from '@app/features/your-drivers/containers/perm/perm-driver-list-container.component';
import { TempDriverListContainerComponent } from '@app/features/your-drivers/containers/temp/temp-driver-list-container.component';

const routes: Routes = [
  {
    path: '',
    component: YourDriversHoldingContainerComponent,
    children: [
      {
        path: 'permanent',
        component: PermDriverListContainerComponent,
      },
      {
        path: 'temporary',
        component: TempDriverListContainerComponent,
      },
      {
        path: 'manage',
        component: ManageDriverHoldingContainerComponent,
        children: [
          {
            path: 'personal-details/:id',
            component: PersonalDetailsContainerComponent,
            resolve: {
              occupations: OccupationResolverService
            },
          },
          {
            path: 'driving-license-number/:id',
            component: DrivingLicenseNumberContainerComponent
          },
          {
            path: 'driving-history/:id',
            component: DrivingHistoryContainerComponent
          }
        ]
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YourDriversRoutingModule {
}
