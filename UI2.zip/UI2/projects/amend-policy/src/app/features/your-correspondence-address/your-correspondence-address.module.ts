import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { AddressModule } from '@app/shared/address/address.module';
import { SharedModule } from '@app/shared/shared.module';
import { YourCorrespondenceAddressRoutingModule } from './your-correspondence-address-routing.module';

import { YourCorrespondenceAddressContainerComponent } from './containers/your-correspondence-address-container.component';

import * as fromYourCorrespondenceAddress from './state/reducers';



@NgModule({
  declarations: [
    YourCorrespondenceAddressContainerComponent
  ],
  imports: [
    AddressModule,
    SharedModule,
    YourCorrespondenceAddressRoutingModule,
    StoreModule.forFeature('yourCorrespondenceAddressStore', fromYourCorrespondenceAddress.reducers)
  ]
})
export class YourCorrespondenceAddressModule {
}
