import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { YourConvictionsContainerComponent } from '@app/features/your-convictions/containers/your-convictions-container.component';


const routes: Routes = [
  {
    path: '',
    component: YourConvictionsContainerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YourConvictionsRoutingModule { }
