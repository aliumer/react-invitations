import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';
import { YourConvictionsRoutingModule } from './your-convictions-routing.module';

import { YourConvictionsContainerComponent } from './containers/your-convictions-container.component';

import * as fromConvictions from './state/reducers';
import { ListYourConvictionsComponent } from './components/list-your-convictions/list-your-convictions.component';
import { ManageYourConvictionsComponent } from './components/manage-your-convictions/manage-your-convictions.component';


@NgModule({
  declarations: [
    YourConvictionsContainerComponent,
    ListYourConvictionsComponent,
    ManageYourConvictionsComponent
  ],
  imports: [
    SharedModule,
    YourConvictionsRoutingModule,
    StoreModule.forFeature('yourConvictionsStore', fromConvictions.reducers)
  ]
})
export class YourConvictionsModule { }
