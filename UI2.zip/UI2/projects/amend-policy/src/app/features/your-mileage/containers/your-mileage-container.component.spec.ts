import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YourMileageContainerComponent } from './your-mileage-container.component';

describe('YourMileageContainerComponent', () => {
  let component: YourMileageContainerComponent;
  let fixture: ComponentFixture<YourMileageContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YourMileageContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YourMileageContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
