import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { YourMileageContainerComponent } from '@app/features/your-mileage/containers/your-mileage-container.component';

const routes: Routes = [
  {
    path: '',
    component: YourMileageContainerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YourMileageRoutingModule { }
