import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { filter, map, takeWhile, tap } from 'rxjs/operators';

import { FormService } from '@app/core/services/form-builder/form.service';
import { ScrollingService } from '@app/shared/services/scrolling/scrolling.service';

import { FeatureBase } from '@app/infrastructure/abstracts/feature-base/feature.base';

import { State as StpState } from '@app/stp/state/reducers';
import { State as YourMileageState } from '@app/features/your-mileage/state/reducers';

import { JourneyNavigationActions, PolicyActions } from '@app/stp/state/actions';
import { YourMileageActions, YourMileageNavigationActions } from '@app/features/your-mileage/state/actions';

import { selectGatewayTimeoutError, selectPolicyDetails, selectPromoCodeError } from '@app/stp/state/selectors';
import {
  selectUpdatedMileage,
  selectYourMileageNavigation,
  selectYourMileageNavigationAndState
} from '@app/features/your-mileage/state/selectors';

@Component({
  selector: 'app-your-mileage-container',
  templateUrl: './your-mileage-container.component.html'
})
export class YourMileageContainerComponent extends FeatureBase<YourMileageState> implements OnInit {

  isShowGatewayTimeoutWarning$: Observable<boolean>;
  currentMileageDisplay$: Observable<string>;
  mileage$: Observable<any>;

  isFormValid = true;

  constructor(
    protected router: Router,
    protected yourMileageStore: Store<YourMileageState>,
    private stpStore: Store<StpState>,
    private fb: FormBuilder,
    private formService: FormService,
    private scrollingService: ScrollingService,
  ) {
    super(
      router,
      yourMileageStore,
      'yourMileage',
      selectYourMileageNavigation,
      YourMileageNavigationActions.resetButtons,
      YourMileageNavigationActions.setupNavigation,
      JourneyNavigationActions.setNavDirection,
      YourMileageActions.resetError
    );
    this.createForm();
    this.retrieveMileageFromStore();
  }

  ngOnInit() {
    super.ngOnInit();
    this.getMileage();
  }

  protected handleNavigation(): void {
    this.yourMileageStore.pipe(
      select(selectYourMileageNavigationAndState),
      takeWhile(() => this.componentActive)
    ).subscribe(({isNextButtonClicked, isBackButtonClicked, navCommands, yourMileage}) => {
      if (isNextButtonClicked) {
        if (this.containerForm.valid && this.updateMileageOfRequestPayload(yourMileage)) {
          this.onNext(navCommands.next);
        } else {
          this.formService.updateControlValidity(this.containerForm);
          this.isFormValid = false;
          this.yourMileageStore.dispatch(YourMileageNavigationActions.resetButtons());
          setTimeout(() => {
            this.scrollingService.scrollToFirstSectionClass('.has-error');
          });
          return;
        }
      }

      if (isBackButtonClicked) {
        this.onBack(navCommands.prev);
      }

      if (isNextButtonClicked || isBackButtonClicked) {
        this.stpStore.dispatch(PolicyActions.resetPolicyStateErrors());
      }
    });
  }

  protected observeOnError(): void {
    this.isShowGatewayTimeoutWarning$ = this.stpStore.pipe(
      select(selectGatewayTimeoutError),
      filter(val => val),
      tap((data) => setTimeout(() => this.scrollingService.scrollToFirstSectionClass('.panel__error')))
    );

    this.isPromoCodeError$= this.stpStore.pipe(
      select(selectPromoCodeError),
      filter(val => val),
      tap(() => setTimeout(() => this.scrollingService.scrollToFirstSectionClass('.panel__invalid')))
    );
  }

  private getMileage(): void {
    this.currentMileageDisplay$ = this.stpStore.pipe(
      select(selectPolicyDetails),
      map(data => {
        const {result: {lobData: {mOTLine_Ext: {coverables: {motVehicles, vehicleDrivers}}}}} = data;
        const vehicleId = vehicleDrivers[0].vehicleID;
        const currentVehicle = motVehicles.filter(m => m.vehicle.publicID === vehicleId)[0].vehicle;

        return currentVehicle.annualMileage;
      })
    );
  }

  private createForm() {
    this.containerForm = this.fb.group({});

    this.containerForm.valueChanges.pipe(
      takeWhile(() => this.componentActive),
      filter(() => this.containerForm.valid)
    ).subscribe(({updatedMileage}) => {
      this.yourMileageStore.dispatch(YourMileageActions.updateMileage({updatedMileage}));
      this.isFormValid = true;
    });
  }

  private updateMileageOfRequestPayload({updatedMileage}): boolean {
    if (updatedMileage.mileage === '') {
      return false;
    }

    this.stpStore.dispatch(PolicyActions.updatePayloadChanges({data: {yourMileage: updatedMileage}}));
    return true;
  }

  private retrieveMileageFromStore() {
    this.mileage$ = this.yourMileageStore.pipe(select(selectUpdatedMileage));
  }
}
