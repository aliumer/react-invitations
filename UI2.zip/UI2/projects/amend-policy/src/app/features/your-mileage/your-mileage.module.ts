import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';
import { YourMileageRoutingModule } from './your-mileage-routing.module';

import { YourMileageContainerComponent } from './containers/your-mileage-container.component';
import { MileageDisplayComponent } from './components/mileage-display/mileage-display.component';

import * as fromYourMileage from './state/reducers';

@NgModule({
  declarations: [YourMileageContainerComponent, MileageDisplayComponent],
  imports: [
    SharedModule,
    YourMileageRoutingModule,
    StoreModule.forFeature('yourMileageStore', fromYourMileage.reducers)
  ]
})
export class YourMileageModule {
}
