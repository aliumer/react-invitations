import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';
import { ReviewServicesModule } from '@app/features/review/services/review-services.module';
import { ReviewRoutingModule } from './review-routing.module';

import { ReviewContainerComponent } from './containers/review-container.component';
import { ReviewFullContainerComponent } from './containers/full/review-full-container.component';
import { ReviewDirectDebitContainerComponent } from './containers/direct-debit/review-direct-debit-container.component';
import { YourCarSummaryComponent } from './components/your-car-summary/your-car-summary.component';
import { YourRegistrationSummaryComponent } from './components/your-registration-summary/your-registration-summary.component';
import { YourAddressSummaryComponent } from './components/your-address-summary/your-address-summary.component';
import { CorrespondenceAddressSummaryComponent } from './components/correspondence-address-summary/correspondence-address-summary.component';
import { YourDetailsSummaryComponent } from './components/your-details-summary/your-details-summary.component';
import { YourDirectDebitSummaryComponent } from './components/your-direct-debit-summary/your-direct-debit-summary.component';
import { YourDrivingHistorySummaryComponent } from './components/your-driving-history-summary/your-driving-history-summary.component';
import { YourAdditionalDriversSummaryComponent } from './components/your-additional-drivers-summary/your-additional-drivers-summary.component';
import { YourCoverSummaryComponent } from '@app/features/review/components/your-cover-summary/your-cover-summary.component';
import { ReviewAdditionalInfoComponent } from './components/review-additional-info/review-additional-info.component';
import { YourDiscountsSummaryComponent } from './components/your-discounts-summary/your-discounts-summary.component';
import { YourMileageSummaryComponent } from '@app/features/review/components/your-mileage-summary/your-mileage-summary.component';

import * as fromReview from './state/reducers';
import { YourConvictionsSummaryComponent } from './components/your-convictions-summary/your-convictions-summary.component';
import { YourTemporaryEuropeanCoverSummaryComponent } from './components/your-temporary-european-cover-summary/your-temporary-european-cover-summary.component';

@NgModule({
  declarations: [
    ReviewContainerComponent,
    ReviewFullContainerComponent,
    ReviewDirectDebitContainerComponent,
    YourCarSummaryComponent,
    YourMileageSummaryComponent,
    YourRegistrationSummaryComponent,
    YourAddressSummaryComponent,
    CorrespondenceAddressSummaryComponent,
    YourDetailsSummaryComponent,
    YourDirectDebitSummaryComponent,
    YourDrivingHistorySummaryComponent,
    YourAdditionalDriversSummaryComponent,
    YourDiscountsSummaryComponent,
    YourCoverSummaryComponent,
    ReviewAdditionalInfoComponent,
    YourConvictionsSummaryComponent,
    YourTemporaryEuropeanCoverSummaryComponent
  ],
  imports: [
    SharedModule,
    ReviewRoutingModule,
    ReviewServicesModule,
    StoreModule.forFeature('reviewStore', fromReview.reducers)
  ]
})
export class ReviewModule { }
