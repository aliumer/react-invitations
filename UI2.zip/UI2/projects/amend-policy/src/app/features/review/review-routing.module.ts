import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ReviewResolverService } from '@app/features/review/services/resolvers/review-resolver.service';

import { ReviewContainerComponent } from './containers/review-container.component';
import { ReviewFullContainerComponent } from './containers/full/review-full-container.component';
import { ReviewDirectDebitContainerComponent } from './containers/direct-debit/review-direct-debit-container.component';

const routes: Routes = [
  {
    path: '',
    component: ReviewContainerComponent,
    children: [
      {
        path: 'full',
        component: ReviewFullContainerComponent,
        resolve: {
          review: ReviewResolverService
        }
      },
      {
        path: 'direct-debit',
        component: ReviewDirectDebitContainerComponent
      }
    ],
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReviewRoutingModule { }
