import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';

import { SharedModule } from '@app/shared/shared.module';
import { BillingRoutingModule } from './billing-routing.module';
import { BillingServicesModule } from './services/billing-services.module';

import { BillingContainerComponent } from './containers/billing-container.component';
import { ErrorModalComponent } from '@app/features/billing/modals/error-modal/error-modal.component';

import { BillingEffects } from './state/effects/billing.effects';

@NgModule({
  declarations: [
    BillingContainerComponent,
    ErrorModalComponent
  ],
  imports: [
    SharedModule,
    BillingRoutingModule,
    BillingServicesModule,
    EffectsModule.forFeature([BillingEffects])
  ],
  entryComponents: [
    ErrorModalComponent
  ]
})
export class BillingModule {
}
