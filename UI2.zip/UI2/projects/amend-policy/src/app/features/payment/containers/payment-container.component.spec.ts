import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';
import { CoreModule } from '@app/core/core.module';

import { PaymentContainerComponent } from './payment-container.component';

import * as fromPayment from '@app/features/payment/state/reducers';

describe('YourCarContainerComponent', () => {
  let component: PaymentContainerComponent;
  let fixture: ComponentFixture<PaymentContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PaymentContainerComponent,
      ],
      imports: [
        CoreModule,
        SharedModule,
        RouterTestingModule,
        StoreModule.forRoot({}),
        StoreModule.forFeature('paymentStore', fromPayment.reducers)
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
