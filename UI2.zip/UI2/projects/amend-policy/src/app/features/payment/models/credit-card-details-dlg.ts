import { Person } from '@app/features/payment/models/person';
import { Address } from '@app/features/premium/models/address';

export interface CreditCardDetailsDlg {
  cardHolderName?: string;
  person?: Person;
  isPolicyHolderPayerInd?: boolean;
  isCardAuthorityInd?: boolean;
  consentToReuseCardInd?: boolean;
  cardType?: string;
  billingAddres?: Address;
  sameNameAndAddressInd?: boolean;
}

