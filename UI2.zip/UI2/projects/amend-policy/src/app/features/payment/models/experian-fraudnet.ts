export interface ExperianFraudnet {
  applicationId: string;
  device: Device;
}

interface Device {
  id: string;
  ipAddress: string;
  headers: Array<{ headerName: string, headerValue: string }>;
  userIdentityCookies: Array<{ key: string, value: string }>;
  jsc: string;
  hdim: { payload: string };
  modelCode: string;
  channelName: string;
  brandName: string;
  serverTime: string;
}
