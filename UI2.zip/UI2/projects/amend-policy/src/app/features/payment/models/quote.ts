import { Param } from '@app/features/payment/models/param';

export interface Quote {
  jsonrpc: string;
  method: string;
  params: Array<Param>;
}

