import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PaymentResolverService } from '@app/features/payment/services/resolvers/payment-resolver/payment-resolver.service';

import { PaymentContainerComponent } from './containers/payment-container.component';
import { DirectDebitDisplayContainerComponent } from '@app/features/payment/containers/direct-debit/direct-debit-display-container/direct-debit-display-container.component';
import { DirectDebitEditContainerComponent } from '@app/features/payment/containers/direct-debit/direct-debit-edit-container/direct-debit-edit-container.component';
import { AnnualContainerComponent } from '@app/features/payment/containers/annual-container/annual-container.component';
import { DirectDebitNewContainerComponent } from '@app/features/payment/containers/direct-debit/direct-debit-new-container/direct-debit-new-container.component';
import { DirectDebitReviewContainerComponent } from '@app/features/payment/containers/direct-debit/direct-debit-review-container/direct-debit-review-container.component';


const routes: Routes = [
  {
    path: '',
    component: PaymentContainerComponent,
    children: [
      {
        path: 'direct-debit-display',
        component: DirectDebitDisplayContainerComponent
      },
      {
        path: 'direct-debit-edit',
        component: DirectDebitEditContainerComponent
      },
      {
        path: 'direct-debit-new',
        component: DirectDebitNewContainerComponent
      },
      {
        path: 'direct-debit-review',
        component: DirectDebitReviewContainerComponent,
      },
      {
        path: 'credit-card',
        component: AnnualContainerComponent
      }
    ],
    resolve: {
      premium: PaymentResolverService
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PaymentRoutingModule {
}
