import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { PaymentRoutingModule } from '@app/features/payment/payment-routing.module';
import { PaymentServicesModule } from '@app/features/payment/services/payment-services.module';
import { SharedModule } from '@app/shared/shared.module';
import { AddressModule } from '@app/shared/address/address.module';

import { PaymentContainerComponent } from '@app/features/payment/containers/payment-container.component';
import { AnnualContainerComponent } from '@app/features/payment/containers/annual-container/annual-container.component';
import { DirectDebitDisplayContainerComponent } from '@app/features/payment/containers/direct-debit/direct-debit-display-container/direct-debit-display-container.component';
import { DirectDebitEditContainerComponent } from '@app/features/payment/containers/direct-debit/direct-debit-edit-container/direct-debit-edit-container.component';
import { DirectDebitNewContainerComponent } from './containers/direct-debit/direct-debit-new-container/direct-debit-new-container.component';
import { DirectDebitReviewContainerComponent } from './containers/direct-debit/direct-debit-review-container/direct-debit-review-container.component';

import { AccountHolderComponent } from '@app/features/payment/components/account-holder/account-holder.component';
import { BankAccountDetailsComponent } from '@app/features/payment/components/bank-account-details/bank-account-details.component';
import { CardholderAddressComponent } from '@app/features/payment/components/cardholder-address/cardholder-address.component';
import { CardholderComponent } from '@app/features/payment/components/cardholder/cardholder.component';
import { CardholderThirdPartyComponent } from '@app/features/payment/components/cardholder-third-party/cardholder-third-party.component';
import { CardTypeComponent } from '@app/features/payment/components/card-type/card-type.component';
import { DirectDebitAmountComponent } from '@app/features/payment/components/direct-debit-amount/direct-debit-amount.component';
import { DirectDebitDisplayComponent } from '@app/features/payment/components/direct-debit-display/direct-debit-display.component';
import { DirectDebitEditComponent } from '@app/features/payment/components/direct-debit-edit/direct-debit-edit.component'
import { DirectDebitThirdPartyComponent } from '@app/features/payment/components/direct-debit-third-party/direct-debit-third-party.component';
import { RepresentativeAPRComponent } from '@app/features/payment/components/representative-apr/representative-apr.component';
import { NumberOfSignaturesComponent } from '@app/features/payment/components/number-of-signatures/number-of-signatures.component';
import { PaymentAnnualSummaryComponent } from '@app/features/payment/components/payment-annual-summary/payment-annual-summary.component';
import { PaymentEntryFailModalComponent } from '@app/features/payment/modals/payment-entry-fail/payment-entry-fail-modal.component';
import { PaymentMonthlySummaryComponent } from '@app/features/payment/components/payment-monthly-summary/payment-monthly-summary.component';
import { WorldPayPaymentComponent } from '@app/features/payment/components/world-pay-payment/world-pay-payment.component';
import { DirectDebitPaymentReviewComponent } from './components/direct-debit-payment-review/direct-debit-payment-review.component';

import * as fromPayment from './state/reducers';

import { PaymentEffects } from './state/effects/payment.effects';

@NgModule({
  declarations: [
    AccountHolderComponent,
    AnnualContainerComponent,
    BankAccountDetailsComponent,
    CardholderAddressComponent,
    CardholderComponent,
    CardholderThirdPartyComponent,
    CardTypeComponent,
    DirectDebitAmountComponent,
    DirectDebitDisplayComponent,
    DirectDebitDisplayContainerComponent,
    DirectDebitEditComponent,
    DirectDebitEditContainerComponent,
    DirectDebitThirdPartyComponent,
    RepresentativeAPRComponent,
    NumberOfSignaturesComponent,
    PaymentAnnualSummaryComponent,
    PaymentContainerComponent,
    PaymentEntryFailModalComponent,
    PaymentMonthlySummaryComponent,
    WorldPayPaymentComponent,
    DirectDebitNewContainerComponent,
    DirectDebitReviewContainerComponent,
    DirectDebitPaymentReviewComponent
  ],
  imports: [
    SharedModule,
    AddressModule,
    PaymentRoutingModule,
    PaymentServicesModule,
    StoreModule.forFeature('paymentStore', fromPayment.reducers),
    EffectsModule.forFeature([PaymentEffects])
  ],
  entryComponents: [
    PaymentEntryFailModalComponent
  ]
})
export class PaymentModule {
}
