import { BaseData } from '@app/features/premium/models/base-data';
import { LobData } from '@app/features/premium/models/lob-data';
import { ExperianFraudnet } from './experian-fraudnet';

export interface Param {
  experianFraudNet?: ExperianFraudnet;
  baseData?: BaseData;
  bindData?: any;
  quoteID?: string;
  sessionUUID?: string;
  lobData?: LobData;
  quoteRef_dlg?: string;
  selectedPeriodPublicId_dlg?: string;
  manPromoCode_dlg?: string;
  performedExperianCheck_dlg?: boolean;
}
