import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { YourCarTempResolverService } from '@app/features/your-car/services/resolvers/your-car-temp-resolver.service';
import { YourCarPermResolverService } from '@app/features/your-car/services/resolvers/your-car-perm-resolver.service';

import { YourCarHoldingContainerComponent } from '@app/features/your-car/containers/your-car-holding-container.component';
import { YourCarPermContainerComponent } from '@app/features/your-car/containers/your-car-perm-container/your-car-perm-container.component';
import { YourCarTempContainerComponent } from '@app/features/your-car/containers/your-car-temp-container/your-car-temp-container.component';


const routes: Routes = [
  {
    path: '',
    component: YourCarHoldingContainerComponent,
    children: [
      {
        path: 'permanent',
        component: YourCarPermContainerComponent,
        resolve: {
          _: YourCarPermResolverService
        }
      },
      {
        path: 'temporary',
        component: YourCarTempContainerComponent,
        resolve: {
          _: YourCarTempResolverService
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YourCarRoutingModule { }
