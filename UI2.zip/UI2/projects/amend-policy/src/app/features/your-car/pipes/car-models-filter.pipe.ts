import { Pipe, PipeTransform } from '@angular/core';
import { VehicleFromAPI } from '@app/features/your-car/models/vehicle';

@Pipe({
  name: 'carModelsFilter'
})

export class CarModelsFilterPipe implements PipeTransform {

  transform(value: VehicleFromAPI[], args: any[]): VehicleFromAPI[] {

    args.forEach( filterBy => {
      const filterValue = Object.keys(filterBy)[0];
      if (filterBy[filterValue]) {
        value = value.filter( car => car[filterValue] === filterBy[filterValue]);
      }
    });

    return value;
  }

}
