import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';
import { CarPanelModule } from '@app/shared/car-panel/car-panel.module';
import { YourCarRoutingModule } from './your-car-routing.module';
import { YourCarServicesModule } from '@app/features/your-car/services/your-car-services.module';

import { YourCarHoldingContainerComponent } from './containers/your-car-holding-container.component';
import { YourCarPermContainerComponent } from './containers/your-car-perm-container/your-car-perm-container.component';
import { YourCarTempContainerComponent } from './containers/your-car-temp-container/your-car-temp-container.component';

import { CarLookupComponent } from './components/car-lookup/car-lookup.component';
import { CarDetailsComponent } from './components/car-details/car-details.component';
import { CarModificationsComponent } from './components/car-modifications/car-modifications.component';
import { PanelComponent } from './components/car-modifications/panel/panel.component';
import { PanelItemComponent } from './components/car-modifications/panel/panel-item/panel-item.component';
import { CarSelectManualComponent } from './components/car-select-manual/car-select-manual.component';

import { CarModelsFilterPipe } from './pipes/car-models-filter.pipe';

import * as fromYourCar from './state/reducers';

@NgModule({
  declarations: [
    YourCarPermContainerComponent,
    CarLookupComponent,
    CarDetailsComponent,
    CarModificationsComponent,
    PanelComponent,
    PanelItemComponent,
    CarSelectManualComponent,
    CarModelsFilterPipe,
    YourCarHoldingContainerComponent,
    YourCarTempContainerComponent
  ],
  imports: [
    SharedModule,
    CarPanelModule,
    YourCarRoutingModule,
    YourCarServicesModule,
    StoreModule.forFeature('yourCarStore', fromYourCar.reducers)
  ]
})
export class YourCarModule { }
