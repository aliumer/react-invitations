import { PanelItem } from './panel-item';

export interface Panel {
  key: string;
  title: string;
  description?: string;
  selectedItemCount?: number;
  isItemOpened: boolean;
  panelItems: PanelItem[];
}
