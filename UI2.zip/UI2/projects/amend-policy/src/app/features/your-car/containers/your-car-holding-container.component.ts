import { Component } from '@angular/core';


@Component({
  selector: 'app-your-car-holding-container',
  template: `<router-outlet></router-outlet>`
})
export class YourCarHoldingContainerComponent {
}
