import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YourCarHoldingContainerComponent } from './your-car-holding-container.component';

describe('YourCarHoldingContainerComponent', () => {
  let component: YourCarHoldingContainerComponent;
  let fixture: ComponentFixture<YourCarHoldingContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YourCarHoldingContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YourCarHoldingContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
