import { FormControl } from '@angular/forms';

import { YourCarValidators } from '@app/features/your-car/validators/your-car.validators';

fdescribe('YourCarValidators', () => {
  it('should show error if temp regno is same as perm regno, same case', () => {
    const tempRegContrl = new FormControl('GK13AOU', YourCarValidators.sameRegistration('GK13AOU'));
    tempRegContrl.updateValueAndValidity();
    expect(tempRegContrl.valid).toBe(false);
    expect(tempRegContrl.errors).toEqual({sameReg: true});
  });

  it('should show error if temp regno is same as perm regno, different case', () => {
    const tempRegContrl = new FormControl('GK13AOU', YourCarValidators.sameRegistration('Gk13 aou'));
    tempRegContrl.updateValueAndValidity();
    expect(tempRegContrl.valid).toBe(false);
    expect(tempRegContrl.errors).toEqual({sameReg: true});
  });

  it('should not show error if temp regno is not same as perm regno', () => {
    const tempRegContrl = new FormControl('GK13AOU', YourCarValidators.sameRegistration('WN18 UML'));
    tempRegContrl.updateValueAndValidity();
    expect(tempRegContrl.valid).toBe(true);
    expect(tempRegContrl.errors).toBe(null);
  });

  it('should not show error if temp regno control is empty', () => {
    const tempRegContrl = new FormControl('', YourCarValidators.sameRegistration('WN18 UML'));
    tempRegContrl.updateValueAndValidity();
    expect(tempRegContrl.valid).toBe(true);
    expect(tempRegContrl.errors).toBe(null);
  });
});
