import { KeyValue } from '@angular/common';

export interface Modification {
  name: string;
  title: string;
  items: KeyValue<string, string>[];
}
