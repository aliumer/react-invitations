import { RegisteredKeeperFull } from '@app/infrastructure/data/your-car.data';

export class YourCarHelpers {
  static mapInitialCarDetailsToYourCarDetails(initialCarDetails: any) {
    const {engineSize,bodyType,fuelType, registrationNumber, transmission, year, make, model, vin, color, noOfDoors, costNew, vRNLookupResp, carWebId } = initialCarDetails;
    const {refID: intCode, carwebIndicativeValue: estimatedValue} = vRNLookupResp;
    const {modifications, isVehiclePurchased, isVehicleModified, annualMileage, registeredOwner, costNew: {amount}} = initialCarDetails;

    const registeredKeeper = RegisteredKeeperFull.find(kv => kv.key === registeredOwner);
    return {
      car: {engineSize,bodyType,fuelType, registrationNumber, transmission, year, make, model, vin, color, noOfDoors, costNew, intCode, estimatedValue, carWebId},
      details: {
        vehicleModified: isVehicleModified ? 'Yes': 'No',
        vehiclePurchased: isVehiclePurchased ? 'Yes': 'No',
        vehicleModifications: modifications,
        registeredKeeper,
        mileage: annualMileage,
        carValue: amount
      }
    };
  }
}
