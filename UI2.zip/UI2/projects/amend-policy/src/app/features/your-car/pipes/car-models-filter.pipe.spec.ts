import { CarModelsFilterPipe } from './car-models-filter.pipe';

describe('CarModelsFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CarModelsFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
