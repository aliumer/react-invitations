import { AbstractControl } from '@angular/forms';

export class YourCarValidators {
  static sameRegistration(registrationNo: string) {
    return function sameRegistration(control: AbstractControl) {
      return control.value?.replace(' ', '').toLowerCase() === registrationNo.replace(' ', '').toLowerCase()
        ? {sameReg: true}
        : null;
    };
  }
}
