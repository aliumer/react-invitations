export interface PanelItem {
  key: string;
  title: string;
  isSelected: boolean;
}
