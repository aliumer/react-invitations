import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { tap, map, filter, takeWhile } from 'rxjs/operators';

import { FormService } from '@app/core/services/form-builder/form.service';
import { ScrollingService } from '@app/shared/services/scrolling/scrolling.service';

import { FeatureBase } from '@app/infrastructure/abstracts/feature-base/feature.base';

import { State as StpState } from '@app/stp/state/reducers';
import { State as YourRegistrationState } from '@app/features/your-registration/state/reducers';
import { State as YourCarState } from '@app/features/your-car/state/reducers';

import { JourneyNavigationActions, PolicyActions } from '@app/stp/state/actions';
import { YourRegistrationActions, YourRegistrationNavigationActions } from '@app/features/your-registration/state/actions';

import {
  selectGatewayTimeoutError,
  selectPolicyDetails,
  selectPermVehicleRegistration,
  selectPromoCodeError,
} from '@app/stp/state/selectors';
import {
  getYourRegistrationError,
  selectYourVehicleDetails,
  selectUpdatedCarDetails,
  selectYourRegistrationNavigationAndState,
  selectYourRegistrationNavigation,
} from '@app/features/your-registration/state/selectors';

import { CustomUtility } from '@app/infrastructure/helpers/custom-utility';

import { Vehicle } from '@app/features/your-car/models/vehicle';

@Component({
  selector: 'app-your-registration-container',
  templateUrl: './your-registration-container.component.html'
})
export class YourRegistrationContainerComponent extends FeatureBase<YourRegistrationState> implements OnInit, OnDestroy {

  currentVehicleDisplay$: Observable<Vehicle>;
  isNoCarNumberPlate = false;
  newVehicleDisplay$: Observable<Vehicle>;
  updatedCarDetails$: Observable<any>;
  navSubscription$: Subscription;
  permVehicleRegistration$: Observable<string>;

  isCarFound = false;
  isShowCarValueField = true;
  isFormValid = true;
  newVehicle = null;
  regMatch = false;

  constructor(
    protected router: Router,
    protected yourRegistrationStore: Store<YourRegistrationState>,
    protected yourCarStore: Store<YourCarState>,
    private stpStore: Store<StpState>,
    private formService: FormService,
    private scrollingService: ScrollingService,
    private fb: FormBuilder
  ) {
    super(
      router,
      yourRegistrationStore,
      'yourRegistration',
      selectYourRegistrationNavigation,
      YourRegistrationNavigationActions.resetButtons,
      YourRegistrationNavigationActions.setupNavigation,
      JourneyNavigationActions.setNavDirection,
      YourRegistrationActions.resetError,
      getYourRegistrationError
    );
    this.createForm();
  }

  private static mapToVehicleDisplay(policyDetails: any): Vehicle {
    const {result: {lobData: {mOTLine_Ext: {coverables: {motVehicles}}}}} = policyDetails;

    const permVehicle = motVehicles.filter(v => v.vehicle.typeOfVehicle === 'permanent')[0].vehicle;
    const {make, model, registrationNumber, transmission, fuelType, year, engineSize, bodyType} = permVehicle;
    return {make, model, registrationNumber, transmission, fuelType, year, engineSize, bodyType};
  }

  onRegMatch(regMatchFlag: boolean) {
    this.changeNextButtonStatus(regMatchFlag);
  }

  onResetCar() {
    this.isNoCarNumberPlate = false;
    this.yourRegistrationStore.dispatch(YourRegistrationActions.resetCar());
    this.regMatch = false;
    this.changeNextButtonStatus(true);
  }

  onCarFound(newVehicle: any) {
    this.yourRegistrationStore.dispatch(YourRegistrationActions.carLookupSuccess({newVehicle}));
    this.isNoCarNumberPlate = false;
    this.newVehicle = newVehicle;
  }

  ngOnInit() {
    super.ngOnInit();
    this.observeOnData();
  }

  ngOnDestroy(): void {
    super.ngOnDestroy();
    if (this.navSubscription$) {
      this.navSubscription$.unsubscribe();
    }
  }

  protected handleNavigation(): void {
    this.navSubscription$ = this.yourRegistrationStore.pipe(
      select(selectYourRegistrationNavigationAndState),
      takeWhile(() => this.componentActive)
    ).subscribe(({isNextButtonClicked, isBackButtonClicked, navCommands, yourRegistration}) => {
      if (isNextButtonClicked) {
        if (this.containerForm.valid && this.updateVehicleDetailsOfRequestPayload(yourRegistration)) {
          this.onNext(navCommands.next);
        } else {
          this.formService.updateControlValidity(this.containerForm);
          this.isFormValid = false;
          this.yourRegistrationStore.dispatch(YourRegistrationNavigationActions.resetButtons());
          setTimeout(() => {
            this.scrollingService.scrollToFirstSectionClass('.has-error');
          });
          return;
        }
      }

      if (isBackButtonClicked) {
        this.onBack(navCommands.prev);
      }

      if (isNextButtonClicked || isBackButtonClicked) {
        this.stpStore.dispatch(PolicyActions.resetPolicyStateErrors());
      }
    });
  }

  protected observeOnError(): void {
    this.isShowGatewayTimeoutWarning$ = this.stpStore.pipe(
      select(selectGatewayTimeoutError),
      filter(val => val),
      tap(() => setTimeout(() => this.scrollingService.scrollToFirstSectionClass('.panel__error') ))
    );

    this.isPromoCodeError$= this.stpStore.pipe(
      select(selectPromoCodeError),
      filter(val => val),
      tap(() => setTimeout(() => this.scrollingService.scrollToFirstSectionClass('.panel__invalid')))
    );
  }

  private changeNextButtonStatus(isDisabled: boolean) {
    this.stpStore.dispatch(JourneyNavigationActions.changeButtonStatus({id: 'continue', status: isDisabled}));
  }

  private updateVehicleDetailsOfRequestPayload({newVehicle, updatedCarDetails}): boolean {
    if (CustomUtility.isEmptyObject(newVehicle) || CustomUtility.isEmptyObject(updatedCarDetails)) {
      return false;
    }

    const vehicleRegNumber = {
      registrationNumber: newVehicle.registrationNumber
    };

    this.stpStore.dispatch(PolicyActions.updatePayloadChanges({data: {yourRegistration: vehicleRegNumber}}));
    return true;
  }

  private createForm() {
    this.containerForm = this.fb.group({});
    this.containerForm.valueChanges.pipe(
      takeWhile(() => this.componentActive),
      filter(() => this.containerForm.valid)
    ).subscribe(({updatedCarDetails}) => {
      this.yourRegistrationStore.dispatch(YourRegistrationActions.updateCarDetails({updatedCarDetails}));
      this.isFormValid = true;
    });
  }

  private observeOnData(): void {
    this.currentVehicleDisplay$ = this.yourRegistrationStore.pipe(
      select(selectPolicyDetails),
      filter(val => val),
      map(YourRegistrationContainerComponent.mapToVehicleDisplay)
    );

    this.newVehicleDisplay$ = this.yourRegistrationStore.pipe(
      select(selectYourVehicleDetails),
      tap(data => {
        this.isCarFound = !!data;
        if (this.isCarFound) {
          this.isShowCarValueField = !data.estimatedValue || data.estimatedValue <= 0;
          this.isNoCarNumberPlate = !data.registrationNumber || data.registrationNumber === 'TBC';
        }
      })
    );

    this.updatedCarDetails$ = this.yourRegistrationStore.pipe(
      select(selectUpdatedCarDetails),
      tap(data => {
        if (Object.keys(data).length !== 0 && data.constructor === Object) {
          if (data.reg !== '' && (data.newRegMatch !== '' && data.newRegMatch !== 'No')) {
            this.changeNextButtonStatus(false);
          }
        }
      })
    );

    this.permVehicleRegistration$ = this.stpStore.pipe(select(selectPermVehicleRegistration));
    this.changeNextButtonStatus(!this.regMatch);
  }
}
