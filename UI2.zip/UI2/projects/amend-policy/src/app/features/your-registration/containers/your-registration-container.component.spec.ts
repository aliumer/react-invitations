import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YourRegistrationContainerComponent } from './your-registration-container.component';

describe('YourRegistrationContainerComponent', () => {
  let component: YourRegistrationContainerComponent;
  let fixture: ComponentFixture<YourRegistrationContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [YourRegistrationContainerComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YourRegistrationContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
