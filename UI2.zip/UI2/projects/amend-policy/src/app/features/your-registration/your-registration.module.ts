import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';
import { CarPanelModule } from '@app/shared/car-panel/car-panel.module';
import { YourRegistrationRoutingModule } from './your-registration-routing.module';
import { YourCarServicesModule } from '@app/features/your-car/services/your-car-services.module';

import { YourRegistrationContainerComponent } from './containers/your-registration-container.component';
import { CarLookupComponent } from './components/car-lookup/car-lookup.component';

import * as fromYourRegistration from './state/reducers';

@NgModule({
  declarations: [
    YourRegistrationContainerComponent,
    CarLookupComponent
  ],
  imports: [
    SharedModule,
    CarPanelModule,
    YourRegistrationRoutingModule,
    YourCarServicesModule,
    StoreModule.forFeature('yourRegistrationStore', fromYourRegistration.reducers)
  ]
})
export class YourRegistrationModule {
}
