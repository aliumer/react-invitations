import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { YourRegistrationContainerComponent } from '@app/features/your-registration/containers/your-registration-container.component';

const routes: Routes = [
  {
    path: '',
    component: YourRegistrationContainerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YourRegistrationRoutingModule {
}
