import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardHoldingContainerComponent } from '@app/features/dashboard/containers/dashboard-holding-container.component';
import { SelectOptionsContainerComponent } from '@app/features/dashboard/containers/select-options-container/select-options-container.component';
import { UpdateDetailsContainerComponent } from '@app/features/dashboard/containers/update-details-container/update-details-container.component';


const routes: Routes = [
  {
    path: '',
    component: DashboardHoldingContainerComponent,
    children: [
      {
        path: 'select',
        component: SelectOptionsContainerComponent
      },
      {
        path: 'update',
        component: UpdateDetailsContainerComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule {
}
