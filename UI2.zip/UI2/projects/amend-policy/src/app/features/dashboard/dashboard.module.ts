import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardServicesModule } from './services/dashboard-services.module'
import { SharedModule } from '@app/shared/shared.module';

import { DashboardHoldingContainerComponent } from './containers/dashboard-holding-container.component';
import { SelectOptionsContainerComponent } from './containers/select-options-container/select-options-container.component';
import { UpdateDetailsContainerComponent } from './containers/update-details-container/update-details-container.component';
import { PolicyChangeSelectorComponent } from './components/policy-change-selector/policy-change-selector.component';
import { PolicyChangeSelectionsComponent } from './components/policy-change-selections/policy-change-selections.component';
import { PolicyChangeDateComponent } from './components/policy-change-date/policy-change-date.component';
import { TemporaryChangeSelectionsComponent } from './components/temporary-change-selections/temporary-change-selections.component';
import { DashboardMessagePanelComponent } from './components/dashboard-message-panel/dashboard-message-panel.component';
import { PolicyPromoCodeComponent } from './components/policy-promo-code/policy-promo-code.component';
import { DashboardHeaderComponent } from './components/dashboard-header/dashboard-header.component';

import { DashboardEffects } from './state/effects/dashboard.effects';

import * as fromDashboard from './state/reducers';

@NgModule({
  declarations: [
    PolicyChangeSelectorComponent,
    PolicyChangeSelectionsComponent,
    PolicyChangeDateComponent,
    TemporaryChangeSelectionsComponent,
    DashboardHoldingContainerComponent,
    SelectOptionsContainerComponent,
    UpdateDetailsContainerComponent,
    DashboardMessagePanelComponent,
    PolicyPromoCodeComponent,
    DashboardHeaderComponent
  ],
  imports: [
    SharedModule,
    DashboardRoutingModule,
    DashboardServicesModule,
    StoreModule.forFeature('dashboardStore', fromDashboard.reducers),
    EffectsModule.forFeature([DashboardEffects])
  ]
})
export class DashboardModule {
}
