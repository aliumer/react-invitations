import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoadPolicyContainerComponent } from './containers/load-policy-container.component';

const routes: Routes = [
  {
    path: '',
    component: LoadPolicyContainerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoadPolicyRoutingModule {
}
