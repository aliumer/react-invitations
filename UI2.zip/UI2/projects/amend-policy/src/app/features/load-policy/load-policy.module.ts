import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';

import { SharedModule } from '@app/shared/shared.module';
import { LoadPolicyRoutingModule } from './load-policy-routing.module';
import { LoadPolicyServicesModule } from './services/load-policy-services.module';

import { LoadPolicyContainerComponent } from './containers/load-policy-container.component';
import { ErrorModalComponent } from '@app/features/load-policy/modals/error-modal/error-modal.component';

import { LoadPolicyEffects } from './state/effects/load-policy.effects';

@NgModule({
  declarations: [
    LoadPolicyContainerComponent,
    ErrorModalComponent
  ],
  imports: [
    SharedModule,
    LoadPolicyRoutingModule,
    LoadPolicyServicesModule,
    EffectsModule.forFeature([LoadPolicyEffects])
  ],
  entryComponents: [
    ErrorModalComponent
  ]
})
export class LoadPolicyModule {
}
