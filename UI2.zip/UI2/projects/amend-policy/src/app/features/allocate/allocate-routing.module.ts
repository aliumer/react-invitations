import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AllocateResolverService } from '@app/features/allocate/services/resolvers/allocate-resolver.service';

import { AllocateContainerComponent } from '@app/features/allocate/containers/allocate-container.component';


const routes: Routes = [
  {
    path: '',
    component: AllocateContainerComponent,
    resolve: {
      allocate: AllocateResolverService
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AllocateRoutingModule { }
