import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { SharedModule } from '@app/shared/shared.module';
import { AllocateRoutingModule } from './allocate-routing.module';
import { AllocateServicesModule } from '@app/features/allocate/services/allocate-services.module';

import { AllocateContainerComponent } from './containers/allocate-container.component';
import { AllocateTempCarComponent } from './components/allocate-temp-car/allocate-temp-car.component';
import { AllocatePermCarComponent } from './components/allocate-perm-car/allocate-perm-car.component';
import { VehicleDisplayComponent } from './components/vehicle-display/vehicle-display.component';

import * as fromAllocate from './state/reducers';
import * as fromYourCar from '@app/features/your-car/state/reducers';

@NgModule({
  declarations: [AllocateContainerComponent, AllocateTempCarComponent, AllocatePermCarComponent, VehicleDisplayComponent],
  imports: [
    SharedModule,
    AllocateRoutingModule,
    AllocateServicesModule,
    StoreModule.forFeature('allocateStore', fromAllocate.reducers),
    // don't remove this; needed to clear the drivers - nshathish
    StoreModule.forFeature('yourCarStore', fromYourCar.reducers)
  ]
})
export class AllocateModule { }
