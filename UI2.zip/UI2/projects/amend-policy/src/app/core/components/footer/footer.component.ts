import { Component } from '@angular/core';

import { environment } from '@env/environment';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html'
})
export class FooterComponent {
  footerCopy = environment.brand_copy;
  currentYear = new Date().getFullYear();
}
