import { throwIfAlreadyLoaded } from '@app/core/guards/module-import.guard';

fdescribe('Module Import Guard', () => {
  it('should throw error if module has a parent', () => {
    try {
      throwIfAlreadyLoaded({}, 'CoreModule');
    } catch (e) {
      expect(true).toBe(true);
    }
  });
});
