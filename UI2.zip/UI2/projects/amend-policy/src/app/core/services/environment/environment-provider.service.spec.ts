import { TestBed, inject } from '@angular/core/testing';

import { EnvironmentProviderService } from './environment-provider.service';
import { Environment } from '@app/core/models/environment';



describe('EnvironmentProviderService', () => {
  beforeEach(() => {
    const windowMock: Window = {
      browserWindow : {
        __env : {
          apiUrl : 'apiUrl'
        }
      }
    } as any;
    TestBed.configureTestingModule({
      providers: [
        EnvironmentProviderService,
        { provide: 'Window', useFactory: (() => windowMock) }
      ]
    });
  });


  it('should be created', inject([Environment], (service: Environment) => {
    expect(service).toBeTruthy();
  }));
});
