import { TestBed } from '@angular/core/testing';

import { Asset } from 'dlg-dolphin/dist/lib/dolphin/asset/asset';
import { Page } from 'dlg-dolphin/dist/lib/dolphin/page/page';
import { Action } from 'dlg-dolphin/dist/lib/dolphin/action/action';
import { User } from 'dlg-dolphin/dist/lib/dolphin/user/user';
import {
  DlgDataAssetCar,
  DlgUserProfile,
  DlgData
} from 'dlg-dolphin/dist/lib/interfaces/dlg-data';

import { AnalyticsService } from './analytics.service';

import {
  mockAdditionalDriver,
  mockCarData,
  mockPolicy
} from '@app/infrastructure/mocks/payloads/analytics-mock';
import { JourneyFeatures } from '@app/infrastructure/data/journey-features';

describe('AnalyticsService', () => {
  let service: AnalyticsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AnalyticsService]
    });

    service = TestBed.inject(AnalyticsService);
    window.dlg_dolphin = {
      architecture: 'SPA',
      brand: 'Privilege Oh Yes!',
      version: '1.0.2',
      type: 'Quote And Buy',
      firstLoad: true,
      page: {} as Page,
      // campaign: {} as Campaign,
      // link: {} as Link,
      action: {} as Action,
      error: {
        trackError: () => {},
      },
      trackPage: () => {
      },
      user: {
        trackUser: (userProfile?: DlgUserProfile) => {
          window.dlg_data.user.push({profile: userProfile});
        },
        removeTrackedUser: (index: number) => {
        }
      } as User,
      asset: {
        trackAssetCar: (car?: DlgDataAssetCar) => {
          window.dlg_data.asset.car.push(car);
        },
        removeTrackedAssetCar: (index: number) => {
        }
      } as Asset,
      trafficSource: { trackTrafficSource: () => { } },
      policy: { trackPolicyOrQuote: () => { } },
      quote: { trackMotorQb: () => { } },
    } as any;

    window.dlg_data = {
      action: [],
      user: [],
      policy: {info: []},
      asset: {car: []},
      quote: {},
      traffic_source: {}
    } as DlgData;

    spyOn<any>(AnalyticsService, 'mapFeature');
  });

  it('AnalyticsService shoule be created', () => {
    expect(service).toBeTruthy();
  });

  it('should track the page', () => {
    spyOn(window.dlg_dolphin, 'trackPage');
    service.trackPage();
    expect(window.dlg_dolphin.trackPage).toHaveBeenCalled();
  });

  it('should track asset car', () => {
    spyOn(window.dlg_dolphin.asset, 'trackAssetCar');
    service.trackFeature('yourCarPerm', mockCarData);
    expect(window.dlg_dolphin.asset.trackAssetCar).toHaveBeenCalled();
  });

  it('should track additional driver', () => {
    spyOn(window.dlg_dolphin.user, 'trackUser');
    service.trackFeature(JourneyFeatures.yourDetails.name, mockAdditionalDriver[0]);
    expect(window.dlg_dolphin.user.trackUser).toHaveBeenCalled();
  });

  it('should track policy name', () => {
    const spy = spyOn(window.dlg_dolphin.policy, 'trackPolicyOrQuote');
    service.trackFeature('policy', mockPolicy);
    expect(spy).toHaveBeenCalled();
  });

  it('should track policy if there is existing policy', () => {
    const spy = spyOn(window.dlg_dolphin.policy, 'trackPolicyOrQuote');
    service.trackFeature('policy', mockPolicy);
    expect(spy).toHaveBeenCalled();
  });

  it('should track policy', () => {
    spyOn(window.dlg_dolphin.quote, 'trackMotorQb');
    service.trackFeature('quote', mockPolicy);
    expect(window.dlg_dolphin.quote.trackMotorQb).toHaveBeenCalled();
  });


  it('should untrack additional driver', () => {
    spyOn(window.dlg_dolphin.user, 'removeTrackedUser');
    service.removedTrackedFeature(JourneyFeatures.yourDetails.name, 0);
    expect(window.dlg_dolphin.user.removeTrackedUser).toHaveBeenCalled();
  });

  it('should untrack asset car', () => {
    spyOn(window.dlg_dolphin.asset, 'removeTrackedAssetCar');
    service.removedTrackedFeature('yourCarPerm', 0);
    expect(window.dlg_dolphin.asset.removeTrackedAssetCar).toHaveBeenCalled();
  });

  it('should track error', () => {
    spyOn(window.dlg_dolphin.error, 'trackError');
    service.trackError();
    expect(window.dlg_dolphin.error.trackError).toHaveBeenCalled();
  });

  it('should track source', () => {
    spyOn(window.dlg_dolphin.trafficSource, 'trackTrafficSource');
    service.trackSource('https://www.gocompare.com/');
    expect(window.dlg_dolphin.trafficSource.trackTrafficSource).toHaveBeenCalled();
  });

  it('should track driver added', () => {
    window.dlg_data.quote.drivers_added = 1;
    service.driverAdded();
    expect(window.dlg_data.quote.drivers_added).toBe(1);
  });

  it('should track driver removed', () => {
    window.dlg_data.quote.drivers_added = 1;
    service.driverRemoved();
    expect(window.dlg_data.quote.drivers_added).toBe(1);
  });
});
