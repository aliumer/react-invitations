import { Injectable } from '@angular/core';

import {
  DlgDataAssetCar,
  DlgUserProfile,
  DlgDataQuote,
  DlgDataPolicyInfo,
  DlgDataError
} from 'dlg-dolphin/dist/lib/interfaces/dlg-data';

import { CoreServicesModule } from '@app/core/services/core-services.module';

import { MapperFactory } from './mappers/analytical-mappers';
import { JourneyFeatures } from '@app/infrastructure/data/journey-features';


@Injectable({
  providedIn: CoreServicesModule
})
export class AnalyticsService {
  private quote: DlgDataQuote;
  private policy: DlgDataPolicyInfo;

  private static mapFeature(featureName: string, formData: any) {
    return MapperFactory.create(featureName).mapFeature(formData);
  }

  trackPage(): void {
    window.dlg_dolphin.trackPage();
  }

  trackSource(site?: string): void {
    window.dlg_dolphin.trafficSource.trackTrafficSource(site);
  }

  trackError(data?: DlgDataError) {
    window.dlg_dolphin.error.trackError(data);
  }

  trackFeature(featureName: string, formData: any): void {
    const data = AnalyticsService.mapFeature(featureName, formData);
    switch (featureName) {
      case JourneyFeatures.yourCarPerm.name:
        window.dlg_dolphin.asset.trackAssetCar(data as DlgDataAssetCar);
        break;
      case JourneyFeatures.yourDetails.name:
        window.dlg_dolphin.user.trackUser(data as DlgUserProfile);
        break;
      case JourneyFeatures.policy.name:
        this.policy = { ...this.policy, ...data};
        if (window.dlg_data.policy.info.length > 0) {
          window.dlg_data.policy.info[0] = this.policy;
        } else {
          window.dlg_dolphin.policy.trackPolicyOrQuote(data);
        }
        break;
      case JourneyFeatures.quote.name:
        this.quote = { ...this.quote, ...data};
        window.dlg_dolphin.quote.trackMotorQb(this.quote);
        break;
      default:
        break;
    }
  }

  removedTrackedFeature(featureName: string, index) {
    switch (featureName) {
      case JourneyFeatures.yourDetails.name:
        window.dlg_dolphin.user.removeTrackedUser(index);
        break;
      case JourneyFeatures.yourCarPerm.name:
        window.dlg_dolphin.asset.removeTrackedAssetCar(index);
        break;
      default:
        break;
    }
  }

  driverAdded() {
    const added: number = (window.dlg_data.quote.drivers_added ? window.dlg_data.quote.drivers_added : 0) + 1;
    this.trackFeature(JourneyFeatures.quote.name, {drivers_added: added});
  }

  driverRemoved() {
    const removed: number = (window.dlg_data.quote.drivers_removed ? window.dlg_data.quote.drivers_removed : 0) + 1;
    this.trackFeature(JourneyFeatures.quote.name, {drivers_removed: removed});
  }
}
