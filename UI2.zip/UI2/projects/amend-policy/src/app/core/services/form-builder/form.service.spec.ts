import { TestBed } from '@angular/core/testing';

import { FormService } from './form.service';
import { CoreModule } from '@app/core/core.module';


describe('FormService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      CoreModule
    ]
  }));

  it('should be created', () => {
    const service: FormService = TestBed.get(FormService);
    expect(service).toBeTruthy();
  });
});
