import { Environment } from '@app/core/models/environment';

import { EnvironmentProviderConfig } from './environment-provider.config';

export const EnvironmentServiceFactory = () => {
  const env = new Environment();
  const hostName = window.location.hostname;
  const envSetting = EnvironmentProviderConfig.find(c => c.key === hostName).values;

  for (const [key, value] of Object.entries(envSetting)) {
    env[key] = value;
  }

  return env;
};

export const EnvironmentProviderService = {
  provide: Environment,
  useFactory: EnvironmentServiceFactory,
  deps: []
};
