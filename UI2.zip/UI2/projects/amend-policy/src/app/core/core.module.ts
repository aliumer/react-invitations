import { NgModule, Optional, SkipSelf } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { SharedModule } from '@app/shared/shared.module';
import { CoreServicesModule } from '@app/core/services/core-services.module';

import { EnvironmentProviderService } from '@app/core/services/environment/environment-provider.service';

import { HeaderComponent } from '@app/core/components/header/header.component';
import { ProgressBarComponent } from '@app/core/components/progress-bar/progress-bar.component';
import { FooterComponent } from '@app/core/components/footer/footer.component';

import { throwIfAlreadyLoaded } from './guards/module-import.guard';


@NgModule({
  imports: [
    HttpClientModule,
    CoreServicesModule,
    SharedModule
  ],
  declarations: [
    HeaderComponent,
    ProgressBarComponent,
    FooterComponent
  ],
  exports: [
    HeaderComponent,
    ProgressBarComponent,
    FooterComponent
  ],
  providers: [
    EnvironmentProviderService
  ]
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    throwIfAlreadyLoaded(parentModule, 'CoreModule');
  }
}
