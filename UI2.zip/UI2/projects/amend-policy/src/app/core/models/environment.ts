export class Environment {
  public production = false;
  public apiRouting = '';
  public apiUrl = '';
  public apiKey = '';
  public recaptchaSiteKey = '';
  public analyticsScript = '';
  public tealiumScript = '';
  public tealiumSync = '';
}
