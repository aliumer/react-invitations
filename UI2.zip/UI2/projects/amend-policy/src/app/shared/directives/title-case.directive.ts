import { Directive, ElementRef, HostListener } from '@angular/core';

import { TextHelpers } from '@app/infrastructure/helpers/text-helpers';


@Directive({
  selector: '[appTitleCase]'
})
export class TitleCaseDirective {

  @HostListener('change', ['$event']) onChange($event: Event) {
    const titleCaseValue = TextHelpers.convertToTitleCase(($event.target as HTMLInputElement).value);
    if (this.el.nativeElement.children.length > 0) {
      (this.el.nativeElement.children[0] as HTMLInputElement).value = titleCaseValue;
    } else {
      (this.el.nativeElement as HTMLInputElement).value = titleCaseValue;
    }

    // must create an "input" event, if not, there are no change in your value (though ui is changed)
    const evt = document.createEvent('Event');
    evt.initEvent('input', false, true);
    $event.target.dispatchEvent(evt);
  }

  constructor(
    private el: ElementRef
  ) { }

}
