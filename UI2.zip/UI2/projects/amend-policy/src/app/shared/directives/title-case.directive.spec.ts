
describe('TitleCaseDirective', () => {
  /*it('should create an instance', () => {
    const directive = new TitleCaseDirective();
    expect(directive).toBeTruthy();
  });*/
});
