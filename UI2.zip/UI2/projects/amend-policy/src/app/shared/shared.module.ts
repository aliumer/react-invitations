import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CurrencyPipe } from '@angular/common';

import { DlgWalrusModule } from 'dlg-angular-components';

import { SharedServicesModule } from '@app/shared/services/shared-services.module';

import { DirectDebitTableComponent } from '@app/shared/components/direct-debit-table/direct-debit-table.component';
import { ErrorComponent } from '@app/shared/components/errors/error/error.component';
import { SaveModalComponent } from '@app/shared/components/modals/save-modal/save-modal.component';
import { RemoveModalComponent } from '@app/shared/components/modals/remove-modal/remove-modal.component';
import { SectionHeadingComponent } from './components/section-heading/section-heading.component';
import { InLineErrorComponent } from './components/errors/in-line-error/in-line-error.component';
import { CarStatusReminderComponent } from '@app/shared/components/car-status-reminder/car-status-reminder.component';
import { SingleAlertComponent } from '@app/shared/components/single-alert/single-alert.component';
import { PromoCodeErrorComponent } from './components/errors/promo-code-error/promo-code-error.component';

import { TitleCaseDirective } from './directives/title-case.directive';
import { FormatAmountPipe } from '@app/shared/pipes/amount-format.pipe';
import { TextSpacePipe } from '@app/shared/pipes/text-space.pipe';
import { SortCodePipe } from '@app/shared/pipes/sort-code.pipe';
import { MaskValuePipe } from '@app/shared/pipes/mask-value.pipe';
import { OrdinalNumberPipe } from '@app/shared/pipes/ordinal-number.pipe';

@NgModule({
  declarations: [
    FormatAmountPipe,
    TextSpacePipe,
    SortCodePipe,
    MaskValuePipe,
    OrdinalNumberPipe,
    TitleCaseDirective,
    DirectDebitTableComponent,
    ErrorComponent,
    SaveModalComponent,
    RemoveModalComponent,
    SectionHeadingComponent,
    InLineErrorComponent,
    CarStatusReminderComponent,
    SingleAlertComponent,
    PromoCodeErrorComponent
  ],
  imports: [
    DlgWalrusModule,
    CommonModule
  ],
  exports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DlgWalrusModule,
    SharedServicesModule,
    TitleCaseDirective,
    FormatAmountPipe,
    TextSpacePipe,
    SortCodePipe,
    MaskValuePipe,
    OrdinalNumberPipe,
    DirectDebitTableComponent,
    ErrorComponent,
    SaveModalComponent,
    RemoveModalComponent,
    SectionHeadingComponent,
    InLineErrorComponent,
    CarStatusReminderComponent,
    SingleAlertComponent,
    PromoCodeErrorComponent
  ],
  entryComponents: [
    SaveModalComponent,
    RemoveModalComponent
  ],
  providers: [
    CurrencyPipe
  ]
})
export class SharedModule { }
