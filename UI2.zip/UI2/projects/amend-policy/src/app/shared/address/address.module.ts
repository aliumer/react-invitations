import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DlgWalrusModule } from 'dlg-angular-components';

import { AddressLookupService } from './services/address-lookup/address-lookup.service';
import { AddressDisplayComponent } from './components/address-display/address-display.component';
import { AddressLookupComponent } from './components/address-lookup/address-lookup.component';
import { AddressFormComponent } from './components/address-form/address-form.component';

@NgModule({
  declarations: [
    AddressFormComponent,
    AddressDisplayComponent,
    AddressLookupComponent
  ],
  imports: [
      DlgWalrusModule,
      CommonModule
    ],
  exports: [
    AddressFormComponent,
    AddressDisplayComponent,
    AddressLookupComponent,
    DlgWalrusModule,
    CommonModule
  ],
  entryComponents: [],
  providers: [ AddressLookupService ]
})
export class AddressModule { }
