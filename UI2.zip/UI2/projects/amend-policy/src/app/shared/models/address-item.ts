export interface AddressItem {
    displayName: string;
    addressLine1: string;
    addressLine2?: string;
    addressLine3?: string;
    town?: string;
    county?: string;
    postCode: string;
    country: string;
    uPRN_dlg: string;
    xcordinate_dlg: string;
    ycordinate_dlg: string;
    latitude_dlg?: string;
    longitude_dlg?: string;
    uDPRN_dlg?: string;
}
