import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CookieServicesModule } from '@app/shared/cookie-banner/services/cookie-services.module';
import { CookieService } from './services/cookie/cookie.service';

import { CookieBannerDisplayComponent } from '@app/shared/cookie-banner/components/cookie-banner-display/cookie-banner-display.component';

@NgModule({
  declarations: [
    CookieBannerDisplayComponent
  ],
  imports: [
    CommonModule,
    CookieServicesModule
  ],
  exports: [
    CookieBannerDisplayComponent
  ],
  entryComponents: [],
  providers: [ CookieService ]
})
export class CookieBannerModule {
}
