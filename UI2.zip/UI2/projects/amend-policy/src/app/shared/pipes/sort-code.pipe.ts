import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'sortCode'})
export class SortCodePipe implements PipeTransform {

  constructor() {
  }

  transform(value: any): string {
    if (!value) { return ''; }

    return value.length === 6 ? value.trim().match(/.{1,2}/g).join('-') : '';
  }
}
