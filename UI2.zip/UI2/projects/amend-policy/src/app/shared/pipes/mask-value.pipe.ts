import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'maskValue'})
export class MaskValuePipe implements PipeTransform {

  constructor() {
  }

  transform(value: any, unmaskedLength: number): string {
    if (!value) { return ''; }

    const maskAllValue = value.replace(/./g, '*'); // convert all value to *
    const maskedValueToDisplay = maskAllValue.substring(0, maskAllValue.length - unmaskedLength); // remove * count that will be visible
    const unmaskedValueToDisplay = value.substr(value.length - unmaskedLength); // chars to be visible

    return `<span class="masked-value"><span class="masked">${maskedValueToDisplay}</span>${unmaskedValueToDisplay}</span>`;
  }
}
