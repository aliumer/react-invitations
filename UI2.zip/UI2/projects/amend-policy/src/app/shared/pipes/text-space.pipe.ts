import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'textSpace'})
export class TextSpacePipe implements PipeTransform {

  constructor() {
  }

  transform(value: any): string {
    if (!value) { return ''; }

    return value.trim().split(' ').join('').split('').join(' ');
  }
}
