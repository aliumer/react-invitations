import { TextSpacePipe } from './text-space.pipe';

describe('Pipe: Text Space', () => {
  const pipe: TextSpacePipe = new TextSpacePipe();

  beforeEach(() => {
  });

  it('should return no value if none is provided', () => {
    expect(pipe.transform('')).toBe('');
    expect(pipe.transform('            ')).toBe('');
  });

  it('should add a space between each character', () => {
    expect(pipe.transform('12345')).toBe('1 2 3 4 5');
    expect(pipe.transform('abcdef')).toBe('a b c d e f');
    expect(pipe.transform('ab cdef')).toBe('a b c d e f');
    expect(pipe.transform('ab c  def')).toBe('a b c d e f');
    expect(pipe.transform('   ab c  def    ')).toBe('a b c d e f');
    expect(pipe.transform('   a    b c  def')).toBe('a b c d e f');
    expect(pipe.transform('ab c  def    ')).toBe('a b c d e f');
    expect(pipe.transform('!@£$%^')).toBe('! @ £ $ % ^');
  });
});
