import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DlgWalrusModule } from 'dlg-angular-components';

import { TabListComponent } from './components/tab-list/tab-list.component';
import { TabListItemComponent } from './components/tab-list-item/tab-list-item.component';

@NgModule({
  declarations: [TabListComponent, TabListItemComponent],
  imports: [
    CommonModule,
    DlgWalrusModule
  ],
  exports: [
    TabListComponent,
    TabListItemComponent
  ]
})
export class TabsModule { }
