import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CarPanelComponent } from './car-panel.component';

@NgModule({
  declarations: [
    CarPanelComponent,
  ],
  imports: [
    CommonModule
  ],
  exports: [
    CarPanelComponent,
    CommonModule
  ]
})
export class CarPanelModule {
}
