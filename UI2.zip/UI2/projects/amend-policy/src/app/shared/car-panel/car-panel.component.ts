import { Component, Input, OnChanges } from '@angular/core';

import { Vehicle } from '@app/features/your-car/models/vehicle';

import { TextHelpers } from '@app/infrastructure/helpers/text-helpers';
import { CustomUtility } from '@app/infrastructure/helpers/custom-utility';

@Component({
  selector: 'app-car-panel',
  templateUrl: './car-panel.component.html'
})
export class CarPanelComponent implements OnChanges {

  @Input() isHighlight = false;
  @Input() panelTitle: string;
  @Input() vehicleDisplay: Vehicle;

  description: string;
  make: string;

  ngOnChanges(): void {
    this.makeModal(this.vehicleDisplay);
    this.carInfo(this.vehicleDisplay);
  }

  private makeModal(vehicle: Vehicle): void {
    let makeModal = vehicle.make ? vehicle.make : ``;
    makeModal = makeModal + (vehicle.model ? ` ${vehicle.model}` : ``) + (vehicle.mark ? ` ${vehicle.mark}` : ``);
    makeModal = makeModal.trim();

    this.make = makeModal;
  }

  private carInfo(vehicle: Vehicle): void {
    let info = vehicle.year ? `${vehicle.year}, ` : ``;
    info = info + (vehicle.maxPower ? ` ${vehicle.maxPower} bhp, ` : ``);
    info = info + (vehicle.engineSize ? ` ${CustomUtility.appendEngineCapacityLabel(vehicle.engineSize)}, ` : ``);
    info = info + (vehicle.bodyType ? ` ${TextHelpers.convertToTitleCase(vehicle.bodyType)}, ` : ``);
    info = info + (vehicle.transmission ? ` ${TextHelpers.convertToTitleCase(vehicle.transmission)}, ` : ``);
    info = info + (vehicle.fuelType ? ` ${TextHelpers.convertToTitleCase(vehicle.fuelType)}` : ``);

    this.description = info;
  }
}
