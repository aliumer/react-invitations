export enum MethodTypeEnum {
  IssueChange = 'issueChange',
  UpdateQuotedChange = 'updateQuotedChange',
  UpdateAddOnCoveragesChange = 'updateAddOnCoveragesChange',
  SaveAndQuoteChange = 'saveAndQuoteChange',
  PolicyChangeStatusCheck = 'policyChangeStatusCheck',
}
