export enum PersonalDetailsEnumSimple {
  firstName = 'first name',
  lastName = 'last name',
  maritalStatus = 'marital status',
  employmentStatus = 'employment status',
  occupation = 'occupation',
  industry = 'industry'
}