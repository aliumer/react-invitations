export enum DataFetchResultTypes {
  Success = 'success',
  Error = 'error',
  None = 'none'
}
