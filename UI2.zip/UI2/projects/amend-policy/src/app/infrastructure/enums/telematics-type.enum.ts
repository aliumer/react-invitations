export enum TelematicsType {
  MOTTelematicsCovTelematicsApp = 'App',
  MOTTelematicsCovTelematicsDevice = 'Device',
  MOTTelematicsCovTelematicsHardWired = 'HardWired',
  MOTTelematicsCovTelematicsSelfInstalled = 'SelfInstalled'
}

export enum TelematicsTypeCapReadable {
  App = 'MOTTelematicsCovTelematicsApp',
  Device = 'MOTTelematicsCovTelematicsDevice',
  HardWired = 'MOTTelematicsCovTelematicsHardWired',
  SelfInstalled = 'MOTTelematicsCovTelematicsSelfInstalled'
}

export enum TelematicsTypeReadable  {
  App = 'App',
  HardWired = 'HardWired',
  SelfInstalled = 'SelfInstalled'
}
