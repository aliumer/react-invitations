export enum TransactionTypeEnum {
  SUBMISSION = 'submission',
  POLICY_CHANGE = 'policychange'
}
