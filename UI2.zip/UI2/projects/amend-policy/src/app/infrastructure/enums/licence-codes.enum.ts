export enum DlnStatus {
  error = 'error',
  successful = 'successful',
  successfulNoData = 'successfulNoData',
  successfulExpiredLicence = 'successfulExpiredLicence',
  unsuccessful = 'unsuccessful',
}

export enum LicenceCodes {
  '200-0001' = 'successful',                    // all good
  '200-0002' = 'successfulExpiredLicence',      // expired licence

  '400-0001' = 'unsuccessful',                  // missing field - dln
  '400-0002' = 'successfulNoData',              // missing field - data receiver id
  '400-0003' = 'successfulNoData',              // missing field - group id
  '400-0004' = 'successfulNoData',              // missing field - proposer indicator
  '400-0005' = 'successfulNoData',              // missing field - type

  '400-0101' = 'unsuccessful',                  // invalid field - dln
  '400-0102' = 'successfulNoData',              // invalid field - data receiver id
  '400-0103' = 'successfulNoData',              // invalid field - group id
  '400-0104' = 'successfulNoData',              // invalid field - post code
  '400-0105' = 'successfulNoData',              // invalid field - proposer indicator
  '400-0106' = 'successfulNoData',              // invalid field - type
  '400-0107' = 'successfulNoData',              // invalid field - vrm

  '400-0201' = 'successfulNoData',              // data error field - proposer indicator
  '400-0202' = 'successfulNoData',              // data error field - group id
  '400-0203' = 'successfulNoData',              // data error field - unique id

  '400-1001' = 'successfulNoData',              // batch error - checksum
  '400-1002' = 'successfulNoData',              // batch error - corrupt CSV
  '400-1003' = 'successfulNoData',              // batch error - corrupt manifest
  '400-1004' = 'successfulNoData',              // batch error - dln exceeded
  '400-1005' = 'successfulNoData',              // batch error - mismatch between manifest and CSV
  '400-1006' = 'successfulNoData',              // batch error - no group id
  '400-1007' = 'successfulNoData',              // batch error - no dln

  '404-0001' = 'unsuccessful',                  // dln not found
  '404-0002' = 'successfulNoData',              // not available
}
