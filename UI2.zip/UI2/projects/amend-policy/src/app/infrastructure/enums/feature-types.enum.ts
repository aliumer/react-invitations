export enum FeatureTypesEnum {
  Dashboard = 'dashboard',
  Review = 'review',
  Premium = 'premium'
}
