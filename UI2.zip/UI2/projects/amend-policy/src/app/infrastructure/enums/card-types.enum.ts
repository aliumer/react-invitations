export enum CardTypesEnum {
  Visa = 'Visa',
  Mastercard = 'Mastercard',
  Amex = 'Amex',
  Maestro = 'Maestro'
}
