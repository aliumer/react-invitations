export enum TransmissionTypeEnum {
  'MANUAL' = 'Manual',
  'SEMI AUTO' = 'Semi-automatic',
  'AUTOMATIC' = 'Automatic',
  'CVT' = 'CVT'
}
