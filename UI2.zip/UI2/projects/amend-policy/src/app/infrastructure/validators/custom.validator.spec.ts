import { FormArray, FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';

import { CustomValidator } from './custom.validator';

describe('Custom validation tests ', () => {
  let validator: CustomValidator = null;


  beforeEach(() => {
    validator = new CustomValidator();
  });

  it('should create instance ', () => {
    expect(validator).toBeTruthy();
  });

  it('should forceError when validating', () => {
    const control = new FormControl('input');
    const forceErrorValidator = CustomValidator.forceError(control);
    expect(forceErrorValidator).toEqual({forceError: true});
  });

  it('should error if maxAge of control value greater than age limit', () => {
    const maxAgeValidator = CustomValidator.maxAge(80, new Date('January 1, 2019 00:00:00'));
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['1', '1', '1938']);
    expect(maxAgeValidator(formArray)).toEqual({maxAge: true});
  });

  it('should validate if maxAge of control value less than age limit', () => {
    const maxAgeValidator = CustomValidator.maxAge(80, new Date('January 1, 2019 00:00:00'));
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['2', '1', '1938']);
    expect(maxAgeValidator(formArray)).toBeNull();
  });

  it('should error if minAge of control value is less than age limit', () => {
    const minAgeValidator = CustomValidator.minAge(16, new Date('January 1, 2019 00:00:00'));
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['2', '1', '2003']);
    expect(minAgeValidator(formArray)).toEqual({minAge: true});
  });

  it('should validate if minAge of control value is equal to or greater than age limit', () => {
    const minAgeValidator = CustomValidator.minAge(16, new Date('January 1, 2019 00:00:00'));
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['1', '1', '2003']);
    expect(minAgeValidator(formArray)).toBeNull();
  });

  it('should error if maxDate of control value greater than 90 days from set date', () => {
    const maxDateValidator = CustomValidator.maxDate(90, new Date('January 1, 2019 00:00:00'));
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['2', '4', '2019']);

    expect(maxDateValidator(formArray)).toEqual({maxDate: true});
  });

  it('should validate if maxDate of control value greater than 90 days from set date', () => {
    const maxDateValidator = CustomValidator.maxDate(90, new Date('January 1, 2019 00:00:00'));
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['1', '4', '2019']);

    expect(maxDateValidator(formArray)).toBeNull();
  });

  it('should error if minDate of control value is less than set date', () => {
    const minDateValidator = CustomValidator.minDate(0, new Date('January 10, 2019 00:00:00'));
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['9', '1', '2019']);

    expect(minDateValidator(formArray)).toEqual({minDate: true});
  });

  it('should validate if minDate of control value is equal to or greater than set date', () => {
    const minDateValidator = CustomValidator.minDate(0, new Date('January 10, 2019 00:00:00'));
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['10', '1', '2019']);

    expect(minDateValidator(formArray)).toBeNull();
  });

  it('should validate if minDateFull of control value is equal to or greater than set date', () => {
    const minDateFullValidator = CustomValidator.minDateFull(['3', '8', '2019']);
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['4', '8', '2019']);

    expect(minDateFullValidator(formArray)).toBeNull();
  });

  it('should error if minDateFull of control value is less than set date', () => {
    const minDateFullValidator = CustomValidator.minDateFull(['25', '9', '2019']);
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['24', '9', '2019']);

    expect(minDateFullValidator(formArray)).toEqual({minMonthYear: true});
  });

  it('should validate if date of control value is equal to or greater than the current date', () => {
    const today = new Date((new Date()).setHours(0, 0, 0, 0));
    const tomorrow = new Date(today.setDate(today.getDate() + 1));
    const noPastDateValidator = CustomValidator.noPastDate();
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array([tomorrow.getDate(), tomorrow.getMonth() + 1, tomorrow.getFullYear()]);

    expect(noPastDateValidator(formArray)).toBeNull();
  });

  it('should error if date of control value is less than the current date', () => {
    const noPastDateValidator = CustomValidator.noPastDate();
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['4', '2', '2019']);

    expect(noPastDateValidator(formArray)).toEqual({noPastDate: true});
  });

  it('should validate if date of control value is less than or equal to the current date', () => {
    const today = new Date((new Date()).setHours(0, 0, 0, 0));
    const noFutureDateValidator = CustomValidator.noFutureDate();
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array([today.getDate(), today.getMonth() + 1, today.getFullYear()]);

    expect(noFutureDateValidator(formArray)).toBeNull();
  });

  it('should error if date of control value is greater than the current date', () => {
    const today = new Date((new Date()).setHours(0, 0, 0, 0));
    const tomorrow = new Date(today.setDate(today.getDate() + 1));
    const noFutureDateValidator = CustomValidator.noFutureDate();
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array([tomorrow.getDate(), tomorrow.getMonth() + 1, tomorrow.getFullYear()]);

    expect(noFutureDateValidator(formArray)).toEqual({noFutureDate: true});
  });

  it('should validate if maxValue of control value is < 10', () => {
    const maxValueValidator = CustomValidator.maxValue(10);
    const control = new FormControl('input');

    control.setValue(9);
    expect(maxValueValidator(control)).toBeNull();
  });

  it('should validate if maxValue of control value is > 10', () => {
    const maxValueValidator = CustomValidator.maxValue(10);
    const control = new FormControl('input');

    control.setValue(11);
    expect(maxValueValidator(control)).toEqual({maxValue: true});
  });

  it('should validate minValue of control value is > 10', () => {
    const minValueValidator = CustomValidator.minValue(10);
    const control = new FormControl('input');

    control.setValue(11);
    expect(minValueValidator(control)).toBeNull();
  });

  it('should validate minValue of control value is < 10', () => {
    const minValueValidator = CustomValidator.minValue(10);
    const control = new FormControl('input');

    control.setValue(9);
    expect(minValueValidator(control)).toEqual({minValue: true});
  });

  it('should validate minLength of control if value length is 6', () => {
    const minLengthValidator = CustomValidator.minLength(6);
    const control = new FormControl('input');

    control.setValue('ABC123');
    expect(minLengthValidator(control)).toBeNull();
  });

  it('should not validate minLength of control if value length is not 6', () => {
    const minLengthValidator = CustomValidator.minLength(6);
    const control = new FormControl('input');

    control.setValue('ABC1');
    expect(minLengthValidator(control)).toEqual({minLength: true});
  });

  it('should validate !validNumber if control value is not a positive number', () => {
    const control = new FormControl('input');
    control.setValue('-1');
    const positiveNumberValidator = CustomValidator.positiveNumber(control);
    expect(positiveNumberValidator).toEqual({validNumber: true});
  });

  it('should validate noLeadingTrailingWhiteSpaces if control value does not contain special characters', () => {
    const control = new FormControl('input');
    control.setValue('BR1 1DP');
    const noLeadingTrailingWhiteSpacesValidator = CustomValidator.noLeadingTrailingWhiteSpaces(control);
    expect(noLeadingTrailingWhiteSpacesValidator).toBe(null);
  });

  it('should not validate noLeadingTrailingWhiteSpaces if control value contains special characters', () => {
    const control = new FormControl('input');
    control.setValue('  BR 1 1 D P  ');
    const noLeadingTrailingWhiteSpacesValidator = CustomValidator.noLeadingTrailingWhiteSpaces(control);
    expect(noLeadingTrailingWhiteSpacesValidator).toEqual({noLeadingTrailingWhiteSpaces: true});
  });

  it('should validate noSpecialCharactersExceptWhitespace if control value does not contain special characters', () => {
    const control = new FormControl('input');
    control.setValue('1234567 qwertyasd fgh456789');
    const noSpecialCharactersExceptWhitespaceValidator = CustomValidator.noSpecialCharactersExceptWhitespace(control);
    expect(noSpecialCharactersExceptWhitespaceValidator).toBe(null);
  });

  it('should not validate noSpecialCharactersExceptWhitespace if control value contains special characters', () => {
    const control = new FormControl('input');
    control.setValue('!@£$%^ &*(){}:"|<> ?[];');
    const noSpecialCharactersExceptWhitespaceValidator = CustomValidator.noSpecialCharactersExceptWhitespace(control);
    expect(noSpecialCharactersExceptWhitespaceValidator).toEqual({noSpecialCharactersExceptWhitespace: true});
  });

  it('should validate noSpecialCharacters if control value does not contain special characters', () => {
    const control = new FormControl('input');
    control.setValue('1234567qwertyasdfgh456789');
    const noSpecialCharactersValidator = CustomValidator.noSpecialCharacters(control);
    expect(noSpecialCharactersValidator).toBe(null);
  });

  it('should not validate noSpecialCharacters if control value contains special characters', () => {
    const control = new FormControl('input');
    control.setValue('!@£$%^&*(){}:"|<> ?[];');
    const noSpecialCharactersValidator = CustomValidator.noSpecialCharacters(control);
    expect(noSpecialCharactersValidator).toEqual({noSpecialCharacters: true});
  });

  it('should validate !positiveNumber if control value has leading zeros', () => {
    const control = new FormControl('input');
    control.setValue('01');
    const positiveNumberValidator = CustomValidator.positiveNumber(control);
    expect(positiveNumberValidator).toEqual({positiveNumber: true});
  });

  it('should validate positiveNumber if control value is a positive number by returning undefined', () => {
    const control = new FormControl('input');
    control.setValue('1');
    const positiveNumberValidator = CustomValidator.positiveNumber(control);
    expect(positiveNumberValidator).toBe(undefined);
  });

  it('should validate dateRequired if no values set', () => {
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['', '', '']);
    const dateRequiredValidator = CustomValidator.dateRequired();

    expect(dateRequiredValidator(formArray)).toEqual({dateRequired: true});
  });

  it('should validate dateRequired if some values set', () => {
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['1', '1', '']);
    const dateRequiredValidator = CustomValidator.dateRequired();

    expect(dateRequiredValidator(formArray)).toEqual({dateRequired: true});
  });

  it('should validate dateRequired if all values set and return null', () => {
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['11', '11', '11']);
    const dateRequiredValidator = CustomValidator.dateRequired();

    expect(dateRequiredValidator(formArray)).toBe(null);
  });

  it('should validate dateRequired with no-day', () => {
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['11', '11', '11']);
    const dateRequiredValidator = CustomValidator.dateRequired(['no-day']);

    expect(dateRequiredValidator(formArray)).toBe(null);
  });

  it('should validate dateRequired with no-month specified and only month and year', () => {
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['11', '11']);
    const dateRequiredValidator = CustomValidator.dateRequired(['no-month']);

    expect(dateRequiredValidator(formArray)).toBe(null);
  });

  it('should validate dateRequired with no-month specified and full date', () => {
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['11', '11', '11']);
    const dateRequiredValidator = CustomValidator.dateRequired(['no-month']);

    expect(dateRequiredValidator(formArray)).toBe(null);
  });

  it('should validate dateRequired with no-year', () => {
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['11', '11', '11']);
    const dateRequiredValidator = CustomValidator.dateRequired(['no-year']);

    expect(dateRequiredValidator(formArray)).toBe(null);
  });

  it('should validate !validDate for an invalid date', () => {
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['31', '02', '2018']);
    const dateRequiredValidator = CustomValidator.validDate(formArray);

    expect(dateRequiredValidator).toEqual({invalidDate: true});
  });

  it('should validate validDate for an valid date', () => {
    const formBuilder = new FormBuilder();
    const formArray = formBuilder.array(['01', '02', '2018']);
    const dateRequiredValidator = CustomValidator.validDate(formArray);

    expect(dateRequiredValidator).toBe(undefined);
  });

  it('should validate matchValue if control value is no', () => {
    const control = new FormControl('input');
    control.setValue({code: 'no', displayValue: 'No'});
    const valueIsNo = CustomValidator.equalTo('no');
    expect(valueIsNo(control)).toEqual({matchValue: true});
  });

  it('should return null if not no', () => {
    const control = new FormControl('input');
    control.setValue({code: 'notno', displayValue: 'NotNo'});
    const valueIsNo = CustomValidator.equalTo('yes');
    expect(valueIsNo(control)).toBe(null);
  });

  it('should return error if sort code input is empty', () => {
    const control = new FormControl('input');
    control.setValue(['', '', '']);
    const sortCodeRequiredValidator = CustomValidator.sortCodeRequired(control);
    expect(sortCodeRequiredValidator).toEqual({sortCodeRequired: true});
  });

  it('should validate if sort code input has one non-empty value', () => {
    const control = new FormControl('input');
    control.setValue(['12', '', '']);
    const sortCodeRequiredValidator = CustomValidator.sortCodeRequired(control);
    expect(sortCodeRequiredValidator).toEqual(null);
  });

  it('should return error if sort code format wrong', () => {
    const control = new FormControl('input');
    control.setValue(['01', '02', '034']);
    const valueIsNo = CustomValidator.sortCode(control);
    expect(valueIsNo.invalidSortCode).toBe(true);
  });

  it('should not return error if sort code format correct', () => {
    const control = new FormControl('input');
    control.setValue(['01', '02', '03']);
    const valueIs = CustomValidator.sortCode(control);
    expect(valueIs).toBeUndefined();
  });

  it('should not return error for validAgreed if user has checked the checkbox', () => {
    const control = new FormControl('input');
    control.setValue(true);
    const valueIs = CustomValidator.validAccept(control);
    expect(valueIs).toBeNull();
  });

  it('should validate email address-lookup user enters character more 60', () => {
    const control = new FormControl('input');
    control.setValue('theheheheheheheheheefmeeeeeeeeeeeeeeeeeeeeeeeeeeee@fmeeeeeeeeeeeeeeeeeeeeeeeeeeee.com');
    const valueIs = CustomValidator.validEmail(control);
    expect(valueIs).toEqual({invalidEmail: true});
  });

  it('should validate email address-lookup user doesn\'t use the @ character', () => {
    const control = new FormControl('input');
    control.setValue('tes-se.com');
    const valueIs = CustomValidator.validEmail(control);
    expect(valueIs).toEqual({invalidEmail: true});
  });

  it('should validate email address-lookup user enters more than one @ character', () => {
    const control = new FormControl('input');
    control.setValue('tes-se@@h.com');
    const valueIs = CustomValidator.validEmail(control);
    expect(valueIs).toEqual({invalidEmail: true});
  });

  it('should validate email address-lookup user doesn\'t enter character before the @ character', () => {
    const control = new FormControl('input');
    control.setValue('@h.com');
    const valueIs = CustomValidator.validEmail(control);
    expect(valueIs).toEqual({invalidEmail: true});
  });

  it('should validate email address-lookup user doesn\'t enter character after the @ character', () => {
    const control = new FormControl('input');
    control.setValue('aaa@.com');
    const valueIs = CustomValidator.validEmail(control);
    expect(valueIs).toEqual({invalidEmail: true});
  });

  it('should return undefined user enters an valid email  with special characters address-lookup', () => {
    const control = new FormControl('input');
    control.setValue('#;!#$%&*+-/=?^_`@fr.com');
    const valueIs = CustomValidator.validEmail(control);
    expect(valueIs).toBeUndefined();
  });

  it('should validate contact number if user enters incorrect number', () => {
    const control = new FormControl('input');
    control.setValue('078990871qq');
    const valueIs = CustomValidator.validContactNumber(control);
    expect(valueIs).toEqual({invalidContactNumber: true});
  });

  it('should return null is form in undefined', () => {
    const control = new FormControl();
    control.setValue('test');
    const value = CustomValidator.validAccept(control);
    expect(value).toBeNull();
  });

  it('should validate postcode if user enters incorrect postcode', () => {
    const control = new FormControl('input');
    control.setValue('se15');
    const valueIs = CustomValidator.validPostcode(control);
    expect(valueIs).toEqual({invalidPostcode: true});
  });

  it('should invalidate if postcode has not been verified', () => {
    const control = new FormControl('input');
    control.setValue('BR11DP');
    const isPostCodeValid = false;
    const verifyPostcodeValidator = CustomValidator.verifyPostcode(isPostCodeValid);
    expect(verifyPostcodeValidator(control)).toEqual({nonVerifiedPostcode: true});
  });

  it('should validate name if user enters invalid character', () => {
    const control = new FormControl('input');
    control.setValue('tes15');
    const valueIs = CustomValidator.validName(control);
    expect(valueIs).toEqual({invalidCharacter: true});
  });

  it('should validate name if user enters invalid character at the end or beginning', () => {
    const control = new FormControl('input');
    control.setValue('tes--');
    const valueIs = CustomValidator.validName(control);
    expect(valueIs).toEqual({invalidBeginEndLetter: true});
  });

  it('should validate name if user enters more than one space', () => {
    const control = new FormControl('input');
    control.setValue('t  es');
    const valueIs = CustomValidator.validName(control);
    expect(valueIs).toEqual({moreThanOneSpace: true});
  });

  it('should validate name if user enters adds consequential invalid characters', () => {
    const control = new FormControl('input');
    control.setValue('tes--tr');
    const valueIs = CustomValidator.validName(control);
    expect(valueIs).toEqual({consecutiveSpecialChars: true});
  });

  it('should validate characters user enters - only letters, number and space allowed', () => {
    const control = new FormControl('input');
    control.setValue('se15-');
    const valueIs = CustomValidator.alphaNumericSpace(control);
    expect(valueIs).toEqual({invalidAlphaNumericSpace: true});
  });

  it('should return null if form array is empty', () => {
    const formArray = new FormArray([], CustomValidator.validItems);
    expect(CustomValidator.validItems(formArray)).toBeNull();
  });

  it('should return null if all forms in form array are valid', () => {
    const formGroup1 = new FormGroup({
      firstName: new FormControl('Mo', Validators.required),
      lastName: new FormControl('Salah', Validators.required)
    });
    const formGroup2 = new FormGroup({
      firstName: new FormControl('Bobby', Validators.required),
      lastName: new FormControl('Firminio', Validators.required)
    });
    const formArray = new FormArray([formGroup1, formGroup2], CustomValidator.validItems);
    expect(CustomValidator.validItems(formArray)).toBeNull();
  });

  it('should return error object if one of the forms in form array is invalid', () => {
    const formGroup1 = new FormGroup({
      firstName: new FormControl('Mo', Validators.required),
      lastName: new FormControl('Salah', Validators.required)
    });
    const formGroup2 = new FormGroup({
      firstName: new FormControl('Bobby', Validators.required),
      lastName: new FormControl('', Validators.required)
    });
    const formArray = new FormArray([formGroup1, formGroup2], CustomValidator.validItems);
    expect(CustomValidator.validItems(formArray)).toEqual({validItems: false});
  });
});
