import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { DateTimeHelpers } from '@app/infrastructure/helpers/date-time-helpers';


export class CustomValidator {

  static forceError(control: FormControl | FormGroup) {
    return {forceError: true};
  }

  static validNumber(control: FormControl) {
    // Validate input to only allow numbers

    // Numeric Regex
    const numberRegExp = /^[0-9]*$/;

    if (control.value) {
      if (!numberRegExp.test(control.value)) {
        return {validNumber: true};
      }
    }

    return null;
  }

  static positiveNumber(control: FormControl) {
    // Validate input to only allow positive numbers

    // must also be numbers only
    if (CustomValidator.validNumber(control)) {
      return {validNumber: true};
    }

    // Positive Number Regex (no leading zero)
    const noLeadingZeroRegExp = /^[1-9][0-9]*$/;

    if (control.value) {
      if (!noLeadingZeroRegExp.test(control.value)) {
        return {positiveNumber: true};
      }
    }

    return null;
  }

  static noLeadingTrailingWhiteSpaces(control: FormControl) {
    // Validate input to avoid leading and trailing whitespaces
    const noLeadingTrailingWhiteSpacesRegExp = /^\s+|\s+$/g;

    if (control.value) {
      if (noLeadingTrailingWhiteSpacesRegExp.test(control.value)) {
        return {noLeadingTrailingWhiteSpaces: true};
      }
    }
    return null;
  }

  static noSpecialCharactersExceptWhitespace(control: FormControl) {

    // Positive Number Regex (no leading zero)
    const noSpecialCharactersExceptWhitespaceRegExp = /^(\d|\w)+$/;

    if (control.value) {
      const value = control.value.replace(/ /g, '');
      if (!noSpecialCharactersExceptWhitespaceRegExp.test(value)) {
        return {noSpecialCharactersExceptWhitespace: true};
      }
    }

    return null;
  }

  static noSpecialCharacters(control: FormControl) {

    // Positive Number Regex (no leading zero)
    const noSpecialCharactersRegExp = /^(\d|\w)+$/;

    if (control.value) {
      if (!noSpecialCharactersRegExp.test(control.value)) {
        return {noSpecialCharacters: true};
      }
    }

    return null;
  }

  static dateRequired(dateTypesToSkip?: any) {
    return (controlArray: FormArray) => {

      if (controlArray.value) {

        let errorFlag = false;

        const newDate: Array<any> = [];


        controlArray.value.forEach(value => {
          newDate.push(value);
        });

        if (dateTypesToSkip) {
          for (const type of dateTypesToSkip) {
            // day is always first so use shift to remove from array
            if (type === 'no-day') {
              newDate.shift();
            }

            // position of month can change depending if day has been removed or not
            if (type === 'no-month') {
              if (newDate.length === 3) {
                newDate.splice(1, 1);
              } else {
                newDate.splice(0, 1);
              }
            }

            // year is always last so use pop to remove from array
            if (type === 'no-year') {
              newDate.pop();
            }
          }
        }

        // Loop through new filtered array values to check if any are empty
        newDate.some((value) => {
          // If value is blank set error flag to true and exit loop
          if (value === '' || value === false) {
            errorFlag = true;
          }

          // exit if true
          return errorFlag;
        });

        if (errorFlag) {
          return {dateRequired: true};
        }
      }

      return null;
    };
  }

  static validDate(controlArray: FormArray) {

    const tempValue: string[] = [];

    if (controlArray && controlArray.value.length) {

      controlArray.value.forEach((value) => {
        value = (value === '' || value === null) ? '1' : value;
        tempValue.push(value);
      });

      const valueString: string = tempValue.join('/');

      // tslint:disable:max-line-length
      const dateRegExp = /(^(((0?[1-9]|1[0-9]|2[0-8])[\/](0?[1-9]|1[012]))|((29|30|31)[\/](0?[13578]|1[02]))|((29|30)[\/](0?[4,6,9]|11)))[\/](19|18|[2-9][0-9])\d\d$)|(^29[\/]0?2[\/](19|[2-9][0-9])(00|04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)$)/;
      // tslint:enable:max-line-length

      if (!dateRegExp.test(valueString)) {
        return {invalidDate: true};
      }
    }

    return null;
  }

  static maxAge(age: number, currentDate: Date) {

    return (controlArray: FormArray) => {

      const formatControls: string = controlArray.value.slice().reverse().join('/');
      const enteredDate: any = new Date(formatControls);
      const maxDate: any = new Date(currentDate.getFullYear() - age - 1, currentDate.getMonth(), currentDate.getDate());
      if (enteredDate.getTime() <= maxDate.getTime()) {
        return {maxAge: true};
      }

      return null;
    };
  }

  static minAge(age: number, currentDate: Date) {
    return (controlArray: FormArray) => {

      const formatControls: string = controlArray.value.slice().reverse().join('/');
      const enteredDate: any = new Date(formatControls);
      const minDate: any = new Date(currentDate.getFullYear() - age, currentDate.getMonth(), currentDate.getDate());
      if (enteredDate.getTime() > minDate.getTime()) {
        return {minAge: true};
      }

      return null;
    };
  }

  static maxDate(offset: number, currentDate: Date) {

    return (controlArray: FormArray) => {

      const formatControls: string = controlArray.value.slice().reverse().join('/');
      const enteredDate = new Date(formatControls);
      const maxDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + offset);

      if (enteredDate.getTime() > maxDate.getTime()) {
        return {maxDate: true};
      }

      return null;
    };
  }

  static minDate(date: number, currentDate: Date) {

    return (controlArray: FormArray) => {
      const formatControls: string = controlArray.value.slice().reverse().join('/');
      const enteredDate: any = new Date(formatControls);
      const minDate: any = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + date);

      if (enteredDate.getTime() < minDate.getTime()) {
        return {minDate: true};
      }

      return null;
    };
  }

  static minDateFull(dateArray: string[] | number[]) {
    return (control: FormArray) => {
      if (dateArray && !CustomValidator.validDate(control)) {
        if (control.value.length === 3) {
          const enteredDateArr = [DateTimeHelpers.lastDayOfMonth(control.value), ...control.value.slice(1)];
          const enteredDate: any = new Date(enteredDateArr.reverse().join('/'));
          const minDate: any = new Date(dateArray.slice().reverse().join('/'));

          if (enteredDate.getTime() < minDate.getTime()) {
            return {minMonthYear: true};
          }
        }
      }

      return null;
    };
  }

  static noPastDate() {
    return (controlArray: FormArray) => {
      const currentDate = new Date((new Date()).setHours(0, 0, 0, 0));
      const formatControls: string = controlArray.value.slice().reverse().join('/');
      const enteredDate: any = new Date(formatControls);

      if (enteredDate.getTime() < currentDate.getTime()) {
        return {noPastDate: true};
      }

      return null;
    };
  }

  static noFutureDate(isPurchaseDate = false) {
    return (controlArray: FormArray) => {
      const currentDate = new Date((new Date()).setHours(0, 0, 0, 0));
      // Appending 1 since Safari and IE are unable to take the default date as 1
      const formatControls: string = isPurchaseDate ? controlArray.value.slice().reverse().join('/').concat('1') : controlArray.value.slice().reverse().join('/');
      const enteredDate: any = new Date(formatControls);

      if (enteredDate.getTime() > currentDate.getTime()) {
        return {noFutureDate: true};
      }

      return null;
    };
  }

  static maxValue(value: number) {
    return (control: FormControl) => {

      const numberEntered = parseInt(control.value, 10);

      if (numberEntered > value) {
        return {maxValue: true};
      }

      return null;
    };
  }

  static minValue(value: number) {
    return (control: FormControl) => {
      const numberEntered = parseInt(control.value, 10);

      if (numberEntered < value) {
        return {minValue: true};
      }

      return null;
    };
  }

  static minLength(value: number) {
    return (control: FormControl) => {

      if (control.value && control.value.length < value) {
        return {minLength: true};
      }

      return null;
    };
  }

  static equalTo(valueToMatch) {
    return (control: FormControl) => {
      if (control.value.key === valueToMatch) {
        return {matchValue: true}; // This will throw error
      }

      return null;
    };
  }

  static sortCodeRequired(control: FormControl): any {
    if (control && control.value) {
      // If all values are empty then return sortCodeRequired error
      if (control.value.every((input) => input === '')) {
        return {sortCodeRequired: true};
      }
    }

    return null;
  }

  static sortCode(control: FormControl): any {
    let errorFlag = false;

    // Sort code Regex - each field must be two numbers
    const sortCodeRegExp = /^[0-9]{2}$/;

    // Loop through array values
    control.value.some((value) => {
      const sortCodeField = sortCodeRegExp.test(value);

      // If value fails test set error flag to true and exit loop
      if (!sortCodeField) {
        errorFlag = true;
      }

      // exit if true
      return errorFlag;
    });

    // If error flag is true - return error to form
    if (errorFlag) {
      return {invalidSortCode: errorFlag};
    }
  }

  static validAccept(control: FormControl) {
    if (!control.value) {
      return {validAccept: false};
    }
    return null;
  }

  static validEmail(control: FormControl) {
    const emailValue: string = control.value;
    const atSymbolRegex: RegExp = /@/g;
    const emailBeforeRegex: RegExp = /^[a-zA-Z0-9!#$%&'*+-/=?^_`{|}~;.]+(\.[a-zA-Z0-9!#$%&'*+\/=?^_`{|}~-]+)*$/;
    const emailAfterRegex: RegExp = /^[a-zA-Z0-9!#$%&’*+\/=?^_`{|}~-]+(\.{1,})+([a-zA-Z0-9!#$%&’*+\/=?^_`{|}~-]+)|^\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}]$/mg;

    if (emailValue) {
      // exceeds the 30 length character limit
      if (emailValue.length > 60) {
        return {invalidEmail: true};
      }

      // does not contain symbol @
      if (!atSymbolRegex.test(emailValue)) {
        return {invalidEmail: true};
      }

      // should contain one symbol @
      if (emailValue.match(atSymbolRegex).length !== 1) {
        return {invalidEmail: true};
      }

      // substring before @ regex test
      const emailBeforeValue: string = emailValue.substring(0, emailValue.indexOf('@'));
      if (!emailBeforeRegex.test(emailBeforeValue)) {
        return {invalidEmail: true};
      }

      // substring after @ regex test
      const emailAfterValue: string = emailValue.substring(emailValue.indexOf('@') + 1, emailValue.length);
      if (!emailAfterRegex.test(emailAfterValue)) {
        return {invalidEmail: true};
      }
    }

    return null;
  }

  static validContactNumber(control: FormControl) {
    const contactNumberRegex = /^(0[1-68-9]{1}[0-9]{9})$|^(07[0-9]{9})$/;

    if (control.value && !contactNumberRegex.test(control.value)) {
      return {invalidContactNumber: true};
    }

    return null;
  }

  static validPostcode(control: FormControl) {
    const postcodeRegex = /([Gg][Ii][Rr] 0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?))))\s?[0-9][A-Za-z]{2})$/;

    if (!postcodeRegex.test(control.value)) {
      return {invalidPostcode: true};
    }

    return null;
  }

  static verifyPostcode(value: boolean) {
    return (control: FormControl) => {
      if (control.value) {
        if (!value) {
          return {nonVerifiedPostcode: true};
        }
      }
      return null;
    };
  }

  static validName(control: FormControl) {

    const value = control.value;
    const invalidCharRegExp = /^[a-zA-Z'\-\s]*$/;
    const invalidBeginEndLetterRegExp = /^[a-zA-Z]{1}.*[a-zA-Z]{1}$/;
    const moreThanOneSpaceRegExp = /^([a-zA-Z-']+\s)*[a-zA-Z-']+$/;
    const consecutiveSpecialCharsRegExp = /['-]{2,}/;

    if (value === '') {
      return null;
    }

    if (!invalidCharRegExp.test(control.value)) {
      return {invalidCharacter: true};
    }

    if (!invalidBeginEndLetterRegExp.test(control.value)) {
      return {invalidBeginEndLetter: true};
    }

    if (!moreThanOneSpaceRegExp.test(control.value)) {
      return {moreThanOneSpace: true};
    }

    if (consecutiveSpecialCharsRegExp.test(control.value)) {
      return {consecutiveSpecialChars: true};
    }
    return null;
  }

  static alphaNumericSpace(control: FormControl) {
    // Input can only include letters, numbers and spaces

    const invalidAlphaNumericRegExp = /^[a-zA-Z0-9 ]*$/;
    const invalidAlphaNumericResult = invalidAlphaNumericRegExp.test(control.value);

    if (!invalidAlphaNumericResult) {
      return {invalidAlphaNumericSpace: true};
    }

    return null;
  }

  static validItems(control: FormArray) {
    const errorArr = [];
    if (control.controls) {
      control.controls.map((fg) => {
        if (fg.status === 'INVALID') {
          errorArr.push('invalidItem');
        }
      });
    }
    return errorArr.length ? {validItems: false} : null;
  }

  static requireCarModificationsSelected(control: FormControl) {

    const val = control.value || [];
    return val.length > 0 ? null : {noModificationSelected: true};
  }
}

