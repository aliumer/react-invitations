import { ModelControl } from './model-control';

export interface ModelControlMap {
  [key: string]: ModelControl;
}
