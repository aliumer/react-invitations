export interface KeyValueDict<T> {
  [key: string]: T;
}
