import { DlnStatus } from '@app/infrastructure/enums/licence-codes.enum';

export interface DVLALicenceNumberRequest {
  brand: string;
  channel: 'WEB';
  product: 'Motor';
  quoteRefId: string;
  tenure: '0' | '-1';
  policyStartDate: string;
  consumerID: 'HY789';
  type: 'Q';
  driver: DVLADriver[];
  pc: string;
}

export interface DVLADriver {
  position: string;
  drvID: string;
  dln: string;
  ind: string;
  vrm: string;
}

export interface DVLALicenceNumberResponse {
  getDVLAInfoResponse: {
    brand: string;
    channel: 'WEB';
    product: 'Motor';
    quoteRefId: string;
    tenure: '0' | '-1';
    policyStartDate: string;
    consumerID: 'HY789';
    type: 'Q'
    driver: DVLADriverResp[],
  };
}

export interface DVLADriverResp {
  getDVLAInfoResponse: {
    drvID: string;
    isDlnValidated: boolean;
    errorCode?: string[];
  };
}

export interface LicenceNumberResponse {
  dlnStatus: DlnStatus;
  errorCode?: string[];
  isMultiCarQuote?: boolean;
}
