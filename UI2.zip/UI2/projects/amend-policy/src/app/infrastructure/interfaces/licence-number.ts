export interface LicenceNumberInput {
  dvlaLicenceNumber: string;
  firstName: string;
  lastName: string;
  dob: Array<string>;
  title: string;
  gender: string;
  action?: 'reset';
}

export interface LicenceNumberOutput {
  action: 'findLicence' | 'cancelLicenceSearch' | 'changeLicenceNumberValue' | 'resetLicence';
  val: string;
}

export interface FindDriverLicenceParams {
  licenceNumber: string;
  policyStartDate: Array<string>;
  postcode: string;
  quoteRefId: string;
  driverCapId: string;
  driverType: 'P' | 'N';
}

export const LicenceCodesMapping = {
  successful: {
    isLicenceVerified: true,
    isLicenceUsed: true,
    isLicenceLookupRequired: true
  },
  successfulExpiredLicence: {
    isLicenceVerified: true,
    isLicenceUsed: true,
    isLicenceLookupRequired: true
  },
  successfulNoData: {
    isLicenceVerified: true,
    isLicenceUsed: false,
    isLicenceLookupRequired: true
  },
  unsuccessful: {
    isLicenceVerified: false,
    isLicenceUsed: null,
    isLicenceLookupRequired: null
  }
};

export enum DvlaDriverType {
  policyHolder = 'P',
  additionalDriver = 'N'
}

export enum DriverType {
  policyHolder = 'policyHolder',
  additionalDriver = 'additionalDriver'
}
