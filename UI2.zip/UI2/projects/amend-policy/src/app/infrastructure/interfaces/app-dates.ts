export interface AppDateObject {
  day?: number;
  month?: number;
  year?: number;
}

export interface GwDate {
  day: number;
  month: number;
  year: number;
}
