export const JourneyFeatures: any = {
  // TODO: this is used in analytics-shouldn't be here
  policy: {
    name: 'policy',
    path: 'policy'
  },
  quote: {
    name: 'quote',
    path: 'quote'
  },
  amendPolicy: {
    name: 'amendPolicy',
    path: 'amend-policy'
  },
  loadPolicy: {
    name: 'loadPolicy',
    path: 'load'
  },
  billing: {
    name: 'billing',
    path: 'billing'
  },
  retrieveQuote: {
    name: 'retrieveQuote',
    path: 'retrieve'
  },
  dashboard: {
    name: 'dashboard',
    path: 'dashboard'
  },
  dashboardSelect: {
    name: 'dashboardSelect',
    path: 'dashboard/select'
  },
  dashboardUpdate: {
    name: 'dashboardUpdate',
    path: 'dashboard/update'
  },
  yourCar: {
    name: 'yourCar',
    path: 'your-car'
  },
  yourCarPerm: {
    name: 'yourCarPerm',
    path: 'your-car/permanent'
  },
  yourCarTemp: {
    name: 'yourCarTemp',
    path: 'your-car/temporary'
  },
  yourTemporaryEuropeanCover: {
    name: 'yourTemporaryEuropeanCover',
    path: 'your-temporary-european-cover'
  },
  yourMileage: {
    name: 'yourMileage',
    path: 'your-mileage'
  },
  yourAddress: {
    name: 'yourAddress',
    path: 'your-address'
  },
  yourDetails: {
    name: 'yourDetails',
    path: 'your-details'
  },
  yourDrivers: {
    name: 'yourDrivers',
    path: 'your-drivers'
  },
  yourDriversPerm: {
    name: 'yourDriversPerm',
    path: 'your-drivers/permanent'
  },
  yourDriversTemp: {
    name: 'yourDriversTemp',
    path: 'your-drivers/temporary'
  },
  yourRegistration: {
    name: 'yourRegistration',
    path: 'your-registration'
  },
  addDriver: {
    name: 'addDriver',
    path: 'add-driver'
  },
  editDriver: {
    name: 'editDriver',
    path: 'edit-driver'
  },
  personalDetails: {
    name: 'personalDetails',
    path: 'your-drivers/manage/personal-details'
  },
  drivingLicenseNumber: {
    name: 'drivingLicenseNumber',
    path: 'your-drivers/manage/driving-license-number'
  },
  drivingHistory: {
    name: 'drivingHistory',
    path: 'your-drivers/manage/driving-history'
  },
  premium: {
    name: 'premium',
    path: 'premium'
  },
  review: {
    name: 'review',
    path: 'review'
  },
  reviewFull: {
    name: 'reviewFull',
    path: 'review/full'
  },
  reviewDirectDebit: {
    name: 'reviewDirectDebit',
    path: 'review/direct-debit'
  },
  payment: {
    name: 'payment',
    path: 'payment'
  },
  directDebitDisplay: {
    name: 'directDebitDisplay',
    path: 'direct-debit-display'
  },
  directDebitEdit: {
    name: 'directDebitEdit',
    path: 'direct-debit-edit'
  },
  directDebitNew: {
    name: 'directDebitNew',
    path: 'direct-debit-new'
  },
  directDebitReview: {
    name: 'directDebitReview',
    path: 'direct-debit-review'
  },
  creditCard: {
    name: 'creditCard',
    path: 'credit-card'
  },
  refund: {
    name: 'refund',
    path: 'refund'
  },
  confirm: {
    name: 'confirm',
    path: 'confirm'
  },
  confirmFull: {
    name: 'confirmFull',
    path: 'confirm/full'
  },
  confirmDirectDebit: {
    name: 'confirmDirectDebit',
    path: 'confirm/direct-debit'
  },
  errors: {
    name: 'errors',
    path: 'errors'
  },
  allocate: {
    name: 'allocate',
    path: 'allocate'
  },
  yourCorrespondenceAddress: {
    name: 'yourCorrespondenceAddress',
    path: 'your-correspondence-address'
  },
  yourConvictions: {
    name: 'yourConvictions',
    path: 'your-convictions'
  }
};
