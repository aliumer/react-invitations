import { environment } from '@env/environment';

export const Coverages = {
    // tslint:disable:max-line-length
    vehicleCoverages: [
      {
        coverType: 'comp',
        coverages: [
          {
            name: environment.brand_copy.premium.benefitsList.comp.courtesyCar,
            codeIdentifier_dlg: 'CourtesyCarCov',
            description: 'If your car\'s being fixed by one of our approved repairers, we\'ll give you a car to use for the whole time yours is in for repairs.',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: environment.brand_copy.premium.benefitsList.comp.courtesyCar
          },
          {
            name: 'New Car Replacement',
            codeIdentifier_dlg: 'NewCarReplacementCov',
            description: 'We\'ll give you the same make and model as your car, if it\'s written off before it\'s 12 months old. You must be the first and only registered keeper.',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'New Car Replacement'
          },
          {
            name: 'Uninsured Driver Promise',
            codeIdentifier_dlg: 'UninsuredDriverPromiseCov',
            description: 'If an uninsured driver hits your car and it\'s confirmed that the accident isn\'t your fault, our cover will protect your claim-free years and cover your excess, too. Make sure you get the registration number, make and model of the other car, and the other driver\'s details (if possible) to make a claim.',
            coverageCategoryCode: 'MOTehicleStndGrp',
            coverageCategoryDisplayName: 'Uninsured Driver Promise'
          },
          {
            name: 'Guaranteed repairs',
            codeIdentifier_dlg: 'GuaranteedRepairsCov',
            description: 'If you get your car fixed by one of our approved repairers, we\'ll guarantee the work for five years. ',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'Guaranteed repairs'
          },
          {
            name: 'Personal accident cover',
            codeIdentifier_dlg: 'PersonalAccidentCover',
            description: 'We\'ll insure you and your spouse/partner up to the value of £5,000. ',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'Personal accident cover'
          }
        ]
      },
      {
        coverType: 'compplus',
        coverages: [
          {
            name: 'Guaranteed Hire Car Plus',
            codeIdentifier_dlg: 'MOTGuaranteedHireCarPlusCov',
            description: 'If your car is being fixed by one of our approved repairers, we\'ll give you a hire car of similar physical size to your own, to drive until yours is fixed. Alternatively, if you prefer to use your own repairer, or your car has been written off or stolen – you\'ll still get a hire car for up to 21 days in a row.',
            coverageCategoryCode: 'MOTehicleStndGrp',
            coverageCategoryDisplayName: 'Guaranteed Hire Car Plus'
          },
          {
            name: 'New Car Replacement',
            codeIdentifier_dlg: 'NewCarReplacementCov',
            description: 'We\'ll give you the same make and model as your car, if it\'s written off before it’s 24 months old. You must be the first and only registered keeper. ',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'New Car Replacement'
          },
          {
            name: 'Uninsured Driver Promise',
            codeIdentifier_dlg: 'UninsuredDriverPromiseCov',
            description: 'If an uninsured driver hits your car and it’s confirmed that the accident isn\'t your fault, our cover will protect your claim-free years and cover your excess, too. Make sure you get the registration number, make and model of the other car, and the other driver\'s details (if possible) to make a claim.',
            coverageCategoryCode: 'MOTehicleStndGrp',
            coverageCategoryDisplayName: 'Uninsured Driver Promise'
          },
          {
            name: 'Personal accident cover',
            codeIdentifier_dlg: 'PersonalAccidentCoverCov',
            description: 'We\'ll insure you and your spouse/partner up to the value of £10,000.',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'Personal accident cover'
          },
          {
            name: 'Motor Legal Cover',
            codeIdentifier_dlg: 'MOTLegalCoverCov',
            description: `We'll cover legal costs up to £100,000 to help you claim for repairs, loss of earnings and personal injury following an accident that wasn't your fault. There must be more than a 50% chance your claim will be successful.`,
            coverageCategoryCode: 'MOTehicleStndGrp',
            coverageCategoryDisplayName: 'Motor Legal Cover'
          },
          {
            name: 'Automatic Foreign Use',
            codeIdentifier_dlg: 'AutomaticForeignUseCov',
            description: 'Our overseas cover automatically gives you Comprehensive insurance for up to 90 days when you use your car abroad. No need to tell us first.',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'Automatic Foreign Use'
          }
        ]
      },
      {
        coverType: 'tpft',
        coverages: [
          {
            name: 'Third party damage',
            codeIdentifier_dlg: 'ThirdPartyDamageCov',
            description: 'Accidental damage to someone else\'s car or property while you\'re driving.',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'Third party damage'
          },
          {
            name: 'Third party injury',
            codeIdentifier_dlg: 'ThirdPartyInjuryCov',
            description: 'Injury to another driver or a passenger in their car.',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'Third party injury'
          },
          {
            name: 'Courtesy car',
            codeIdentifier_dlg: 'CourtesyCarCov',
            description: 'If your car\'s being fixed by one of our approved repairers, we\'ll give you a car to use for the duration of repairs.',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'Courtesy car'
          },
          {
            name: 'Fire damage',
            codeIdentifier_dlg: 'MOTFireCov',
            description: 'If your car is damaged or destroyed by fire, we\'ll cover the cost or repair or replacement.',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'Fire damage'
          },
          {
            name: 'Stolen car',
            codeIdentifier_dlg: 'StolenCarCov',
            description: 'If your car is stolen, we’ll provide a replacement.',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'Stolen car'
          }
        ]
      },
      {
        coverType: 'drivexpert',
        coverages: [
          {
            name: 'Courtesy car',
            codeIdentifier_dlg: 'CourtesyCarCov',
            description: 'If your car\'s being fixed by one of our approved repairers, we\'ll give you a car to use for the whole time yours is in for repairs.',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'Courtesy car'
          },
          {
            name: 'New Car Replacement',
            codeIdentifier_dlg: 'NewCarReplacementCov',
            description: 'We\'ll give you the same make and model as your car, if it\'s written off before it\'s 12 months old. You must be the first and only registered keeper.',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'New Car Replacement'
          },
          {
            name: 'Uninsured Driver Promise',
            codeIdentifier_dlg: 'UninsuredDriverPromiseCov',
            description: 'If an uninsured driver hits your car and it\'s confirmed that the accident isn\'t your fault, our cover will protect your claim-free years and cover your excess, too. Make sure you get the registration number, make and model of the other car, and the other driver\'s details (if possible) to make a claim.',
            coverageCategoryCode: 'MOTehicleStndGrp',
            coverageCategoryDisplayName: 'Uninsured Driver Promise'
          },
          {
            name: 'Guaranteed repairs',
            codeIdentifier_dlg: 'GuaranteedRepairsCov',
            description: 'If you get your car fixed by one of our approved repairers, we\'ll guarantee the work for five years. ',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'Guaranteed repairs'
          },
          {
            name: 'Personal accident cover',
            codeIdentifier_dlg: 'PersonalAccidentCover',
            description: 'We\'ll insure you and your spouse/partner up to the value of £5,000. ',
            coverageCategoryCode: 'MOTVehicleStndGrp',
            coverageCategoryDisplayName: 'Personal accident cover'
          }
        ]
      }
    ]
  };
