import { Result } from '@app/features/premium/models/result';

import { TextHelpers } from '@app/infrastructure/helpers/text-helpers';

interface GwDate {
  day: number;
  month: number;
  year: number;
}

export class GwHelpers {

  static getGender(title: string, gender: string): string {
    if (gender) {
      return gender === 'Male' ? 'M' : 'F';
    }
    if (title) {
      return title.toLowerCase() === 'mr' ? 'M' : 'F';
    }
    return null;
  }

  /*static getConvictionCode(conviction): string {
    let code = '';
    if (conviction.commonConviction && conviction.commonConviction !== '') {
      code = conviction.commonConviction.code;
    } else {
      code = conviction.otherConviction.code;
    }
    return code;
  }*/

  static convertToBoolean(value: any): boolean {
    return value === undefined ? false :
      typeof value === 'boolean' ? value :
        (value as string).toLowerCase() === 'yes';
  }

  static deletePromCodes(result: Result): Result {
    const premDataResultClone: Result = JSON.parse(JSON.stringify(result));

    const {lobData: {mOTLine_Ext: {offerings: offerings}}} = premDataResultClone;
    if (offerings && offerings.length) {
      offerings.forEach(offering => {
        if (offering.coverages && offering.coverages.vehicleCoverages) {
          offering.coverages.vehicleCoverages.forEach(vehicleCoverage => {
            delete vehicleCoverage.automaticAppliedPromos_dlg;
          });
        }
      });
    }

    return premDataResultClone;
  }

  static convertToGwDateObject([day, month, year]) {
    return {
      day: day ? +day : 1,
      month: +month - 1,
      year: +year
    };
  }

  static convertGwDateToDate({day, month, year}: GwDate): Date {
    return new Date(year, month, day);
  }

  static convertTitleForPayload(title: string): string {
    return title !== 'Miss' ? title.toLowerCase() : 'miss_dlg';
  }

  static convertTitleForDisplay(title: string): string {
    return title !== 'miss_dlg' ? TextHelpers.convertToTitleCase(title) : 'Miss';
  }

  static getGenderForDisplay(gender: string): string {
    if (gender.toLowerCase() === 'm') {
      return 'Male';
    }
    if (gender.toLowerCase() === 'f') {
      return 'Female';
    }
    return '';
  }
}
