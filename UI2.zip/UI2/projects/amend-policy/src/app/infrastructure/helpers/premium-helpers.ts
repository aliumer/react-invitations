import { KeyValue } from '@angular/common';

import { DateTimeHelpers } from '@app/infrastructure/helpers/date-time-helpers';

import { ChangeTypeEnum } from '@app/infrastructure/enums/change-type.enum';
import { KeyValueDict } from '@app/infrastructure/interfaces/key-value-dict';

import { VehicleCoverageCover } from '@app/features/premium/models/vehicle-coverage-cover';
import { RescueCoveragesDlg } from '@app/features/premium/models/rescue-coverages-dlg';

export class PremiumHelpers {
  static extractPremiumChangeDetails(premium) {
    const {
      transactionCost: {amount: transactionCost},
      selectedPeriodPublicId_dlg,
      lobData: {mOTLine_Ext: {offerings}}, quoteData: {offeredQuotes},
      bindData: {offeredPaymentPlans_dlg, refundTable, chosenQuote, selectedPaymentPlan}
    } = premium;
    const branchCode = offerings.filter(o => o.periodPublicId_dlg === selectedPeriodPublicId_dlg)?.[0]?.offeringCode_dlg;
    if (branchCode) {
      const offeredQuote = offeredQuotes.find(quote => quote.branchCode === branchCode);
      if (offeredQuote) {
        const paymentPlan = offeredPaymentPlans_dlg
          .find(item => item.periodPublicId === chosenQuote).paymentPlans
          .find(item => item.billingId === selectedPaymentPlan)?.name;
        const amount = offeredQuote.premium.changeInCost_dlg.amount;
        // TODO: remove after finding if they ever differ
        if (transactionCost !== amount) {
          console.error('diff in transaction cost', transactionCost - amount);
        }
        return {
          paymentPlan,
          amount,
          isRefundTableExists: !!refundTable
        };
      }
    }

    return {paymentPlan: null, amount: null, isRefundTableExists: null};
  }

  static extractLatestTempChangeEndDate(premium): Date {
    const {lobData: {mOTLine_Ext: {coverables: {drivers, motVehicles}}}} = premium;
    const tempVehicles = motVehicles.filter(v => v.vehicle.typeOfVehicle === ChangeTypeEnum.Temporary);
    const tempDrivers = drivers.filter(d => d.driverType === ChangeTypeEnum.Temporary);
    const schItems = motVehicles.filter(v => v.vehicle.typeOfVehicle === ChangeTypeEnum.Permanent)
      .map(v => v.vehicle.schItems.filter(s => s).map(s => s.tripEndDate))
      .filter(v => !!v)
      .map(d => d.map(v => new Date(v.year, v.month, v.day)))
      .reduce((a, c) => ([...a, c]));

    const endDates: Date[] = [
      ...tempVehicles.map(v => {
        const ed = v.vehicle.vehicleEndDate;
        return new Date(ed.year, ed.month, ed.day);
      }),
      ...tempDrivers.map(d => {
        const ed = d.driverEndDate;
        return new Date(ed.year, ed.month, ed.day);
      }),
      ...schItems
    ];

    return endDates.length > 1 ? DateTimeHelpers.getLatestDate(endDates) : endDates[0];
  }

  static deletePromCodes(updateAddOnData: any): any {
    const updateAddOnDataDeepClone = JSON.parse(JSON.stringify(updateAddOnData));
    for (const cov of updateAddOnDataDeepClone.vehicleCoverages) {
      delete cov.automaticAppliedPromos_dlg;
    }
    return updateAddOnDataDeepClone;
  }

  static buildUpdateAddOnCoveragesChangeRequest(selection: KeyValueDict<KeyValue<string, boolean>>, data: any): any {

    if (selection.hasOwnProperty('extras')) {
      const vehicleCoverageCovers: VehicleCoverageCover[] = data.vehicleCoverages[0].coverages.filter((cover: VehicleCoverageCover) => cover.codeIdentifier_dlg === selection.extras.key);
      if (vehicleCoverageCovers && vehicleCoverageCovers.length > 0) {
        vehicleCoverageCovers.forEach(vc => vc.selected = selection.extras.value);
      }
    }

    if (selection.hasOwnProperty('breakdowns')) {

      if (selection.breakdowns.key === 'RESEuroBrkdownLongTermCov' || selection.breakdowns.key === 'RESPersonalCov') {
        const vehicleCoverageCovers = data.vehicleCoverages[0].rescueCoverages_dlg.filter((rescueCoveragesDlg: RescueCoveragesDlg) => rescueCoveragesDlg.covName === selection.breakdowns.key);

        if (vehicleCoverageCovers && vehicleCoverageCovers.length > 0) {
          vehicleCoverageCovers.forEach(vc => vc.selected = selection.breakdowns.value);
        }

      } else {

        const allHomeBreakdownCovers = data.vehicleCoverages[0].rescueCoverages_dlg.filter((rescueCoveragesDlg: RescueCoveragesDlg) => rescueCoveragesDlg.covName !== 'RESEuroBrkdownLongTermCov' && rescueCoveragesDlg.covName !== 'RESPersonalCov');

        if (selection.breakdowns.value) {
          allHomeBreakdownCovers.forEach((rescueCoveragesDlg: RescueCoveragesDlg) => {
            rescueCoveragesDlg.selected = rescueCoveragesDlg.covName === selection.breakdowns.key ? selection.breakdowns.value : !selection.breakdowns.value;
          });
        } else {
          const vehicleCoverageCovers = allHomeBreakdownCovers.filter((rescueCoveragesDlg: RescueCoveragesDlg) => rescueCoveragesDlg.covName === selection.breakdowns.key);

          if (vehicleCoverageCovers && vehicleCoverageCovers.length > 0) {
            vehicleCoverageCovers.forEach(vc => vc.selected = selection.breakdowns.value);
          }
        }
      }
    }

    return {
      lobData: {
        mOTLine_Ext: {
          vehicleCoverages: data.vehicleCoverages
        }
      },
      jobID: data.jobID,
      selectedPeriodPublicId_dlg: data.selectedPeriodPublicId_dlg
    };
  };
}
