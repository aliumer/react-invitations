import { v4 as uuidv4 } from 'uuid';
import { CoverageTypeNames, CoverageTypeEnumSimple } from '@app/infrastructure/enums/coverage-type.enum';
import {
  YOUR_CAR_PERM,
  YOUR_CAR_TEMP,
  YOUR_DETAILS,
  YOUR_DRIVERS_PERM,
  YOUR_DRIVERS_TEMP,
  YOUR_ADDRESS,
  YOUR_REGISTRATION,
  ALLOCATE,
  PREMIUM,
  REVIEW_FULL,
  REVIEW_FULL_ROUTE,
  REVIEW_DIRECT_DEBIT,
  REVIEW_DIRECT_DEBIT_ROUTE,
  CONFIRM_FULL,
  CONFIRM_FULL_ROUTE,
  CONFIRM_DIRECT_DEBIT,
  CONFIRM_DIRECT_DEBIT_ROUTE,
  ERRORS,
  REFUND,
  PAYMENT_DIRECT_DEBIT_DISPLAY,
  PAYMENT_DIRECT_DEBIT_DISPLAY_ROUTE,
  PAYMENT_DIRECT_DEBIT_EDIT,
  PAYMENT_DIRECT_DEBIT_EDIT_ROUTE,
  PAYMENT_CREDIT_CARD,
  PAYMENT_CREDIT_CARD_ROUTE,
  DASHBOARD_SELECT,
  DASHBOARD_UPDATE,
  YOUR_CORRESPONDENCE,
  YOUR_MILEAGE,
  YOUR_CONVICTIONS,
  YOUR_TEMPORARY_EUROPEAN_COVER
} from '@app/infrastructure/constants';
import { coverageTypeMap, coverageTypeToNamesMap } from '@app/infrastructure/constants/premium';
import { environment } from '@env/environment';
import { JourneyFeatures } from '@app/infrastructure/data/journey-features';

export class CustomUtility {

  private static readonly featuresMap = new Map<string, string>([
    ['dashboardSelect', DASHBOARD_SELECT],
    ['dashboardUpdate', DASHBOARD_UPDATE],
    ['yourCarPerm', YOUR_CAR_PERM],
    ['yourCarTemp', YOUR_CAR_TEMP],
    ['yourMileage', YOUR_MILEAGE],
    ['yourRegistration', YOUR_REGISTRATION],
    ['yourDetails', YOUR_DETAILS],
    ['yourAddress', YOUR_ADDRESS],
    ['yourDriversPerm', YOUR_DRIVERS_PERM],
    ['yourDriversTemp', YOUR_DRIVERS_TEMP],
    ['yourConvictions', YOUR_CONVICTIONS],
    ['yourCorrespondenceAddress', YOUR_CORRESPONDENCE],
    ['yourTemporaryEuropeanCover', YOUR_TEMPORARY_EUROPEAN_COVER],
    [ALLOCATE, ALLOCATE],
    [PREMIUM, PREMIUM],
    [REVIEW_FULL, REVIEW_FULL_ROUTE],
    [REVIEW_DIRECT_DEBIT, REVIEW_DIRECT_DEBIT_ROUTE],
    [PAYMENT_DIRECT_DEBIT_DISPLAY, PAYMENT_DIRECT_DEBIT_DISPLAY_ROUTE],
    [PAYMENT_DIRECT_DEBIT_EDIT, PAYMENT_DIRECT_DEBIT_EDIT_ROUTE],
    [JourneyFeatures.directDebitNew.name, `/payment/${JourneyFeatures.directDebitNew.path}`],
    [JourneyFeatures.directDebitReview.name, `/payment/${JourneyFeatures.directDebitReview.path}`],
    [PAYMENT_CREDIT_CARD, PAYMENT_CREDIT_CARD_ROUTE],
    [REFUND, REFUND],
    [CONFIRM_FULL, CONFIRM_FULL_ROUTE],
    [CONFIRM_DIRECT_DEBIT, CONFIRM_DIRECT_DEBIT_ROUTE],
    [ERRORS, ERRORS]
  ]);

  static lookupFeature = (featureName: string) => CustomUtility.lookupByKeyFromMapper(CustomUtility.featuresMap, featureName);

  static getDriverXpertBrandName = (coverName: CoverageTypeNames) => coverName === CoverageTypeNames.Drivexpert ? environment.brand_copy[coverName.toLowerCase()] : coverName;

  static lookupCoverageType = (coverType: string) => CustomUtility.lookupByKeyFromMapper(coverageTypeMap, coverType);

  static lookupCoverageTypeToName = (coverType: CoverageTypeEnumSimple) => CustomUtility.lookupByKeyFromMapper(coverageTypeToNamesMap, coverType);

  static isEmptyObject(obj: any): boolean {
    return obj === null || obj === undefined || Array.isArray(obj) && obj.length === 0
      ? true
      : Object.entries(obj).length === 0 && obj.constructor === Object;
  }

  static redirectToExternalUrl(url: string) {
    const baseUrl = location.origin || `${location.protocol}//${location.hostname}${location.port ? ':' + location.port : ''}`;
    window.location.href = `${baseUrl}${url}`;
  }

  static appendEngineCapacityLabel(engineCapacity: string | number): string {
    const engineCapacityString = engineCapacity.toString() || '';
    return engineCapacityString + (engineCapacityString.indexOf('.') !== -1 || parseInt(engineCapacityString, 10) < 20 ? 'L' : 'CC');
  }

  static removeNullEntries(obj: any): any {
    Object.entries(obj).forEach(([key, value]) =>
      (value && typeof value === 'object') && CustomUtility.removeNullEntries(value) ||
      (value === null || value === '') && delete obj[key]);
    return obj;
  }

  private static lookupByKeyFromMapper<K, V>(mapper: Map<K, V>, key: K): V {
    return mapper.get(key) || null;
  }

  static getUniqueId(length = 9, isAllowSeparators = false): string {
    let uniqueId = uuidv4();
    if (!isAllowSeparators) {
      uniqueId = uniqueId.replace('-', '');
    }
    if (length) {
      uniqueId = uniqueId.substr(0, length);
    }
    return uniqueId;
  }

  static isEmpty(obj: any): boolean {
    if(!obj) {
      return true;
    }
    return Object.keys(obj).length === 0 && obj.constructor === Object;
  }
}
