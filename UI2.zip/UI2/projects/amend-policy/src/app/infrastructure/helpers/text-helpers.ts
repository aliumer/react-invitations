export class TextHelpers {

  static convertToUpperCase(value: string): string {
    return value.toUpperCase();
  }

  static convertToTitleCase(value: string): string {
    return value.replace(/\w\S*/g, txt => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
  }
}
