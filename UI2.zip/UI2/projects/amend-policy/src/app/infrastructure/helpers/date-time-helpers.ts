import { DateTime, Duration } from 'luxon';

import { AppDateObject } from '@app/infrastructure/interfaces/app-dates';
import { YearFormat } from '@app/features/your-drivers/models/year-format';

export class DateTimeHelpers {

  static get today() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return today;
  }

  static differenceInDaysWithDaysInFuture(date, numberOfDaysAdded): number {
    const todayPlusDays = DateTime.fromJSDate(DateTimeHelpers.today).plus({days: numberOfDaysAdded});
    const referenceDate = DateTime.fromJSDate(date);
    return (todayPlusDays.diff(referenceDate, 'days').toObject()).days;
  }

  static getShortMonth(paramMonthIdx: number): any {
    const monthIdx = paramMonthIdx - 1;
    const shortMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return shortMonths[monthIdx];
  }

  static differenceInDays(dateFrom, dateTo): number {
    return DateTime.fromJSDate(dateTo).diff(DateTime.fromJSDate(dateFrom), 'days').toObject().days;
  }

  static differenceInMonths(dateFrom, dateTo) {
    return dateTo.getMonth() - dateFrom.getMonth() +
      (12 * (dateTo.getFullYear() - dateFrom.getFullYear()));
  }

  static toFormat(
    dateObject: number[] | { day?: number, month: number, year: number },
    isShortYearFormat = false,
    delimiter: string = '/'): string {
    if (Array.isArray(dateObject)) {
      const [day, month, year] = dateObject.filter(v => +v !== undefined);
      dateObject = day ? {day, month, year} : {month, year};
    }
    return isShortYearFormat ?
      DateTime.fromObject(dateObject).toFormat(`dd${delimiter}MM${delimiter}yy`) :
      DateTime.fromObject(dateObject).toFormat(`dd${delimiter}MM${delimiter}yyyy`);
  }

  static toFormatMonthYear({year, month}: { year: number, month: number }, isMonthJsArrayIndexed = false): string {
    return DateTime.fromObject({year, month: isMonthJsArrayIndexed ? month + 1 : month}).toFormat(`MMM yyyy`);
  }

  static dateCompare(inputDate1: Date, inputDate2: Date): boolean {
    return inputDate1.getDate() === inputDate2.getDate() &&
      inputDate1.getMonth() === inputDate2.getMonth() &&
      inputDate1.getFullYear() === inputDate2.getFullYear();
  }

  static setDateToObject(date: string[], convertMonthToZeroBased: boolean = false): AppDateObject {
    const dateAsObject: AppDateObject = {};

    if (date && date.length === 3) {
      dateAsObject.day = date[0] !== '' ? Number(date[0]) : 1;
      dateAsObject.month = convertMonthToZeroBased ? this.setValueAsZeroBasedIndex(Number(date[1])) : Number(date[1]);
      dateAsObject.year = Number(date[2]);
    }

    return dateAsObject;
  }

  static setValueAsZeroBasedIndex(value: number): number {
    return value > 0 ? --value : value;
  }

  static isDateTodayOrInFuture(date: Date, isTodayIncluded = true) {
    return isTodayIncluded ?
      date >= DateTimeHelpers.today :
      date > DateTimeHelpers.today;
  }

  static getDifferenceInYears(date1: string[], date2: string[]): number {
    // Return 0 if there are any null, undefined, or empty values in the date parameters
    if (this.checkDateForEmptyValue(date1) || this.checkDateForEmptyValue(date2)) {
      return 0;
    }

    const sortedDates: any[] = this.sortDates([date1, date2]);
    const sortedDate1: number[] = this.formatDateTypeToNumber(sortedDates[0]);
    const sortedDate2: number[] = this.formatDateTypeToNumber(sortedDates[1]);

    let yearsDifference: number = sortedDate2[2] - sortedDate1[2];
    const months: number = sortedDate2[1] - sortedDate1[1];
    if (months < 0 || (months === 0 && sortedDate2[0] < sortedDate1[0])) {
      yearsDifference--;
    }
    return yearsDifference;
  }

  static diffNow(
    date: number[] | { day?: number, month: number, year: number }): Duration {
    return DateTimeHelpers.createDateTimeObject(date).diffNow(['days', 'months', 'years']);
  }

  static lastDayOfMonth(date: Date | string[]): number {
    if (Array.isArray(date)) {
      return new Date(+date[2], +date[1], 0).getDate();
    }
    return new Date(date.getFullYear(), date.getMonth(), 0).getDate();
  }

  static getYearFormat(yearRange: number): YearFormat {
    const currentTime = new Date();
    const currentYear = currentTime.getFullYear();
    return {
      years:
        {
          min: currentYear - yearRange,
          max: currentYear
        }
    };
  }

  static addMonthsToDate(date: string[], monthsToAdd: number): string {
    return DateTime
      .fromObject({year: +date[2], month: +date[1]})
      .plus({months: monthsToAdd})
      .toFormat('dd/MM/yyyy');
  }

  static createNewDate(srcDate: Date, delta: number): Date {
    const copy = new Date(srcDate.valueOf());
    return new Date(copy.setDate(copy.getDate() + delta));
  }

  static getLatestDate(dates: Date[]): Date {
    return dates.sort((a, b) => a > b ? -1 : a < b ? 1 : 0)[0];
  }

  private static checkDateForEmptyValue(date: string[]): boolean {
    return date.filter(d => !d).length > 0;
  }

  private static sortDates(dates: Array<string[]>, descending?: boolean): any[] {
    const sortedArray = dates.map((date) => {
      const year = date[2] && (Number(date[2]) < 10) && date[2].length < 2 ? '0' + date[2] : date[2];
      const month = date[1] && (Number(date[1]) < 10) && date[1].length < 2 ? '0' + date[1] : date[1];
      const day = date[0] && (Number(date[0]) < 10) && date[0].length < 2 ? '0' + date[0] : date[0];
      return [year, month, day];
    }).sort().map((date) => {
      const year = date[0] && date[0].charAt(0) === '0' ? date[0].substr(1) : date[0];
      const month = date[1] && date[1].charAt(0) === '0' ? date[1].substr(1) : date[1];
      const day = date[2] && date[2].charAt(0) === '0' ? date[2].substr(1) : date[2];
      return [day, month, year];
    });
    return descending ? sortedArray.reverse() : sortedArray;
  }

  private static formatDateTypeToNumber(date: string[]): number[] {
    return date.map(d => d ? +d : d === undefined ? undefined : null);
  }

  private static createDateTimeObject(
    dateObject: number[] | { day?: number, month: number, year: number }
  ): DateTime {
    if (Array.isArray(dateObject)) {
      const [day, month, year] = dateObject.filter(v => v);
      dateObject = day ? {day, month, year} : {month, year};
    }
    return DateTime.fromObject(dateObject);
  }
}
