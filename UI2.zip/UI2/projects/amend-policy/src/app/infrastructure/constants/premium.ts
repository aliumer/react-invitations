import { CoverageTypeEnum, CoverageTypeEnumSimple, CoverageTypeNames } from '@app/infrastructure/enums/coverage-type.enum';
import { KeyValueDict } from '@app/infrastructure/interfaces/key-value-dict';


export const MOT_LEGAL_COVER_COV = 'MOTLegalCoverCov';
export const MOT_GUARANTEED_HIRE_CAR_PLUS_COV = 'MOTGuaranteedHireCarPlusCov';
export const MOT_NO_CLAIM_DISC_COV = 'MOTNoClaimDiscCov';

// TODO:: use maps and eliminate the use of KeyValueDict
export const BreakdownCoverMap: KeyValueDict<string> = {
  fulluk: 'Full UK',
  roadsidehome: 'Roadside home',
  roadside: 'Roadside',
  RESEuroBrkdownLongTermCov: 'European',
  ResPersonalCov: 'Personal Cover'
};

export const BreakdownCoverMapSimple: KeyValueDict<string> = {
  fulluk: 'fulluk',
  roadsidehome: 'roadsidehome',
  roadside: 'roadside',
  RESEuroBrkdownLongTermCov: 'RESEuroBrkdownLongTermCov',
  ResPersonalCov: 'ResPersonalCov'
}

export const BreakdownFullNameCoverMap: KeyValueDict<string> = {
  fulluk: 'Full UK Breakdown Cover',
  roadsidehome: 'Roadside home Breakdown Cover',
  roadside: 'Roadside Breakdown Cover',
  RESEuroBrkdownLongTermCov: 'European Breakdown Cover',
  ResPersonalCov: 'Personal Cover'
};

export const DlgCoverCodeMap: KeyValueDict<string> = {
  RESRoadsideAssistanceCov: 'Roadside assistance',
  RESHomeBreakdownCov: 'Home breakdown',
  RESNationalRecoveryCov: 'National recovery',
  RESOnwardTravelOptsCov: 'Onward travel options',
  RESCaravanandTrailerCvrCov: 'Caravan and trailer cover',
  RESSpecialistEquipmentCov: 'Specialist equipment',
  RESEuroBrkdownLongTermCov: 'European Breakdown Cover',
  ResPersonalCov: 'Personal Cover'
};

/*export const PaymentTypes: KeyValueDict<string> = {
  payAnnual: 'Single Payment',
  payMonthly: 'Monthly - Deposit and 10 Instalments'
};*/

export const coverageTypeMap = new Map<string, CoverageTypeEnum>([
  ['comp', CoverageTypeEnum.Comp],
  ['compplus', CoverageTypeEnum.CompPlus],
  ['tpft', CoverageTypeEnum.TPFT],
  ['drivexpert', CoverageTypeEnum.Drivexpert]
]);

export const coverageTypeToNamesMap = new Map<CoverageTypeEnumSimple, CoverageTypeNames>([
  [CoverageTypeEnumSimple.Comp, CoverageTypeNames.Comp],
  [CoverageTypeEnumSimple.CompPlus, CoverageTypeNames.CompPlus],
  [CoverageTypeEnumSimple.TPFT, CoverageTypeNames.TPFT],
  [CoverageTypeEnumSimple.Drivexpert, CoverageTypeNames.Drivexpert]
]);


