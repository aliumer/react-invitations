import { JourneyFeatures } from '@app/infrastructure/data/journey-features';

// export const STP = '';

// export const LOAD_POLICY = JourneyFeatures.loadPolicy.path;

// export const BILLING = JourneyFeatures.billing.path;

// export const RETRIEVE_QUOTE = JourneyFeatures.retrieveQuote.path;

export const DASHBOARD_SELECT = JourneyFeatures.dashboardSelect.path;
export const DASHBOARD_SELECT_ROUTE = `/${DASHBOARD_SELECT}`;
export const DASHBOARD_UPDATE = JourneyFeatures.dashboardUpdate.path;
export const DASHBOARD_UPDATE_ROUTE = `/${DASHBOARD_UPDATE}`;

export const YOUR_CAR_PERM = JourneyFeatures.yourCarPerm.path;
export const YOUR_CAR_PERM_ROUTE = `/${YOUR_CAR_PERM}`;

export const YOUR_CAR_TEMP = JourneyFeatures.yourCarTemp.path;
export const YOUR_CAR_TEMP_ROUTE = `/${YOUR_CAR_TEMP}`;

export const YOUR_TEMPORARY_EUROPEAN_COVER = JourneyFeatures.yourTemporaryEuropeanCover.path;
export const YOUR_TEMPORARY_EUROPEAN_COVER_ROUTE = `/${YOUR_TEMPORARY_EUROPEAN_COVER}`;

export const YOUR_MILEAGE = JourneyFeatures.yourMileage.path;
export const YOUR_MILEAGE_ROUTE = `/${YOUR_MILEAGE}`;

export const YOUR_DETAILS = JourneyFeatures.yourDetails.path;
export const YOUR_DETAILS_ROUTE = `/${YOUR_DETAILS}`;

export const YOUR_REGISTRATION = JourneyFeatures.yourRegistration.path;
export const YOUR_REGISTRATION_ROUTE = `/${YOUR_REGISTRATION}`;

export const YOUR_DRIVERS_PERM = JourneyFeatures.yourDriversPerm.path;
export const YOUR_DRIVERS_PERM_ROUTE = `/${YOUR_DRIVERS_PERM}`;

export const YOUR_DRIVERS_TEMP = JourneyFeatures.yourDriversTemp.path;
export const YOUR_DRIVERS_TEMP_ROUTE = `/${YOUR_DRIVERS_TEMP}`;

export const YOUR_ADDRESS = JourneyFeatures.yourAddress.path;
export const YOUR_ADDRESS_ROUTE = `/${YOUR_ADDRESS}`;

// export const ADD_DRIVER = JourneyFeatures.addDriver.path;
// export const EDIT_DRIVER = JourneyFeatures.editDriver.path;

export const MANAGE_PERSONAL_DETAILS = JourneyFeatures.personalDetails.path;
export const MANAGE_LICENSE_NUMBER = JourneyFeatures.drivingLicenseNumber.path;
// export const MANAGE_DRIVING_HISTORY = JourneyFeatures.drivingHistory.path;

export const PREMIUM = JourneyFeatures.premium.path;
export const PREMIUM_ROUTE = `/${PREMIUM}`;

// export const REVIEW = JourneyFeatures.review.path;
export const REVIEW_FULL = JourneyFeatures.reviewFull.name;
export const REVIEW_FULL_ROUTE = `/${JourneyFeatures.reviewFull.path}`;

export const REVIEW_DIRECT_DEBIT = JourneyFeatures.reviewDirectDebit.name;
export const REVIEW_DIRECT_DEBIT_ROUTE = `/${JourneyFeatures.reviewDirectDebit.path}`;

export const PAYMENT = JourneyFeatures.payment.path;
export const PAYMENT_DIRECT_DEBIT_DISPLAY = JourneyFeatures.directDebitDisplay.name;
export const PAYMENT_DIRECT_DEBIT_DISPLAY_ROUTE = `/payment/${JourneyFeatures.directDebitDisplay.path}`;

export const PAYMENT_DIRECT_DEBIT_EDIT = JourneyFeatures.directDebitEdit.name;
export const PAYMENT_DIRECT_DEBIT_EDIT_ROUTE = `/payment/${JourneyFeatures.directDebitEdit.path}`;

export const PAYMENT_CREDIT_CARD = JourneyFeatures.creditCard.name;
export const PAYMENT_CREDIT_CARD_ROUTE = `/payment/${JourneyFeatures.creditCard.path}`;

export const REFUND = JourneyFeatures.refund.path;

export const CONFIRM = JourneyFeatures.confirm.path;
export const CONFIRM_FULL = JourneyFeatures.confirmFull.name;
export const CONFIRM_FULL_ROUTE = `/${JourneyFeatures.confirmFull.path}`;

export const CONFIRM_DIRECT_DEBIT = JourneyFeatures.confirmDirectDebit.name;
export const CONFIRM_DIRECT_DEBIT_ROUTE = `/${JourneyFeatures.confirmDirectDebit.path}`;

export const ALLOCATE = JourneyFeatures.allocate.path;

export const YOUR_CORRESPONDENCE = JourneyFeatures.yourCorrespondenceAddress.path;
export const YOUR_CORRESPONDENCE_ROUTE = `/${YOUR_CORRESPONDENCE}`;

export const YOUR_CONVICTIONS = JourneyFeatures.yourConvictions.path;
export const YOUR_CONVICTIONS_ROUTE = `/${YOUR_CONVICTIONS}`;

export const ERRORS = JourneyFeatures.errors.path;
export const ERRORS_ROUTE = `/${ERRORS}`;
export const ERRORS_LOAD_POLICY_FAILED = `${ERRORS_ROUTE}/load-policy-failed`;
export const ERRORS_POLICY_OUTSIDE_VALID_DURATION = `${ERRORS_ROUTE}/policy-outside-valid-duration`;
export const ERRORS_SESSION_TIMEOUT = `${ERRORS_ROUTE}/session-timeout`;
export const ERRORS_DECLINED = `${ERRORS_ROUTE}/declined`;
export const ERRORS_REFUND = `${ERRORS_ROUTE}/refund-failed`;
export const ERRORS_TRANSACTION_FAILED = `${ERRORS_ROUTE}/transaction-failed`;
export const ERRORS_TRANSACTION_REFUSED = `${ERRORS_ROUTE}/transaction-refused`;
export const ERRORS_PAYMENT_CONTACT_CENTRE = `${ERRORS_ROUTE}/payment-contact-centre`;
export const ERRORS_QUOTE = `${ERRORS_ROUTE}/quote-error`;
export const ERRORS_SUSPENDED_VEHICLE = `${ERRORS_ROUTE}/suspended-vehicle`;

export const MY_ACCOUNT_POLICY_DASHBOARD_URL = '/my-dashboard#/dashboard/policies';
