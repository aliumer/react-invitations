export const LOADING_PAGE_TITLE = 'Your policy';
export const BILLING_PAGE_TITLE = 'Your billing';
export const RETRIEVE_QUOTE_TITLE = 'Your Quote';

export const DASHBOARD_PAGE_TITLE = 'Change policy';

export const YOUR_CAR_PAGE_TITLE = 'Your car details';
export const YOUR_MILEAGE_PAGE_TITLE = 'Your mileage';
export const YOUR_CAR_REGISTRATION_MILEAGE_PAGE_TITLE = 'Your car registration';
export const YOUR_ADDRESS_PAGE_TITLE = 'Your address';
export const YOUR_CORRESPONDENCE_ADDRESS_PAGE_TITLE = 'Your correspondence address';
export const YOUR_PERSONAL_DETAILS_PAGE_TITLE = 'Your personal details';
export const YOUR_CONVICTIONS_PAGE_TITLE = 'Your motoring offences';
export const YOUR_DRIVER_PAGE_TITLE = 'Your drivers';
export const YOUR_TEMPORARY_EUROPEAN_COVER_PAGE_TITLE = 'Your Temporary European Cover';
export const ADD_DRIVER_PAGE_TITLE = 'Add a driver';
export const ALLOCATE_PAGE_TITLE = 'Allocate drivers and cars';

export const PREMIUM_PAGE_TITLE = 'New premium';
export const REVIEW_PAGE_TITLE = 'Review changes';

export const REFUND_PAGE_TITLE = 'Refund';
export const PAYMENT_PAGE_TITLE = 'Payment';
export const PAYMENT_DIRECT_DEBIT_EDIT_PAGE_TITLE = 'Edit your direct debit';

export const CONFIRM_PAGE_TITLE = 'Confirm';

export const ERROR_PAGE_TITLE = 'Error';
