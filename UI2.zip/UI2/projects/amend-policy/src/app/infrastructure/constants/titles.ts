export const projectTitle = 'B4C UI STP';
