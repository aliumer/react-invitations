import { CardTypesEnum } from '@app/infrastructure/enums/card-types.enum';


export const paymentTypeMap = new Map<string, CardTypesEnum>([
  ['visadebit', CardTypesEnum.Visa],
  ['mastercard', CardTypesEnum.Mastercard],
  ['amex', CardTypesEnum.Amex],
  ['maestro', CardTypesEnum.Maestro]
]);
