export const UW_ISSUE_DECLINED_CODE = 6014;
export const ACTIVE_JOB_COUNT_CODE = 6017;
export const INVALID_PROMO_CODE = 6019;
export const TIMEOUT_ERROR_CODE = 504;
export const TIMEOUT_STATUS_TEXT = 'gateway timeout';
