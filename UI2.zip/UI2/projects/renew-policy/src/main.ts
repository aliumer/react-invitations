import { enableProdMode, Injector } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { MainModule } from '@ren/main/main.module';

import { EnvironmentProviderService } from '@ren/core/services/environment-provider/environment-provider.service';

import { Environment } from '@ren/infrastructure/models/environment';
import { environment as env } from '@env/environment';

const injector = Injector.create({ providers: [ EnvironmentProviderService ]});
const environment = injector.get(Environment);

if (environment.production) {
  enableProdMode();
}

if (window.dlg_dolphin) {
  window.dlg_dolphin.brand = env.brand_copy.brand;
  window.dlg_dolphin.architecture = 'SPA';
  window.dlg_dolphin.type = 'Quote And Buy';
}

// TODO: commenting this codfe temporarily cause of dcja-368
// need to un comment when launch tag is compatible with tealium.
// if (environment.tealiumSync) {
//   const tealiumSync = document.createElement('script');
//   tealiumSync.src = environment.tealiumSync;
//   document.head.appendChild(tealiumSync);
// }
if (environment.tealiumSync) {
  const tealiumSync = document.createElement('script');
  tealiumSync.src = environment.tealiumSync;
  document.head.appendChild(tealiumSync);
}
const script = document.createElement('script');
script.src = environment.analyticsScript;
script.async = true;
document.head.appendChild(script);

// TODO: commenting this codfe temporarily cause of dcja-368
// need to un comment when launch tag is compatible with tealium.
// if (environment.tealiumScript) {
//   const tealiumScriptSettings = document.createElement('script');
//   tealiumScriptSettings.innerText = 'window.utag_cfg_ovrd = { noview : true };';
//   document.head.appendChild(tealiumScriptSettings);
//   const tealiumScript = document.createElement('script');
//   tealiumScript.src = environment.tealiumScript;
//   document.head.appendChild(tealiumScript);
// }

if (environment.tealiumScript) {
  const tealiumScriptSettings = document.createElement('script');
  tealiumScriptSettings.innerText = 'window.utag_cfg_ovrd = { noview : true };';
  document.head.appendChild(tealiumScriptSettings);
  const tealiumScript = document.createElement('script');
  tealiumScript.src = environment.tealiumScript;
  document.head.appendChild(tealiumScript);
}

platformBrowserDynamic().bootstrapModule(MainModule)
  .catch(err => console.error(err));
