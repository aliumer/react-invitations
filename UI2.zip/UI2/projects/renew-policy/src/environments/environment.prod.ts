import { brandCopy } from '../assets/common/copy';

export const environment = {
  production: true,
  brand_copy: brandCopy
};
