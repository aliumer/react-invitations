import { NgModule, Optional, SkipSelf } from '@angular/core';

import { CoreServicesModule } from '@ren/core/services/core-services.module';

import { EnvironmentProviderService } from '@ren/core/services/environment-provider/environment-provider.service';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  imports: [
    HttpClientModule,
    CoreServicesModule
  ],
  exports: [
    HttpClientModule,
    CoreServicesModule
  ],
  providers: [
    EnvironmentProviderService
  ]
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    throwIfAlreadyLoaded(parentModule, 'CoreModule');
  }
}

function throwIfAlreadyLoaded(parentModule: any, moduleName: string) {
  if (parentModule) {
    throw new Error(`${moduleName} has already loaded. Import module in the top level only.`);
  }
}
