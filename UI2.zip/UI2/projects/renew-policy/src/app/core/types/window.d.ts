import { DlgData } from 'dlg-dolphin/dist/lib/interfaces/dlg-data';
import { DlgDolphin } from 'dlg-dolphin/dist/lib/dolphin/dlg-dolphin';

declare global {
  interface Window {
    dlg_dolphin: DlgDolphin;
    dlg_data: DlgData;
    lpTag: any;
    utag?: any;
  }
}
