import {
  DlgDataAssetCar,
  DlgUserProfile,
  DlgDataQuote,
  DlgDataPolicyInfo
} from 'dlg-dolphin/dist/lib/interfaces/dlg-data';

import { DateTimeHelpers } from '@ren/infrastructure/helpers/date-time.helpers';


export interface MapperStrategy {
  mapFeature(data: any): any;
}

export class AnalyticsMapper {
  constructor(private mapperStrategy: MapperStrategy) {
  }

  mapFeature(data: any): any {
    return this.mapperStrategy.mapFeature(data);
  }
}

export class MapperFactory {
  static create(featureName: string): AnalyticsMapper {
    // tslint:disable-next-line: no-use-before-declare
    return new FeatureToAnalyticsMap()[featureName];
  }
}

export class PolicyMapper implements MapperStrategy {
  mapFeature(data: any): DlgDataPolicyInfo {
    return {
      name: data.name,
      price: data.price,
      quantity: 1
    };
  }
}

export class QuoteMapper implements MapperStrategy {
  mapFeature(data: any): DlgDataQuote {
    return {
      landing: {price: data.price},
      final: {price: data.price},
      apr: data.apr,
      payment_type: data.payment_type,
      payment_card_type: data.card_type,
      formId: data.quoteID,
      ...(data.renew && { renew: data.renew }),
      ...(data.price && { value: data.price }),
    };
  }
}

export class CarMapper implements MapperStrategy {

  private static getNumberOfModifications(data: any): number {
    return data && data.length ? data.length : 0;
  }

  static getObjectToDate(dateValue) {
    if (!isNaN(Date.parse(dateValue))) {
      const time = Date.parse(dateValue);
      return new Date(time).toString();
    } else {
      return null;
    }
  }

  mapFeature(data: any): DlgDataAssetCar {
    return {
      make: data?.make ?? '',
      model: data?.model ?? '',
      year: data?.year ?? '',
      modified: data?.modifications > 0 ? 'Yes' : 'No',
      modifications: data?.modifications
        ? CarMapper.getNumberOfModifications(data.modifications)
        : undefined,
      purchased: data?.isVehiclePurchased ? 'Yes' : 'No',
      purchased_date: CarMapper.getObjectToDate(data?.purchaseDate),
      // value: data.costNew.amount,
      est_mileage: data?.annualMileage ?? undefined,
      registered_keeper: data?.registeredKeeper ?? ''
      // home_overnight: data.isVehicleGarageAtHome ? 'Yes' : 'No',
      // use: data.primaryUse
    };
  }
}

export class ProfileMapper implements MapperStrategy {

  private static getDriverAge(dateOfBirth: any): number {
    const today = new Date();
    const todayArray = [
      today.getDate().toString(),
      today.getMonth().toString() + 1,
      today.getFullYear().toString()
    ];
    return DateTimeHelpers.getDifferenceInYears(dateOfBirth, todayArray);
  }

  mapFeature(data: any): DlgUserProfile[] {
    const users = [];
    data.forEach((user) => {
      const objUser = {
        title: user.title,
        sso_id: user.sso_id,
        DoB: user.dob,
        age: user.dob
          ? ProfileMapper.getDriverAge(user.dob)
          : undefined,
        employment_status: user.employmentStatus,
        gender: user.gender ? user.gender : '',
        industry: user.industry
          ? user.industry
            ? user.industry
            : ''
          : '',
        marital_status: user.maritalStatus
          ? user.maritalStatus
            ? user.maritalStatus
            : ''
          : '',
        occupation: user.occupation
          ? user.occupation
            ? user.occupation
            : ''
          : '',
        convictions: user.convictions
          ? user.convictions.length
          : 0,
        claims: user.claims
          ? user.claims.length
          : 0,
        email: user.emailAddress ? user.emailAddress : '',
        postcode: user.postCode ? user.postCode : '',
        postcode_first: user.postCode ? user.postCode.split(' ')[0] : '',
        license_type: user.licenseType,
        uk_resident: user.ukResident,
        uk_resident_since: user.ukResidentSince,
        years_license_held: user.licenseHeldFor,
        user_type: user.userType
      };
      users.push(objUser);
    });
    return users;
  }
}

export class FeatureToAnalyticsMap {
  'yourCarPerm' = new AnalyticsMapper(new CarMapper());
  'yourCarTemp' = new AnalyticsMapper(new CarMapper());
  'yourDetails' = new AnalyticsMapper(new ProfileMapper());
  'policy' = new AnalyticsMapper(new PolicyMapper());
  'quote' = new AnalyticsMapper(new QuoteMapper());
  'additionalDrivers' = new AnalyticsMapper(new ProfileMapper());
}
