import { Injectable } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { KeyValue } from '@angular/common';

import { CoreServicesModule } from '@ren/core/services/core-services.module';

import { ControlTypesEnum } from '@ren/infrastructure/enums/control-types.enum';
import { ModelControlMap } from '@ren/infrastructure/interfaces/model-control-map';


@Injectable({
  providedIn: CoreServicesModule
})
export class FormService {

  constructor(private fb: FormBuilder) {
  }

  createForm(formConfig: ModelControlMap, parentFormConfig: KeyValue<string, FormGroup> = null): FormGroup {
    const form: FormGroup = this.fb.group({});

    for (const [key] of Object.entries(formConfig)) {
      switch (formConfig[key].controlType) {
        case ControlTypesEnum.Group:
          const childFormForGrp = this.createForm(formConfig[key].controls);
          form.addControl(key, childFormForGrp);
          break;
        case ControlTypesEnum.Array:
          const childFormForArr = formConfig[key].controls ?
            this.createForm(formConfig[key].controls) :
            new FormControl('');
          form.addControl(key, new FormArray([childFormForArr], formConfig[key].validators));
          break;
        case ControlTypesEnum.DateArray:
          form.addControl(key,
            new FormArray(
              [new FormControl(''),
                new FormControl(''),
                new FormControl('')
              ], formConfig[key].validators));
          break;
        case ControlTypesEnum.SortCodeArray:
          form.addControl(key,
            new FormArray(
              [new FormControl(''),
                new FormControl(''),
                new FormControl('')
              ], formConfig[key].validators));
          break;
        default:
          form.addControl(key, new FormControl(formConfig[key].defaultValue || '', formConfig[key].validators));
          break;
      }
    }
    if (parentFormConfig) {
      const {key, value: parentForm} = parentFormConfig;
      parentForm.addControl(key, form);
      form.setParent(parentForm);
    }
    return form;
  }

  updateControlValidity(form: FormGroup) {
    for (const ctrl of Object.values(form.controls)) {
      if (ctrl instanceof FormGroup) {
        this.updateControlValidity(ctrl);
      } else if (ctrl instanceof FormControl || ctrl instanceof FormArray) {
        ctrl.markAsTouched();
        ctrl.markAsDirty();
        ctrl.updateValueAndValidity();
      }
    }
  }
}
