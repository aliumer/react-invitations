const AnalyticsScripts = {
  privilege: {
    dev: '//assets.adobedtm.com/97c3794ffa62/751a231f6e84/launch-bf5e62e25734-development.min.js',
    qa: '//assets.adobedtm.com/97c3794ffa62/751a231f6e84/launch-bf5e62e25734-development.min.js',
    prod: '//assets.adobedtm.com/97c3794ffa62/751a231f6e84/launch-9f03ed0e032a.min.js'
  },
  churchill: {
    dev: '//assets.adobedtm.com/97c3794ffa62/34e6a49e56dc/launch-5395d855dc5f-development.min.js',
    qa: '//assets.adobedtm.com/97c3794ffa62/34e6a49e56dc/launch-5395d855dc5f-development.min.js',
    prod: '//assets.adobedtm.com/97c3794ffa62/34e6a49e56dc/launch-64960364bb90.min.js'
  },
  directline: {
    dev: '//assets.adobedtm.com/97c3794ffa62/3a2654a5245e/launch-596a65caa8c5-development.min.js',
    qa: '//assets.adobedtm.com/97c3794ffa62/3a2654a5245e/launch-596a65caa8c5-development.min.js',
    prod: '//assets.adobedtm.com/97c3794ffa62/3a2654a5245e/launch-9040a3d03f01.min.js'
  }
};

const RecaptchaSiteKeys = {
  dev: '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI',
  qa: '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI',
  prod: '6LdlX5oUAAAAACgO6jDM8ufdpSbfpv3EoeZgCeca'
};

const ApiKeys = {
  dev: 'CwYPaUVJc6aWmTxlz1b1xaAQoWFP44QR7L0CqbgU',
  qa: 'CwYPaUVJc6aWmTxlz1b1xaAQoWFP44QR7L0CqbgU',
  prod: 'Tv872hqPV156qf5iIlklZ7blHS5mPw448cWw7hq3'
};

const TealiumScripts = {
  privilege: {
    script: {
      dev: 'https://tags.tiqcdn.com/utag/dlg/privilege/dev/utag.js',
      prod: 'https://tags.tiqcdn.com/utag/dlg/privilege/prod/utag.js',
      qa: 'https://tags.tiqcdn.com/utag/dlg/privilege/qa/utag.js'
    },
    sync: {
      dev: 'https://tags.tiqcdn.com/utag/dlg/privilege/dev/utag.sync.js',
      prod: 'https://tags.tiqcdn.com/utag/dlg/privilege/prod/utag.sync.js',
      qa: 'https://tags.tiqcdn.com/utag/dlg/privilege/qa/utag.sync.js',
    }
  },
  churchill: {
    script: {
      dev: 'https://tags.tiqcdn.com/utag/dlg/churchill/dev/utag.js',
      prod: 'https://tags.tiqcdn.com/utag/dlg/churchill/prod/utag.js',
      qa: 'https://tags.tiqcdn.com/utag/dlg/churchill/qa/utag.js'
    },
    sync: {
      dev: 'https://tags.tiqcdn.com/utag/dlg/churchill/dev/utag.sync.js',
      prod: 'https://tags.tiqcdn.com/utag/dlg/churchill/prod/utag.sync.js',
      qa: 'https://tags.tiqcdn.com/utag/dlg/churchill/qa/utag.sync.js'
    }
  },
  directline: {
    script: {
      dev: 'https://tags.tiqcdn.com/utag/dlg/directline/dev/utag.js',
      prod: 'https://tags.tiqcdn.com/utag/dlg/directline/prod/utag.js',
      qa: 'https://tags.tiqcdn.com/utag/dlg/directline/qa/utag.js'
    },
    sync: {
      dev: 'https://tags.tiqcdn.com/utag/dlg/directline/dev/utag.sync.js',
      prod: 'https://tags.tiqcdn.com/utag/dlg/directline/prod/utag.sync.js',
      qa: 'https://tags.tiqcdn.com/utag/dlg/directline/qa/utag.sync.js',
    }
  }
};

const Environments = [
  ['b4c-e2e-rc2-c11-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2e-rc2-c11-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-e2e-rc2-c11-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-uat-rc2-c11-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-uat-rc2-c11-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-uat-rc2-c11-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-uattt-rc2-c11-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-uattt-rc2-c11-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-uattt-rc2-c11-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-e2ett-rc3-c12-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2ett-rc3-c12-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-e2ett-rc3-c12-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-e2e1-rc2-c11-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2e1-rc2-c11-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-e2e1-rc2-c11-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-e2e-rc3-c12-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2e-rc3-c12-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-e2e-rc3-c12-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-uat-r1c-c10-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-nft-rc2-c11-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-nft-rc2-c11-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-nft-rc2-c11-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-sit-rc2-c12-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-sit-rc2-c12-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-sit-rc2-c12-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-dev-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'qa'],
  ['b4c-dev-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'qa'],
  ['b4c-dev-dl.dlgdigitalservices.com', 'car/api', 'directline', 'qa'],
  ['b4c-e2ett-rc2-c11-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2ett-rc2-c11-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-e2ett-rc2-c11-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-sit-rc2-c11-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-sit-rc2-c11-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-sit-rc2-c11-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['s1b-web-cluster.b4c-qa.dlgdigitalapi.com', 'live', 'privilege', 'dev'],
  ['e2e-s1b-web.b4c-qa.dlgdigitalapi.com', 'live', 'privilege', 'dev'],
  ['nft-s2b-web.b4c-qa.dlgdigitalapi.com', 'live', 'privilege', 'dev'],
  ['b4c-e2e-s1b-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2e-b1c-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['e2e-s1c-web.b4c-qa.dlgdigitalapi.com', 'live', 'privilege', 'dev'],
  ['b4c-qa-s1b-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['p3-qa-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-nft-b2b-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-uat-b3b-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-uat-r1c-c10-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2e-b1b-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['green-stp.b4c.dlgdigitalapi.com', 'live', 'privilege', 'prod'],
  ['blue-stp.b4c.dlgdigitalapi.com', 'live', 'privilege', 'prod'],
  ['stp.b4c.dlgdigitalapi.com', 'live', 'privilege', 'dev'],
  ['privilege.com', 'car/api', 'privilege', 'prod'],
  ['www.privilege.com', 'car/api', 'privilege', 'prod'],
  ['b4c-pro-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'prod'],
  ['b4c-pro-rc2-c11-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'prod'],
  ['b4c-pro-rc2-c11-dl.dlgdigitalservices.com', 'car/api', 'directline', 'prod'],
  ['b4c-pro-rc2-c11-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'prod'],
  ['www.directline.com', 'car/api', 'directline', 'prod'],
  ['directline.com', 'car/api', 'directline', 'prod'],
  ['www.churchill.com', 'car/api', 'churchill', 'prod'],
  ['churchill.com', 'car/api', 'churchill', 'prod'],
  ['b4c-e2ett-rc4-c11-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-ddev-rc3-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-ddev-rc3-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-ddev-rc3-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-e2e-rc3-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2e-rc3-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-e2e-rc3-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-sit-rc3-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-sit-rc3-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-sit-rc3-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-e2ett-rc3-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2ett-rc3-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-e2ett-rc3-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-e2ett4-rc3-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2ett4-rc3-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-e2ett4-rc3-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-sit-rc4-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-sit-rc4-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-sit-rc4-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['mm-qa-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-rc4-e2ett4-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-rc4-e2ett4-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-rc4-e2ett4-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-r1c-e2e-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-r1c-e2e-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-r1c-e2e-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['das-qa2-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['das-qa2-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['das-qa2-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-e2e-rc4-c11-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2e-rc4-c11-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-e2e-rc4-c11-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['ag-qa-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['cb-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['cb2-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['crafter-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['da-qa-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['das-qa-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['das-qa2-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['dasmta-qa-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['db-qa-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['digidev1-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['digidev2-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['digiqa1-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['digiqa2-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['digiqa3-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['digiqa4-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['digiqa5-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['digiqa6-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['digiqa7-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['digiqa8-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['gr-qa-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['home-ad-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['home-ed-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['home-id-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['home-idd-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['home-qa-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['home-qa2-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['home-ua-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['new-ch-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['payd-sit-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['plt-qa-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['project-virtual-assistant-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['directline-preprod.prod.dlgdigitalapi.com', 'car/api', 'directline', 'prod'],
  ['churchill-preprod.prod.dlgdigitalapi.com', 'car/api', 'churchill', 'prod'],
  ['b4c-pro-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'prod'],
  ['b4c-pro-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'prod'],
  ['b4c-pro-dl.dlgdigitalservices.com', 'car/api', 'directline', 'prod'],
  ['b4c-uat-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-uat-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-uat-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-nft-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-nft-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-nft-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-sittt-rc3-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-sittt-rc3-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-sittt-rc3-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2ett2-rc3-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-e2ett2-rc3-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-e2ett2-rc3-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2e-rc3-digital-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-e2e-rc3-digital-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-e2e-rc3-digital-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-mta-qa-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
  ['b4c-mta-qa-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-mta-qa-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-mta-ci-dl.dlgdigitalservices.com', 'car/api', 'directline', 'qa'],
  ['b4c-mta-ci-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'qa'],
  ['b4c-mta-ci-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'qa'],
  ['b4c-pcw-dev-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'qa'],
  ['b4c-pcw-dev-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'qa'],
  ['b4c-pcw-dev-dl.dlgdigitalservices.com', 'car/api', 'directline', 'qa'],
  ['b4c-qa-pr.dlgdigitalservices.com', 'car/api', 'privilege', 'dev'],
  ['b4c-qa-ch.dlgdigitalservices.com', 'car/api', 'churchill', 'dev'],
  ['b4c-qa-dl.dlgdigitalservices.com', 'car/api', 'directline', 'dev'],
];

const mergedEnvironments = Environments.reduce((acc, curr) => [...acc, `${curr[0]}|${curr[1]}|${curr[2]}|${curr[3]}`], []);
const uniqueEnvironments = [...new Set(mergedEnvironments)].map(e => e.split('|'));

const localhosts = [{
  key: 'localhost',
  values: {
    production: false,
    apiUrl: 'http://localhost:4500',
    apiKey: ApiKeys.dev,
    recaptchaSiteKey: RecaptchaSiteKeys.dev,
    analyticsScript: AnalyticsScripts.privilege.dev,
    tealiumScript: TealiumScripts.privilege.script.dev,
    tealiumSync: TealiumScripts.privilege.sync.dev
  }
}, {
  key: 'localhost.charlesproxy.com',
  values: {
    production: false,
    apiUrl: 'http://localhost.charlesproxy.com:4500',
    apiKey: ApiKeys.dev,
    recaptchaSiteKey: RecaptchaSiteKeys.dev,
    analyticsScript: AnalyticsScripts.privilege.dev,
    tealiumScript: TealiumScripts.privilege.script.dev,
    tealiumSync: TealiumScripts.privilege.sync.dev
  }
}];

export const EnvironmentProviderConfig = [...localhosts, ...uniqueEnvironments.map(e => ({
  key: e[0],
  values: {
    production: e[3] === 'prod',
    apiUrl: `https://${e[0]}/${e[1]}`,
    apiKey: ApiKeys[e[3]],
    recaptchaSiteKey: RecaptchaSiteKeys[e[3]],
    analyticsScript: AnalyticsScripts[e[2]][e[3]],
    tealiumScript: TealiumScripts[e[2]].script[e[3]],
    tealiumSync: TealiumScripts[e[2]].sync[e[3]]
  }
}))];
