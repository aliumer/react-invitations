import { Injectable } from '@angular/core';

import {
  DlgDataAssetCar,
  DlgUserProfile,
  DlgDataQuote,
  DlgDataPolicyInfo,
  DlgDataError,
  DlgDataAction
} from 'dlg-dolphin/dist/lib/interfaces/dlg-data';

import { CoreServicesModule } from '@ren/core/services/core-services.module';

import { MapperFactory } from './analytics-mappers';

@Injectable({
  providedIn: CoreServicesModule
})
export class AnalyticsService {
  private quote: DlgDataQuote;
  private policy: DlgDataPolicyInfo;

  private static mapFeature(featureName: string, formData: any) {
    return MapperFactory.create(featureName).mapFeature(formData);
  }

  trackPage(): void {
    window.dlg_dolphin.trackPage();
  }

  trackAction(data): void {
    const action: DlgDataAction = {
      event_name: data.event_name,
      event_time: data.event_time,
      attributes: {
        component_name: data.component_name,
        link_name: data.link_name
      }
    };
    if (window.dlg_data && window.dlg_data.action 
      && window.dlg_data.action[window.dlg_data.action.length - 1].event_time !== data.event_time) {
      window.dlg_data.action.push(action);
    }
  }

  trackSource(site?: string): void {
    window.dlg_dolphin.trafficSource.trackTrafficSource(site);
  }

  trackError(data?: DlgDataError) {
    window.dlg_dolphin.error.trackError(data);
  }

  trackFeature(featureName: string, formData: any): void {
    const data = AnalyticsService.mapFeature(featureName, formData);
    switch (featureName) {
      case 'yourCarPerm':
        window.dlg_dolphin.asset.trackAssetCar(data as DlgDataAssetCar);
        break;
      case 'yourDetails':
        if (data && data.length > 0) {
          window.dlg_data.user = [];
          data.forEach((user) => {
            window.dlg_dolphin.user.trackUser(user as DlgUserProfile);
          });
        }
        break;
      case 'additionalDrivers':
        // window.dlg_dolphin.user.trackUser(data as DlgUserProfile);
        break;
      case 'policy':
        this.policy = {...this.policy, ...data};
        if (window.dlg_data.policy.info.length > 0) {
          window.dlg_data.policy.info[0] = this.policy;
        } else {
          window.dlg_dolphin.policy.trackPolicyOrQuote(data);
        }
        break;
      case 'quote':
        this.quote = {...this.quote, ...data};
        window.dlg_dolphin.quote.trackMotorQb(this.quote);
        break;
      default:
        break;
    }
  }

  removedTrackedFeature(featureName: string, index) {
    switch (featureName) {
      case 'yourDetails':
        window.dlg_dolphin.user.removeTrackedUser(index);
        break;
      case 'yourCarPerm':
        window.dlg_dolphin.asset.removeTrackedAssetCar(index);
        break;
      default:
        break;
    }
  }

  driverAdded() {
    const added: number = (window.dlg_data.quote.drivers_added ? window.dlg_data.quote.drivers_added : 0) + 1;
    this.trackFeature('quote', {drivers_added: added});
  }

  driverRemoved() {
    const removed: number = (window.dlg_data.quote.drivers_removed ? window.dlg_data.quote.drivers_removed : 0) + 1;
    this.trackFeature('quote', {drivers_removed: removed});
  }


}
