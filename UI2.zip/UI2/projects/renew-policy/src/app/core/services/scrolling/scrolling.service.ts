import { Injectable } from '@angular/core';

import { CoreServicesModule } from '@ren/core/services/core-services.module';

@Injectable({
  providedIn: CoreServicesModule
})
export class ScrollingService {

  private static scrollToElement(element: any, scrollModifier: number = 0) {
    window.scrollTo(0, element.getBoundingClientRect().top - document.body.getBoundingClientRect().top - 24 + scrollModifier);
  }

  scrollToSection(sectionId: string) {
    const element = document.querySelector(`#${sectionId}`);

    if (element) {
      ScrollingService.scrollToElement(element);
    }
  }

  scrollToFirstError(selector = '.has-error') {
    setTimeout(() => {
      const firstElementError = document.querySelector(selector);
      if (firstElementError) {
        ScrollingService.scrollToElement(firstElementError);
      }
    });
  }

  scrollToFirstPanelError() {
    const firstPanelError = document.querySelector('.panel__error');

    if (firstPanelError) {
      ScrollingService.scrollToElement(firstPanelError);
    }
  }
}
