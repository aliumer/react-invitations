import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PremiumContainerComponent } from './premium-container.component';

describe('PremiumContainerComponent', () => {
  let component: PremiumContainerComponent;
  let fixture: ComponentFixture<PremiumContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PremiumContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PremiumContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
