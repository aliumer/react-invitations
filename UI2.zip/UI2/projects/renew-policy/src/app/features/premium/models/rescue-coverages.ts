import { VehicleCoverageCover } from '@ren/features/review/interfaces/vehicle-coverage-cover';
import { Amount } from '@ren/features/premium/models/amount';

export interface RescueCoverages {
  covName: string;
  coverages?: Array<VehicleCoverageCover>;
  amount: Amount;
  monthlyAmount: Amount;
  selected: boolean;
  codeIdentifier_dlg?: string;
}
