import { PaymentPlan } from '@ren/features/premium/models/payment-plan';


export interface OfferedPaymentPlan {
  periodPublicId?: string;
  branchName: string;
  paymentPlans: Array<PaymentPlan>;

  // TODO:: CAP - in b4c-ui and not in STP
  paymentPlanMessage_dlg?: string;
  periodPublicId_dlg?: string;
}
