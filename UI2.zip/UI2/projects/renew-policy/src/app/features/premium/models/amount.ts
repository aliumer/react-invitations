export interface Amount {
  amount: number;
  currency: string;
}
