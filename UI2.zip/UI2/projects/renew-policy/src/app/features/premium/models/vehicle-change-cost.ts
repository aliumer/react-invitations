import { Amount } from '@ren/features/premium/models/amount';


export interface VehicleChangeCost {
  vehicleID?: string;
  vehicleChangeCost?: Amount;
}
