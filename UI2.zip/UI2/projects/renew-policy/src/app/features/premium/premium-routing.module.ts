import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PremiumResolverService } from '@ren/features/premium/services/premium-resolver/premium-resolver.service';

import { PremiumContainerComponent } from './containers/premium-container.component';


const routes: Routes = [
  {
    path: '',
    component: PremiumContainerComponent,
    resolve: {
      _: PremiumResolverService
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PremiumRoutingModule { }
