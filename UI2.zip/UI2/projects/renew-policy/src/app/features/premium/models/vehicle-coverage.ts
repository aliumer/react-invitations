import { PromoDiscount } from '@ren/features/premium/models/promo-discount';
import { RescueCoverages } from '@ren/features/premium/models/rescue-coverages';
import { VehicleExcess } from '@ren/features/premium/models/vehicle-excess';
import { Amount } from '@ren/features/premium/models/amount';


export interface VehicleCoverage {
  publicID: string;
  fixedId?: number;
  vehicleName?: string;
  typeOfVehicle?: string;
  automaticAppliedPromos_dlg?: Array<PromoDiscount>;
  coverages?: Array<VehicleCoverageCover>;
  rescueCoverages_dlg?: Array<RescueCoverages>;
  vehicleExcess_dlg?: VehicleExcess;
}

export interface VehicleCoverages {
  vehicleCoverages: Array<VehicleCoverage>;
}

export interface VehicleCoverageCover {
  name?: string;
  covName?: string;
  codeIdentifier_dlg?: string;
  updated?: boolean;
  selected?: boolean;
  required?: boolean;
  description?: string;
  coverageCategoryCode?: string;
  coverageCategoryDisplayName?: string;
  existanceType_dlg?: string;


  // TODO:: in b4c-ui but recheck if they exists
  amount?: Amount;
  monthlyAmount_dlg?: Amount;
  publicID?: string;

}
