export interface DriverExcess {
  publicID: string;
  name: string;
  mainDriver?: boolean;
  compulsoryExcess: number;
  voluntaryExcess?: any;
  fireandTheftExcess: number;
  fireandTheftTotalExcess?: number;
  driverExcess?: number;
  totalExcess: number;
  windScreenRepair?: number;
  windScreenReplace?: number;
  vehicleID?: string;
  driverID?: string;
}
