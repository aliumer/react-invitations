import { VehicleCoverages } from '@ren/features/premium/models/vehicle-coverage';
import { DriverExcess } from '@ren/features/premium/models/driver-excess';

export interface Offering {
  branchName: string;
  periodPublicId_dlg: string;
  offeringCode_dlg: string;
  isPriorOffering_dlg: boolean;
  coverages: VehicleCoverages;
  versionGroupId_dlg?: number;
  driverExcess_dlg: Array<DriverExcess>;
  noClaimDiscountApplied_dlg: boolean;
}
