import { Premium } from '@ren/features/premium/models/premium';


export interface OfferedQuote {
  publicID?: string;
  branchName?: string;
  branchCode?: string;
  isCustom?: boolean;
  premium?: Premium;

  // TODO::: CAP in B4c, but not in STP
  periodPublicId_dlg?: string;
  hasBlockingUWIssues?: boolean;
  uwIssueDetails_dlg?: Array<any>;
}
