import { Amount } from '@ren/features/premium/models/amount';
import { VehicleChangeCost } from '@ren/features/premium/models/vehicle-change-cost';

export interface Premium {
  monthlyPremium: Amount;
  termMonths: number;
  previousTotalCost_dlg: Amount;
  totalCost_dlg: Amount;
  changeInCost_dlg: Amount;
  vehicleChangeCost_dlg: Array<VehicleChangeCost>;
  feesCost_dlg: Amount;
  // TODO:: CAP in b4c-ui but not in STP, can we delete.
  total?: Amount;
  offeringPremium_dlg?: Amount;
  taxes?: Amount;
  totalBeforeTaxes?: Amount;
}
