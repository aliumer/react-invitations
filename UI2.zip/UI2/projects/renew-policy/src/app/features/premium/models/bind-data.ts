import { OfferedPaymentPlan } from '@ren/features/premium/models/offered-payment-plan';
import { DriverEmail } from '@ren/features/premium/models/driver-email';
import { Refund } from '@ren/features/premium/models/refund';

export interface BindData {
  accountNumber?: string;
  chosenQuote?: string;
  offeredPaymentPlans_dlg?: Array<OfferedPaymentPlan>;
  selectedPaymentPlan?: string;
  selectedPaymentOption?: string;
  contactEmail?: string;
  confirmCarRegAndStartDateInd_dlg?: boolean;
  confirmCommunicationPrefInd_dlg?: boolean;
  confirmToProceedInd_dlg?: boolean;
  recvRenewalNoticeInd_dlg?: boolean;
  preferredPaymentDate_dlg?: number;
  autoRenewInd_dlg?: boolean;
  driversEmail_dlg?: Array<DriverEmail>;
  eligiblePaymentOptions?: Array<any>;
  refundTable?: Array<Refund>;

  // TODO:: CAP, IN B4C-UI BUT NOT IN STP
  offeredPaymentPlans?: Array<OfferedPaymentPlan>;
  contactPhone?: string;
  creditCardDetails_dlg?: any;
  availableDirectDebitDetails_dlg?: any[];
  availableCreditCardDetails_dlg?: any[];
  directDebitDetails_dlg?: any;
}
