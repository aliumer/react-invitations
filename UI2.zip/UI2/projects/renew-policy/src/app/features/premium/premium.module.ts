import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { ErrorModule } from '@ren/shared/error/error.module';
import { PipesModule } from '@ren/shared/pipes/pipes.module';
import { SubmissionModule } from '@ren/shared/submission/submission.module';
import { PremiumRoutingModule } from '@ren/features/premium/premium-routing.module';
import { PremiumServicesModule } from '@ren/features/premium/services/premium-services.module';

import { PremiumContainerComponent } from '@ren/features/premium/containers/premium-container.component';

import { PremiumHeaderComponent } from '@ren/features/premium/components/premium-header/premium-header.component';
import { SummaryTabsComponent } from '@ren/features/premium/components/tabs/summary-tabs/summary-tabs.component';
import { SummaryTabItemComponent } from '@ren/features/premium/components/tabs/summary-tab-item/summary-tab-item.component';
import { SummaryNoTabComponent } from '@ren/features/premium/components/tabs/summary-no-tab/summary-no-tab.component';
import { TabListComponent } from '@ren/features/premium/components/tabs/tab-list/tab-list.component';
import { TabListItemComponent } from '@ren/features/premium/components/tabs/tab-list-item/tab-list-item.component';
import { SummaryInfoComponent } from '@ren/features/premium/components/tabs/summary-info/summary-info.component';
import { BenefitsComponent } from '@ren/features/premium/components/benefits/benefits.component';
import { BenefitsItemComponent } from '@ren/features/premium/components/benefits/benefits-item/benefits-item.component';
import { CoverSelectComponent } from '@ren/features/premium/components/cover-select/cover-select.component';
import { ExtrasListComponent } from '@ren/features/premium/components/extras-list/extras-list.component';
import { ExtrasListItemComponent } from '@ren/features/premium/components/extras-list/extras-list-item/extras-list-item.component';
import { ExtrasPriceComponent } from '@ren/features/premium/components/extras-price/extras-price.component';
import { BreakdownDetailsComponent } from '@ren/features/premium/components/breakdown-details/breakdown-details.component';
import { BreakdownCoverListComponent } from '@ren/features/premium/components/breakdown-cover-list/breakdown-cover-list.component';
import { EuBreakdownCoverComponent } from '@ren/features/premium/components/eu-breakdown-cover/eu-breakdown-cover.component';
import { QuoteSummaryComponent } from '@ren/features/premium/components/quote-summary/quote-summary.component';
import { DirectDebitTableComponent } from '@ren/features/premium/components/quote-summary/direct-debit-table/direct-debit-table.component';
import { LegacyCoversComponent } from '@ren/features/premium/components/legacy-covers/legacy-covers.component';
import { PersonalCoverComponent } from '@ren/features/premium/components/personal-cover/personal-cover.component';
import { PromosDiscountsComponent } from '@ren/features/premium/components/promos-discounts/promos-discounts.component';
import { NcdModalComponent } from '@ren/features/premium/modals/ncd-modal/ncd-modal.component';
import { BreakdownModalComponent } from '@ren/features/premium/modals/breakdown-modal/breakdown-modal.component';
import { MonthlyRepresentativeComponent } from './components/monthly-representative/monthly-representative.component';
import { ExcessComponent } from './components/excess/excess.component';

import * as fromPremium from '@ren/features/premium/state/reducers';

import { PremiumEffects } from '@ren/features/premium/state/effects/premium.effects';

import { PREMIUM_STORE_KEY } from '@ren/infrastructure/constants';



@NgModule({
  declarations: [
    PremiumContainerComponent,
    PremiumHeaderComponent,
    SummaryTabsComponent,
    SummaryTabItemComponent,
    SummaryNoTabComponent,
    TabListComponent,
    TabListItemComponent,
    SummaryInfoComponent,
    BenefitsComponent,
    BenefitsItemComponent,
    CoverSelectComponent,
    ExtrasListComponent,
    ExtrasListItemComponent,
    ExtrasPriceComponent,
    BreakdownDetailsComponent,
    BreakdownCoverListComponent,
    EuBreakdownCoverComponent,
    QuoteSummaryComponent,
    DirectDebitTableComponent,
    LegacyCoversComponent,
    PersonalCoverComponent,
    PromosDiscountsComponent,
    NcdModalComponent,
    BreakdownModalComponent,
    MonthlyRepresentativeComponent,
    ExcessComponent
  ],
  imports: [
    CoreUiModule,
    ErrorModule,
    PipesModule,
    SubmissionModule,
    PremiumRoutingModule,
    PremiumServicesModule,
    StoreModule.forFeature(PREMIUM_STORE_KEY, fromPremium.reducers),
    EffectsModule.forFeature([PremiumEffects])
  ]
})
export class PremiumModule {
}
