export interface GwDate {
  day?: number;
  month?: number;
  year?: number;
}
