import { Component, OnInit } from '@angular/core';
import { KeyValue } from '@angular/common';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { filter, takeWhile, tap } from 'rxjs/operators';

import { ModalRef, ModalService } from 'dlg-angular-components';

import { AppErrorService } from '@ren/shared/error/services/app-error/app-error.service';
import { ScrollingService } from '@ren/core/services/scrolling/scrolling.service';

import { FeatureBase } from '@ren/infrastructure/abstracts/feature.base';

import { NcdModalComponent } from '@ren/features/premium/modals/ncd-modal/ncd-modal.component';
import { RejectQuoteModalComponent } from '@ren/shared/modals/components/reject-quote-modal/reject-quote-modal.component';
import { BreakdownModalComponent } from '@ren/features/premium/modals/breakdown-modal/breakdown-modal.component';

import { JourneyNavigationActions, RenewActions } from '@ren/main/state/actions';
import { PremiumActions } from '@ren/features/premium/state/actions';

import { selectLatestPremium, getNcdModalData, selectInlineError } from '@ren/main/state/selectors/policy.selectors';
import {
  selectJourneyNavigationButtonDetailsWithExtra
} from '@ren/main/state/selectors/journey.selectors';
import { selectPremiumUpdateError } from '@ren/features/premium/state/selectors/premium.selectors';

import { ChangeTypeEnum } from '@ren/infrastructure/enums/change-type.enum';

import { KeyValueDict } from '@app/infrastructure/interfaces/key-value-dict';

import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';


@Component({
  selector: 'app-premium-container',
  templateUrl: './premium-container.component.html'
})
export class PremiumContainerComponent extends FeatureBase implements OnInit {

  premium$: Observable<any>;
  isShowInlineError$: Observable<boolean>;
  changeType: ChangeTypeEnum;

  private modal: ModalRef;
  private ncdModalActive = false;

  constructor(
    protected router: Router,
    protected store: Store,
    private modalService: ModalService,
    private appErrorService: AppErrorService,
    private scrollingService: ScrollingService
  ) {
    super(router, store, JourneyFeaturesConfig.premium.name);
  }

  onTabChangeSelected(coverID: string) {
    this.store.dispatch(PremiumActions.updatePremium({coverID}));
  }

  onAddOnSelection(extras: KeyValueDict<KeyValue<string, boolean>>) {
    this.store.dispatch(PremiumActions.updatePremiumAddOns({extras}));
  }

  onExcessSelection(vehicleExcess: number) {
    this.store.dispatch(PremiumActions.updatePremiumExcess({vehicleExcess}));
  }

  onAddOnDetailsSelection() {
    this.ncdModalActive = true;
    this.store.pipe(
      select(getNcdModalData),
      takeWhile(() => this.ncdModalActive)
    ).subscribe(({amountPerYear, ncdYears}) => {
      this.modalService.open(NcdModalComponent, {amountPerYear, ncdYears});
      this.ncdModalActive = false;
    });
  }

  onBkdownCoverDetailsSelection() {
    this.modalService.open(BreakdownModalComponent);
  }

  ngOnInit(): void {
    super.ngOnInit();
  }

  protected handleNavigation() {
    this.store.pipe(
      select(selectJourneyNavigationButtonDetailsWithExtra),
      filter(({
                isBackButtonClicked,
                isNextButtonClicked,
                isSkipButtonClicked
              }) => isBackButtonClicked || isNextButtonClicked || isSkipButtonClicked),
      takeWhile(() => this.isComponentActive)
    ).subscribe(({isBackButtonClicked, isNextButtonClicked, isSkipButtonClicked, navCommands}) => {
      try {
        if (isNextButtonClicked) {
          this.onNext(navCommands.next);
        }

        if (isSkipButtonClicked) {
          this.store.dispatch(JourneyNavigationActions.resetButtons());
          this.modal = this.modalService.open(RejectQuoteModalComponent);
          this.modal.closed$.subscribe(({isBackToMyAccount}) => {
            if (isBackToMyAccount) {
              this.store.dispatch(RenewActions.rejectQuote());
              this.router.navigate([JourneyFeaturesConfig.reviewInitial.path]);
            }
          });
          return;
        }

        if (isBackButtonClicked) {
          this.onBack(navCommands.prev);
        }
      } catch {
        this.store.dispatch(JourneyNavigationActions.resetButtons());
      }
    });
  }

  protected observeOnData() {
    this.premium$ = this.store.pipe(
      select(selectLatestPremium)
    );

    /*this.store.pipe(
      select(selectNewVersionCreatedStatus),
      takeWhile(() => this.isComponentActive)
    ).subscribe(isNewVersionCreated => {
      this.store.dispatch(JourneyNavigationActions.changeButtonVisibility({
        id: 'skip',
        status: !isNewVersionCreated
      }));
    });*/
  }

  protected observeOnError() {
    this.isShowInlineError$ = this.store.pipe(
      select(selectInlineError),
      filter(val => val),
      tap(() => setTimeout(() => this.scrollingService.scrollToFirstPanelError()))
    );

    this.store.pipe(
      select(selectPremiumUpdateError),
      filter(({logicalError, httpError}) => logicalError || httpError),
      takeWhile(() => this.isComponentActive)
    ).subscribe(({logicalError, httpError}) => {
      const url = this.router.url;
      if (logicalError) {
        this.appErrorService.handleLogicalErrors(logicalError, url);
      } else {
        this.appErrorService.handleHttpErrors(httpError, url);
      }
    });
  }
}
