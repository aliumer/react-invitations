export interface PromoDiscount {
  code: string;
  descriptions: Array<string>;
}
