export interface DriverEmail {
  publicID?: string;
  emailAddress?: string;
}
