import { GwDate } from '@ren/features/premium/models/gw-date';


export interface Refund {
  payeeName?: string;
  policyHolderPayerInd: boolean;
  cardType?: string;
  refundAmount?: string;
  refundDate?: GwDate;
}
