export interface BenefitsItem {
  benefitTitle: string;
  benefitDescription: string;
}
