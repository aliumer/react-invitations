import { Amount } from '@ren/features/premium/models/amount';


export interface PaymentPlan {
  name: string;
  downPayment?: Amount;
  total?: Amount;
  installment?: Amount;
  billingId: string;
  firstInstallment_dlg?: Amount;
  remainingInstallment_dlg?: Amount;
  installmentPercentage_dlg?: number;
  installmentCharge_dlg?: Amount;
  aPR_dlg?: number;
}
