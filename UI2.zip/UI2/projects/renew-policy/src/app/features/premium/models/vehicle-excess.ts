export interface VehicleExcess {
  compulsoryExcess?: number;
  voluntaryExcess?: Array<number>;
  selectedVoluntaryExcess: number;
  driverExcess?: number;
  totalExcess?: number;
  fireandTheftExcess?: number;
  windScreenRepair?: number;
  windScreenReplace?: number;
  fireandTheftTotalExcess?: number;
}
