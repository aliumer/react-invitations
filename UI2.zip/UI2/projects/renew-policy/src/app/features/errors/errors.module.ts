import { NgModule } from '@angular/core';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { AlertsModule } from '@ren/shared/alerts/alerts.module';
import { ErrorsRoutingModule } from './errors-routing.module';

import { ErrorsContainerComponent } from './containers/errors-container.component';
import { SessionTimeoutComponent } from './components/session-timeout/session-timeout.component';
import { ErrorsNavigationComponent } from './components/errors-navigation/errors-navigation.component';
import { TransactionFailedComponent } from './components/transaction-failed/transaction-failed.component';
import { TransactionRefusedComponent } from './components/transaction-refused/transaction-refused.component';
import { PaymentContactCentreComponent } from './components/payment-contact-centre/payment-contact-centre.component';
import { RenewalDeclinedComponent } from './components/renewal-declined/renewal-declined.component';
import { QuoteErrorComponent } from './components/quote-error/quote-error.component';



@NgModule({
  declarations: [ErrorsContainerComponent, SessionTimeoutComponent, ErrorsNavigationComponent, TransactionFailedComponent, TransactionRefusedComponent, PaymentContactCentreComponent, RenewalDeclinedComponent, QuoteErrorComponent],
  imports: [
    CoreUiModule,
    AlertsModule,
    ErrorsRoutingModule
  ]
})
export class ErrorsModule { }
