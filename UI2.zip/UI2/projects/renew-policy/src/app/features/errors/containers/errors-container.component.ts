import { Component, OnInit } from '@angular/core';
import { LocationStrategy } from '@angular/common';

@Component({
  selector: 'app-errors-container',
  template: `<router-outlet></router-outlet>`
})
export class ErrorsContainerComponent implements OnInit {

  constructor(
    private locationStrategy: LocationStrategy
  ) { }

  ngOnInit(): void {
    this.preventBackButton(this.locationStrategy);
  }

  private preventBackButton(locationStrategy: LocationStrategy) {
    history.pushState(null, null, location.href);
    locationStrategy.onPopState(() => {
      history.pushState(null, null, location.href);
    });
  }

}
