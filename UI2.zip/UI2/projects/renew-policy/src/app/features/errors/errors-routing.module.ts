import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ErrorsContainerComponent } from '@ren/features/errors/containers/errors-container.component';

import { SessionTimeoutComponent } from '@ren/features/errors/components/session-timeout/session-timeout.component';
import { TransactionFailedComponent } from '@ren/features/errors/components/transaction-failed/transaction-failed.component';
import { TransactionRefusedComponent } from '@ren/features/errors/components/transaction-refused/transaction-refused.component';
import { PaymentContactCentreComponent } from '@ren/features/errors/components/payment-contact-centre/payment-contact-centre.component';
import { RenewalDeclinedComponent } from '@ren/features/errors/components/renewal-declined/renewal-declined.component';

import {
  PAYMENT_CONTACT_CENTRE_URL,
  RENEWAL_DECLINED_URL,
  SESSION_TIMEOUT_URL,
  TRANSACTION_FAILED_URL,
  TRANSACTION_REFUSED_URL
} from '@ren/infrastructure/constants';


const routes: Routes = [
  {
    path: '',
    component: ErrorsContainerComponent,
    children: [
      {path: RENEWAL_DECLINED_URL, component: RenewalDeclinedComponent},
      {path: SESSION_TIMEOUT_URL, component: SessionTimeoutComponent},
      {path: TRANSACTION_FAILED_URL, component: TransactionFailedComponent},
      {path: TRANSACTION_REFUSED_URL, component: TransactionRefusedComponent},
      {path: `${PAYMENT_CONTACT_CENTRE_URL}/:errorCode`, component: PaymentContactCentreComponent}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ErrorsRoutingModule {
}
