import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LapsedRenewalContainerComponent } from '@ren/features/lapsed-renewal/containers/lapsed-renewal-container.component';


const routes: Routes = [
  {
    path: '',
    component: LapsedRenewalContainerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LapsedRenewalRoutingModule { }
