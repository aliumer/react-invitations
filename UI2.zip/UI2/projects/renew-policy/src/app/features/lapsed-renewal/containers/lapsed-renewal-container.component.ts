import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { select, Store } from '@ngrx/store';
import { concatMap, filter, map, take, takeWhile } from 'rxjs/operators';

import { FeatureBase } from '@ren/infrastructure/abstracts/feature.base';

import { FormService } from '@ren/core/services/form/form.service';
import { ScrollingService } from '@ren/core/services/scrolling/scrolling.service';

import { JourneyNavigationActions, MainActions, PolicyActions } from '@ren/main/state/actions';

import { selectJourneyNavigationButtonDetails } from '@ren/main/state/selectors/journey.selectors';
import { selectLatestPremium } from '@ren/main/state/selectors/policy.selectors';

import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';

@Component({
  selector: 'app-lapsed-renewal-container',
  templateUrl: './lapsed-renewal-container.component.html'
})
export class LapsedRenewalContainerComponent extends FeatureBase implements OnInit {

  isShowWarning: boolean;

  constructor(
    private fb: FormBuilder,
    private formService: FormService,
    private scrollingService: ScrollingService,
    protected router: Router,
    protected store: Store
  ) {
    super(router, store, JourneyFeaturesConfig.lapsedRenewal.name);
  }

  ngOnInit() {
    super.ngOnInit();
    this.createForm();
  }

  protected handleNavigation() {
    this.store.pipe(
      takeWhile(() => this.isComponentActive),
      select(selectJourneyNavigationButtonDetails),
      filter(({isBackButtonClicked, isNextButtonClicked}) => isBackButtonClicked || isNextButtonClicked),
      concatMap(({isBackButtonClicked, isNextButtonClicked}) => this.store.pipe(
        select(selectLatestPremium),
        map(premium => ({isBackButtonClicked, isNextButtonClicked, premium})),
        take(1)
      ))
    ).subscribe(({isBackButtonClicked, isNextButtonClicked, premium}) => {
      try {
        if (isNextButtonClicked) {
          if (this.containerForm?.valid) {
            const today = new Date();
            const payload = {
              jsonrpc: '2.0',
              method: 'saveAndQuoteRenewal',
              params: [{
                ...premium,
                baseData: {
                  ...premium.baseData,
                  periodStartDate: {year: today.getFullYear(), month: today.getMonth(), day: today.getDate()}
                },
                createVersion_dlg: true
              }]
            };
            this.store.dispatch(PolicyActions.lapsedRenewalRequote({payload}));
          } else {
            this.formService.updateControlValidity(this.containerForm);
            this.scrollingService.scrollToFirstError();
          }
        }

        if (isBackButtonClicked) {
          this.store.dispatch(MainActions.redirectToMyAccountDashboard());
        }
      } finally {
        this.store.dispatch(JourneyNavigationActions.resetButtons());
      }
    });
  }

  protected observeOnData() {
  }

  protected observeOnError() {
  }

  private createForm() {
    this.containerForm = this.fb.group({});
    this.containerForm.valueChanges.pipe(
      takeWhile(() => this.isComponentActive)
    ).subscribe(({confirmClaims: {isClaimedDuringLapsedPeriod: {key}}}) => {
      const isClaimedDuringLapsedPeriod = key === 'yes';
      this.isShowWarning = isClaimedDuringLapsedPeriod;
      this.store.dispatch(JourneyNavigationActions.changeButtonStatus({id: 'continue', status: isClaimedDuringLapsedPeriod}));
    });
  }

}
