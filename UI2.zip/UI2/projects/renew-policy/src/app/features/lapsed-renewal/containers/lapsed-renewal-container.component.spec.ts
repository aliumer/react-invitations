import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LapsedRenewalContainerComponent } from './lapsed-renewal-container.component';

describe('LapsedRenewalContainerComponent', () => {
  let component: LapsedRenewalContainerComponent;
  let fixture: ComponentFixture<LapsedRenewalContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LapsedRenewalContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LapsedRenewalContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
