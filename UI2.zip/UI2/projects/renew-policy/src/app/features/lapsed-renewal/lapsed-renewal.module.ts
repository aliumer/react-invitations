import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { SubmissionModule } from '@ren/shared/submission/submission.module';
import { LapsedRenewalRoutingModule } from './lapsed-renewal-routing.module';

import { LapsedRenewalContainerComponent } from './containers/lapsed-renewal-container.component';

import { LapsedRenewalEffects } from '@ren/features/lapsed-renewal/state/effects/lapsed-renewal.effects';
import { ConfirmClaimsComponent } from './components/confirm-claims/confirm-claims.component';



@NgModule({
  declarations: [LapsedRenewalContainerComponent, ConfirmClaimsComponent],
  imports: [
    CoreUiModule,
    SubmissionModule,
    LapsedRenewalRoutingModule,
    EffectsModule.forFeature([LapsedRenewalEffects])
  ]
})
export class LapsedRenewalModule { }
