import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { concatMap, filter, map, take, takeWhile, tap } from 'rxjs/operators';

import { FeatureBase } from '@ren/infrastructure/abstracts/feature.base';

import { FormService } from '@ren/core/services/form/form.service';
import { ScrollingService } from '@ren/core/services/scrolling/scrolling.service';

import { JourneyNavigationActions, RenewActions } from '@ren/main/state/actions';
import { DashboardActions } from '@ren/features/dashboard/state/actions';

import { selectPolicyChangeSelectionLockedStatus, selectQuotedStatus } from '@ren/main/state/selectors/renewal.selectors';
import { selectJourneyNavigationButtonDetails } from '@ren/main/state/selectors/journey.selectors';
import {
  selectDashboardPolicyDetails, selectPolicyChangeOptions
} from '@ren/features/dashboard/state/selectors/dashboard.selectors';

import { KeyValueDict } from '@ren/infrastructure/interfaces/key-value-dict';
import { PolicyDetails } from '@ren/features/dashboard/interfaces/policy-details';
import { JourneyPath } from '@ren/main/interfaces/journey-path-state';
import { PolicyChangeSelectionLockStatus } from '@ren/features/dashboard/interfaces/policy-change-selection-lock-status';

import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';


@Component({
  selector: 'app-dashboard-container',
  templateUrl: './dashboard-container.component.html'
})
export class DashboardContainerComponent extends FeatureBase implements OnInit {

  policyDetails$: Observable<PolicyDetails>;
  alterOptions$: Observable<KeyValueDict<boolean>>;
  policyChangeSelectionLockedStatus$: Observable<PolicyChangeSelectionLockStatus>;


  containerForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private formService: FormService,
    private scrollingService: ScrollingService,
    protected router: Router,
    protected store: Store
  ) {
    super(router, store, JourneyFeaturesConfig.dashboard.name);
    this.store.dispatch(DashboardActions.loadDashboard());
  }

  onPolicyChange(alterOptions: KeyValueDict<boolean>) {
    this.store.dispatch(DashboardActions.changePolicyOptions({alterOptions}));
    this.store.dispatch(RenewActions.updatePolicyChangeOptions({options: alterOptions}));
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.createForm();
  }

  protected handleNavigation() {
    this.store.pipe(
      takeWhile(() => this.isComponentActive),
      select(selectJourneyNavigationButtonDetails),
      filter(({isBackButtonClicked, isNextButtonClicked}) => isBackButtonClicked || isNextButtonClicked),
      concatMap(({isBackButtonClicked, isNextButtonClicked, navCommands}) => this.store.pipe(
        select(selectQuotedStatus),
        map(isQuoted => ({isBackButtonClicked, isNextButtonClicked, navCommands, isQuoted})),
        take(1)
      ))
    ).subscribe(({isBackButtonClicked, isNextButtonClicked, navCommands, isQuoted}) => {
      try {
        if (isNextButtonClicked) {
          if (this.containerForm.valid || (this.containerForm.errors === null && this.containerForm.status.toLowerCase() === 'disabled')) {
            this.onNext(navCommands.next);
          } else {
            this.formService.updateControlValidity(this.containerForm);
            this.scrollingService.scrollToFirstError();
            this.store.dispatch(JourneyNavigationActions.resetButtons());
            return;
          }
        }

        if (isBackButtonClicked) {
          if (!isQuoted) {
            this.store.dispatch(RenewActions.resetPolicySelections());
            this.store.dispatch(DashboardActions.resetPolicySelections());
          }
          this.onBack(navCommands.prev);
        }
      } catch {
        this.store.dispatch(JourneyNavigationActions.resetButtons());
      }
    });
  }

  protected observeOnData() {
    this.policyDetails$ = this.store.pipe(select(selectDashboardPolicyDetails));
    this.policyChangeSelectionLockedStatus$ = this.store.pipe(select(selectPolicyChangeSelectionLockedStatus), take(1));
    this.alterOptions$ = this.store.pipe(
      select(selectPolicyChangeOptions),
      tap(alterOptions => this.createJourneyPath(alterOptions))
    );
  }

  protected observeOnError() {
  }

  private createForm() {
    this.containerForm = this.fb.group({});
  }

  private createJourneyPath(alterOptions: KeyValueDict<boolean>) {
    const list = [JourneyFeaturesConfig.reviewInitial.name, JourneyFeaturesConfig.dashboard.name];
    const {yourCar, yourAddress, yourCorrespondenceAddress, yourDrivers} = alterOptions;
    if (yourCar) {
      list.push(JourneyFeaturesConfig.yourCar.name);
    }
    if (yourAddress) {
      list.push(JourneyFeaturesConfig.yourAddress.name);
    }
    if (yourCorrespondenceAddress) {
      list.push(JourneyFeaturesConfig.yourCorrespondenceAddress.name);
    }
    if (yourDrivers) {
      list.push(JourneyFeaturesConfig.yourDriversList.name);
    }
    list.push(JourneyFeaturesConfig.premium.name);
    list.push(JourneyFeaturesConfig.reviewEdit.name);

    this.store.dispatch(JourneyNavigationActions.buildJourneyPath({journeyPath: {path: list} as JourneyPath}));
  }
}
