export interface PolicyDetails {
  yourCar: string;
  yourDrivers: string[];
  yourAddress: string;
  yourCorrespondenceAddress: string;
  policyRenewDate: string;
}
