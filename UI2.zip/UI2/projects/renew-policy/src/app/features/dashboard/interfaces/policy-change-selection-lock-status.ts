export interface PolicyChangeSelectionLockStatus {
  yourCar: boolean;
  yourDrivers: boolean;
  yourAddress: boolean;
  yourCorrespondenceAddress: boolean;
}
