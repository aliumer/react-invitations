import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { DashboardRoutingModule } from '@ren/features/dashboard/dashboard-routing.module';

import { DashboardContainerComponent } from '@ren/features/dashboard/containers/dashboard-container.component';
import { PolicyChangeSelectionsComponent } from './components/policy-change-selections/policy-change-selections.component';
import { DashboardMessagePanelComponent } from './components/dashboard-message-panel/dashboard-message-panel.component';

import { reducers as DashboardReducers } from '@ren/features/dashboard/state/reducers';

import { DashboardEffects } from '@ren/features/dashboard/state/effects/dashboard.effects';

import { DASHBOARD_STORE_KEY } from '@ren/infrastructure/constants/store_keys.constant';



@NgModule({
  declarations: [DashboardContainerComponent, PolicyChangeSelectionsComponent, DashboardMessagePanelComponent],
  imports: [
    CoreUiModule,
    DashboardRoutingModule,
    StoreModule.forFeature(DASHBOARD_STORE_KEY, DashboardReducers),
    EffectsModule.forFeature([DashboardEffects])
  ]
})
export class DashboardModule { }
