import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { YourAddressContainerComponent } from './containers/your-address-container.component';


const routes: Routes = [
  {
    path: '',
    component: YourAddressContainerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YourAddressRoutingModule { }
