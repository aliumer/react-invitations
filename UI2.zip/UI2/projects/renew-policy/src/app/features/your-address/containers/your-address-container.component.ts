import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { concatMap, filter, map, take, takeWhile, tap } from 'rxjs/operators';

import { FeatureBase } from '@ren/infrastructure/abstracts/feature.base';

import { FormService } from '@ren/core/services/form/form.service';
import { ScrollingService } from '@ren/core/services/scrolling/scrolling.service';

import { JourneyNavigationActions, PolicyActions } from '@ren/main/state/actions';
import { YourAddressActions } from '@ren/features/your-address/state/actions';


import { selectJourneyNavigationButtonDetailsWithExtra } from '@ren/main/state/selectors/journey.selectors';
import { selectInitialPolicyDetails, selectInlineError } from '@ren/main/state/selectors/policy.selectors';
import {
  selectUpdatedAddress,
  selectUpdatedAddressDetails,
  selectUpdatedOvernightParking
} from '@ren/features/your-address/state/selectors/your-address.selectors';

import { CustomHelpers } from '@ren/infrastructure/helpers/custom.helpers';

import { KeyValueDict } from '@ren/infrastructure/interfaces/key-value-dict';
import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';

@Component({
  selector: 'app-your-address-container',
  templateUrl: './your-address-container.component.html'
})
export class YourAddressContainerComponent extends FeatureBase implements OnInit {

  currentAddressDisplay$: Observable<string>;
  addressDetails$: Observable<any>;
  overnightParkingDetails$: Observable<any>;
  isShowInlineError$: Observable<boolean>;

  constructor(
    protected router: Router,
    protected store: Store,
    private fb: FormBuilder,
    private formService: FormService,
    private scrollingService: ScrollingService
  ) {
    super(router, store, JourneyFeaturesConfig.yourAddress.name);
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.createForm();
  }

  protected handleNavigation() {
    this.store.pipe(
      select(selectJourneyNavigationButtonDetailsWithExtra),
      filter(({isBackButtonClicked, isNextButtonClicked, isCancelButtonClicked}) => isBackButtonClicked || isNextButtonClicked || isCancelButtonClicked),
      concatMap(({isBackButtonClicked, isNextButtonClicked, isCancelButtonClicked, navCommands}) => this.store.pipe(
        select(selectUpdatedAddressDetails),
        map(updatedAddressDetails => ({isBackButtonClicked, isNextButtonClicked, isCancelButtonClicked, navCommands, updatedAddressDetails})),
        take(1)
      )),
      takeWhile(() => this.isComponentActive)
    ).subscribe(({isBackButtonClicked, isNextButtonClicked, isCancelButtonClicked, navCommands, updatedAddressDetails}) => {
      try {
        this.store.dispatch(PolicyActions.resetErrors());
        if (isNextButtonClicked) {
          if(this.containerForm.valid && this.updateAddressDetailsOfRequestPayload(updatedAddressDetails)) {
            this.onNext(navCommands.next);
          } else {
            this.formService.updateControlValidity(this.containerForm);
            this.scrollingService.scrollToFirstError();
            this.store.dispatch(JourneyNavigationActions.resetButtons());
            return;
          }
        }

        if (isBackButtonClicked) {
          this.onBack(navCommands.prev);
        }

        if (isCancelButtonClicked) {
          this.onCancel();
        }
      } catch {
        this.store.dispatch(JourneyNavigationActions.resetButtons());
      }
    });
  }

  protected observeOnData() {
    this.currentAddressDisplay$ = this.store.pipe(
      select(selectInitialPolicyDetails),
      map(data => data.baseData.policyAddress.displayName)
    );

    this.addressDetails$ = this.store.pipe(select(selectUpdatedAddress));
    this.overnightParkingDetails$ = this.store.pipe(select(selectUpdatedOvernightParking));
  }

  protected observeOnError() {
    this.isShowInlineError$ = this.store.pipe(
      select(selectInlineError),
      filter(val => val),
      tap(() => setTimeout(() => this.scrollingService.scrollToFirstPanelError()))
    );
  }

  private createForm() {
    this.containerForm = this.fb.group({});

    this.containerForm.valueChanges.pipe(
      takeWhile(() => this.isComponentActive),
      filter(() => this.containerForm.valid && this.containerForm.controls.address?.value && this.containerForm.controls.overnightParking?.value)
    ).subscribe((updatedAddressDetails) => {
      this.store.dispatch(YourAddressActions.updateAddressDetails({updatedAddressDetails}));
    });
  }

  private updateAddressDetailsOfRequestPayload(updatedAddressDetails: {address: KeyValueDict<any>, overnightParking: KeyValueDict<any>}): boolean {
    if (CustomHelpers.isEmptyObject(updatedAddressDetails)) {
      return false;
    }

    const {
      address: {addressDetails: {value: addressDetails}},
    } = updatedAddressDetails;

    const {
      address,
      overnightParking: {
        vehicleOvernightLocation: {key: vehicleOvernightLocation},
        vehicleOvernightPostcode,
        vehicleOvernightWhere,
      }
    } = updatedAddressDetails;

    const newAddressData: KeyValueDict<any> = {
      addressDetails: {
        addressLine1: address.addressLine1 !== '' ? address.addressLine1 : addressDetails.addressLine1,
        addressLine2: address.addressLine2 !== '' ? address.addressLine2 : addressDetails.addressLine2,
        addressLine3: address.addressLine3 !== '' ? address.addressLine3 : addressDetails.addressLine3,
        county_dlg: addressDetails.county,
        postalCode: addressDetails.postCode,
        city: addressDetails.town,
        displayName: addressDetails.displayName,
        uPRN_dlg: addressDetails.uPRN_dlg,
        xcordinate_dlg: addressDetails.xcordinate_dlg,
        ycordinate_dlg: addressDetails.ycordinate_dlg,
        latitude_dlg: addressDetails.latitude_dlg,
        longitude_dlg: addressDetails.longitude_dlg,
        uDPRN_dlg: addressDetails.uDPRN_dlg,
        country: 'GB'
      },
      overNightDetails: {
        isVehicleGarageAtHome: vehicleOvernightLocation !== 'no',
        garageNightPostcode: vehicleOvernightPostcode || addressDetails.postCode
      }
    };

    if (vehicleOvernightWhere) {
      newAddressData.overNightDetails.garageNightLocation = vehicleOvernightWhere.key;
    }

    this.store.dispatch(PolicyActions.updatePayloadChanges({data: {yourAddress: newAddressData}}));
    return true;
  }

}
