import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { AddressModule } from '@ren/shared/address/address.module';
import { ErrorModule } from '@ren/shared/error/error.module';
import { YourAddressRoutingModule } from './your-address-routing.module';

import { YourAddressContainerComponent } from './containers/your-address-container.component';

import * as fromYourAddress from './state/reducers';

import { YOUR_ADDRESS_STORE_KEY } from '@ren/infrastructure/constants';



@NgModule({
  declarations: [YourAddressContainerComponent],
  imports: [
    CoreUiModule,
    AddressModule,
    ErrorModule,
    YourAddressRoutingModule,
    StoreModule.forFeature(YOUR_ADDRESS_STORE_KEY, fromYourAddress.reducers)
  ]
})
export class YourAddressModule {
}
