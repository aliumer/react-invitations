export interface IssuanceStatusCheckPayload{
  quoteID: string;
  quoteRef_dlg: string;
  accountNumber: string;
  policyNumber: string;
  syncSuccess: boolean;
}
