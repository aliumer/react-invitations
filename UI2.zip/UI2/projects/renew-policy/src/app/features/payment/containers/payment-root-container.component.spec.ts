import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentRootContainerComponent } from './payment-root-container.component';

describe('PaymentRootContainerComponent', () => {
  let component: PaymentRootContainerComponent;
  let fixture: ComponentFixture<PaymentRootContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentRootContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentRootContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
