import { FormControl } from '@angular/forms';

export class CreditCardValidators {
  static equalTo(valueToMatch) {
    return (control: FormControl) => {
      if (control.value.key === valueToMatch) {
        return {matchValue: true};
      }
      return null;
    };
  }
}
