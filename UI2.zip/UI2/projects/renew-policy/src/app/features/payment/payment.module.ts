import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { AddressModule } from '@ren/shared/address/address.module';
import { DirectivesModule } from '@ren/shared/directives/directives.module';
import { ErrorModule } from '@ren/shared/error/error.module';
import { MonthlyBreakdownModule } from '@ren/shared/monthly-breakdown/monthly-breakdown.module';
import { SubmissionModule } from '@ren/shared/submission/submission.module';
import { PaymentRoutingModule } from '@ren/features/payment/payment-routing.module';
import { PaymentServicesModule } from '@ren/features/payment/services/payment-services.module';
import { PipesModule } from '@ren/shared/pipes/pipes.module';

import { PaymentRootContainerComponent } from '@ren/features/payment/containers/payment-root-container.component';
import { DirectDebitHoldingContainerComponent } from '@ren/features/payment/containers/direct-debit/direct-debit-holding-container.component';
import { CreditCardHoldingContainerComponent } from '@ren/features/payment/containers/credit-card/credit-card-holding-container.component';
import { NewDirectDebitContainerComponent } from '@ren/features/payment/containers/direct-debit/new-direct-debit-container/new-direct-debit-container.component';
import { NewCreditCardContainerComponent } from '@ren/features/payment/containers/credit-card/new-credit-card-container/new-credit-card-container.component';
import { PaymentListContainerComponent } from './containers/list/payment-list-container.component';
import { ReviewDirectDebitContainerComponent } from '@ren/features/payment/containers/direct-debit/review-direct-debit-container/review-direct-debit-container.component';
import { EditDirectDebitContainerComponent } from '@ren/features/payment/containers/direct-debit/edit-direct-debit-container/edit-direct-debit-container.component';
import { EditCreditCardContainerComponent } from './containers/credit-card/edit-credit-card-container/edit-credit-card-container.component';

import { MonthlyYearlyToggleComponent } from '@ren/features/payment/components/shared/monthly-yearly-toggle/monthly-yearly-toggle.component';
import { DirectDebitInfoComponent } from '@ren/features/payment/components/direct-debit/direct-debit-info/direct-debit-info.component';
import { DirectDebitGuaranteeComponent } from '@ren/features/payment/components/direct-debit/direct-debit-guarantee/direct-debit-guarantee.component';
import { NewDirectDebitComponent } from '@ren/features/payment/components/direct-debit/new-direct-debit/new-direct-debit.component';
import { AutoRenewalsComponent } from '@ren/features/payment/components/shared/auto-renewals/auto-renewals.component';
import { SecciAcceptanceComponent } from '@ren/features/payment/components/direct-debit/secci-acceptance/secci-acceptance.component';
import { AccountHolderComponent } from '@ren/features/payment/components/direct-debit/account-holder/account-holder.component';
import { DirectDebitServiceInfoComponent } from '@ren/features/payment/components/direct-debit/direct-debit-service-info/direct-debit-service-info.component';
import { AccountSignatureComponent } from '@ren/features/payment/components/direct-debit/account-signature/account-signature.component';
import { PaymentDescriptionComponent } from '@ren/features/payment/components/shared/payment-description/payment-description.component';
import { DirectDebitListTableComponent } from '@ren/features/payment/components/direct-debit/direct-debit-list-table/direct-debit-list-table.component';
import { CreditCardListTableComponent } from '@ren/features/payment/components/credit-card/credit-card-list-table/credit-card-list-table.component';
import { DirectDebitReviewTableComponent } from '@ren/features/payment/components/direct-debit/direct-debit-review-table/direct-debit-review-table.component';
import { PaymentAnnualSummaryComponent } from '@ren/features/payment/components/credit-card/payment-annual-summary/payment-annual-summary.component';
import { NewCreditCardComponent } from '@ren/features/payment/components/credit-card/new-credit-card/new-credit-card.component';
import { CardholderComponent } from '@ren/features/payment/components/credit-card/cardholder/cardholder.component';
import { CardholderThirdPartyComponent } from '@ren/features/payment/components/credit-card/cardholder-third-party/cardholder-third-party.component';
import { PaymentBillingAddressComponent } from '@ren/features/payment/components/shared/payment-billing-address/payment-billing-address.component';
import { CardTypeComponent } from '@ren/features/payment/components/credit-card/card-type/card-type.component';
import { EditCreditCardComponent } from '@ren/features/payment/components/credit-card/edit-credit-card/edit-credit-card.component';
import { CardholderSummaryComponent } from '@ren/features/payment/components/credit-card/cardholder-summary/cardholder-summary.component';
import { WordPayWrapperComponent } from '@ren/features/payment/components/credit-card/word-pay-wrapper/word-pay-wrapper.component';
import { AccountDetailsComponent } from './components/shared/account-details/account-details.component';
import { PaymentMonthlySummaryComponent } from './components/direct-debit/payment-monthly-summary/payment-monthly-summary.component';
import { SecciModalComponent } from '@ren/features/payment/modals/secci-modal/secci-modal.component';

import * as fromPayment from '@ren/features/payment/state/reducers';

import { PaymentEffects } from '@ren/features/payment/state/effects/payment.effects';

import { PAYMENT_STORE_KEY } from '@ren/infrastructure/constants';
import { PaymentFailedErrorComponent } from './components/credit-card/payment-failed-error/payment-failed-error.component';
import { AccountHolderAndSignatureToggleComponent } from './components/direct-debit/account-holder-and-signature-toggle/account-holder-and-signature-toggle.component';
import { NewBankAccountDetailsComponent } from './components/direct-debit/new-bank-account-details/new-bank-account-details.component';




@NgModule({
  declarations: [
    PaymentRootContainerComponent,
    DirectDebitHoldingContainerComponent,
    CreditCardHoldingContainerComponent,
    NewDirectDebitContainerComponent,
    NewCreditCardContainerComponent,
    ReviewDirectDebitContainerComponent,
    MonthlyYearlyToggleComponent,
    PaymentDescriptionComponent,
    DirectDebitListTableComponent,
    CreditCardListTableComponent,
    DirectDebitInfoComponent,
    DirectDebitGuaranteeComponent,
    NewDirectDebitComponent,
    AutoRenewalsComponent,
    SecciAcceptanceComponent,
    AccountHolderComponent,
    DirectDebitServiceInfoComponent,
    AccountSignatureComponent,
    EditDirectDebitContainerComponent,
    DirectDebitReviewTableComponent,
    PaymentAnnualSummaryComponent,
    NewCreditCardComponent,
    CardholderComponent,
    CardholderThirdPartyComponent,
    PaymentBillingAddressComponent,
    CardTypeComponent,
    AccountDetailsComponent,
    PaymentMonthlySummaryComponent,
    EditCreditCardComponent,
    CardholderSummaryComponent,
    EditCreditCardContainerComponent,
    WordPayWrapperComponent,
    SecciModalComponent,
    PaymentListContainerComponent,
    PaymentFailedErrorComponent,
    AccountHolderAndSignatureToggleComponent,
    NewBankAccountDetailsComponent
  ],
  imports: [
    CoreUiModule,
    AddressModule,
    ErrorModule,
    MonthlyBreakdownModule,
    DirectivesModule,
    SubmissionModule,
    PaymentRoutingModule,
    PaymentServicesModule,
    StoreModule.forFeature(PAYMENT_STORE_KEY, fromPayment.reducers),
    EffectsModule.forFeature([PaymentEffects]),
    MonthlyBreakdownModule,
    PipesModule
  ]
})
export class PaymentModule { }
