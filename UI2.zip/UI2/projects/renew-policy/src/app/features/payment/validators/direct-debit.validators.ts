import { FormControl } from '@angular/forms';

export class DirectDebitValidators {
  static sortCode(control: FormControl): any {
    let errorFlag = false;
    const sortCodeRegExp = /^[0-9]{2}$/;

    control.value.some((value) => {
      const sortCodeField = sortCodeRegExp.test(value);
      if (!sortCodeField) {
        errorFlag = true;
      }

      return errorFlag;
    });

    if (errorFlag) {
      return {invalidSortCode: errorFlag};
    }
  }

  static sortCodeRequired(control: FormControl): any {
    if (control && control.value) {
      if (control.value.every((input) => input === '')) {
        return {sortCodeRequired: true};
      }
    }

    return null;
  }

  static validAccept(control: FormControl) {
    if (!control.value) {
      return {validAccept: false};
    }
    return null;
  }
}
