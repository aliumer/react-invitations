import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PaymentResolverService } from '@ren/features/payment/services/payment-resolver/payment-resolver.service';
import { DirectDebitReviewResolverService } from '@ren/features/payment/services/direct-debit-review-resolver/direct-debit-review-resolver.service';

import { PaymentRootContainerComponent } from '@ren/features/payment/containers/payment-root-container.component';
import { DirectDebitHoldingContainerComponent } from '@ren/features/payment/containers/direct-debit/direct-debit-holding-container.component';
import { CreditCardHoldingContainerComponent } from '@ren/features/payment/containers/credit-card/credit-card-holding-container.component';
import { NewDirectDebitContainerComponent } from '@ren/features/payment/containers/direct-debit/new-direct-debit-container/new-direct-debit-container.component';
import { ReviewDirectDebitContainerComponent } from '@ren/features/payment/containers/direct-debit/review-direct-debit-container/review-direct-debit-container.component';
import { NewCreditCardContainerComponent } from '@ren/features/payment/containers/credit-card/new-credit-card-container/new-credit-card-container.component';
import { EditDirectDebitContainerComponent } from '@ren/features/payment/containers/direct-debit/edit-direct-debit-container/edit-direct-debit-container.component';
import { EditCreditCardContainerComponent } from '@ren/features/payment/containers/credit-card/edit-credit-card-container/edit-credit-card-container.component';
import { PaymentListContainerComponent } from '@ren/features/payment/containers/list/payment-list-container.component';


const routes: Routes = [
  {
    path: '',
    component: PaymentRootContainerComponent,
    resolve: {
      _: PaymentResolverService
    },
    children: [
      {
        path: 'list',
        component: PaymentListContainerComponent
      },
      {
        path: 'direct-debit',
        component: DirectDebitHoldingContainerComponent,
        children: [
          {
            path: 'new',
            component: NewDirectDebitContainerComponent
          },
          {
            path: 'edit',
            component: EditDirectDebitContainerComponent
          },
          {
            path: 'review',
            component: ReviewDirectDebitContainerComponent,
            resolve: {
              _: DirectDebitReviewResolverService
            }
          }
        ]
      },
      {
        path: 'credit-card',
        component: CreditCardHoldingContainerComponent,
        children: [
          {
            path: 'new',
            component: NewCreditCardContainerComponent
          },
          {
            path: 'edit',
            component: EditCreditCardContainerComponent
          }
        ]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PaymentRoutingModule { }
