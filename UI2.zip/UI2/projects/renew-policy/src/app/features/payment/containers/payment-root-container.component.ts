import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-root-container',
  template: `
    <router-outlet></router-outlet>`
})
export class PaymentRootContainerComponent {
}
