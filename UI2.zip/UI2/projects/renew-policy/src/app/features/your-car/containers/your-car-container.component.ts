import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { concatMap, filter, map, take, takeWhile, tap } from 'rxjs/operators';

import { FeatureBase } from '@ren/infrastructure/abstracts/feature.base';

import { FormService } from '@ren/core/services/form/form.service';
import { ScrollingService } from '@ren/core/services/scrolling/scrolling.service';

import { YourCarActions } from '@ren/features/your-car/state/actions';
import { JourneyNavigationActions, PolicyActions } from '@ren/main/state/actions';

import { selectJourneyNavigationButtonDetailsWithExtra } from '@ren/main/state/selectors/journey.selectors';
import { selectExistingPermanentVehicleDetails, selectInlineError } from '@ren/main/state/selectors/policy.selectors';
import {
  selectUpdatedCarDetails,
  selectYourCarState,
  selectYourVehicleDetails
} from '@ren/features/your-car/state/selectors/your-car.selectors';

import { CustomHelpers } from '@ren/infrastructure/helpers/custom.helpers';
import { GwHelpers } from '@ren/infrastructure/helpers/gw.helpers';

import { Vehicle } from '@ren/features/your-car/interfaces/vehicle';

import { RegisteredKeeper } from '@ren/infrastructure/data/your-car.data';
import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';


@Component({
  selector: 'app-your-car-container',
  templateUrl: './your-car-container.component.html'
})
export class YourCarContainerComponent extends FeatureBase implements OnInit {

  currentVehicleDisplay$: Observable<Vehicle>;
  newVehicleDisplay$: Observable<Vehicle>;
  updatedCarDetails$: Observable<any>;
  policyChangeDate$: Observable<Date>;
  isShowInlineError$: Observable<boolean>;
  carManufacturerYear: string;

  isNoCarNumberPlate = false;
  isCarFound = false;
  isUpdatedCarDetailsAvailable = false;
  isShowCarValueField = true;
  isFormValid = true;
  newVehicle = null;
  registeredKeeperOptions = RegisteredKeeper;

  private currentVehicleVrn: string;

  constructor(
    protected router: Router,
    protected store: Store,
    private fb: FormBuilder,
    private formService: FormService,
    private scrollingService: ScrollingService
  ) {
    super(router, store, JourneyFeaturesConfig.yourCar.name);
  }

  onResetCar() {
    this.isNoCarNumberPlate = false;
    this.isCarFound = this.isUpdatedCarDetailsAvailable = false;
    this.createForm();
    this.store.dispatch(YourCarActions.resetCar());
    this.newVehicle = null;
    this.changeNextButtonStatus(true);
  }

  onCarFound(newVehicle: any) {
    this.store.dispatch(YourCarActions.carLookupSuccess({newVehicle}));
    this.isNoCarNumberPlate = false;
    this.newVehicle = newVehicle;
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.createForm();
    this.observeOnData();
  }

  protected handleNavigation() {
    this.store.pipe(
      select(selectJourneyNavigationButtonDetailsWithExtra),
      filter(({
                isBackButtonClicked,
                isNextButtonClicked,
                isCancelButtonClicked
              }) => isBackButtonClicked || isNextButtonClicked || isCancelButtonClicked),
      concatMap(({isBackButtonClicked, isNextButtonClicked, isCancelButtonClicked, navCommands}) => this.store.pipe(
        select(selectYourCarState),
        map(({newVehicle, updatedCarDetails}) => ({
          isBackButtonClicked,
          isNextButtonClicked,
          isCancelButtonClicked,
          navCommands,
          newVehicle,
          updatedCarDetails
        })),
        take(1)
      )),
      takeWhile(() => this.isComponentActive)
    ).subscribe(({isBackButtonClicked, isNextButtonClicked, isCancelButtonClicked, navCommands, newVehicle, updatedCarDetails}) => {
      try {
        this.store.dispatch(PolicyActions.resetErrors());
        if (isNextButtonClicked) {
          if (this.containerForm.valid && this.updateVehicleDetailsOfRequestPayload({newVehicle, updatedCarDetails})) {
            this.onNext(navCommands.next);
          } else {
            this.formService.updateControlValidity(this.containerForm);
            this.isFormValid = false;
            this.scrollingService.scrollToFirstError();
            this.store.dispatch(JourneyNavigationActions.resetButtons());
            return;
          }
        }

        if (isBackButtonClicked) {
          this.onBack(navCommands.prev);
        }

        if (isCancelButtonClicked) {
          this.onCancel();
        }
      } catch {
        this.store.dispatch(JourneyNavigationActions.resetButtons());
      }
    });
  }

  protected observeOnData() {
    this.currentVehicleDisplay$ = this.store.pipe(
      select(selectExistingPermanentVehicleDetails),
      tap(({registrationNumber}) => this.currentVehicleVrn = registrationNumber),
      takeWhile(() => this.isComponentActive),
    );

    this.newVehicleDisplay$ = this.store.pipe(
      select(selectYourVehicleDetails),
      tap(data => {
        this.isCarFound = !!data;
        if (this.isCarFound) {
          this.isShowCarValueField = !data.estimatedValue || data.estimatedValue <= 0;
          this.carManufacturerYear = data.year;
          this.isNoCarNumberPlate = !data.registrationNumber || data.registrationNumber === 'TBC';
        }

        setTimeout(() => this.changeNextButtonStatus(!this.isCarFound));
      }),
      takeWhile(() => this.isComponentActive),
    );

    this.updatedCarDetails$ = this.store.pipe(
      select(selectUpdatedCarDetails),
      tap(data => this.isUpdatedCarDetailsAvailable = !(data === undefined || data === null || Object.keys(data).length === 0)),
      takeWhile(() => this.isComponentActive),
    );

  }

  protected observeOnError() {
    this.isShowInlineError$ = this.store.pipe(
      select(selectInlineError),
      filter(val => val),
      tap(() => setTimeout(() => this.scrollingService.scrollToFirstPanelError()))
    );
  }

  private updateVehicleDetailsOfRequestPayload({newVehicle, updatedCarDetails}): boolean {
    if (CustomHelpers.isEmptyObject(newVehicle) || CustomHelpers.isEmptyObject(updatedCarDetails)) {
      return false;
    }

    const {
      mileage: annualMileage,
      registeredKeeper: {key: registeredOwner},
      vehiclePurchasedDate,
      vehicleModified,
      vehicleModifications: modifications
    } = updatedCarDetails;

    const vehicle = {
      ...newVehicle,
      costNew: {...newVehicle.costNew, amount: +(newVehicle.costNew.amount ? newVehicle.costNew.amount : updatedCarDetails.carValue)},
      annualMileage: +annualMileage,
      registeredOwner,
      isVehiclePurchased: true,
      isVehicleModified: vehicleModified === 'Yes',
      modifications,
      purchaseDate: GwHelpers.convertToGwDateObject(vehiclePurchasedDate),
      isVRNChanged: newVehicle.registrationNumber ? !this.isSameVehicle(newVehicle.registrationNumber) : true
    };

    this.store.dispatch(PolicyActions.updatePayloadChanges({data: {yourCar: CustomHelpers.removeNullEntries(vehicle)}}));
    return true;
  }

  private createForm() {
    this.containerForm = this.fb.group({});
    this.containerForm.valueChanges.pipe(
      takeWhile(() => this.isComponentActive),
      filter(() => this.containerForm.valid)
    ).subscribe(({updatedCarDetails}) => {
      this.store.dispatch(YourCarActions.updateCarDetails({updatedCarDetails}));
      this.isFormValid = true;
    });
  }

  private changeNextButtonStatus(isDisabled: boolean) {
    this.store.dispatch(JourneyNavigationActions.changeButtonStatus({id: 'continue', status: isDisabled}));
  }

  private isSameVehicle(registrationNumber: string): boolean {
    return this.currentVehicleVrn?.toLowerCase() === registrationNumber?.toLowerCase();
  }

}
