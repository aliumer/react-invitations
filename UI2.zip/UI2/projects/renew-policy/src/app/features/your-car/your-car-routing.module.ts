import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { YourCarContainerComponent } from '@ren/features/your-car/containers/your-car-container.component';


const routes: Routes = [
  {
    path: '',
    component: YourCarContainerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YourCarRoutingModule { }
