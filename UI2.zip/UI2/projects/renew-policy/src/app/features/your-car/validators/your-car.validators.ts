import { FormArray, FormControl } from '@angular/forms';

import { DateTimeHelpers } from '@ren/infrastructure/helpers/date-time.helpers';


export class YourCarValidators {

  static minDateFull(dateArray: string[] | number[]) {
    return (control: FormArray) => {
      if (dateArray && !YourCarValidators.validDate(control)) {
        if (control.value.length === 3) {
          const enteredDateArr = [DateTimeHelpers.lastDayOfMonth(control.value), ...control.value.slice(1)];
          const enteredDate: any = new Date(enteredDateArr.reverse().join('/'));
          const minDate: any = new Date(dateArray.slice().reverse().join('/'));

          if (enteredDate.getTime() < minDate.getTime()) {
            return {minMonthYear: true};
          }
        }
      }

      return null;
    };
  }

  static alphaNumericSpace(control: FormControl) {
    const invalidAlphaNumericRegExp = /^[a-zA-Z0-9 ]*$/;
    const invalidAlphaNumericResult = invalidAlphaNumericRegExp.test(control.value);

    if (!invalidAlphaNumericResult) {
      return {invalidAlphaNumericSpace: true};
    }

    return null;
  }

  static requireCarModificationsSelected(control: FormControl) {
    const val = control.value || [];
    return val.length > 0 ? null : {noModificationSelected: true};
  }

  private static validDate(controlArray: FormArray) {

    const tempValue: string[] = [];

    if (controlArray && controlArray.value.length) {

      controlArray.value.forEach((value) => {
        value = (value === '' || value === null) ? '1' : value;
        tempValue.push(value);
      });

      const valueString: string = tempValue.join('/');

      // tslint:disable:max-line-length
      const dateRegExp = /(^(((0?[1-9]|1[0-9]|2[0-8])[\/](0?[1-9]|1[012]))|((29|30|31)[\/](0?[13578]|1[02]))|((29|30)[\/](0?[4,6,9]|11)))[\/](19|18|[2-9][0-9])\d\d$)|(^29[\/]0?2[\/](19|[2-9][0-9])(00|04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)$)/;
      // tslint:enable:max-line-length

      if (!dateRegExp.test(valueString)) {
        return {invalidDate: true};
      }
    }

    return null;
  }
}
