import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YourCarContainerComponent } from './your-car-container.component';

describe('YourCarContainerComponent', () => {
  let component: YourCarContainerComponent;
  let fixture: ComponentFixture<YourCarContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YourCarContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YourCarContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
