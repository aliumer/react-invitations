export interface Vehicle {
  bodyType?: string;
  engineSize?: string;
  maxPower?: number;
  fuelType?: string;
  year?: string;
  registrationNumber: string;
  transmission?: string;
  color?: string;
  controlType?: string;
  estimatedValue?: number;
  intCode?: string;
  mark?: string;
  noOfDoors?: number;
  vin?: string;
  carWebId?: string;
  make?: string;
  model?: string;
  costNew?: {
    currency: string;
    amount: number
  };
  changeType?: string;
}

export interface VehicleFromAPI {
  Abi1?: string;
  BodyStyleDescription: string;
  CarwebID?: string;
  Combined_EngineCapacity: string;
  Combined_Make: string;
  Combined_Model: string;
  Combined_Transmission: string;
  FuelType: string;
  MaximumPowerBHP: number;
  ModelVariantDescription: string;
  MostPopulated: number;
  NumberOfDoors: number;
  ProductionStartDate: string;
}
