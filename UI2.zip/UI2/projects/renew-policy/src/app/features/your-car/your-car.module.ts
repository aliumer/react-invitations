import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { ErrorModule } from '@ren/shared/error/error.module';
import { MessagesModule } from '@ren/shared/messages/messages.module';
import { YourCarRoutingModule } from './your-car-routing.module';
import { YourCarServicesModule } from '@ren/features/your-car/services/your-car-services.module';

import { YourCarContainerComponent } from './containers/your-car-container.component';
import { CarPanelComponent } from './components/car-panel/car-panel.component';
import { CarLookupComponent } from './components/car-lookup/car-lookup.component';
import { CarDetailsComponent } from './components/car-details/car-details.component';
import { CarModificationsComponent } from './components/car-modifications/car-modifications.component';
import { PanelComponent } from './components/car-modifications/panel/panel.component';
import { PanelItemComponent } from './components/car-modifications/panel/panel-item/panel-item.component';

import * as fromYourCar from './state/reducers';

import { YOUR_CAR_STORE_KEY } from '@ren/infrastructure/constants';



@NgModule({
  declarations: [YourCarContainerComponent, CarPanelComponent, CarLookupComponent, CarDetailsComponent, CarModificationsComponent, PanelComponent, PanelItemComponent],
  imports: [
    CoreUiModule,
    ErrorModule,
    MessagesModule,
    YourCarRoutingModule,
    YourCarServicesModule,
    StoreModule.forFeature(YOUR_CAR_STORE_KEY, fromYourCar.reducers)
  ]
})
export class YourCarModule { }
