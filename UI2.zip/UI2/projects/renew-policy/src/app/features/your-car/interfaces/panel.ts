import { PanelItem } from '@ren/features/your-car/interfaces/panel-item';

export interface Panel {
  key: string;
  title: string;
  description?: string;
  selectedItemCount?: number;
  isItemOpened: boolean;
  panelItems: PanelItem[];
}
