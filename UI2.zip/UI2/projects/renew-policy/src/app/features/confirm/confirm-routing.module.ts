import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AutoRenewResolverService } from '@ren/features/confirm/services/auto-renew-resolver/auto-renew-resolver.service';
import { PaymentSuccessResolverService } from '@ren/features/confirm/services/payment-success-resolver/payment-success-resolver.service';

import { ConfirmHoldingContainerComponent } from '@ren/features/confirm/containers/confirm-holding-container.component';
import { AutoRenewContainerComponent } from '@ren/features/confirm/containers/auto-renew-container/auto-renew-container.component';
import { PaymentSuccessContainerComponent } from '@ren/features/confirm/containers/payment-success-container/payment-success-container.component';

const routes: Routes = [
  {
    path: '',
    component: ConfirmHoldingContainerComponent,
    children: [
      {
        path: 'auto-renew',
        component: AutoRenewContainerComponent,
        resolve: {
          _: AutoRenewResolverService
        }
      },
      {
        path: 'payment-success',
        component: PaymentSuccessContainerComponent,
        resolve: {
          _: PaymentSuccessResolverService
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfirmRoutingModule { }
