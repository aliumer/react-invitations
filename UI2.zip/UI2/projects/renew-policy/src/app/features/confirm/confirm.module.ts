import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { AlertsModule } from '@ren/shared/alerts/alerts.module';
import { ErrorModule } from '@ren/shared/error/error.module';
import { SubmissionModule } from '@ren/shared/submission/submission.module';
import { ConfirmServicesModule } from '@ren/features/confirm/services/confirm-services.module';
import { ConfirmRoutingModule } from '@ren/features/confirm/confirm-routing.module';

import { AutoRenewContainerComponent } from '@ren/features/confirm/containers/auto-renew-container/auto-renew-container.component';
import { PaymentSuccessContainerComponent } from '@ren/features/confirm/containers/payment-success-container/payment-success-container.component';
import { ConfirmHoldingContainerComponent } from '@ren/features/confirm/containers/confirm-holding-container.component';

import { ConfirmDetailsAutoRenewComponent } from './components/confirm-details-auto-renew/confirm-details-auto-renew.component';
import { ConfirmDetailsComponent } from '@ren/features/confirm/components/confirm-details/confirm-details.component';

import * as fromConfirm from '@ren/features/confirm/state/reducers';

import { ConfirmEffects } from '@ren/features/confirm/state/effects/confirm.effects';



@NgModule({
  declarations: [
    ConfirmDetailsComponent,
    AutoRenewContainerComponent,
    PaymentSuccessContainerComponent,
    ConfirmHoldingContainerComponent,
    ConfirmDetailsAutoRenewComponent
  ],
  imports: [
    AlertsModule,
    CoreUiModule,
    ErrorModule,
    SubmissionModule,
    ConfirmRoutingModule,
    ConfirmServicesModule,
    StoreModule.forFeature(fromConfirm.confirmFeatureKey, fromConfirm.reducers, { metaReducers: fromConfirm.metaReducers }),
    EffectsModule.forFeature([ConfirmEffects])
  ]
})
export class ConfirmModule { }
