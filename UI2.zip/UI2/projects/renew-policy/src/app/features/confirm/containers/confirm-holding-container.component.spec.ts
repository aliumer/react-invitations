import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmHoldingContainerComponent } from './confirm-holding-container.component';

describe('ConfirmHoldingContainerComponent', () => {
  let component: ConfirmHoldingContainerComponent;
  let fixture: ComponentFixture<ConfirmHoldingContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmHoldingContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmHoldingContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
