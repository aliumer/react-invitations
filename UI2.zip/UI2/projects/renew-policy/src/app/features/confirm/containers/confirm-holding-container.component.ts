import { Component } from '@angular/core';

@Component({
  selector: 'app-confirm-holding-container',
  template: `
    <router-outlet></router-outlet>`
})
export class ConfirmHoldingContainerComponent {
}
