export interface YourPaymentsSummary {
  paymentType: string;
  cardholder?: string;
  billingAddressCard?: string;
  cardType?: string;
  cardNumber?: string;
  expiryDate?: string;
  accountHolder?: string;
  billingAddressDirectDebit?: string;
  accountNumber?: string;
  sortCode?: string;
  bankOrBuildingSociety?: string;
}
