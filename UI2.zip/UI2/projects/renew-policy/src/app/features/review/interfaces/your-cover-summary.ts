import { TelematicsTypeReadableEnum } from '@ren/infrastructure/enums/telematics-type.enum';

import { CoverageTypeEnumSimple, CoverageTypeNames } from '@ren/infrastructure/enums/coverage-type.enum';

import { DriverExcess } from '@ren/features/review/interfaces/driver-excess';
import { VehicleCoverageCover } from '@ren/features/review/interfaces/vehicle-coverage-cover';

export interface YourCoverSummary {
  coverLevel?: CoverageTypeNames;
  policyStartDate?: string;
  policyEndDate?: string;
  quoteValidUntil?: string;
  driverExcesses?: DriverExcess[];
  yourPremiumExtrasSummary?: VehicleCoverageCover[];
  rescueCover: string;
  deviceTypeTelematics: TelematicsTypeReadableEnum;
  coverLevelSimple: CoverageTypeEnumSimple;
  tpftExcess?: number;
  isPersonalCover: boolean;
  isEuRescueCover: boolean;
}
