import { YourCarSummary } from '@ren/features/review/interfaces/your-car-summary';
// import { YourAddressSummary } from '@ren/features/review/interfaces/your-address-summary';
import { YourDetailsSummary } from '@ren/features/review/interfaces/your-details-summary';
import { YourAdditionalDriversSummary } from '@ren/features/review/interfaces/your-additional-drivers-summary';
import { YourDrivingHistorySummary } from '@ren/features/review/interfaces/your-driving-history-summary';
import { YourDiscountsSummary } from '@ren/features/review/interfaces/your-discounts-summary';
import { YourCoverSummary } from '@ren/features/review/interfaces/your-cover-summary';

export interface ReviewDetails {
  yourCarSummary: YourCarSummary;
  // yourAddressSummary: YourAddressSummary;
  yourDetailsSummary?: YourDetailsSummary;
  yourDrivingHistorySummary?: YourDrivingHistorySummary;
  yourAdditionalDriversSummary?: YourAdditionalDriversSummary[];
  yourAdditionalTempDriversSummary?: YourAdditionalDriversSummary[];
  yourDiscountsSummary?: YourDiscountsSummary;
  yourCoverSummary?: YourCoverSummary;
}
