import { YourDrivingHistorySummary } from '@ren/features/review/interfaces/your-driving-history-summary';

export interface YourAdditionalDriversSummary extends YourDrivingHistorySummary {
  prefix: string;
  name: string;
  employmentStatus: string;
  dob: string;
  relationship: string;
  occupation: string;
  driverStartDate: string;
  driverEndDate: string;
}
