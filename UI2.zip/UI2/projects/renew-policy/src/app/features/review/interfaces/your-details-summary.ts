export interface YourDetailsSummary {
  mainPolicyHolder: string;
  dateOfBirth?: string;
  occupation?: string;
  policyAddress?: string;
  correspondenceAddress?: string;
  contactNumber?: string;
  emailAddress?: string;
}
