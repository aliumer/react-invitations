export interface YourQuoteSummary {
  quotePrice: number;
  termMonths: string;
}
