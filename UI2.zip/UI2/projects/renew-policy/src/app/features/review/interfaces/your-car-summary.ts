export interface YourCarSummary {
  make: string;
  displayName: string;
  registrationNumber: string;
  modifications: number;
  annualMileage: string;
  registeredKeeper: string;
  isVehiclePurchased: boolean;
  purchaseDate?: Date;
  vehicleStartDate?: string;
  vehicleEndDate?: string;
  engineSize?: string;
  year?: number;
  model?: string;
}
