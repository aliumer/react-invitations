export interface YourDiscountsSummary {
  carUsage: string;
  carLocationPostcode: string;
  isVehicleGarageAtHome: boolean;
  vehicleNightLocation?: string;
  mainDriver: string;
  ncdOwner: string;
  ncdLength: string;
  ncdEarnedOn: string;
}
