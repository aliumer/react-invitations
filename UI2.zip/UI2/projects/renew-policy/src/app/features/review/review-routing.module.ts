import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// import { ReviewResolverService } from '@ren/features/review/services/review-resolver/review-resolver.service';
import { ReviewResolverInitialService } from '@ren/features/review/services/review-resolver-initial/review-resolver-initial.service';
import { ReviewResolverEditService } from '@ren/features/review/services/review-resolver-edit/review-resolver-edit.service';

import { ReviewHoldingContainerComponent } from '@ren/features/review/containers/review-holding-container.component';
import { ReviewEditContainerComponent } from '@ren/features/review/containers/review-edit-container/review-edit-container.component';
import { ReviewInitialContainerComponent } from '@ren/features/review/containers/review-initial-container/review-initial-container.component';


const routes: Routes = [
  {
    path: '',
    component: ReviewHoldingContainerComponent,
    /*resolve: {
      _: ReviewResolverService
    },*/
    children: [
      {
        path: 'initial',
        component: ReviewInitialContainerComponent,
        resolve: {
          _: ReviewResolverInitialService
        }
      },
      {
        path: 'edit',
        component: ReviewEditContainerComponent,
        resolve: {
          _: ReviewResolverEditService
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReviewRoutingModule {
}
