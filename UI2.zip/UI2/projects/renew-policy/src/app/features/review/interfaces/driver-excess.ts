export interface DriverExcess {
  driverID: string;
  name: string;
  mainDriver: boolean;
  totalExcess: number;
  driverType: string;
  driverExcess?: number;
  compulsoryExcess?: number;
  voluntaryExcess?: number;
  fireandTheftExcess?: number;
  fireandTheftTotalExcess?: number;
}
