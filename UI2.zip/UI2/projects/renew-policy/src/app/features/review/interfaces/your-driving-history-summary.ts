export interface YourDrivingHistorySummary {
  licenseType: string;
  licenseHeldFor: string;
  ukResidentSince: string;
  convictions: any[];
  claims: any[];
}
