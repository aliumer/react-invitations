import { Component } from '@angular/core';

@Component({
  selector: 'app-review-holding-container',
  template: `
    <router-outlet></router-outlet>`
})
export class ReviewHoldingContainerComponent {
}
