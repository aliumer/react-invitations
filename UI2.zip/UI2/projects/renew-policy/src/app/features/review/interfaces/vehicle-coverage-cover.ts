
export interface VehicleCoverageCover {
  name?: string;
  covName?: string;
  codeIdentifier_dlg?: string;
  updated?: boolean;
  selected?: boolean;
  required?: boolean;
  description?: string;
  coverageCategoryCode?: string;
  coverageCategoryDisplayName?: string;
  existanceType_dlg?: string;
  amount?: any;
  monthlyAmount_dlg?: any;
}
