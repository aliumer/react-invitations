export interface PaymentOptions {
    renewOrPay: any;
    paymentMethod: any;
}
