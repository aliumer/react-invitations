import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewHoldingContainerComponent } from './review-holding-container.component';

describe('ReviewHoldingContainerComponent', () => {
  let component: ReviewHoldingContainerComponent;
  let fixture: ComponentFixture<ReviewHoldingContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewHoldingContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewHoldingContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
