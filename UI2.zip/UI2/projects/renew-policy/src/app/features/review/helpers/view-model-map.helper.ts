import { KeyValue } from '@angular/common';

import { DateTimeHelpers } from '@ren/infrastructure/helpers/date-time.helpers';
import { PaymentHelpers } from '@ren/infrastructure/helpers/payment.helpers';
import { GwHelpers } from '@ren/infrastructure/helpers/gw.helpers';

import { CoverageTypeEnumSimple } from '@ren/infrastructure/enums/coverage-type.enum';
import { TelematicsTypeEnum, TelematicsTypeReadableEnum } from '@ren/infrastructure/enums/telematics-type.enum';
import { PaymentBillingIdEnum } from '@ren/infrastructure/enums/payments.enum';

import { YourQuoteSummary } from '@ren/features/review/interfaces/your-quote-summary';
import { YourCarSummary } from '@ren/features/review/interfaces/your-car-summary';
import { YourDetailsSummary } from '@ren/features/review/interfaces/your-details-summary';
import { YourDrivingHistorySummary } from '@ren/features/review/interfaces/your-driving-history-summary';
import { YourAdditionalDriversSummary } from '@ren/features/review/interfaces/your-additional-drivers-summary';
import { YourDiscountsSummary } from '@ren/features/review/interfaces/your-discounts-summary';
import { YourPaymentsSummary } from '@ren/features/review/interfaces/your-payments-summary';
import { VehicleCoverageCover } from '@ren/features/review/interfaces/vehicle-coverage-cover';
import { BookletCodes } from '@ren/features/review/interfaces/booklet-codes';
import { DriverExcess } from '@ren/features/review/interfaces/driver-excess';

import { RegisteredKeeperFull } from '@ren/infrastructure/data/your-car.data';
import { VehicleLocationQuestions } from '@ren/infrastructure/data/your-address.data';
import { OtherConvictionList } from '@ren/infrastructure/data/your-drivers.data';
import { DriverRelationship, LicenceHeldForMonths, LicenceHeldForYears, LicenseType } from '@ren/infrastructure/data/your-drivers.data';
import { NcdEarnedMonths, NcdEarnedOn, NcdEarnedYears, VehicleUseOptions } from '@ren/infrastructure/data/your-discounts.data';



export class ViewModelMapHelper {

  static getYourQuoteSummary(premium: any): YourQuoteSummary {
    const {selectedPeriodPublicId_dlg} = premium;
    const selectedQuote = premium.quoteData.offeredQuotes.find(item => item.publicID === selectedPeriodPublicId_dlg);
    return {
      quotePrice: selectedQuote.premium.total.amount,
      termMonths: selectedQuote.premium.termMonths
    };
  }

  static getYourCarSummary(vehicle: any): YourCarSummary {
    const {
      make,
      displayName,
      registrationNumber,
      modifications,
      isVehiclePurchased,
      purchaseDate,
      annualMileage,
      registeredOwner,
      vehicleStartDate,
      vehicleEndDate,
      year,
      engineSize,
      model
    } = vehicle;

    return {
      make,
      year,
      engineSize,
      model,
      displayName,
      registrationNumber,
      modifications: modifications.length,
      isVehiclePurchased,
      purchaseDate: new Date(purchaseDate.year, purchaseDate.month),
      annualMileage,
      registeredKeeper: RegisteredKeeperFull.filter(k => k.key === registeredOwner)[0].value,
      vehicleStartDate: vehicleStartDate ? DateTimeHelpers.toFormat([vehicleStartDate.day, vehicleStartDate.month + 1, vehicleStartDate.year]) : null,
      vehicleEndDate: vehicleEndDate ? DateTimeHelpers.toFormat([vehicleEndDate.day, vehicleEndDate.month + 1, vehicleEndDate.year]) : null
    } as YourCarSummary;
  }

  static getYourDeviceTypeTelematics(offerings: any[], coverType: CoverageTypeEnumSimple): TelematicsTypeReadableEnum {
    const offeringsIndex = offerings.findIndex(o => o.offeringCode_dlg === coverType);
    const {coverages} = offerings[offeringsIndex];
    const cover = coverages.vehicleCoverages[0];
    const telematicsType = cover.hasOwnProperty('deviceTypeTelematics') ? TelematicsTypeEnum[cover.deviceTypeTelematics] : null;

    return telematicsType === TelematicsTypeReadableEnum.App ? null : telematicsType;
  }

  static getYourDetailsSummary(drivers: any, accountHolder: any, policyAddress: string, correspondenceAddress: string, occupations: KeyValue<string, string>[]): YourDetailsSummary {
    const policyHolder = drivers.filter(ph => ph.isPolicyHolder === true)[0].person;
    const dateOfBirth = policyHolder.dateOfBirth;

    return {
      mainPolicyHolder: `${GwHelpers.convertTitleForDisplay(policyHolder.prefix)} ${policyHolder.displayName}`,
      dateOfBirth: dateOfBirth ? DateTimeHelpers.toFormat([dateOfBirth.day, dateOfBirth.month + 1, dateOfBirth.year]) : null,
      contactNumber: policyHolder.workNumber,
      emailAddress: accountHolder.emailAddress1,
      occupation: occupations.filter(o => o.key === accountHolder.occupation_dlg)[0].value,
      policyAddress,
      correspondenceAddress: correspondenceAddress ?? policyAddress
    } as YourDetailsSummary;
  }

  static getYourDrivingHistorySummary(policyHolder: any): YourDrivingHistorySummary {
    const {
      residentInUkFromBirth,
      typeOfDrivingLicense,
      lengthOfDrivingLicHeldYear,
      lengthOfDrivingLicHeldMonth,
      yearInUK_dlg,
      claimsDetails,
      convictionDetails
    } = policyHolder;

    return {
      licenseType: LicenseType.filter(l => l.key === typeOfDrivingLicense)[0]?.value,
      licenseHeldFor: ViewModelMapHelper.mapLicenceHeldForDuration(lengthOfDrivingLicHeldYear, lengthOfDrivingLicHeldMonth),
      claims: ViewModelMapHelper.mapClaims(claimsDetails),
      convictions: ViewModelMapHelper.mapConvictions(convictionDetails),
      ukResidentSince: residentInUkFromBirth ? 'Birth' : `${(+yearInUK_dlg.month) + 1}/${yearInUK_dlg.year}`
    } as YourDrivingHistorySummary;
  }

  static getDurationLabel(duration: string, label: string) {
    return label === 'month' && parseInt(duration, 10) === 0 ? '' : parseInt(duration, 10) > 1 ? label + 's' : label;
  }

  static getYourAdditionalDriversSummary(additionalDrivers: any, occupations: KeyValue<string, string>[]): YourAdditionalDriversSummary[] {
    return additionalDrivers.map(d => {
      const {
        person: {prefix, displayName, dateOfBirth},
        relationToPolHolder,
        employmentStatus_dlg,
        residentInUkFromBirth,
        typeOfDrivingLicense,
        lengthOfDrivingLicHeldYear,
        lengthOfDrivingLicHeldMonth,
        occupation_dlg,
        yearInUK_dlg,
        driverStartDate,
        driverEndDate,
        claimsDetails,
        convictionDetails
      } = d;

      return {
        prefix,
        name: displayName,
        employmentStatus: employmentStatus_dlg,
        dob: dateOfBirth ? DateTimeHelpers.toFormat([dateOfBirth.day, dateOfBirth.month + 1, dateOfBirth.year]) : null,
        relationship: DriverRelationship.filter(r => r.key === relationToPolHolder)[0]?.value,
        ukResidentSince: residentInUkFromBirth ? 'Birth' : `${(+yearInUK_dlg.month) + 1}/${yearInUK_dlg.year}`,
        licenseType: LicenseType.filter(l => l.key === typeOfDrivingLicense)[0]?.value,
        occupation: occupations.filter(o => o.key === occupation_dlg)[0].value,
        licenseHeldFor: ViewModelMapHelper.mapLicenceHeldForDuration(lengthOfDrivingLicHeldYear, lengthOfDrivingLicHeldMonth),
        claims: ViewModelMapHelper.mapClaims(claimsDetails),
        convictions: ViewModelMapHelper.mapConvictions(convictionDetails),
        driverStartDate: DateTimeHelpers.toFormat([driverStartDate.day, driverStartDate.month + 1, driverStartDate.year]),
        driverEndDate: DateTimeHelpers.toFormat([driverEndDate.day, driverEndDate.month + 1, driverEndDate.year])
      } as YourAdditionalDriversSummary;
    });
  }

  static getYourDiscountsSummary(vehicle: any, drivers: any, vehicleDrivers: any): YourDiscountsSummary {
    const {
      primaryUse,
      garageNightPostcode,
      garageNightLocation,
      isVehicleGarageAtHome,
      ncdOwnerInUse,
      yearsNoClaim,
      monthsNoClaim,
      ncdEarn
    } = vehicle;

    const mainDriver = drivers.filter(d => d.publicID === vehicleDrivers[0].mainDriverID)[0];
    const ncdOwner = drivers.filter(d => d.publicID === ncdOwnerInUse)[0];
    const ncdLength = yearsNoClaim ?
      (NcdEarnedYears.filter(n => n.key === yearsNoClaim)[0] && NcdEarnedYears.filter(n => n.key === yearsNoClaim)[0].value) :
      NcdEarnedMonths.filter(n => n.key === monthsNoClaim)[0].value;

    return {
      mainDriver: mainDriver.person.displayName,
      carUsage: VehicleUseOptions.filter(v => v.key === primaryUse)[0].value,
      carLocationPostcode: garageNightPostcode,
      isVehicleGarageAtHome,
      vehicleNightLocation: VehicleLocationQuestions.find(item => item.key === garageNightLocation)?.value,
      ncdOwner: ncdOwner.person.displayName,
      ncdLength: parseInt(ncdLength, 10) === 1 ? `${ncdLength} year` : `${ncdLength} years`,
      ncdEarnedOn: NcdEarnedOn.filter(n => n.key === ncdEarn)[0].value
    } as YourDiscountsSummary;
  }

  static getBookletCodes(baseData: any): BookletCodes {
    return {
      motorBookletVersion: baseData.motorBookletVersion_dlg ?? null,
      motorIPIDVersion: baseData.motorIPIDVersion_dlg ?? null,
      rescueBookletVersion: baseData.rescueBookletVersion_dlg ?? null,
      rescueIPIDVersion: baseData.rescueIPIDVersion_dlg ?? null
    }
  }

  static getYourPaymentsSummary(bindData: any): YourPaymentsSummary {
    const {selectedPaymentPlan, directDebitDetails_dlg, creditCardDetails_dlg} = bindData;
    return {
      paymentType: selectedPaymentPlan === PaymentBillingIdEnum.PayAnnual ? 'annual' : 'monthly',
      cardholder: creditCardDetails_dlg?.cardHolderName,
      billingAddressCard: creditCardDetails_dlg?.billingAddres?.displayName,
      cardType: creditCardDetails_dlg?.cardType,
      cardNumber: creditCardDetails_dlg?.cardNumber ?? 'NA',
      expiryDate: PaymentHelpers.getCardExpiryDateDisplay(creditCardDetails_dlg?.expDate),
      accountHolder: directDebitDetails_dlg?.person?.displayName,
      billingAddressDirectDebit: directDebitDetails_dlg?.billingAddres?.displayName,
      accountNumber: directDebitDetails_dlg?.bankDetails?.accountNumber,
      sortCode: directDebitDetails_dlg?.bankDetails?.sortCode,
      bankOrBuildingSociety: directDebitDetails_dlg?.bankDetails?.institutionName
    };
  }

  static getYourSelectedPremiumExtras(offerings: any[], coverType: CoverageTypeEnumSimple): VehicleCoverageCover[] {
    const vehicleCoverage = ViewModelMapHelper.getPremiumVehicleCoveragesByCoverType(offerings, coverType);
    const coverages = vehicleCoverage.coverages;
    let returnVal: VehicleCoverageCover[];
    if (coverages && coverages.length) {
      returnVal = coverages.filter(cover => cover.existanceType_dlg === 'Electable' && cover.selected === true).slice().sort((a, b) => {
        const coverageA = a.codeIdentifier_dlg.toUpperCase();
        const coverageB = b.codeIdentifier_dlg.toUpperCase();
        return (coverageA < coverageB) ? -1 : (coverageA > coverageB) ? 1 : 0;
      }) || null;

    }

    return (returnVal && returnVal.length) ? returnVal : null;
  }

  static getPolicyCoverageType(offerings: any[]): CoverageTypeEnumSimple {
    const requiredOffering = offerings.find(offering => offering.coverages);
    return requiredOffering.offeringCode_dlg;
  }

  static getDriverExcesses(offerings: any[], coverType: CoverageTypeEnumSimple, drivers: any[]): DriverExcess[] {

    if (offerings && offerings.length && drivers && drivers.length) {
      const offeringByCoverType = offerings.filter((cover) => cover.offeringCode_dlg === coverType);
      const driverExcesses = offeringByCoverType.map(o => o.driverExcess_dlg).reduce((acc, val) => acc.concat(val), []);

      if (driverExcesses && driverExcesses.length) {
        const driverExcessesMapped = driverExcesses.map((driverExcess) => {
          const driver: any = drivers.filter(d => d.publicID === driverExcess.driverID);
          return {
            driverType: driver[0].driverType,
            driverID: driverExcess.driverID,
            name: driverExcess.name,
            mainDriver: driverExcess.mainDriver,
            totalExcess: driverExcess.totalExcess
          } as DriverExcess;
        });

        const driverPublicIds = new Set(drivers.map(driver => driver.publicID));

        if (driverExcessesMapped && driverExcessesMapped.length && driverPublicIds.size > 0) {
          return driverExcessesMapped.filter((de: DriverExcess) => driverPublicIds.has(de.driverID));
        }
      }
    }

    return null;
  }

  static getTPFTExcess(offerings: any[], coverType: CoverageTypeEnumSimple): number {
    if (offerings && offerings.length && coverType === CoverageTypeEnumSimple.TPFT) {
      const offeringByCoverType = offerings.filter((cover) => cover.offeringCode_dlg === coverType);
      return offeringByCoverType[0].coverages.vehicleCoverages[0].vehicleExcess_dlg.fireandTheftExcess;
    }

    return null;
  }

  private static getPremiumVehicleCoveragesByCoverType(offerings: any[], coverType: CoverageTypeEnumSimple): any {
    if (offerings && offerings.length > 0) {
      const offering = offerings.find((cover) => cover.offeringCode_dlg === coverType);
      return offering.coverages.vehicleCoverages[0];
    }
    return null;
  }

  private static mapLicenceHeldForDuration(lengthOfDrivingLicHeldYear: string, lengthOfDrivingLicHeldMonth: string): string {
    return isNaN(parseInt(lengthOfDrivingLicHeldYear, 10)) ? isNaN(parseInt(lengthOfDrivingLicHeldMonth, 10)) ? null :
      `${LicenceHeldForMonths.filter(l => l.key === lengthOfDrivingLicHeldMonth)[0]?.value} ${this.getDurationLabel(lengthOfDrivingLicHeldMonth, 'month')}` :
      `${LicenceHeldForYears.filter(l => l.key === lengthOfDrivingLicHeldYear)[0]?.value} ${this.getDurationLabel(lengthOfDrivingLicHeldYear, 'year')}`;
  }

  private static mapConvictions(convictionDetails): { date: string, title: string }[] {
    return (convictionDetails ?? []).map(item => {
      return {
        date: `${DateTimeHelpers.getShortMonth(item.convictionDate.month + 1)} ${item.convictionDate.year}`,
        title: OtherConvictionList.find(c => c.key === item.convictionCode).value
      };
    });
  }

  private static mapClaims(claimsDetails): { date: string, title: string }[] {
    return (claimsDetails ?? []).map(item => {
      return {
        date: `${DateTimeHelpers.getShortMonth(item.incidentDate.month + 1)} ${item.incidentDate.year}`,
        title: item.incidentType
      };
    });
  }
}
