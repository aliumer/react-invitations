import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { AlertsModule } from '@ren/shared/alerts/alerts.module';
import { ErrorModule } from '@ren/shared/error/error.module';
import { OccupationsModule } from '@ren/shared/occupations/occupations.module';
import { ReviewRoutingModule } from '@ren/features/review/review-routing.module';
import { ReviewServicesModule } from '@ren/features/review/services/review-services.module';
import { SubmissionModule } from '@ren/shared/submission/submission.module';

import { ReviewHoldingContainerComponent } from './containers/review-holding-container.component';
import { ReviewEditContainerComponent } from './containers/review-edit-container/review-edit-container.component';
import { ReviewInitialContainerComponent } from './containers/review-initial-container/review-initial-container.component';

import { ReviewIntroComponent } from '@ren/features/review/components/review-intro/review-intro.component';
import { TelematicsComponent } from '@ren/features/review/components/telematics/telematics.component';
import { YourCarSummaryComponent } from '@ren/features/review/components/your-car-summary/your-car-summary.component';
import { YourDetailsSummaryComponent } from '@ren/features/review/components/your-details-summary/your-details-summary.component';
import { YourDrivingHistorySummaryComponent } from '@ren/features/review/components/your-driving-history-summary/your-driving-history-summary.component';
import { YourDiscountsSummaryComponent } from '@ren/features/review/components/your-discounts-summary/your-discounts-summary.component';
import { YourCoverSummaryComponent } from '@ren/features/review/components/your-cover-summary/your-cover-summary.component';
import { ReviewAdditionalInfoComponent } from '@ren/features/review/components/review-additional-info/review-additional-info.component';
import { YourPaymentsSummaryComponent } from '@ren/features/review/components/your-payments-summary/your-payments-summary.component';
import { YourAdditionalDriversSummaryComponent } from '@ren/features/review/components/your-additional-drivers-summary/your-additional-drivers-summary.component';
import { PaymentOptionsComponent } from '@ren/features/review/components/payment-options/payment-options.component';

import { reducers as ReviewReducer } from '@ren/features/review/state/reducers';

import { REVIEW_STORE_KEY } from '@ren/infrastructure/constants';





@NgModule({
  declarations: [
    ReviewIntroComponent,
    TelematicsComponent,
    YourCarSummaryComponent,
    YourDetailsSummaryComponent,
    YourDrivingHistorySummaryComponent,
    YourDiscountsSummaryComponent,
    YourCoverSummaryComponent,
    ReviewAdditionalInfoComponent,
    YourPaymentsSummaryComponent,
    YourAdditionalDriversSummaryComponent,
    PaymentOptionsComponent,
    ReviewHoldingContainerComponent,
    ReviewEditContainerComponent,
    ReviewInitialContainerComponent
  ],
  imports: [
    CoreUiModule,
    AlertsModule,
    ErrorModule,
    OccupationsModule,
    SubmissionModule,
    ReviewRoutingModule,
    ReviewServicesModule,
    StoreModule.forFeature(REVIEW_STORE_KEY, ReviewReducer)
  ]
})
export class ReviewModule {
}
