export interface BookletCodes {
  motorBookletVersion: string;
  motorIPIDVersion: string;
  rescueBookletVersion: string;
  rescueIPIDVersion: string;
}
