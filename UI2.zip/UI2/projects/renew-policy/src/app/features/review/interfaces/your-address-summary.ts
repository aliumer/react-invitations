export interface YourAddressSummary {
  address: string;
  isVehicleAtHome: boolean;
  overNightLocation: string;
}
