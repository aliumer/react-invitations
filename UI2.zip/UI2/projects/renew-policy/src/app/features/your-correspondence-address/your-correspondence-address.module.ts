import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { AddressModule } from '@ren/shared/address/address.module';
import { ErrorModule } from '@ren/shared/error/error.module';
import { YourCorrespondenceAddressRoutingModule } from './your-correspondence-address-routing.module';

import { YourCorrespondenceAddressContainerComponent } from './containers/your-correspondence-address-container.component';

import * as fromYourCorrespondenceAddress from './state/reducers';

import { YOUR_CORRESPONDENCE_ADDRESS_STORE_KEY } from '@ren/infrastructure/constants';

@NgModule({
  declarations: [YourCorrespondenceAddressContainerComponent],
  imports: [
    CoreUiModule,
    AddressModule,
    ErrorModule,
    YourCorrespondenceAddressRoutingModule,
    StoreModule.forFeature(YOUR_CORRESPONDENCE_ADDRESS_STORE_KEY, fromYourCorrespondenceAddress.reducers)
  ]
})
export class YourCorrespondenceAddressModule { }
