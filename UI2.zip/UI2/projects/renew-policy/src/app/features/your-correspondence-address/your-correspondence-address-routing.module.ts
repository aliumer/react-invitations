import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { YourCorrespondenceAddressContainerComponent } from '@ren/features/your-correspondence-address/containers/your-correspondence-address-container.component';


const routes: Routes = [
  {
    path: '',
    component: YourCorrespondenceAddressContainerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YourCorrespondenceAddressRoutingModule { }
