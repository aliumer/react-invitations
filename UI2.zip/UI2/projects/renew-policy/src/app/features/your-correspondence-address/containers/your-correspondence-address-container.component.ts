import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { concatMap, filter, map, take, takeWhile, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { FeatureBase } from '@ren/infrastructure/abstracts/feature.base';

import { FormService } from '@ren/core/services/form/form.service';
import { ScrollingService } from '@ren/core/services/scrolling/scrolling.service';

import { JourneyNavigationActions, PolicyActions } from '@ren/main/state/actions';
import { YourCorrespondenceAddressActions } from '@ren/features/your-correspondence-address/state/actions';

import { selectJourneyNavigationButtonDetailsWithExtra } from '@ren/main/state/selectors/journey.selectors';
import { selectInitialPolicyDetails, selectInlineError } from '@ren/main/state/selectors/policy.selectors';
import { selectUpdatedCorrespondenceAddress } from '@ren/features/your-correspondence-address/state/selectors/your-correspondence-address.selectors';

import { CustomHelpers } from '@ren/infrastructure/helpers/custom.helpers';

import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';


@Component({
  selector: 'app-your-correspondence-address-container',
  templateUrl: './your-correspondence-address-container.component.html'
})
export class YourCorrespondenceAddressContainerComponent extends FeatureBase implements OnInit {

  currentAddressDisplay$: Observable<string>;
  newAddressDetails$: Observable<any>;
  isShowInlineError$: Observable<boolean>;

  constructor(
    protected router: Router,
    protected store: Store,
    private fb: FormBuilder,
    private formService: FormService,
    private scrollingService: ScrollingService
  ) {
    super(router, store, JourneyFeaturesConfig.yourCorrespondenceAddress.name);
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.createForm();
  }

  protected handleNavigation() {
    this.store.pipe(
      select(selectJourneyNavigationButtonDetailsWithExtra),
      filter(({isBackButtonClicked, isNextButtonClicked, isCancelButtonClicked}) => isBackButtonClicked || isNextButtonClicked || isCancelButtonClicked),
      concatMap(({isBackButtonClicked, isNextButtonClicked, isCancelButtonClicked, navCommands}) => this.store.pipe(
        select(selectUpdatedCorrespondenceAddress),
        map(correspondenceAddress => ({isBackButtonClicked, isNextButtonClicked, isCancelButtonClicked, navCommands, correspondenceAddress})),
        take(1)
      )),
      takeWhile(() => this.isComponentActive)
    ).subscribe(({isBackButtonClicked, isNextButtonClicked, isCancelButtonClicked, navCommands, correspondenceAddress}) => {
      try {
        this.store.dispatch(PolicyActions.resetErrors());
        if (isNextButtonClicked) {
          if (this.containerForm.valid && this.updateCorrespondenceAddressDetailsOfRequestPayload(correspondenceAddress)) {
            this.onNext(navCommands.next);
          } else {
            this.formService.updateControlValidity(this.containerForm);
            this.scrollingService.scrollToFirstError();
            this.store.dispatch(JourneyNavigationActions.resetButtons());
            return;
          }
        }

        if (isBackButtonClicked) {
          this.onBack(navCommands.prev);
        }

        if (isCancelButtonClicked) {
          this.onCancel();
        }
      } catch {
        this.store.dispatch(JourneyNavigationActions.resetButtons());
      }
    });
  }

  protected observeOnData() {
    this.currentAddressDisplay$ = this.store.pipe(
      select(selectInitialPolicyDetails),
      map(({baseData: {isCorrespondAdSameAsPolAd_dlg, polCorrespondenceAddress_dlg, policyAddress}}) =>
        isCorrespondAdSameAsPolAd_dlg ? policyAddress.displayName : polCorrespondenceAddress_dlg.displayName
      )
    );
    this.newAddressDetails$ = this.store.pipe(
      select(selectUpdatedCorrespondenceAddress)
    );
  }

  protected observeOnError() {
    this.isShowInlineError$ = this.store.pipe(
      select(selectInlineError),
      filter(val => val),
      tap(() => setTimeout(() => this.scrollingService.scrollToFirstPanelError()))
    );
  }

  private createForm() {
    this.containerForm = this.fb.group({});

    this.containerForm.valueChanges.pipe(
      takeWhile(() => this.isComponentActive),
      filter(() => this.containerForm.valid && this.containerForm.controls.address?.value)
    ).subscribe(({address: updatedCorrespondenceAddress}) => {
      this.store.dispatch(YourCorrespondenceAddressActions.updateCorrespondenceAddress({updatedCorrespondenceAddress}));
    });
  }

  private updateCorrespondenceAddressDetailsOfRequestPayload(correspondenceAddress): boolean {
    if (CustomHelpers.isEmptyObject(correspondenceAddress)) {
      return false;
    }

    const {addressDetails: {value: addressDetails}} = correspondenceAddress;
    const yourCorrespondenceAddress = {
      addressDetails: {
        addressLine1: correspondenceAddress.addressLine1 !== '' ? correspondenceAddress.addressLine1 : addressDetails.addressLine1,
        addressLine2: correspondenceAddress.addressLine2 !== '' ? correspondenceAddress.addressLine2 : addressDetails.addressLine2,
        addressLine3: correspondenceAddress.addressLine3 !== '' ? correspondenceAddress.addressLine3 : addressDetails.addressLine3,
        county_dlg: addressDetails.county,
        postalCode: addressDetails.postCode,
        city: addressDetails.town,
        displayName: addressDetails.displayName,
        uPRN_dlg: addressDetails.uPRN_dlg,
        xcordinate_dlg: addressDetails.xcordinate_dlg,
        ycordinate_dlg: addressDetails.ycordinate_dlg,
        latitude_dlg: addressDetails.latitude_dlg,
        longitude_dlg: addressDetails.longitude_dlg,
        uDPRN_dlg: addressDetails.uDPRN_dlg,
        country: 'GB'
      }
    };

    this.store.dispatch(PolicyActions.updatePayloadChanges({data: {yourCorrespondenceAddress}}));
    return true;
  }

}
