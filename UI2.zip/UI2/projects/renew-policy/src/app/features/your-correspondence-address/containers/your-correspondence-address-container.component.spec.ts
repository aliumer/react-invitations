import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YourCorrespondenceAddressContainerComponent } from './your-correspondence-address-container.component';

describe('YourCorrespondenceAddressContainerComponent', () => {
  let component: YourCorrespondenceAddressContainerComponent;
  let fixture: ComponentFixture<YourCorrespondenceAddressContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YourCorrespondenceAddressContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YourCorrespondenceAddressContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
