import { KeyValue } from '@angular/common';

import { DvlaSearchStatusEnum } from '@ren/features/your-drivers/models/dvla-search-status.enum';


export const DvlaSearchResponseCodes: KeyValue<string, DvlaSearchStatusEnum>[] = [
  {key: '200-0001', value: DvlaSearchStatusEnum.Successful},                // all good
  {key: '200-0002', value: DvlaSearchStatusEnum.SuccessfulExpiredLicence},  // expired licence

  {key: '400-0001', value: DvlaSearchStatusEnum.Unsuccessful},              // missing field - dln
  {key: '400-0002', value: DvlaSearchStatusEnum.SuccessfulNoData},          // missing field - data receiver id
  {key: '400-0003', value: DvlaSearchStatusEnum.SuccessfulNoData},          // missing field - group id
  {key: '400-0004', value: DvlaSearchStatusEnum.SuccessfulNoData},          // missing field - proposer indicator
  {key: '400-0005', value: DvlaSearchStatusEnum.SuccessfulNoData},          // missing field - type

  {key: '400-0101', value: DvlaSearchStatusEnum.Unsuccessful},              // invalid field - dln
  {key: '400-0102', value: DvlaSearchStatusEnum.SuccessfulNoData},          // invalid field - data receiver id
  {key: '400-0103', value: DvlaSearchStatusEnum.SuccessfulNoData},          // invalid field - group id
  {key: '400-0104', value: DvlaSearchStatusEnum.SuccessfulNoData},          // invalid field - post code
  {key: '400-0105', value: DvlaSearchStatusEnum.SuccessfulNoData},          // invalid field - proposer indicator
  {key: '400-0106', value: DvlaSearchStatusEnum.SuccessfulNoData},          // invalid field - type
  {key: '400-0107', value: DvlaSearchStatusEnum.SuccessfulNoData},          // invalid field - vrm

  {key: '400-0201', value: DvlaSearchStatusEnum.SuccessfulNoData},          // data error field - proposer indicator
  {key: '400-0202', value: DvlaSearchStatusEnum.SuccessfulNoData},          // data error field - group id
  {key: '400-0203', value: DvlaSearchStatusEnum.SuccessfulNoData},          // data error field - unique id

  {key: '400-1001', value: DvlaSearchStatusEnum.SuccessfulNoData},          // batch error - checksum
  {key: '400-1002', value: DvlaSearchStatusEnum.SuccessfulNoData},          // batch error - corrupt CSV
  {key: '400-1003', value: DvlaSearchStatusEnum.SuccessfulNoData},          // batch error - corrupt manifest
  {key: '400-1004', value: DvlaSearchStatusEnum.SuccessfulNoData},          // batch error - dln exceeded
  {key: '400-1005', value: DvlaSearchStatusEnum.SuccessfulNoData},          // batch error - mismatch between manifest and CSV
  {key: '400-1006', value: DvlaSearchStatusEnum.SuccessfulNoData},          // batch error - no group id
  {key: '400-1007', value: DvlaSearchStatusEnum.SuccessfulNoData},          // batch error - no dln

  {key: '404-0001', value: DvlaSearchStatusEnum.Unsuccessful},              // dln not found
  {key: '404-0002', value: DvlaSearchStatusEnum.SuccessfulNoData}           // not available
];
