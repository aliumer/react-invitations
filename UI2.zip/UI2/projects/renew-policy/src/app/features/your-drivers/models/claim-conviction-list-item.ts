export enum ClaimOrConviction {
  Claim,
  Conviction
}

export interface ClaimConvictionListItem {
  title: string;
  date: string[];
  description: string;
  type: ClaimOrConviction;
}
