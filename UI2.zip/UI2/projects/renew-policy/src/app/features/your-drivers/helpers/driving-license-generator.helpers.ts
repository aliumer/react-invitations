import { LicenseNumberInput } from '@ren/features/your-drivers/models/license-number-input';

export class DrivingLicenseGeneratorHelpers {

  static buildLicenceNumberFirstPart(data: LicenseNumberInput): string {
    const fromName = DrivingLicenseGeneratorHelpers.buildFromName(data.lastName);
    const fromDate = DrivingLicenseGeneratorHelpers.buildFromDob(data);
    return  (fromName + ' ' + fromDate).trim();
  }

  private static getYearFromDob(dob: Array<string>): string {
    if (dob && dob[2]) {
      const birthYear = dob[2];
      if (birthYear.length === 4) {
        return birthYear.charAt(2) + birthYear.charAt(3);
      }
      if (birthYear.length === 2) {
        return birthYear.charAt(0) + birthYear.charAt(1);
      }
    }
    return null;
  }

  private static getDateFromDob(dob: Array<string>): string {
    if (dob && dob[0]) {
      if (dob[0].length === 2) {
        return dob[0];
      }
      if (dob[0].length === 1) {
        return '0' + dob[0].charAt(0);
      }
    }
    return null;
  }

  private static isFemale(title: string, gender: string): boolean {
    if (gender) {
      return gender.toLowerCase() !== 'male';
    }
    if (title) {
      return title.toLowerCase() !== 'mr';
    }
    return false;
  }

  private static getMonthFromDob(dob: Array<string>, title: string, gender: string): string {
    let val: string;
    if (dob && dob[1]) {
      if (dob[1].length === 2) {
        val = dob[1];
      }
      if (dob[1].length === 1) {
        val = '0' + dob[1].charAt(0);
      }
      if (DrivingLicenseGeneratorHelpers.isFemale(title, gender)) {
        const firstChar: string = val.charAt(0);
        const parsed = parseInt(firstChar, 10);
        if (parsed === 0 || parsed === 1) {
          const newVal = parsed + 5;
          val =  '' + newVal + val.charAt(1);
        }
        return val;
      } else {
        return val;
      }
    }
    return null;
  }

  private static buildFromDob(data: any): string {
    const yr = DrivingLicenseGeneratorHelpers.getYearFromDob(data.dob);
    const mth = DrivingLicenseGeneratorHelpers.getMonthFromDob(data.dob, data.title, data.gender);
    const dte = DrivingLicenseGeneratorHelpers.getDateFromDob(data.dob);
    if (yr && mth && dte) {
      return yr.charAt(0) + mth + dte + yr.charAt(1);
    }
    return '';
  }

  private static isLetter(ch: string): boolean {
    return typeof ch === 'string' && ch.length === 1
      && (ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z');
  }

  private static buildFromName(lastName: string): string {
    let val = '';
    for (let i = 0; i < 5; i++) {
      const char = lastName[i];
      if (!DrivingLicenseGeneratorHelpers.isLetter(char)) {
        val = val + '9';
      } else {
        val = val + char;
      }
    }
    return val.toUpperCase();
  }
}
