export interface DriverListDisplayItem {
  driverType: string;
  isPolicyHolder: boolean;
  isMainDriver: boolean;
  isNcdOwner: boolean;
  relationToPolHolder: string;
  displayName: string;
  dob: string;
  id?: string;
  isFromPolicy?: boolean;
}
