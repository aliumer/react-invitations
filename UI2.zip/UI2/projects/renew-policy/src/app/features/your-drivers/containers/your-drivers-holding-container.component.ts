import { Component } from '@angular/core';

@Component({
  selector: 'app-your-drivers-holding-container',
  template: `
    <router-outlet></router-outlet>`
})
export class YourDriversHoldingContainerComponent {
}
