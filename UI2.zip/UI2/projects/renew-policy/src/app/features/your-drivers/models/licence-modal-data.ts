export interface LicenceModalData {
  type: string;
  heading: string;
  copy: string;
}
