import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';

import { AlertsModule } from '@ren/shared/alerts/alerts.module';
import { ErrorModule } from '@ren/shared/error/error.module';
import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { OccupationsModule } from '@ren/shared/occupations/occupations.module';
import { DirectivesModule } from '@ren/shared/directives/directives.module';
import { ModalsModule } from '@ren/shared/modals/modals.module';
import { YourDriversRoutingModule } from '@ren/features/your-drivers/your-drivers-routing.module';
import { YourDriversServicesModule } from '@ren/features/your-drivers/services/your-drivers-services.module';
import { PipesModule } from '@ren/shared/pipes/pipes.module';

import { YourDriversHoldingContainerComponent } from '@ren/features/your-drivers/containers/your-drivers-holding-container.component';
import { DriverListContainerComponent } from '@ren/features/your-drivers/containers/list/driver-list-container/driver-list-container.component';
import { ManageDriverHoldingContainerComponent } from './containers/manage/manage-driver-holding-container.component';
import { PersonalDetailsContainerComponent } from './containers/manage/personal-details-container/personal-details-container.component';
import { DrivingLicenseNumberContainerComponent } from './containers/manage/driving-license-number-container/driving-license-number-container.component';
import { DrivingHistoryContainerComponent } from './containers/manage/driving-history-container/driving-history-container.component';

import { YourDriverListComponent } from '@ren/features/your-drivers/components/list/your-driver-list/your-driver-list.component';
import { AdditionalDetailsComponent } from '@ren/features/your-drivers/components/list/additional-details/additional-details.component';
import { YourDriverListItemComponent } from '@ren/features/your-drivers/components/list/your-driver-list-item/your-driver-list-item.component';
import { PersonalDetailsComponent } from './components/manage/personal-details/personal-details.component';
import { DrivingLicenseNumberComponent } from './components/manage/driving-license-number/driving-license-number.component';
import { DrivingHistoryComponent } from './components/manage/driving-history/driving-history.component';
import { DriverClaimsComponent } from './components/manage/driver-claims/driver-claims.component';
import { DriverConvictionsComponent } from './components/manage/driver-convictions/driver-convictions.component';
import { ClaimConvictionListItemComponent } from './components/manage/claim-conviction-list-item/claim-conviction-list-item.component';
import { ManageClaimComponent } from './components/manage/driver-claims/manage-claim/manage-claim.component';
import { ManageConvictionComponent } from './components/manage/driver-convictions/manage-conviction/manage-conviction.component';
import { PersonalDetailsSimpleComponent } from './components/manage/personal-details-simple/personal-details-simple.component';
import { ConfirmRemoveModalComponent } from '@ren/shared/modals/components/confirm-remove-modal/confirm-remove-modal.component';
import { LicenceModalComponent } from './modals/licence-modal/licence-modal.component';

import * as fromYourDrivers from '@ren/features/your-drivers/state/reducers';

import { YOUR_DRIVERS_STORE_KEY } from '@ren/infrastructure/constants';



@NgModule({
  declarations: [
    YourDriversHoldingContainerComponent,
    DriverListContainerComponent,
    YourDriverListComponent,
    AdditionalDetailsComponent,
    YourDriverListItemComponent,
    ManageDriverHoldingContainerComponent,
    PersonalDetailsContainerComponent,
    DrivingLicenseNumberContainerComponent,
    DrivingHistoryContainerComponent,
    PersonalDetailsComponent,
    DrivingLicenseNumberComponent,
    DrivingHistoryComponent,
    ClaimConvictionListItemComponent,
    ManageClaimComponent,
    ManageConvictionComponent,
    DriverClaimsComponent,
    DriverConvictionsComponent,
    PersonalDetailsSimpleComponent,
    LicenceModalComponent
  ],
  imports: [
    AlertsModule,
    CoreUiModule,
    ErrorModule,
    ModalsModule,
    OccupationsModule,
    DirectivesModule,
    YourDriversRoutingModule,
    YourDriversServicesModule,
    PipesModule,
    StoreModule.forFeature(YOUR_DRIVERS_STORE_KEY, fromYourDrivers.reducers)
  ],
  entryComponents: [
    ConfirmRemoveModalComponent
  ]
})
export class YourDriversModule { }
