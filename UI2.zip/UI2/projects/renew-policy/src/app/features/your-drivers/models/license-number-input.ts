export interface LicenseNumberInput {
  firstName: string;
  lastName: string;
  dob: string[];
  title: string;
  gender: string;
}
