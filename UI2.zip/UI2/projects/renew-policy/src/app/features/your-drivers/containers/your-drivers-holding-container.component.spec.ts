import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YourDriversHoldingContainerComponent } from './your-drivers-holding-container.component';

describe('YourDriversHoldingContainerComponent', () => {
  let component: YourDriversHoldingContainerComponent;
  let fixture: ComponentFixture<YourDriversHoldingContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YourDriversHoldingContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YourDriversHoldingContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
