import { AbstractControl, ValidationErrors } from '@angular/forms';

export class YourDriversValidators {
  static dvlaSearchNotCompleted(getDvlaSearchResponse: () => any) {
    return function dvlaSearchNotCompleted(control: AbstractControl): ValidationErrors | null {
      const dvlaSearchResponse = getDvlaSearchResponse();
      if (dvlaSearchResponse) {
        return null;
      }
      return {dvlaSearchNotCompleted: true};
    };
  }
}
