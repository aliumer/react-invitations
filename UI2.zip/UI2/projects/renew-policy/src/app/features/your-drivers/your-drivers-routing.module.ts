import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OccupationResolverService } from '@ren/features/your-drivers/services/occupation-resolver/occupation-resolver.service';
import { DriverListResolverService } from '@ren/features/your-drivers/services/driver-list-resolver/driver-list-resolver.service';

import { YourDriversHoldingContainerComponent } from '@ren/features/your-drivers/containers/your-drivers-holding-container.component';
import { DriverListContainerComponent } from '@ren/features/your-drivers/containers/list/driver-list-container/driver-list-container.component';
import { ManageDriverHoldingContainerComponent } from '@ren/features/your-drivers/containers/manage/manage-driver-holding-container.component';
import { PersonalDetailsContainerComponent } from '@ren/features/your-drivers/containers/manage/personal-details-container/personal-details-container.component';
import { DrivingLicenseNumberContainerComponent } from '@ren/features/your-drivers/containers/manage/driving-license-number-container/driving-license-number-container.component';
import { DrivingHistoryContainerComponent } from '@ren/features/your-drivers/containers/manage/driving-history-container/driving-history-container.component';


const routes: Routes = [
  {
    path: '',
    component: YourDriversHoldingContainerComponent,
    resolve: {
      _: DriverListResolverService
    },
    children: [
      {
        path: 'list',
        component: DriverListContainerComponent
      },
      {
        path: 'add',
        component: ManageDriverHoldingContainerComponent,
        children: [
          {
            path: 'personal-details',
            component: PersonalDetailsContainerComponent,
            resolve: {
              occupations: OccupationResolverService
            }
          },
          {
            path: 'driving-license-number',
            component: DrivingLicenseNumberContainerComponent
          },
          {
            path: 'driving-history',
            component: DrivingHistoryContainerComponent
          }
        ]
      },
      {
        path: 'edit',
        component: ManageDriverHoldingContainerComponent,
        children: [
          {
            path: 'personal-details/:id',
            component: PersonalDetailsContainerComponent,
            resolve: {
              occupations: OccupationResolverService
            }
          },
          {
            path: 'driving-license-number/:id',
            component: DrivingLicenseNumberContainerComponent
          },
          {
            path: 'driving-history/:id',
            component: DrivingHistoryContainerComponent
          }
        ]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YourDriversRoutingModule { }
