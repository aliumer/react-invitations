export enum DvlaSearchStatusEnum {
  Successful = 'successful',
  SuccessfulExpiredLicence = 'successfulExpiredLicence',
  Unsuccessful = 'unsuccessful',
  SuccessfulNoData = 'successfulNoData'
}
