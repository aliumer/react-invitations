import { DvlaSearchStatusEnum } from '@ren/features/your-drivers/models/dvla-search-status.enum';

export interface DvlaSearchResponse {
  dvlaSearchStatus: DvlaSearchStatusEnum;
  dvlaSearchSuccessMessage: string;
  errorCode: string[];
  drivingLicenseNumber: string;
}
