export interface YearFormat {
  years:
    {
      min: number,
      max: number
    };
}
