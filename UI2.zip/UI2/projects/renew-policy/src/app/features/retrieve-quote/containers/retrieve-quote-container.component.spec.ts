import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetrieveQuoteContainerComponent } from './retrieve-quote-container.component';

describe('RetrieveQuoteContainerComponent', () => {
  let component: RetrieveQuoteContainerComponent;
  let fixture: ComponentFixture<RetrieveQuoteContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetrieveQuoteContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetrieveQuoteContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
