import { Component, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { of, Subscription } from 'rxjs';
import { concatMap } from 'rxjs/operators';

import { ModalRef, ModalService } from 'dlg-angular-components';

import { ErrorModalComponent } from '@ren/shared/modals/components/error-modal/error-modal.component';

import { MainActions, PolicyActions } from '@ren/main/state/actions';

import { selectLoadPolicyError } from '@ren/main/state/selectors/policy.selectors';

import { CustomHelpers } from '@ren/infrastructure/helpers/custom.helpers';

import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';

import { LoadPolicyConstants, MY_ACCOUNT_POLICY_DASHBOARD_URL } from '@ren/infrastructure/constants';



@Component({
  selector: 'app-retrieve-quote-container',
  templateUrl: './retrieve-quote-container.component.html'
})
export class RetrieveQuoteContainerComponent implements OnDestroy {
  private modal: ModalRef;
  private subscription$: Subscription;

  constructor(
    route: ActivatedRoute,
    private router: Router,
    private store: Store,
    private modalService: ModalService
  ) {
    this.clearStore();
    this.retrievePolicy(route.snapshot.paramMap.get('token'));
    this.observeOnError();
  }

  ngOnDestroy(): void {
    this.subscription$.unsubscribe();
  }

  private clearStore() {
    this.store.dispatch(MainActions.clearState());
  }

  private retrievePolicy(token: string) {
    if (token) {
      this.store.dispatch(PolicyActions.retrieveQuote({token}));
    } else {
      this.router.navigate([`${JourneyFeaturesConfig.errors.path}/retrieve-quote-failed`]);
    }
  }

  private observeOnError() {
    this.subscription$ = this.store.pipe(
      select(selectLoadPolicyError),
      concatMap(err => {
        if (err) {
          this.store.dispatch(PolicyActions.resetLoadPolicyError());
          this.modal = this.modalService.open(ErrorModalComponent);
          return this.modal.closed$;
        }
        return of({event: null});
      })
    ).subscribe(({event}) => {
      if (event === LoadPolicyConstants.BACK_TO_DASHBOARD) {
        CustomHelpers.redirectToExternalUrl(MY_ACCOUNT_POLICY_DASHBOARD_URL);
      }
    });
  }
}
