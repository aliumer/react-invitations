import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RetrieveQuoteContainerComponent } from '@ren/features/retrieve-quote/containers/retrieve-quote-container.component';


const routes: Routes = [
  {
    path: '',
    component: RetrieveQuoteContainerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RetrieveQuoteRoutingModule { }
