import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';

import { AlertsModule } from '@ren/shared/alerts/alerts.module';
import { LoadersModule } from '@ren/shared/loaders/loaders.module';
import { ModalsModule } from '@ren/shared/modals/modals.module';
import { RetrieveQuoteRoutingModule } from '@ren/features/retrieve-quote/retrieve-quote-routing.module';
import { RetrieveQuoteServicesModule } from '@ren/features/retrieve-quote/services/retrieve-quote-services.module';

import { RetrieveQuoteContainerComponent } from '@ren/features/retrieve-quote/containers/retrieve-quote-container.component';

import { RetrieveQuoteEffects } from '@ren/features/retrieve-quote/state/effects/retrieve-quote.effects';
import { ErrorModalComponent } from '@ren/shared/modals/components/error-modal/error-modal.component';



@NgModule({
  declarations: [RetrieveQuoteContainerComponent],
  imports: [
    LoadersModule,
    AlertsModule,
    ModalsModule,
    RetrieveQuoteRoutingModule,
    RetrieveQuoteServicesModule,
    EffectsModule.forFeature([RetrieveQuoteEffects])
  ],
  entryComponents: [
    ErrorModalComponent
  ]
})
export class RetrieveQuoteModule { }
