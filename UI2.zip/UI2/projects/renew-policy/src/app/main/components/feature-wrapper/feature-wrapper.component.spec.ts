import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { SharedModule } from '@app/shared/shared.module';

import { FeatureWrapperComponent } from './feature-wrapper.component';
import { LoadingIndicatorComponent } from '../loading-indicator/loading-indicator.component';


describe('FeatureWrapperComponent', () => {
  let component: FeatureWrapperComponent;
  let fixture: ComponentFixture<FeatureWrapperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        SharedModule
      ],
      declarations: [ FeatureWrapperComponent, LoadingIndicatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeatureWrapperComponent);
    component = fixture.componentInstance;
    component.panelConfig = { isVisible: false };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
