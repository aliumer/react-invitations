import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-section-heading',
  templateUrl: './section-heading.component.html'
})
export class SectionHeadingComponent {
  @Input() mainTitle: string;
  @Input() subTitle: string;
  @Input() titleIcon: string;
  @Input() policyId: string;
  @Input() isShowPolicyNumber: boolean;
  @Input() isNotification: boolean;
  @Input() policyChangeDate: Date;
}
