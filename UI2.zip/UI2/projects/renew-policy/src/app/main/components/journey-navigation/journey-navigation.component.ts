import { ChangeDetectionStrategy, Component, Input, ChangeDetectorRef, AfterViewChecked } from '@angular/core';
import { Store } from '@ngrx/store';

import { ButtonState } from '@ren/main/interfaces/button-state';



@Component({
  selector: 'app-journey-navigation',
  templateUrl: './journey-navigation.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class JourneyNavigationComponent implements AfterViewChecked {

  @Input() navigationDetails: ButtonState[];

  constructor(
    private store: Store<{}>,
    private cd: ChangeDetectorRef
  ) { }

  onButtonClick(fn: (store?: any) => any) {
    if (fn) {
      fn(this.store);
    }
  }

  ngAfterViewChecked(): void {
    this.cd.detectChanges();
  }
}
