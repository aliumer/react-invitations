import { Component, Input, OnChanges } from '@angular/core';

import { PanelState } from '@ren/main/interfaces/panel-state';



@Component({
  selector: 'app-feature-wrapper',
  templateUrl: './feature-wrapper.component.html',
})
export class FeatureWrapperComponent implements OnChanges {

  @Input() panelConfig: PanelState;
  @Input() policyId: string;
  @Input() isProgressing = false;
  @Input() policyChangeDate: Date;
  @Input() journeyPath: any;

  featureIndex = 0;
  currentFeatures: string[] = [];
  totalPages: number;
  titleIcon: string;

  onActivate(event) {
    window.scroll(0, 0);
  }

  ngOnChanges(): void {
    this.currentFeatures = this.journeyPath.path;
    this.totalPages = this.currentFeatures.length - 1;
    this.featureIndex = this.currentFeatures.indexOf(this.panelConfig.breadcrumbFeatureName);
    this.titleIcon = this.panelConfig.icon;
  }
}
