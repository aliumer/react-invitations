import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Store, StoreModule } from '@ngrx/store';

import { DlgWalrusModule } from 'dlg-angular-components';

import { JourneyNavigationComponent } from './journey-navigation.component';

import * as fromStp from '../../../stp/state/reducers';


describe('JourneyNavigationComponent', () => {
  let component: JourneyNavigationComponent;
  let fixture: ComponentFixture<JourneyNavigationComponent>;
  let store: Store<fromStp.State>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        DlgWalrusModule,
        RouterTestingModule,
        StoreModule.forRoot({}),
        StoreModule.forFeature('stpStore', fromStp.reducers)
      ],
      declarations: [ JourneyNavigationComponent ]
    })
    .compileComponents();

    store = TestBed.get(Store);
    spyOn(store, 'dispatch').and.callThrough();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JourneyNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
