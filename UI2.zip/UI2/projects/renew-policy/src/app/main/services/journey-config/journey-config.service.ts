import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { MainServicesModule } from '@ren/main/services/main-services.module';

import { FeatureState } from '@ren/main/interfaces/feature-state';

import { JourneyConfig } from '@ren/main/services/journey-config/journey.config';
import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';


@Injectable({
  providedIn: MainServicesModule
})
export class JourneyConfigService {

  getJourneyDetails(url: string): Observable<FeatureState> {
    // TODO: renew-policy => this needs to use the name and not path (also look at simplifying this) -nshathish
    let key;
    if (url.indexOf(JourneyFeaturesConfig.retrieveQuote.path) >= 0) {
      key = JourneyFeaturesConfig.retrieveQuote.path;
    } else if (url.indexOf(JourneyFeaturesConfig.loadQuote.path) >= 0) {
      key = JourneyFeaturesConfig.loadQuote.path;
    } else if (url.indexOf(JourneyFeaturesConfig.dashboard.path) >= 0) {
      key = JourneyFeaturesConfig.dashboard.path;
    } else if (url.indexOf(JourneyFeaturesConfig.yourCar.path) >= 0) {
      key = JourneyFeaturesConfig.yourCar.path;
    } else if (url.indexOf(JourneyFeaturesConfig.yourAddress.path) >= 0) {
      key = JourneyFeaturesConfig.yourAddress.path;
    } else if (url.indexOf(JourneyFeaturesConfig.yourCorrespondenceAddress.path) >= 0) {
      key = JourneyFeaturesConfig.yourCorrespondenceAddress.path;
    } else if (url.indexOf(JourneyFeaturesConfig.yourDriversList.path) >= 0) {
      key = JourneyFeaturesConfig.yourDriversList.path;
    } else if (url.indexOf(JourneyFeaturesConfig.addDriverPersonalDetails.path) >= 0) {
      key = JourneyFeaturesConfig.addDriverPersonalDetails.path;
    } else if (url.indexOf(JourneyFeaturesConfig.addDriverDln.path) >= 0) {
      key = JourneyFeaturesConfig.addDriverDln.path;
    } else if (url.indexOf(JourneyFeaturesConfig.addDriverDrivingHistory.path) >= 0) {
      key = JourneyFeaturesConfig.addDriverDrivingHistory.path;
    } else if (url.indexOf(JourneyFeaturesConfig.editDriverPersonalDetails.path) >= 0) {
      key = JourneyFeaturesConfig.editDriverPersonalDetails.path;
    } else if (url.indexOf(JourneyFeaturesConfig.editDriverDln.path) >= 0) {
      key = JourneyFeaturesConfig.editDriverDln.path;
    } else if (url.indexOf(JourneyFeaturesConfig.editDriverDrivingHistory.path) >= 0) {
      key = JourneyFeaturesConfig.editDriverDrivingHistory.path;
    } else if (url.indexOf(JourneyFeaturesConfig.premium.path) >= 0) {
      key = JourneyFeaturesConfig.premium.path;
    } else if (url.indexOf(JourneyFeaturesConfig.paymentList.path) >= 0) {
      key = JourneyFeaturesConfig.paymentList.path;
    } else if (url.indexOf(JourneyFeaturesConfig.creditCardNew.path) >= 0) {
      key = JourneyFeaturesConfig.creditCardNew.path;
    } else if (url.indexOf(JourneyFeaturesConfig.creditCardEdit.path) >= 0) {
      key = JourneyFeaturesConfig.creditCardEdit.path;
    } else if (url.indexOf(JourneyFeaturesConfig.directDebitNew.path) >= 0) {
      key = JourneyFeaturesConfig.directDebitNew.path;
    } else if (url.indexOf(JourneyFeaturesConfig.directDebitEdit.path) >= 0) {
      key = JourneyFeaturesConfig.directDebitEdit.path;
    } else if (url.indexOf(JourneyFeaturesConfig.directDebitReview.path) >= 0) {
      key = JourneyFeaturesConfig.directDebitReview.path;
    } else if (url.indexOf(JourneyFeaturesConfig.reviewInitial.path) >= 0) {
      key = JourneyFeaturesConfig.reviewInitial.path;
    } else if (url.indexOf(JourneyFeaturesConfig.reviewEdit.path) >= 0) {
      key = JourneyFeaturesConfig.reviewEdit.path;
    } else if (url.indexOf(JourneyFeaturesConfig.confirmAutoRenew.path) >= 0) {
      key = JourneyFeaturesConfig.confirmAutoRenew.path;
    } else if (url.indexOf(JourneyFeaturesConfig.confirmPaymentSuccess.path) >= 0) {
      key = JourneyFeaturesConfig.confirmPaymentSuccess.path;
    } else if (url.indexOf(JourneyFeaturesConfig.errors.path) >= 0) {
      key = JourneyFeaturesConfig.errors.path;
    } else if (url.indexOf(JourneyFeaturesConfig.lapsedRenewal.path) >= 0) {
      key = JourneyFeaturesConfig.lapsedRenewal.path;
    }

    const selectedDetails = JourneyConfig[key];
    return of(selectedDetails);
  }
}
