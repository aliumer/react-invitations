import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, mergeMap } from 'rxjs/operators';

import { SessionService } from '@ren/main/services/session/session.service';

import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';

import { SESSION_TIMEOUT_URL } from '@ren/infrastructure/constants';

@Injectable()
export class SessionInterceptorService implements HttpInterceptor {

  constructor(
    private router: Router,
    private sessionService: SessionService
  ) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (req.url.indexOf('sessions') >= 0) {
      return next.handle(req);
    }

    return this.sessionService.getSession().pipe(
      mergeMap(sessionId => {
        if (sessionId) {
          req = req.clone({
            setHeaders: {
              sessionId
            }
          });
        }
        return next.handle(req).pipe(
          catchError(err => {
            // TODO: implement this logic after release 1.1
            /*if(err.status === 401 && err.error?.toLowerCase().indexOf('jwt is not valid') >=0) {
              return throwError(new HttpResponse({ status: TIMEOUT_ERROR_CODE, statusText: TIMEOUT_STATUS_TEXT}));
            }*/

            /*const url = req.url.toLowerCase();
            if(url.indexOf('saveandquotechange') >= 0 || url.toLowerCase().indexOf('updatequotedcahnge') >= 0){
              return throwError(err);
            }*/

            const {status, error} = err;
            if (status === 404 && (error?.errorMessage.toLowerCase() === 'session not found' ||
              error?.statusText?.toLowerCase().indexOf('not found') >= 0)) {
              this.router.navigate([`${JourneyFeaturesConfig.errors.path}/${SESSION_TIMEOUT_URL}`]);
              return of({} as HttpEvent<any>);
            }
            return throwError(err);
          })
        );
      })
    );
  }
}
