import { TestBed } from '@angular/core/testing';

import { JourneyConfigService } from './journey-config.service';

describe('JourneyConfigService', () => {
  let service: JourneyConfigService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JourneyConfigService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
