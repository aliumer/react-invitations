import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { RenewActions } from '@ren/main/state/actions';


@Injectable()
export class LoaderInterceptorService  implements HttpInterceptor{

  private counter = 0;

  constructor(
    private store: Store
  ) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (req.url.indexOf('policyChangeIssuanceStatusCheck') > 0) {
      return next.handle(req);
    }

    this.counter++;
    this.store.dispatch(RenewActions.showProgressBar({isDisplayProgressBar: true}));

    return next.handle(req).pipe(
      finalize(() => {
        this.counter--;
        if (this.counter === 0) {
          this.store.dispatch(RenewActions.showProgressBar({isDisplayProgressBar: false}));
        }
      })
    );
  }
}
