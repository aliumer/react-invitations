import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import { MainServicesModule } from '@ren/main/services/main-services.module';

import { ResourceService } from '@ren/infrastructure/abstracts/resource.service';

import { Environment } from '@ren/infrastructure/models/environment';


@Injectable({
  providedIn: MainServicesModule
})
export class SessionService extends ResourceService<any> {

  constructor(
    httpClient: HttpClient,
    env: Environment
  ) {
    super(httpClient, env, 'sessions');
  }

  private static readonly SESSION_KEY = 'app-sessionid';

  public static clearSession(isClearSessionId = true) {
    if(!isClearSessionId) {
      const sessionId = SessionService.getSessionFromStorage();
      sessionStorage.clear();
      SessionService.setSessionToStorage(sessionId);
    } else {
      sessionStorage.clear();
    }
  }

  private static getSessionFromStorage(): any | null {
    const sessionObj = sessionStorage.getItem(SessionService.SESSION_KEY);
    return !!sessionObj ? JSON.parse(sessionObj) : null;
  }

  private static setSessionToStorage(data: any) {
    sessionStorage.removeItem(SessionService.SESSION_KEY);
    sessionStorage.setItem(SessionService.SESSION_KEY, JSON.stringify(data));
  }

  getSession(): Observable<string> {
    const sessionData = SessionService.getSessionFromStorage();
    return sessionData ? of(sessionData.sessionId) : this.createSession();
  }

  private createSession(): Observable<string> {
    return this.create(null, false).pipe(
      tap(data =>  SessionService.setSessionToStorage(data)),
      map(data => data.sessionId)
    );
  }
}
