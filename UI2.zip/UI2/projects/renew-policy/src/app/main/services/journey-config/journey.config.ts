import { JourneyNavigationActions } from '@ren/main/state/actions';

import { FeatureState } from '@ren/main/interfaces/feature-state';

import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';

import {
  ADD_DRIVER_PAGE_TITLE, CONFIRM_PAGE_TITLE,
  DASHBOARD_PAGE_TITLE, ERROR_PAGE_TITLE, PAYMENT_PAGE_TITLE, PREMIUM_PAGE_TITLE,
  RETRIEVE_QUOTE_TITLE, REVIEW_PAGE_TITLE, YOUR_ADDRESS_TITLE,
  YOUR_CAR_PAGE_TITLE, YOUR_CORRESPONDENCE_ADDRESS_TITLE, YOUR_DRIVER_PAGE_TITLE
} from '@ren/infrastructure/constants/page-titles.constant';


const retrieveQuote: FeatureState = {
  panelConfig: {
    isVisible: false,
    pageTitle: RETRIEVE_QUOTE_TITLE
  },
  navConfig: []
};

const loadQuote: FeatureState = {
  panelConfig: {
    isVisible: false,
    pageTitle: RETRIEVE_QUOTE_TITLE
  },
  navConfig: []
};

const lapsedRenewal: FeatureState = {
  panelConfig: {
    isVisible: false,
    pageTitle: RETRIEVE_QUOTE_TITLE
  },
  navConfig: [
    {
      label: 'Cancel',
      id: 'back',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null,
      isDisabled: false
    },
    {
      label: 'Continue',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      isDisabled: false,
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const dashboard: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: false,
    isShowPolicyNumber: true,
    mainTitle: 'Make a change',
    subTitle: 'Tell us what you want to change',
    breadcrumbFeatureName: JourneyFeaturesConfig.dashboard.name,
    pageTitle: DASHBOARD_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Cancel',
      id: 'back',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null,
      isDisabled: false
    },
    {
      label: 'Start quote',
      id: 'continue-ds',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      isDisabled: false,
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const yourCar: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: true,
    isShowPolicyNumber: true,
    mainTitle: 'Make a change',
    subTitle: 'Change your car',
    breadcrumbFeatureName: JourneyFeaturesConfig.yourCar.name,
    pageTitle: YOUR_CAR_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Cancel',
      id: 'cancel',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.cancelButtonClicked()),
      theme: null
    },
    {
      label: 'Next',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const yourAddress: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: true,
    isShowPolicyNumber: true,
    mainTitle: 'Make a change',
    subTitle: 'Change your policy address',
    breadcrumbFeatureName: JourneyFeaturesConfig.yourAddress.name,
    pageTitle: YOUR_ADDRESS_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Cancel',
      id: 'cancel',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.cancelButtonClicked()),
      theme: null
    },
    {
      label: 'Next',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const yourCorrespondenceAddress: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: true,
    isShowPolicyNumber: true,
    mainTitle: 'Make a change',
    subTitle: 'Change your correspondence address',
    breadcrumbFeatureName: JourneyFeaturesConfig.yourCorrespondenceAddress.name,
    pageTitle: YOUR_CORRESPONDENCE_ADDRESS_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Cancel',
      id: 'cancel',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.cancelButtonClicked()),
      theme: null
    },
    {
      label: 'Next',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const yourDriversList: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: true,
    isShowPolicyNumber: true,
    mainTitle: 'Make a change',
    subTitle: 'Add or remove drivers',
    breadcrumbFeatureName: JourneyFeaturesConfig.yourDrivers.name,
    pageTitle: YOUR_DRIVER_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Cancel',
      id: 'cancel',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.cancelButtonClicked()),
      theme: null
    },
    {
      label: 'Next',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const addDriverPersonalDetails: FeatureState = {
  panelConfig: {
    isVisible: false,
    isSectionWrapper: false,
    isNotification: false,
    isShowPolicyNumber: true,
    mainTitle: 'Add a driver',
    subTitle: 'Personal details',
    breadcrumbFeatureName: JourneyFeaturesConfig.yourDrivers.name,
    pageTitle: ADD_DRIVER_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Cancel',
      id: 'cancel',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Next',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const addDriverDln: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: false,
    isShowPolicyNumber: true,
    mainTitle: 'Add a driver',
    subTitle: 'Driving license number',
    breadcrumbFeatureName: JourneyFeaturesConfig.yourDrivers.name,
    pageTitle: ADD_DRIVER_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'back',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Cancel',
      id: 'cancel',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.cancelButtonClicked()),
      theme: null
    },
    {
      label: 'Skip',
      id: 'skip',
      css: 'section__button-list',
      ariaLabel: 'Skip',
      theme: null,
      onClick: (store) => store.dispatch(JourneyNavigationActions.skipButtonClicked())
    },
    {
      label: 'Next',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const addDriverDrivingHistory: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: false,
    isShowPolicyNumber: true,
    mainTitle: 'Add a driver',
    subTitle: 'Driving history',
    breadcrumbFeatureName: JourneyFeaturesConfig.yourDrivers.name,
    pageTitle: ADD_DRIVER_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'back',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Cancel',
      id: 'cancel',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Add this driver',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const editDriverPersonalDetails: FeatureState = {
  panelConfig: {
    isVisible: false,
    isSectionWrapper: false,
    isNotification: false,
    isShowPolicyNumber: true,
    mainTitle: 'Edit details',
    subTitle: 'Personal details',
    breadcrumbFeatureName: JourneyFeaturesConfig.yourDrivers.name,
    pageTitle: ADD_DRIVER_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Cancel',
      id: 'cancel',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Next',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const editDriverDln: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: false,
    isShowPolicyNumber: true,
    mainTitle: 'Edit details',
    subTitle: 'Driving license number',
    breadcrumbFeatureName: JourneyFeaturesConfig.yourDrivers.name,
    pageTitle: ADD_DRIVER_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'back',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Cancel',
      id: 'cancel',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.cancelButtonClicked()),
      theme: null
    },
    {
      label: 'Skip',
      id: 'skip',
      css: 'section__button-list',
      ariaLabel: 'Skip',
      theme: null,
      onClick: (store) => store.dispatch(JourneyNavigationActions.skipButtonClicked())
    },
    {
      label: 'Next',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const editDriverDrivingHistory: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: false,
    isShowPolicyNumber: true,
    mainTitle: 'Edit details',
    subTitle: 'Driving history',
    breadcrumbFeatureName: JourneyFeaturesConfig.yourDrivers.name,
    pageTitle: ADD_DRIVER_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'back',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Cancel',
      id: 'cancel',
      css: 'journey-service__button-back section__button-list',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.cancelButtonClicked()),
      theme: null
    },
    {
      label: 'Update',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const premium: FeatureState = {
  panelConfig: {
    isVisible: false,
    isSectionWrapper: false,
    isNotification: true,
    isShowPolicyNumber: false,
    breadcrumbFeatureName: JourneyFeaturesConfig.premium.name,
    pageTitle: PREMIUM_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Reject this quote',
      id: 'skip',
      css: 'section__button-list',
      ariaLabel: 'Skip',
      theme: null,
      onClick: (store) => store.dispatch(JourneyNavigationActions.skipButtonClicked())
    },
    {
      label: 'Save and review',
      id: 'continue',
      css: null,
      ariaLabel: 'Save and review',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const reviewInitial: FeatureState = {
  panelConfig: {
    isVisible: false,
    isSectionWrapper: false,
    isNotification: true,
    isShowPolicyNumber: false,
    mainTitle: 'Final check',
    subTitle: 'Review your policy details',
    breadcrumbFeatureName: JourneyFeaturesConfig.review.name,
    pageTitle: REVIEW_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back to My Dashboard',
      id: 'back',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Pay now',
      id: 'paynow',
      css: null,
      ariaLabel: 'Pay now',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const reviewEdit: FeatureState = {
  panelConfig: {
    isVisible: false,
    isSectionWrapper: false,
    isNotification: true,
    isShowPolicyNumber: false,
    mainTitle: 'Final check',
    subTitle: 'Review your policy details',
    breadcrumbFeatureName: JourneyFeaturesConfig.review.name,
    pageTitle: REVIEW_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Next',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const paymentList: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: false,
    isShowPolicyNumber: false,
    icon: 'padlock',
    mainTitle: 'Payment',
    subTitle: 'Payment',
    breadcrumbFeatureName: JourneyFeaturesConfig.payment.name,
    pageTitle: PAYMENT_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    }
  ]
}

const directDebitNew: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: false,
    isShowPolicyNumber: false,
    icon: 'padlock',
    mainTitle: 'Payment',
    subTitle: 'Add secure payment details',
    breadcrumbFeatureName: JourneyFeaturesConfig.directDebitNew.name,
    pageTitle: PAYMENT_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Next',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const directDebitEdit: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: false,
    isShowPolicyNumber: false,
    icon: 'padlock',
    mainTitle: 'Payment',
    subTitle: 'Payment details',
    breadcrumbFeatureName: JourneyFeaturesConfig.directDebitNew.name,
    pageTitle: PAYMENT_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Next',
      id: 'continue',
      css: null,
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const directDebitReview: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: false,
    isShowPolicyNumber: false,
    icon: 'padlock',
    mainTitle: 'Payment method',
    subTitle: 'Payment details',
    breadcrumbFeatureName: JourneyFeaturesConfig.directDebitReview.name,
    pageTitle: PAYMENT_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Cancel',
      id: 'cancel',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Pay for renewal',
      id: 'continue',
      css: null,
      ariaLabel: 'Pay for renewal',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const creditCardNew: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: false,
    isShowPolicyNumber: false,
    icon: 'padlock',
    mainTitle: 'Payment',
    subTitle: 'Add secure payment details',
    breadcrumbFeatureName: JourneyFeaturesConfig.creditCardNew.name,
    pageTitle: PAYMENT_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Securely enter card details',
      id: 'continue',
      css: 'dlg-button--no-max-width',
      ariaLabel: 'Continue',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const creditCardEdit: FeatureState = {
  panelConfig: {
    isVisible: true,
    isSectionWrapper: true,
    isNotification: false,
    isShowPolicyNumber: false,
    icon: 'padlock',
    mainTitle: 'Payment',
    subTitle: 'Update your payment details',
    breadcrumbFeatureName: JourneyFeaturesConfig.creditCardEdit.name,
    pageTitle: PAYMENT_PAGE_TITLE
  },
  navConfig: [
    {
      label: 'Back',
      id: 'back',
      css: 'journey-service__button-back',
      ariaLabel: 'cancel',
      onClick: (store) => store.dispatch(JourneyNavigationActions.backButtonClicked()),
      theme: null
    },
    {
      label: 'Enter security code',
      id: 'continue',
      css: null,
      ariaLabel: 'Enter security code',
      theme: 'primary',
      onClick: (store) => store.dispatch(JourneyNavigationActions.nextButtonClicked())
    }
  ]
};

const confirmAutoRenew: FeatureState = {
  panelConfig: {
    isVisible: false,
    isSectionWrapper: false,
    isNotification: true,
    isShowPolicyNumber: false,
    pageTitle: CONFIRM_PAGE_TITLE
  },
  navConfig: []
};

const confirmPaymentSuccess: FeatureState = {
  panelConfig: {
    isVisible: false,
    isSectionWrapper: false,
    isNotification: true,
    isShowPolicyNumber: false,
    pageTitle: CONFIRM_PAGE_TITLE
  },
  navConfig: []
};

const errors: FeatureState = {
  panelConfig: {
    isVisible: false,
    isSectionWrapper: false,
    pageTitle: ERROR_PAGE_TITLE,
    breadcrumbFeatureName: JourneyFeaturesConfig.errors.name
  },
  navConfig: []
};

export const JourneyConfig = {
  [JourneyFeaturesConfig.retrieveQuote.path]: retrieveQuote,
  [JourneyFeaturesConfig.loadQuote.path]: loadQuote,
  [JourneyFeaturesConfig.lapsedRenewal.path]: lapsedRenewal,
  [JourneyFeaturesConfig.dashboard.path]: dashboard,
  [JourneyFeaturesConfig.yourCar.path]: yourCar,
  [JourneyFeaturesConfig.yourAddress.path]: yourAddress,
  [JourneyFeaturesConfig.yourCorrespondenceAddress.path]: yourCorrespondenceAddress,
  [JourneyFeaturesConfig.yourDriversList.path]: yourDriversList,
  [JourneyFeaturesConfig.addDriverPersonalDetails.path]: addDriverPersonalDetails,
  [JourneyFeaturesConfig.addDriverDln.path]: addDriverDln,
  [JourneyFeaturesConfig.addDriverDrivingHistory.path]: addDriverDrivingHistory,
  [JourneyFeaturesConfig.editDriverPersonalDetails.path]: editDriverPersonalDetails,
  [JourneyFeaturesConfig.editDriverDln.path]: editDriverDln,
  [JourneyFeaturesConfig.editDriverDrivingHistory.path]: editDriverDrivingHistory,
  [JourneyFeaturesConfig.premium.path]: premium,
  [JourneyFeaturesConfig.reviewInitial.path]: reviewInitial,
  [JourneyFeaturesConfig.reviewEdit.path]: reviewEdit,
  [JourneyFeaturesConfig.paymentList.path]: paymentList,
  [JourneyFeaturesConfig.directDebitNew.path]: directDebitNew,
  [JourneyFeaturesConfig.directDebitEdit.path]: directDebitEdit,
  [JourneyFeaturesConfig.directDebitReview.path]: directDebitReview,
  [JourneyFeaturesConfig.creditCardNew.path]: creditCardNew,
  [JourneyFeaturesConfig.creditCardEdit.path]: creditCardEdit,
  [JourneyFeaturesConfig.confirmAutoRenew.path]: confirmAutoRenew,
  [JourneyFeaturesConfig.confirmPaymentSuccess.path]: confirmPaymentSuccess,
  [JourneyFeaturesConfig.errors.path]: errors
};
