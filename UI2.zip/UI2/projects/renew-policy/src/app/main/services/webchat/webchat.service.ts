import { Injectable } from '@angular/core';

import { MainServicesModule } from '@ren/main/services/main-services.module';

@Injectable({
  providedIn: MainServicesModule
})
export class WebchatService {

  waitForMethod(method) {
    let count = 0;
    const tries = 20;
    const timeToWait = 10000;
    const methodArray = method.split('.');
    return new Promise((resolve, reject) => {
      const interval = window.setInterval(() => {
        count++;
        if (count === tries) {
          window.clearInterval(interval);
          resolve(false);
        } else if (methodArray.length > 1) {
          if (methodArray.reduce((a, b) => {
            return a && a[b] ? a[b] : undefined;
          }, window)) {
            window.clearInterval(interval);
            resolve(true);
          }
        } else if (window[methodArray[0]]) {
          window.clearInterval(interval);
          resolve(true);
        }
      }, timeToWait / tries);
    });
  }

  setSDES(data) {
    this.waitForMethod('lpTag.sdes').then((value) => {
      if (value) {
        window.lpTag.sdes.push(data);
      }
    });
  }

  setCustomerPolicyIdSDES(policyId: string) {
    this.setSDES({
      type: 'ctmrinfo',
      info: {
        customerId: policyId
      }
    });
  }

}
