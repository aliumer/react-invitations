import { AfterViewChecked, ChangeDetectorRef, Component, OnInit, OnDestroy } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { select, Store } from '@ngrx/store';
import { Observable, Subject } from 'rxjs';
import { tap, filter, takeUntil } from 'rxjs/operators';

import { AnalyticsService } from '@ren/core/services/analytics/analytics.service';
import { WebchatService } from '@ren/main/services/webchat/webchat.service';

import { RenewActions } from '@ren/main/state/actions';

import { selectJourneyPath, selectNavigationDetails, selectPanelConfig } from '@ren/main/state/selectors/journey.selectors';
import { selectPolicyChangeDate, selectPolicyId, selectProgressbarDisplayStatus } from '@ren/main/state/selectors/renewal.selectors';

import { ButtonState } from '@ren/main/interfaces/button-state';
import { PanelState } from '@ren/main/interfaces/panel-state';
import { projectArea, projectTitle } from '@ren/infrastructure/constants/titles';
import { environment } from '@ren-env/environment';


@Component({
  selector: 'app-main-container',
  templateUrl: './main-container.component.html'
})
export class MainContainerComponent implements OnInit, AfterViewChecked, OnDestroy {

  keepTracking$: Subject<boolean> = new Subject<boolean>();

  navigationDetails$: Observable<ButtonState[]>;
  panelConfig$: Observable<PanelState>;
  isShowProgressBar$: Observable<boolean>;
  policyId$: Observable<string>;
  policyChangeDate$: Observable<Date>;
  journeyPath$: Observable<any>;

  policyId: string;

  brandName = environment.brand_copy.brand;

  constructor(
    private store: Store,
    private cd: ChangeDetectorRef,
    private title: Title,
    private router: Router,
    private analyticsService: AnalyticsService,
    private webChatService: WebchatService
  ) {
  }

  setSection(journey, page) {
    if (journey && page) {
      window.lpTag.newPage(window.location.href);
      window.lpTag.section = [this.brandName, projectArea, journey, page];
    }
  }

  ngOnInit(): void {
    this.store.dispatch(RenewActions.showProgressBar({isDisplayProgressBar: false}));
    this.navigationDetails$ = this.store.pipe(select(selectNavigationDetails));
    this.panelConfig$ = this.store.pipe(select(selectPanelConfig),
      tap(config => {
        if (config.pageTitle) {
          this.title.setTitle(config.pageTitle);
        }
      })
    );
    this.policyId$ = this.store.pipe(select(selectPolicyId),
      tap(policyId => {
        this.policyId = policyId;
      })
    );
    this.policyChangeDate$ = this.store.pipe(select(selectPolicyChangeDate));
    this.journeyPath$ = this.store.pipe(select(selectJourneyPath));

    this.isShowProgressBar$ = this.store.pipe(select(selectProgressbarDisplayStatus));
    this.trackPage();
  }

  ngAfterViewChecked(): void {
    this.cd.detectChanges();
  }

  ngOnDestroy(): void {
    this.keepTracking$.next(false);
    this.keepTracking$.unsubscribe();
  }

  private trackPage(): void {
    this.router.events.pipe(
      filter((event) => event instanceof NavigationEnd),
      takeUntil(this.keepTracking$)
    ).subscribe((event: NavigationEnd) => {
      this.analyticsService.trackPage();
      if (window.hasOwnProperty('utag')) {
        if (window.location.pathname.split('/').indexOf('review') === -1) {
          window.utag.view();
        }
      }
      this.webChatTrackSection(event);
    });
  }

  private webChatTrackSection(event): void {
    const interval = setInterval(() => {
      if (window.lpTag && window.lpTag.loaded) {
        clearInterval(interval);
        const journey = projectTitle;
        const pageName: string = this.normaliseRoute(event.url)[0];
        this.setSection(journey, pageName);
        this.webChatService.setCustomerPolicyIdSDES(this.policyId);
      }
    }, 2000);
  }

  private normaliseRoute(route) {
    const pathSegments = route.split('/');
    pathSegments.forEach((segment, index) => {
      if (segment === '') {
        pathSegments.splice(index, 1);
      }
    });
    return pathSegments;
  }

}
