export interface JourneyPath {
  path?: string[];
}
