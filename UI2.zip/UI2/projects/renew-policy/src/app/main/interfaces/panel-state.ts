export interface PanelState {
  isVisible: boolean;
  isNotification?: boolean;
  isShowPolicyNumber?: boolean;
  isSectionWrapper?: boolean;
  icon?: string;
  mainTitle?: string;
  subTitle?: string;
  breadcrumbFeatureName?: string;
  pageTitle?: string;
}
