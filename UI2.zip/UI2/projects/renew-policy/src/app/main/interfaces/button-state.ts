export interface ButtonState {
  id: string;
  label: string;
  css: string;
  ariaLabel: string;
  theme: string;
  onClick: (store?: any) => any;
  isDisabled?: boolean;
  isHidden?: boolean;
}
