import { ButtonState } from './button-state';
import { PanelState } from './panel-state';

export interface FeatureState {
  panelConfig: PanelState;
  navConfig: ButtonState[];
}
