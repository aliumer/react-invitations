import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';


const routes: Routes = [
  {
    path: `${JourneyFeaturesConfig.retrieveQuote.path}/:token`,
    loadChildren: () => import('../features/retrieve-quote/retrieve-quote.module').then(m => m.RetrieveQuoteModule)
  },
  {
    path: `${JourneyFeaturesConfig.loadQuote.path}/:token`,
    loadChildren: () => import('../features/retrieve-quote/retrieve-quote.module').then(m => m.RetrieveQuoteModule)
  },
  {
    path: `${JourneyFeaturesConfig.lapsedRenewal.path}`,
    loadChildren: () => import('../features/lapsed-renewal/lapsed-renewal.module').then(m => m.LapsedRenewalModule)
  },
  {
    path: JourneyFeaturesConfig.dashboard.path,
    loadChildren: () => import('../features/dashboard/dashboard.module').then(m => m.DashboardModule)
  },
  {
    path: JourneyFeaturesConfig.yourCar.path,
    loadChildren: () => import('../features/your-car/your-car.module').then(m => m.YourCarModule)
  },
  {
    path: JourneyFeaturesConfig.yourAddress.path,
    loadChildren: () => import('../features/your-address/your-address.module').then(m => m.YourAddressModule)
  },
  {
    path: JourneyFeaturesConfig.yourCorrespondenceAddress.path,
    loadChildren: () => import('../features/your-correspondence-address/your-correspondence-address.module').then(m => m.YourCorrespondenceAddressModule)
  },
  {
    path: JourneyFeaturesConfig.yourDrivers.path,
    loadChildren: () => import('../features/your-drivers/your-drivers.module').then(m => m.YourDriversModule)
  },
  {
    path: JourneyFeaturesConfig.premium.path,
    loadChildren: () => import('../features/premium/premium.module').then(m => m.PremiumModule)
  },
  {
    path: JourneyFeaturesConfig.review.path,
    loadChildren: () => import('../features/review/review.module').then(m => m.ReviewModule)
  },
  {
    path: JourneyFeaturesConfig.payment.path,
    loadChildren: () => import('../features/payment/payment.module').then(m => m.PaymentModule)
  },
  {
    path: JourneyFeaturesConfig.confirm.path,
    loadChildren: () => import('../features/confirm/confirm.module').then(m => m.ConfirmModule)
  },
  {
    path: JourneyFeaturesConfig.errors.path,
    loadChildren: () => import('../features/errors/errors.module').then(m => m.ErrorsModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {onSameUrlNavigation: 'reload', enableTracing: false})],
  exports: [RouterModule]
})
export class MainRoutingModule {
}
