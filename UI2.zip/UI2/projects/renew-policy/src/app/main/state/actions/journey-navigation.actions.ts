import { createAction, props, union } from '@ngrx/store';

import { FeatureState } from '@ren/main/interfaces/feature-state';
import { JourneyPath } from '@ren/main/interfaces/journey-path-state';
import { KeyValueDict } from '@ren/infrastructure/interfaces/key-value-dict';


export const loadNextJourneyDetails = createAction(
  '[JourneyNavigation] Load Next Journey Details',
  props<{ nextJourneyDetails: FeatureState }>()
);

export const buildJourneyPath = createAction(
  '[JourneyNavigation] Build Journey Path',
  props<{ journeyPath: JourneyPath }>()
);

export const setNavDirection = createAction(
  '[JourneyNavigation] Set Nav Direction',
  props<{ navDirection: number }>()
);

export const setupNavigation = createAction(
  '[JourneyNavigation] Setup Navigation',
  props<{ navCommands: KeyValueDict<string> }>()
);

export const changeButtonStatus = createAction(
  '[JourneyNavigation] Change Button Status',
  props<{ id: string, status: boolean }>()
);

export const changeButtonLabel = createAction(
  '[JourneyNavigation] Change Button Label',
  props<{ id: string, value: string }>()
);

export const changeButtonVisibility = createAction(
  '[JourneyNavigation] Change Button Visibility',
  props<{ id: string, status: boolean }>()
);

export const nextButtonClicked = createAction(
  '[JourneyNavigation] Next Button Clicked'
);

export const backButtonClicked = createAction(
  '[JourneyNavigation] Back Button Clicked'
);

export const cancelButtonClicked = createAction(
  '[JourneyNavigation] Cancel Button Clicked'
);

export const skipButtonClicked = createAction(
  '[JourneyNavigation] Skip Button Clicked'
);

export const resetButtons = createAction(
  '[JourneyNavigation] Reset Buttons'
);



const all = union({
  loadNextJourneyDetails,
  buildJourneyPath,
  setNavDirection,
  changeButtonStatus,
  changeButtonVisibility,
  nextButtonClicked,
  backButtonClicked,
  cancelButtonClicked,
  skipButtonClicked,
  resetButtons
});

export type JourneyNavigationActionsUnion = typeof all;
