import { createReducer, on } from '@ngrx/store';

import { PolicyActionsUnion } from '@ren/main/state/actions/policy.actions';
import { PolicyActions } from '@ren/main/state/actions';

import { KeyValueDict } from '@ren/infrastructure/interfaces/key-value-dict';


export interface PolicyState {
  initialState: {
    policyDetails: any;
    error: any;
  };
  requestPayload: {
    premium: any;
  };
  finalState: {
    boundPolicy: any;
  };
  errors: {
    isInlineError: boolean;
    isInvalidPromoCode: boolean;
  };
  changes: KeyValueDict<any>;
}

export const initialState: PolicyState = {
  initialState: {
    policyDetails: null,
    error: null
  },
  requestPayload: {
    premium: null
  },
  finalState: {
    boundPolicy: null
  },
  errors: {
    isInlineError: false,
    isInvalidPromoCode: false,
  },
  changes: null
};


const policyReducer = createReducer(
  initialState,
  on(PolicyActions.retrieveQuoteSucceeded, updateInitialStateOnLoadSuccess),
  on(PolicyActions.retrieveQuoteFailed, updateInitialStateOnFailure),
  on(PolicyActions.updatePayloadChanges, (state, {data}) => ({...state, changes: {...state.changes, ...data}})),
  on(PolicyActions.replaceRequestPayloadWithNewQuote, replaceRequestPayloadWithNewQuote),
  on(PolicyActions.replaceInitialQuoteWithNewQuote, replaceInitialQuoteWithNewQuote),
  on(PolicyActions.resetPayloadChanges, state => ({...state, changes: null})),
  on(PolicyActions.updateInvalidPromoCodeError, state => ({...state, errors: {...state.errors, isInvalidPromoCode: true}})),
  on(PolicyActions.updateInlineError, state => ({...state, errors: {...state.errors, isInlineError: true}})),
  on(PolicyActions.updateSelectedPaymentBillingId, updateSelectedPaymentBillingId),
  on(PolicyActions.updateBoundPolicy, (state, {boundPolicy}) => ({...state, finalState: {boundPolicy}})),
  on(PolicyActions.resetErrors, state => ({...state, errors: {isInlineError: false, isInvalidPromoCode: false}}))
);

export function reducer(state: PolicyState | undefined, action: PolicyActionsUnion) {
  return policyReducer(state, action);
}

function updateInitialStateOnLoadSuccess(state, {data: policyDetails}) {
  return {
    ...state,
    initialState: {policyDetails: policyDetails.result, error: null},
    requestPayload: {premium: policyDetails.result}
  };
}

function updateInitialStateOnFailure(state, {error}) {
  return {
    ...state,
    initialState: {error, policyDetails: null},
    requestPayload: {premium: null}
  };
}

function updateSelectedPaymentBillingId(state, {selectedPaymentPlan}) {
  const {requestPayload, requestPayload: {premium, premium: {bindData}}} = state;
  return {
    ...state,
    requestPayload: {
      ...requestPayload,
      premium: {
        ...premium,
        bindData: {
          ...bindData,
          selectedPaymentPlan
        }
      }
    }
  };
}

function replaceRequestPayloadWithNewQuote(state, {premium}) {
  return {
    ...state,
    requestPayload: {premium},
    errors: {...state.errors, isInlineError: false, isInvalidPromoCode: false}
  };
}

function replaceInitialQuoteWithNewQuote(state, {data}) {
  return {
    ...state,
    initialState: {
      policyDetails: data,
      error: null
    },
    requestPayload: {premium: data},
    errors: {...state.errors, isInlineError: false, isInvalidPromoCode: false}
  };
}
