import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { RouterNavigationAction, ROUTER_NAVIGATED, ROUTER_ERROR } from '@ngrx/router-store';
import { of } from 'rxjs';
import { concatMap, map } from 'rxjs/operators';

import { JourneyConfigService } from '@ren/main/services/journey-config/journey-config.service';

import { JourneyNavigationActions } from '@ren/main/state/actions';


@Injectable()
export class JourneyNavigationEffects {

  loadJourneyStates$ = createEffect(() => this.actions$.pipe(
    ofType<RouterNavigationAction>(ROUTER_NAVIGATED),
    concatMap(action => {
      return this.journeyConfigService.getJourneyDetails(action.payload.event.url).pipe(
        map(
          (nextJourneyDetails) => JourneyNavigationActions.loadNextJourneyDetails({ nextJourneyDetails })
        )
      );
    })
  ));

  // TODO: add ROUTER_CANCEL
  setNavDirectionStates$ = createEffect(() => this.actions$.pipe(
    ofType<RouterNavigationAction>(ROUTER_NAVIGATED, ROUTER_ERROR),
    concatMap(action => {
      return of(JourneyNavigationActions.setNavDirection({navDirection: 0}));
    })
  ));

  constructor(
    private actions$: Actions,
    private journeyConfigService: JourneyConfigService
  ) {}

}
