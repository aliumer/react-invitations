import { createAction } from '@ngrx/store';

export const clearState = createAction(
  '[Main] Clear State'
);

export const redirectToMyAccountDashboard = createAction(
  '[Main] Redirect To MyAccount Dashboard'
);
