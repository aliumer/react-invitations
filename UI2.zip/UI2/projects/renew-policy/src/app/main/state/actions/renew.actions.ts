import { createAction, props, union } from '@ngrx/store';
import { KeyValueDict } from '@app/infrastructure/interfaces/key-value-dict';

export const showProgressBar = createAction(
  '[RenewState] Show Progress Bar',
  props<{ isDisplayProgressBar: boolean }>()
);

export const updatePolicyChangeOptions = createAction(
  '[RenewState] Update Policy Change Options',
  props<{ options: KeyValueDict<boolean> }>()
);

export const updateQuotedStatus = createAction(
  '[RenewState] Update Quoted Status',
  props<{ isQuoted: boolean }>()
);

export const updateNewVersionStatus = createAction(
  '[RenewState] Update New Version Status',
  props<{isNewVersionCreated: boolean}>()
);

export const resetPolicySelections = createAction(
  '[RenewState] Reset Policy Selections'
);

export const rejectQuote = createAction(
  '[RenewState] Reject Quote'
);

export const cancelChanges = createAction(
  '[RenewState] Cancel Changes'
);

const all = union({
  showProgressBar,
  updatePolicyChangeOptions,
  updateNewVersionStatus,
  updateQuotedStatus,
  resetPolicySelections,
  rejectQuote,
  cancelChanges
});

export type RenewActionsUnion = typeof all;
