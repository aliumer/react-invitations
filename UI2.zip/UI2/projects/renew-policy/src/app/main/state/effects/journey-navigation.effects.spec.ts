import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { JourneyConfigService } from '@app/stp/services/journey-config/journey-config.service';

import { JourneyNavigationEffects } from './journey-navigation.effects';


describe('JourneyNavigationEffects', () => {
  // tslint:disable-next-line:prefer-const
  let actions$: Observable<any>;
  let effects: JourneyNavigationEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        JourneyNavigationEffects,
        JourneyConfigService,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(JourneyNavigationEffects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
