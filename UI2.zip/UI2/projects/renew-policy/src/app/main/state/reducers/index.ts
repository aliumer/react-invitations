import { ActionReducer, ActionReducerMap, MetaReducer } from '@ngrx/store';
import { routerReducer, RouterReducerState } from '@ngrx/router-store';
import { localStorageSync } from 'ngrx-store-localstorage';

import { SessionService } from '@ren/main/services/session/session.service';

import { reducer as journeyNavigationReducer, JourneyNavigationState } from '@ren/main/state/reducers/journey-navigation.reducer';
import { reducer as policyReducer, PolicyState } from '@ren/main/state/reducers/policy.reducer';
import { reducer as renewalReducer, RenewalState } from '@ren/main/state/reducers/renewal.reducer';

import { MainActions, RenewActions } from '@ren/main/state/actions';

import { CustomHelpers } from '@ren/infrastructure/helpers/custom.helpers';

import { environment } from '@ren-env/environment';
import {
  DASHBOARD_STORE_KEY,
  MAIN_STORE_KEY,
  MY_ACCOUNT_POLICY_DASHBOARD_URL,
  REVIEW_STORE_KEY,
  YOUR_ADDRESS_STORE_KEY,
  YOUR_CAR_STORE_KEY,
  YOUR_CORRESPONDENCE_ADDRESS_STORE_KEY,
  YOUR_DRIVERS_STORE_KEY,
  PAYMENT_STORE_KEY
} from '@ren/infrastructure/constants';


export interface State {
  router: RouterReducerState;
  journeyNavigationState: JourneyNavigationState;
  policyState: PolicyState;
  renewState: RenewalState;
}

export const reducers: ActionReducerMap<State> = {
  router: routerReducer,
  journeyNavigationState: journeyNavigationReducer,
  policyState: policyReducer,
  renewState: renewalReducer
};


let shouldRehydrate = true;
let clearSession = false;

function sessionStorageSyncReducer(reducer: ActionReducer<any>) {
  return localStorageSync({
    keys: [
      MAIN_STORE_KEY,
      DASHBOARD_STORE_KEY,
      YOUR_CAR_STORE_KEY,
      YOUR_ADDRESS_STORE_KEY,
      YOUR_CORRESPONDENCE_ADDRESS_STORE_KEY,
      YOUR_DRIVERS_STORE_KEY,
      REVIEW_STORE_KEY,
      PAYMENT_STORE_KEY
    ],
    storage: sessionStorage,
    rehydrate: shouldRehydrate,
    removeOnUndefined: clearSession
  })(reducer);
}

function clearState(reducer) {
  // tslint:disable-next-line:only-arrow-functions
  return function(state, action) {
    const actionType = action.type;
    if (actionType === MainActions.redirectToMyAccountDashboard.type ||
      actionType === MainActions.clearState.type) {
      shouldRehydrate = false;
      clearSession = true;
      SessionService.clearSession();
      if (actionType === MainActions.redirectToMyAccountDashboard.type) {
        setTimeout(() => {
          // prevent brief empty dashboard display when navigating back to My Account from Temp state
          state = undefined;
        });
        CustomHelpers.redirectToExternalUrl(MY_ACCOUNT_POLICY_DASHBOARD_URL);
      } else {
        state = undefined;
      }
    } else if (actionType === RenewActions.rejectQuote.type || actionType === RenewActions.cancelChanges.type) {
      shouldRehydrate = false;
      clearSession = true;
      SessionService.clearSession(false);

      state = mapStateForCancelOrReject(state);
    }

    return reducer(state, action);
  };
}

function mapStateForCancelOrReject(state): typeof state {
  const {
    mainStore: {journeyNavigationState, policyState: {initialState}}
  } = state;

  let newState: typeof state = {
    mainStore: {
      router: state.mainStore.router,
      journeyNavigationState: {...journeyNavigationState, navDirection: 1},
      policyState: {
        initialState,
        requestPayload: {
          premium: initialState.policyDetails
        },
        errors: {
          isInlineError: false,
          isInvalidPromoCode: false,
        },
        finalState: {
          boundPolicy: null
        },
        changes: null
      }
    }
  };

  if (state.dashboardStore) {
    const {dashboardStore: {dashboardState}} = state;
    newState = {
      ...newState,
      dashboardStore: {
        dashboardState: {
          ...dashboardState,
          alterOptions: {
            yourCar: false,
            yourAddress: false,
            yourCorrespondenceAddress: false,
            yourDrivers: false,
          }
        }
      }
    };
  }

  return newState;
}

export const metaReducers: MetaReducer<{}>[] = [clearState, sessionStorageSyncReducer, ...!environment.production ? [] : []];
