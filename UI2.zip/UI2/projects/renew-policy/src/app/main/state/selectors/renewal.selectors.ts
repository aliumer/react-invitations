import { createFeatureSelector, createSelector } from '@ngrx/store';

import { State } from '@ren/main/state/reducers';


const mainStore = createFeatureSelector<State>('mainStore');

const selectRenewalState = createSelector(
  mainStore,
  state => state.renewState
);

const selectInitialPolicyDetails = createSelector(
  mainStore,
  (state: State) => state?.policyState.initialState.policyDetails
);


export const selectPolicyId = createSelector(
  selectInitialPolicyDetails,
  policyDetails => policyDetails?.policyNumber || 'NA'
);

export const selectProgressbarDisplayStatus = createSelector(
  selectRenewalState,
  state => state.isDisplayProgressBar
);

export const selectPolicyChangeSelection = createSelector(
  selectRenewalState,
  state => state.policyChangeSelection
);

export const selectPolicyChangeDate = createSelector(
  selectInitialPolicyDetails,
  policyDetails => {
    const changeDate = policyDetails?.baseData.periodStartDate;
    if (changeDate) {
      const {year, month, day} = changeDate;
      return new Date(year, month, day);
    }
    return null;
  }
);

export const selectQuotedStatus = createSelector(
  selectRenewalState,
  state => state.isQuoted
);

export const selectPolicyChangeSelectionLockedStatus = createSelector(
  selectRenewalState,
  state => state.policyChangeSelectionLockedStatus
);

/*export const selectNewVersionCreatedStatus = createSelector(
  selectRenewalState,
  state => state.isNewVersionCreated
);*/
