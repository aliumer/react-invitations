import { createSelector } from '@ngrx/store';

import { selectPolicyChangeSelection } from '@ren/main/state/selectors/renewal.selectors';
import { selectPolicyState } from '@ren/main/state/selectors/policy.selectors';

import { GwHelpers } from '@app/infrastructure/helpers/gw-helpers';

import { ChangeTypeEnum } from '@app/infrastructure/enums/change-type.enum';
import { PaymentBillingIdEnum } from '@ren/infrastructure/enums/payments.enum';
import { CustomHelpers } from '@ren/infrastructure/helpers/custom.helpers';


export const selectRenewalRequestPayload = createSelector(
  selectPolicyChangeSelection,
  selectPolicyState,
  (policyChangeSelection, state) => {

    const {options} = policyChangeSelection;
    const {requestPayload: {premium}, changes} = state;

    if (!options) {
      return premium;
    }

    let requestPayload = premium;

    if (!options) {
      return requestPayload;
    }

    const {yourCar, yourAddress, yourCorrespondenceAddress, yourDrivers} = options;

    if (yourCar) {
      requestPayload = updatePermVehicleDetails(requestPayload, changes.yourCar);
    }
    if (yourAddress) {
      requestPayload = updateAddressDetails(requestPayload, changes.yourAddress);
    }
    if (yourCorrespondenceAddress) {
      requestPayload = updateYourCorrespondenceAddressDetails(requestPayload, changes.yourCorrespondenceAddress);
    }
    if (yourDrivers) {
      requestPayload = updateDrivers(requestPayload, changes.yourDrivers);
    }

    return requestPayload;
  }
);

export const selectDirectDebitReviewResolverPayload = createSelector(
  selectPolicyState,
  state => {
    const {requestPayload: {premium}, changes} = state;

    if (!changes?.payment) {
      return {
        ...premium,
        bindData: {
          ...premium.bindData,
          selectedPaymentMethod: 'DirectDebit',
          selectedPaymentPlan: PaymentBillingIdEnum.PayMonthly,
          renewThisVersionInd_dlg: true,
          recvRenewalNoticeInd_dlg: true
        }
      };
    }

    const {paymentDetails} = changes.payment;
    return {
      ...premium,
      bindData: {
        ...premium.bindData,
        directDebitDetails_dlg: paymentDetails,
        selectedPaymentMethod: 'DirectDebit',
        selectedPaymentPlan: PaymentBillingIdEnum.PayMonthly,
        renewThisVersionInd_dlg: true,
        recvRenewalNoticeInd_dlg: true,
        autoRenewInd_dlg: paymentDetails.isAutoRenewal
      }
    };
  }
);

function updatePermVehicleDetails(premium, vehicle) {
  const {lobData: {mOTLine_Ext, mOTLine_Ext: {coverables: {drivers, motVehicles, vehicleDrivers}}}} = premium;
  const tempVehicles = motVehicles.filter(v => v.vehicle.typeOfVehicle.toLowerCase() === ChangeTypeEnum.Temporary);
  const permVehicle = motVehicles.filter(v => v.vehicle.typeOfVehicle.toLowerCase() === ChangeTypeEnum.Permanent)[0];
  const {
    garageNightPostcode,
    isVehicleGarageAtHome,
    monthsNoClaim,
    ncdEarn,
    ncdOwnerInUse,
    primaryUse,
    publicID,
    fixedId,
    schItems,
    travellingInd,
    typeOfVehicle,
    yearsNoClaim,
    vehicleEndorsement,
  } = permVehicle.vehicle;

  const updatedVehicle = vehicle.isVRNChanged ? vehicle:mergeVehicleDetailsForNonVrnChange(permVehicle.vehicle, vehicle);

  return {
    ...premium,
    lobData: {
      mOTLine_Ext: {
        ...mOTLine_Ext,
        coverables: {
          drivers,
          vehicleDrivers,
          motVehicles: [
            ...tempVehicles,
            {
              ...permVehicle,
              vehicle: {
                garageNightPostcode,
                isVehicleGarageAtHome,
                monthsNoClaim,
                ncdEarn,
                ncdOwnerInUse,
                primaryUse,
                publicID,
                fixedId,
                schItems,
                travellingInd,
                typeOfVehicle,
                yearsNoClaim,
                vehicleEndorsement,
                ...updatedVehicle
              }
            }
          ]
        }
      }
    }
  };
}

function updateAddressDetails(premium, newAddressData) {
  const {lobData: {mOTLine_Ext, mOTLine_Ext: {coverables: {drivers, motVehicles, vehicleDrivers}}}} = premium;
  const permVehicle = motVehicles.filter(v => v.vehicle.typeOfVehicle === ChangeTypeEnum.Permanent)[0];
  const tempVehicles = motVehicles.filter(v => v.vehicle.typeOfVehicle === ChangeTypeEnum.Temporary);

  return {
    ...premium,
    baseData: {
      ...premium.baseData,
      policyAddress: {
        ...premium.baseData.policyAddress,
        ...newAddressData.addressDetails
      }
    },
    lobData: {
      ...premium.lobData,
      mOTLine_Ext: {
        ...mOTLine_Ext,
        coverables: {
          drivers,
          vehicleDrivers,
          motVehicles: [
            ...tempVehicles,
            {
              ...permVehicle,
              vehicle: {
                ...permVehicle.vehicle,
                ...newAddressData.overNightDetails,
                garageNightPostcode: newAddressData.overNightDetails.garageNightPostcode,
              }
            }
          ]
        }
      }
    },
  };
}

function updateYourCorrespondenceAddressDetails(premium, newAddressData) {
  return {
    ...premium,
    baseData: {
      ...premium.baseData,
      isCorrespondAdSameAsPolAd_dlg: false,
      polCorrespondenceAddress_dlg: {
        ...newAddressData.addressDetails
      }
    }
  };
}

function updateDrivers(premium, {drivers: allDrivers, removedDrivers, additionalDetails}) {
  const {lobData: {mOTLine_Ext, mOTLine_Ext: {coverables: {drivers, motVehicles, vehicleDrivers}}}} = premium;

  const newDrivers = allDrivers.filter(d => !d.fixedId).map(CustomHelpers.removeNullEntriesV2);
  const oldDrivers = allDrivers.filter(d => d.fixedId);
  const updatedDrivers = drivers.map(d => {
    const temp = oldDrivers.find(od => od.fixedId === d.fixedId);
    if (!temp) {
      return d;
    }
    return CustomHelpers.removeNullEntriesV2({...d, ...temp});
  }).filter(d => {
    const i = removedDrivers.findIndex(id => d.fixedId === id);
    return i < 0;
  });

  return {
    ...premium,
    baseData: {
      ...premium.baseData,
      cancelByInsurerInd_dlg: GwHelpers.convertToBoolean(additionalDetails.hasPolicyCancelled)
    },
    lobData: {
      mOTLine_Ext: {
        ...mOTLine_Ext,
        coverables: {
          drivers: [
            ...updatedDrivers,
            ...newDrivers
          ],
          vehicleDrivers: [
            ...vehicleDrivers.map(vd => ({
              ...vd,
              driversID: [
                ...updatedDrivers.map(d => d.publicID),
                ...newDrivers.map(d => d.tempDigitalId_dlg)
              ]
            }))
          ],
          motVehicles
        }
      }
    }
  };
}

function mergeVehicleDetailsForNonVrnChange(oldVehicle, newVehicle) {
  const {
    annualMileage,
    registeredOwner,
    isVehiclePurchased,
    isVehicleModified,
    modifications,
    purchaseDate,
    isVRNChanged
  } = newVehicle;
  return {
    ...oldVehicle,
    annualMileage,
    registeredOwner,
    isVehiclePurchased,
    isVehicleModified,
    modifications,
    purchaseDate,
    isVRNChanged
  };
}


