import { createReducer, on } from '@ngrx/store';

import { RenewActionsUnion } from '@ren/main/state/actions/renew.actions';
import { RenewActions } from '@ren/main/state/actions';

import { KeyValueDict } from '@app/infrastructure/interfaces/key-value-dict';


export interface RenewalState {
  isDisplayProgressBar: boolean;
  isQuoted: boolean;
  isNewVersionCreated: boolean;
  renewalStartDate: Date;
  policyChangeSelection: {
    options: KeyValueDict<boolean>;
  };
  policyChangeSelectionLockedStatus: {
    yourCar: boolean;
    yourDrivers: boolean;
    yourAddress: boolean;
    yourCorrespondenceAddress: boolean;
  }
}

export const initialState: RenewalState = {
  isDisplayProgressBar: false,
  isQuoted: false,
  isNewVersionCreated: false,
  renewalStartDate: null,
  policyChangeSelection: {
    options: null
  },
  policyChangeSelectionLockedStatus: null
};

export const renewalReducer = createReducer(
  initialState,
  on(RenewActions.showProgressBar, (state, {isDisplayProgressBar}) => ({...state, isDisplayProgressBar})),
  on(RenewActions.updatePolicyChangeOptions, (state, {options}) => ({
    ...state,
    policyChangeSelection: {...state.policyChangeSelection, options}
  })),
  on(RenewActions.updateQuotedStatus, updateQuotedStatus),
  on(RenewActions.resetPolicySelections, state => ({...state, policyChangeSelection: {options: null}})),
  on(RenewActions.updateNewVersionStatus, (state, {isNewVersionCreated}) => ({...state, isNewVersionCreated}))
);

export function reducer(state: RenewalState | undefined, action: RenewActionsUnion) {
  return renewalReducer(state, action);
}

function updateQuotedStatus(state: RenewalState, {isQuoted}: { isQuoted: boolean }): RenewalState {
  if (isQuoted && state.policyChangeSelection.options) {
    const {yourCar, yourDrivers, yourAddress, yourCorrespondenceAddress} = state.policyChangeSelection.options;
    return {
      ...state,
      isQuoted,
      policyChangeSelectionLockedStatus: {yourCar, yourDrivers, yourAddress, yourCorrespondenceAddress}
    };
  }
  return {...state, isQuoted};
}
