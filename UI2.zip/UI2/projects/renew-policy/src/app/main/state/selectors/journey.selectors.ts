import { createFeatureSelector, createSelector } from '@ngrx/store';

import { State } from '@ren/main/state/reducers';

const mainStore = createFeatureSelector<State>('mainStore');

const selectJourneyNavigationState = createSelector(
  mainStore,
  (state: State) => state.journeyNavigationState
);

const selectJourneyNavigationDetails = createSelector(
  selectJourneyNavigationState,
  (state) => state.nextJourneyDetails
);

export const selectNavigationDetails = createSelector(
  selectJourneyNavigationDetails,
  (state) => state.navConfig
);

export const selectPanelConfig = createSelector(
  selectJourneyNavigationDetails,
  (state) => state.panelConfig
);

export const selectJourneyPath = createSelector(
  selectJourneyNavigationState,
  (state) => state.journeyPath
);

export const selectJourneyNavigationButtonDetails = createSelector(
  selectJourneyNavigationState,
  ({isNextButtonClicked, isBackButtonClicked, navCommands}) => ({isNextButtonClicked, isBackButtonClicked, navCommands})
);

export const selectJourneyNavigationButtonDetailsWithExtra = createSelector(
  selectJourneyNavigationState,
  ({isNextButtonClicked, isBackButtonClicked, isCancelButtonClicked, isSkipButtonClicked, navCommands}) =>
    ({isNextButtonClicked, isBackButtonClicked, isCancelButtonClicked, isSkipButtonClicked, navCommands})
);

export const selectNavDirection = createSelector(
  selectJourneyNavigationState,
  (state) => state.navDirection
);
