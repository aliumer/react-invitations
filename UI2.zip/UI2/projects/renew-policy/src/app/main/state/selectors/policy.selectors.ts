import { createFeatureSelector, createSelector } from '@ngrx/store';

import { State } from '@ren/main/state/reducers';

import { ChangeTypeEnum } from '@ren/infrastructure/enums/change-type.enum';
import { PaymentBillingIdEnum } from '@ren/infrastructure/enums/payments.enum';

import { Vehicle } from '@ren/features/your-car/interfaces/vehicle';

import { BreakdownCoverMap, DlgCoverCodeMap, BreakdownCoverMapSimple } from '@ren/infrastructure/configs/premium-cover.config';

import { MAIN_STORE_KEY } from '@ren/infrastructure/constants/store_keys.constant';


const mainStore = createFeatureSelector<State>(MAIN_STORE_KEY);

export const selectPolicyState = createSelector(
  mainStore,
  (state: State) => state.policyState
);

export const selectInitialPolicyDetails = createSelector(
  selectPolicyState,
  state => state.initialState.policyDetails
);

export const selectLoadPolicyError = createSelector(
  selectPolicyState,
  state => state.initialState.error
);

export const selectLatestPremium = createSelector(
  selectPolicyState,
  ({requestPayload: {premium}}) => premium
);

export const selectBoundPolicy = createSelector(
  selectPolicyState,
  ({finalState: {boundPolicy}}) => boundPolicy
);

export const selectLatestRescueCoverages = createSelector(
  selectLatestPremium,
  premium => {
    const {lobData, selectedPeriodPublicId_dlg} = premium;
    const activeOffering = lobData.mOTLine_Ext.offerings.filter(offerings => offerings.periodPublicId_dlg === selectedPeriodPublicId_dlg)[0];
    const vehicleCoverages = activeOffering.coverages.vehicleCoverages[0];
    return vehicleCoverages.rescueCoverages_dlg;
  }
);

export const selectPolicyChanges = createSelector(
  selectPolicyState,
  ({changes}) => changes
);

export const selectPremiumForReview = (occupations) => createSelector(
  selectLatestPremium,
  premium => ({occupations, premium})
);

export const selectExistingPermanentVehicleDetails = createSelector(
  selectInitialPolicyDetails,
  policyDetails => mapToVehicleDisplay(policyDetails, ChangeTypeEnum.Permanent)
);

export const getNcdModalData = createSelector(
  selectLatestPremium,
  (premium) => {

    const offerings = premium.lobData.mOTLine_Ext.offerings;
    const motVehicles = premium.lobData.mOTLine_Ext.coverables.motVehicles;
    const periodPublicIdDlg = premium.selectedPeriodPublicId_dlg;

    // TODO: place in a method;
    let amountPerYear = null;
    if (offerings && motVehicles && periodPublicIdDlg) {
      const selectedOffering = offerings.find(offering => offering.periodPublicId_dlg === periodPublicIdDlg);
      if (selectedOffering) {
        const coverage = selectedOffering.coverages.vehicleCoverages[0].coverages.filter(cover => cover.codeIdentifier_dlg === 'MOTNoClaimDiscCov');
        amountPerYear = coverage[0] ? coverage[0].amount : null;
      }
    }
    // TODO: place in a method;
    let ncdYears: string = null;
    const vehicles = motVehicles.filter(cover => cover);
    if (vehicles && vehicles.length) {
      ncdYears = vehicles[0].vehicle.yearsNoClaim;
      if (ncdYears && ncdYears === '9plus') {
        ncdYears = '9';
      }
    }
    return {amountPerYear, ncdYears};
  }
);

export const selectPremiumCoverLevel = createSelector(
  selectLatestPremium,
  premium => {
    const {
      bindData: {chosenQuote: chosenQuoteId},
      quoteData: {offeredQuotes},
      lobData: {mOTLine_Ext: {offerings, coverables: {motVehicles}}}
    } = premium;

    const {branchCode} = offeredQuotes.filter(q => q.publicID === chosenQuoteId)[0];
    const {coverages: {vehicleCoverages}} = offerings.filter(o => o.periodPublicId_dlg === chosenQuoteId)[0];
    const rescueExtras = (vehicleCoverages[0].rescueCoverages_dlg || []).filter(r => r.selected)
      .map(r => BreakdownCoverMap[r.covName] !== undefined ? BreakdownCoverMap[r.covName] : DlgCoverCodeMap[r.covName]);

    return {
      coverLevelKey: branchCode,
      optionalExtrasRescue: [...rescueExtras],
      vehicleEndorsements: motVehicles[0].vehicle.vehicleEndorsement
    };
  }
);

export const selectExistingDriversInPolicy = createSelector(
  selectLatestPremium,
  ({lobData: {mOTLine_Ext: {coverables}}}) => {
    const {drivers, motVehicles, vehicleDrivers} = coverables;
    const permVehicle = motVehicles.filter(v => v.vehicle.typeOfVehicle === ChangeTypeEnum.Permanent)[0];
    const mainDriverId = vehicleDrivers.filter(vd => vd.vehicleID === permVehicle.vehicle.publicID)[0].mainDriverID;

    return {
      drivers: drivers.filter(d => !d.tempDigitalId_dlg),
      mainDriverId,
      ncdOwnerId: permVehicle.vehicle.ncdOwnerInUse
    };
  }
);

export const selectPolicyHolder = createSelector(
  selectLatestPremium,
  ({lobData: {mOTLine_Ext: {coverables}}}) => coverables.drivers.filter(d => d.isPolicyHolder)[0]
);


export const selectDvlaSearchParams = createSelector(
  selectLatestPremium,
  premium => {
    const {
      lobData: {mOTLine_Ext: {coverables: {motVehicles}}},
      baseData: {policyAddress: {postalCode}, periodStartDate, termNumber_dlg: tenure},
      quoteRef_dlg: quoteRefId
    } = premium;
    const vrm = motVehicles.filter(v => v.vehicle.typeOfVehicle === ChangeTypeEnum.Permanent)[0]?.vehicle.registrationNumber;

    return {
      vrm,
      postalCode,
      periodStartDate,
      quoteRefId,
      tenure
    };
  }
);

export const getUpdateTabSelectionData = (coverId: string) => createSelector(
  selectLatestPremium,
  premium => {
    const {bindData} = premium;

    return {
      ...premium,
      bindData: {
        ...bindData,
        chosenQuote: coverId,
        renewThisVersionInd_dlg: false
      },
      selectedPeriodPublicId_dlg: coverId
    };
  }
);

export const getUpdateAddOnData = (addOn: any) => createSelector(
  selectLatestPremium,
  premium => {
    const {
      lobData: {mOTLine_Ext},
      quoteID,
      quoteRef_dlg,
      selectedPeriodPublicId_dlg
    } = premium;

    const activeOffering = mOTLine_Ext.offerings.filter(offerings => offerings.periodPublicId_dlg === selectedPeriodPublicId_dlg)[0];
    const vehicleCoveragesToEdit = activeOffering.coverages.vehicleCoverages[0];
    let coverageIndex = null;
    let rescueCoveragesIndex = null;

    if (addOn.hasOwnProperty('extras')) {
      coverageIndex = vehicleCoveragesToEdit.coverages.findIndex(coverages => coverages.codeIdentifier_dlg === addOn.extras.key);
    } else {
      rescueCoveragesIndex = vehicleCoveragesToEdit.rescueCoverages_dlg.findIndex(coverages => coverages.covName === addOn.breakdowns.key);
    }

    const vehicleCoveragesDeepClone = JSON.parse(JSON.stringify(vehicleCoveragesToEdit));

    if (coverageIndex >= 0 && coverageIndex !== null) {
      vehicleCoveragesDeepClone.coverages[coverageIndex].selected = addOn.extras.value;
    }

    if (rescueCoveragesIndex >= 0 && rescueCoveragesIndex !== null) {
      if (vehicleCoveragesDeepClone.rescueCoverages_dlg[rescueCoveragesIndex].covName !== BreakdownCoverMapSimple.RESEuroBrkdownLongTermCov &&
        vehicleCoveragesDeepClone.rescueCoverages_dlg[rescueCoveragesIndex].covName !== BreakdownCoverMapSimple.RESPersonalCov) {
        vehicleCoveragesDeepClone.rescueCoverages_dlg.forEach((rescueCoverages) => {
          if (rescueCoverages.covName !== BreakdownCoverMapSimple.RESEuroBrkdownLongTermCov && rescueCoverages.covName !== BreakdownCoverMapSimple.RESPersonalCov) {
            rescueCoverages.selected = false;
          }
        });
      }

      vehicleCoveragesDeepClone.rescueCoverages_dlg[rescueCoveragesIndex].selected = addOn.breakdowns.value;
    }

    return {
      lobData: {
        mOTLine_Ext: {vehicleCoverages: [vehicleCoveragesDeepClone]}
      },
      quoteID,
      quoteRef_dlg,
      selectedPeriodPublicId_dlg
    };
  }
);

export const getUpdateExcessData = (vehicleExcess: any) => createSelector(
  selectLatestPremium,
  premium => {
    const {
      lobData: {mOTLine_Ext},
      quoteID,
      quoteRef_dlg,
      selectedPeriodPublicId_dlg
    } = premium;

    const activeOffering = mOTLine_Ext.offerings.filter(offerings => offerings.periodPublicId_dlg === selectedPeriodPublicId_dlg)[0];
    const vehicleCoveragesToEdit = activeOffering.coverages.vehicleCoverages[0];
    const vehicleCoveragesDeepClone = JSON.parse(JSON.stringify(vehicleCoveragesToEdit));

    vehicleCoveragesDeepClone.vehicleExcess_dlg.selectedVoluntaryExcess = vehicleExcess;

    return {
      lobData: {
        mOTLine_Ext: {vehicleCoverages: [vehicleCoveragesDeepClone]}
      },
      quoteID,
      quoteRef_dlg,
      selectedPeriodPublicId_dlg
    };
  }
);

export const selectDefaultPaymentBillingId = createSelector(
  selectLatestPremium,
  ({bindData: {selectedPaymentPlan}}) => selectedPaymentPlan as PaymentBillingIdEnum
);

export const selectDefaultPaymentDetails = (defaultPaymentPlan: PaymentBillingIdEnum) => createSelector(
  selectLatestPremium,
  ({bindData: {directDebitDetails_dlg, creditCardDetails_dlg}}) => defaultPaymentPlan === PaymentBillingIdEnum.PayAnnual
    ? creditCardDetails_dlg
    : directDebitDetails_dlg
);

export const selectParametersForPolicyChangeStatusCheck = (isWpResponseReceived: boolean) => createSelector(
  selectLatestPremium,
  premium => {
    const {baseData: {accountNumber}, policyNumber, quoteID, quoteRef_dlg} = premium;
    return {quoteID, quoteRef_dlg, accountNumber, policyNumber, syncSuccess: isWpResponseReceived};
  }
);

export const selectIsAutoRenewalIndicator = (isFromMyAccount: boolean) => createSelector(
  isFromMyAccount ? selectInitialPolicyDetails : selectLatestPremium,
  ({bindData: {autoRenewInd_dlg}}) => !!autoRenewInd_dlg
);

export const selectInlineError = createSelector(
  selectPolicyState,
  state => state.errors.isInlineError
);

const mapToVehicleDisplay = (policyDetails: any, typeOfVehicle: ChangeTypeEnum): Vehicle => {
  const {lobData: {mOTLine_Ext: {coverables: {motVehicles}}}} = policyDetails;
  const currentVehicle = motVehicles.filter(m => m.vehicle.typeOfVehicle === typeOfVehicle)[0];
  if (currentVehicle) {
    const {make, model, registrationNumber, transmission, fuelType, year, engineSize, bodyType} = currentVehicle.vehicle;
    return {make, model, registrationNumber, transmission, fuelType, year, engineSize, bodyType};
  }

  return null;
};

