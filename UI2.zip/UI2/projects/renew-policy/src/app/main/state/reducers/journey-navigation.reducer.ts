import { createReducer, on } from '@ngrx/store';

import { JourneyNavigationActionsUnion } from '@ren/main/state/actions/journey-navigation.actions';
import { JourneyNavigationActions } from '@ren/main/state/actions';

import { FeatureState } from '@ren/main/interfaces/feature-state';
import { JourneyPath } from '@ren/main/interfaces/journey-path-state';
import { KeyValueDict } from '@ren/infrastructure/interfaces/key-value-dict';
import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';

export interface JourneyNavigationState {
  isNextButtonClicked: boolean;
  isBackButtonClicked: boolean;
  isCancelButtonClicked: boolean;
  isSkipButtonClicked: boolean;
  nextJourneyDetails: FeatureState;
  journeyPath?: JourneyPath;
  navDirection?: number;
  navCommands?: KeyValueDict<string>;
}

export const initialState: JourneyNavigationState = {
  isNextButtonClicked: false,
  isBackButtonClicked: false,
  isCancelButtonClicked: false,
  isSkipButtonClicked: false,
  nextJourneyDetails: {
    panelConfig: {isVisible: true},
    navConfig: []
  },
  journeyPath: {
    path: [JourneyFeaturesConfig.reviewInitial.name]
  },
  navDirection: 0,
  navCommands: {
    next: null,
    prev: null
  }
};


export const journeyNavigationReducer = createReducer(
  initialState,
  on(JourneyNavigationActions.loadNextJourneyDetails, (state, {nextJourneyDetails}) => ({...state, nextJourneyDetails})),
  on(JourneyNavigationActions.nextButtonClicked, state => ({...state, isNextButtonClicked: true})),
  on(JourneyNavigationActions.backButtonClicked, state => ({...state, isBackButtonClicked: true})),
  on(JourneyNavigationActions.cancelButtonClicked, state => ({...state, isCancelButtonClicked: true})),
  on(JourneyNavigationActions.skipButtonClicked, state => ({...state, isSkipButtonClicked: true})),
  on(JourneyNavigationActions.backButtonClicked, state => ({...state, isBackButtonClicked: true})),
  on(JourneyNavigationActions.resetButtons, state => ({
    ...state,
    isNextButtonClicked: false,
    isBackButtonClicked: false,
    isSkipButtonClicked: false,
    isCancelButtonClicked: false
  })),
  on(JourneyNavigationActions.setNavDirection, (state, {navDirection}) => ({...state, navDirection})),
  on(JourneyNavigationActions.setupNavigation, (state, {navCommands}) => ({...state, navCommands})),
  on(JourneyNavigationActions.buildJourneyPath, (state, {journeyPath}) => ({
    ...state,
    journeyPath: {path: [...new Set(journeyPath.path)]}
  })),
  on(JourneyNavigationActions.changeButtonStatus, changeButtonStatus),
  on(JourneyNavigationActions.changeButtonLabel, changeButtonLabel),
  on(JourneyNavigationActions.changeButtonVisibility, changeButtonVisibility)
);

export function reducer(state: JourneyNavigationState | undefined, action: JourneyNavigationActionsUnion) {
  return journeyNavigationReducer(state, action);
}

function changeButtonStatus(state, {id, status}) {
  const {nextJourneyDetails: {navConfig}} = state;
  const buttonIndex = navConfig.findIndex(b => b.id === id);
  if (buttonIndex > -1) {
    return {
      ...state,
      nextJourneyDetails: {
        ...state.nextJourneyDetails,
        navConfig: [
          ...navConfig.slice(0, buttonIndex),
          {...navConfig[buttonIndex], isDisabled: status},
          ...navConfig.slice(buttonIndex + 1)
        ]
      }
    };
  }
  return state;
}

function changeButtonLabel(state, {id, value}) {
  const {nextJourneyDetails: {navConfig}} = state;
  const buttonIndex = navConfig.findIndex(b => b.id === id);
  if (buttonIndex > -1) {
    return {
      ...state,
      nextJourneyDetails: {
        ...state.nextJourneyDetails,
        navConfig: [
          ...navConfig.slice(0, buttonIndex),
          {...navConfig[buttonIndex], label: value},
          ...navConfig.slice(buttonIndex + 1)
        ]
      }
    };
  }
  return state;
}

function changeButtonVisibility(state, {id, status}) {
  const {nextJourneyDetails: {navConfig}} = state;
  const buttonIndex = navConfig.findIndex(b => b.id === id);
  if (buttonIndex > -1) {
    return {
      ...state,
      nextJourneyDetails: {
        ...state.nextJourneyDetails,
        navConfig: [
          ...navConfig.slice(0, buttonIndex),
          {...navConfig[buttonIndex], isHidden: status},
          ...navConfig.slice(buttonIndex + 1)
        ]
      }
    };
  }
  return state;
}
