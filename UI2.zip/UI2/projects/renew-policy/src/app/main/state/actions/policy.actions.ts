import { createAction, props, union } from '@ngrx/store';

import { KeyValueDict } from '@ren/infrastructure/interfaces/key-value-dict';
import { PaymentBillingIdEnum } from '@ren/infrastructure/enums/payments.enum';

export const retrieveQuote = createAction(
  '[Policy] Retrieve Policy',
  props<{ token: string }>()
);

export const retrieveQuoteSucceeded = createAction(
  '[Policy] Retrieve Policy Succeeded',
  props<{ data: any }>()
);

export const retrieveQuoteFailed = createAction(
  '[Policy] Retrieve Policy Failed',
  props<{ error: any }>()
);

export const resetLoadPolicyError = createAction(
  '[Policy] Reset Load Policy Error'
);

export const updatePayloadChanges = createAction(
  '[Policy] Update Payload Changes',
  props<{ data: KeyValueDict<any> }>()
);

export const replaceInitialQuoteWithNewQuote = createAction(
  '[Policy] Replace Initial Quote With NewQuote',
  props<{data: any}>()
);

export const replaceRequestPayloadWithNewQuote = createAction(
  '[Policy] Replace Request Payload With NewQuote',
  props<{ premium: any }>()
);

export const resetPayloadChanges = createAction(
  '[Policy] Reset Payload Changes'
);

export const updateInvalidPromoCodeError = createAction(
  '[Policy] Update Invalid PromoCode Error'
);

export const updateInlineError = createAction(
  '[Policy] Update Inline Error'
);

export const resetErrors = createAction(
  '[Policy] Reset Errors'
);

export const updateSelectedPaymentBillingId = createAction(
  '[Policy] Update Selected Payment Billing Id',
  props<{ selectedPaymentPlan: PaymentBillingIdEnum}>()
);

export const updateBoundPolicy = createAction(
  '[Policy] Update Bound Policy',
  props<{ boundPolicy: any }>()
);

export const lapsedRenewalRequote = createAction(
  '[Policy] Lapsed Renewal Requote',
  props<{payload: any}>()
);

export const lapsedRenewalRequoteSucceeded = createAction(
  '[Policy] Lapsed Renewal Requote Succeeded'
);

export const lapsedRenewalRequoteFailed = createAction(
  '[Policy] Lapsed Renewal Requote Failed',
  props<{ error: any }>()
);

const all = union({
  retrieveQuote,
  retrieveQuoteSucceeded,
  retrieveQuoteFailed,
  updatePayloadChanges,
  replaceRequestPayloadWithNewQuote,
  replaceInitialQuoteWithNewQuote,
  resetPayloadChanges,
  updateInvalidPromoCodeError,
  updateInlineError,
  updateSelectedPaymentBillingId,
  updateBoundPolicy,
  lapsedRenewalRequote,
  lapsedRenewalRequoteSucceeded,
  lapsedRenewalRequoteFailed,
  resetErrors
});

export type PolicyActionsUnion = typeof all;
