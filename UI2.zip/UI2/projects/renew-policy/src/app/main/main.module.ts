import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { EffectsModule } from '@ngrx/effects';
import { StoreRouterConnectingModule } from '@ngrx/router-store';

import { CoreModule } from '@ren/core/core.module';
import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { MainRoutingModule } from '@ren/main/main-routing.module';
import { MainServicesModule } from '@ren/main/services/main-services.module';
import { CookieBannerModule } from '@ren/shared/cookie-banner/cookie-banner.module';

import { SessionInterceptorService } from '@ren/main/services/session/session-interceptor.service';
import { LoaderInterceptorService } from '@ren/main/services/loader/loader-interceptor.service';

import { SectionHeadingComponent } from '@ren/main/components/section-heading/section-heading.component';
import { MainContainerComponent } from '@ren/main/containers/main-container.component';
import { HeaderComponent } from '@ren/main/components/header/header.component';
import { FooterComponent } from '@ren/main/components/footer/footer.component';
import { LoadingIndicatorComponent } from '@ren/main/components/loading-indicator/loading-indicator.component';
import { JourneyNavigationComponent } from '@ren/main/components/journey-navigation/journey-navigation.component';
import { FeatureWrapperComponent } from '@ren/main/components/feature-wrapper/feature-wrapper.component';

import { metaReducers, reducers as MainReducer } from '@ren/main/state/reducers';

import { JourneyNavigationEffects } from '@ren/main/state/effects/journey-navigation.effects';

import { environment } from '@ren-env/environment';

import { MAIN_STORE_KEY } from '@ren/infrastructure/constants/store_keys.constant';




@NgModule({
  declarations: [
    MainContainerComponent,
    HeaderComponent,
    FooterComponent,
    LoadingIndicatorComponent,
    JourneyNavigationComponent,
    FeatureWrapperComponent,
    SectionHeadingComponent
  ],
  imports: [
    BrowserModule,
    CoreModule,
    CoreUiModule,
    MainRoutingModule,
    MainServicesModule,
    CookieBannerModule,
    StoreModule.forRoot({}, {
      metaReducers,
      runtimeChecks: {
        strictStateImmutability: true,
        strictActionImmutability: true
      }
    }),
    StoreModule.forFeature(MAIN_STORE_KEY, MainReducer),
    StoreDevtoolsModule.instrument({maxAge: 25, logOnly: environment.production}),
    EffectsModule.forRoot([JourneyNavigationEffects]),
    StoreRouterConnectingModule.forRoot()
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: SessionInterceptorService, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptorService, multi: true }
  ],
  bootstrap: [
    MainContainerComponent
  ]
})
export class MainModule { }
