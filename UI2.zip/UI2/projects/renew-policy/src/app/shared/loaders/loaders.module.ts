import { NgModule } from '@angular/core';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';

import { WaitLoaderComponent } from '@ren/shared/loaders/components/wait-loader/wait-loader.component';


@NgModule({
  declarations: [WaitLoaderComponent],
  imports: [
    CoreUiModule
  ],
  exports: [WaitLoaderComponent]
})
export class LoadersModule { }
