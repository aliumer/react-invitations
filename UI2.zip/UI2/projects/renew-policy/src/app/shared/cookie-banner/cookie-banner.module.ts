import { NgModule } from '@angular/core';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { CookieServicesModule } from '@ren/shared/cookie-banner/services/cookie-services.module';

import { CookieBannerDisplayComponent } from '@ren/shared/cookie-banner/components/cookie-banner-display/cookie-banner-display.component';




@NgModule({
  declarations: [
    CookieBannerDisplayComponent
  ],
  imports: [
    CoreUiModule,
    CookieServicesModule
  ],
  exports: [
    CookieBannerDisplayComponent
  ]
})
export class CookieBannerModule {
}
