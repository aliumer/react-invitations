import { NgModule } from '@angular/core';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { ErrorServicesModule } from '@ren/shared/error/services/error-services.module';

import { InLineErrorComponent } from './components/in-line-error/in-line-error.component';




@NgModule({
  declarations: [InLineErrorComponent],
  imports: [
    CoreUiModule,
    ErrorServicesModule
  ],
  exports: [InLineErrorComponent]
})
export class ErrorModule { }
