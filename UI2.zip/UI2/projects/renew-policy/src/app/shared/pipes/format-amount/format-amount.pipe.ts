import { Pipe, PipeTransform } from '@angular/core';
import { CurrencyPipe } from '@angular/common';

import { AmountFormat } from '@ren/infrastructure/enums/format.enum';


@Pipe({name: 'formatAmount'})
export class FormatAmountPipe implements PipeTransform {
  constructor(private currencyPipe: CurrencyPipe) {
  }

  private static getDecimal(value: string): string {
    let returnValue;
    if (value.indexOf('.') === -1) {
      returnValue = '.00';
    } else {
      returnValue = value.slice(value.indexOf('.'));
    }
    if (returnValue.length === 2) {
      returnValue = returnValue + '0';
    }
    return returnValue;
  }

  private static setCorrectFormat(formatAmount: number): string {
    const formatAmountStr = formatAmount === 0 ? '0.00' : formatAmount.toString();

    // This is where investigate should happen
    const integer: any = Math.trunc(Math.abs(formatAmount));
    const decimal = FormatAmountPipe.getDecimal(formatAmountStr);
    const negativeStr = formatAmount < 0 ? '-' : '';
    return `<span class="price__small-copy">${negativeStr}&pound;</span><span class="price__large-copy">${integer}</span><span class="price__small-copy">${decimal}</span>`;
  }

  transform(value: number, format: string): any {
    let formatAmount;
    if (value || value === 0) {
      if (format === AmountFormat.Simple) {
        return this.currencyPipe.transform(value, 'GBP', 'symbol');
      } else if (format === AmountFormat.Split) {
        formatAmount = FormatAmountPipe.setCorrectFormat(value);
        return formatAmount;
      }
    } else {
      return this.currencyPipe.transform(0, 'GBP', 'symbol');
    }
  }
}
