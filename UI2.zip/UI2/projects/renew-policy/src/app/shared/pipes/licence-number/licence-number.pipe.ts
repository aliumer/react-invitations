import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'licenceNumber'})
export class LicenceNumberPipe implements PipeTransform {

  constructor() { }

  transform(value: any): string {
    if (!value) { return ''; }
    const license = value.trim().toUpperCase();
    const licenseSpaces = license.match(/(^.{4})(.{4})(.{3})(.{5})/);
    licenseSpaces.shift();

    return licenseSpaces.join(' ');
  }
}
