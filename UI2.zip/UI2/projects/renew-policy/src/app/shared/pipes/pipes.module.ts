import { NgModule } from '@angular/core';
import { CurrencyPipe } from '@angular/common';

import { FormatAmountPipe } from '@ren/shared/pipes/format-amount/format-amount.pipe';
import { OrdinalNumberPipe } from '@ren/shared/pipes/ordinal-number/ordinal-number.pipe';
import { LicenceNumberPipe } from '@ren/shared/pipes/licence-number/licence-number.pipe';

@NgModule({
  declarations: [
    FormatAmountPipe,
    OrdinalNumberPipe,
    LicenceNumberPipe
  ],
  exports: [
    FormatAmountPipe,
    OrdinalNumberPipe,
    LicenceNumberPipe
  ],
  providers: [
    CurrencyPipe
  ]
})
export class PipesModule { }
