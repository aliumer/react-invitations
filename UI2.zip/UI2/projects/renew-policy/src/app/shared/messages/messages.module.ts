import { NgModule } from '@angular/core';

import { CarStatusReminderComponent } from './car-status-reminder/car-status-reminder.component';


@NgModule({
  declarations: [CarStatusReminderComponent],
  exports: [CarStatusReminderComponent]
})
export class MessagesModule { }
