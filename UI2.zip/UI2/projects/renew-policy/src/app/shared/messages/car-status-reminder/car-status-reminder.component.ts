import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-car-status-reminder',
  templateUrl: './car-status-reminder.component.html'
})
export class CarStatusReminderComponent {
  @Input() message: string;

}
