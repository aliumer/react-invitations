import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarStatusReminderComponent } from './car-status-reminder.component';

describe('CarStatusReminderComponent', () => {
  let component: CarStatusReminderComponent;
  let fixture: ComponentFixture<CarStatusReminderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarStatusReminderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarStatusReminderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
