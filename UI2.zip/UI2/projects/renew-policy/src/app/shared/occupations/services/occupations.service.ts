import { Injectable } from '@angular/core';
import { KeyValue } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import { OccupationsModule } from '@ren/shared/occupations/occupations.module';

import { ResourceService } from '@ren/infrastructure/abstracts/resource.service';

import { Environment } from '@ren/infrastructure/models/environment';

export type OccupationResponse = KeyValue<string, string>[];

@Injectable({
  providedIn: OccupationsModule
})
export class OccupationsService extends ResourceService<any> {

  private readonly OCCUPATIONS_KEY = 'app-occupation';

  get Occupations(): OccupationResponse {
    const sessionObj = sessionStorage.getItem(this.OCCUPATIONS_KEY);
    return !!sessionObj ? JSON.parse(sessionObj) as OccupationResponse : null;
  }

  set Occupations(occupations: OccupationResponse) {
    sessionStorage.removeItem(this.OCCUPATIONS_KEY);
    sessionStorage.setItem(this.OCCUPATIONS_KEY, JSON.stringify(occupations));
  }

  constructor(
    protected httpClient: HttpClient,
    protected env: Environment) {
    super(httpClient, env, 'occupations');
  }

  getOccupations(): Observable<OccupationResponse> {
    const occupations = this.Occupations;
    return occupations ?  of(occupations) :
      this.list().pipe(
        map(result => result.map(o => ({ key: o.code, value: o.value}))),
        tap(result => this.Occupations = result)
      );
  }
}
