import { KeyValue } from '@angular/common';

export const MonthlyBreakdownSummaryColumns: KeyValue<string, string>[] = [
  {
    key: 'policyCashPrice',
    value: 'Total amount of credit'
  },
  {
    key: 'total',
    value: 'Total amount payable'
  },
  {
    key: 'installmentPercentage_dlg',
    value:  'Interest rate fixed'
  },
  {
    key: 'aPR_dlg',
    value: 'Representative APR'
  },
  {
    key: 'policyCashPrice',
    value:  'Policy cash price'
  },
  {
    key: 'name',
    value: 'Agreement term'
  }
];
