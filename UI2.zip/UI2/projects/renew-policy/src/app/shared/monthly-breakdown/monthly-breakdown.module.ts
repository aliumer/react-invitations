import { NgModule } from '@angular/core';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';

import { MonthlyBreakdownSummaryComponent } from './components/monthly-breakdown-summary/monthly-breakdown-summary.component';




@NgModule({
  declarations: [MonthlyBreakdownSummaryComponent],
  exports: [
    MonthlyBreakdownSummaryComponent
  ],
  imports: [
    CoreUiModule,
  ]
})
export class MonthlyBreakdownModule { }
