import { NgModule } from '@angular/core';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { AddressServicesModule } from '@ren/shared/address/services/address-services.module';

import { AddressDisplayComponent } from './components/address-display/address-display.component';
import { AddressLookupComponent } from './components/address-lookup/address-lookup.component';
import { AddressOvernightComponent } from '@ren/shared/address/components/address-overnight/address-overnight.component';




@NgModule({
  declarations: [
    AddressDisplayComponent,
    AddressLookupComponent,
    AddressOvernightComponent
  ],
  imports: [
    CoreUiModule,
    AddressServicesModule
  ],
  exports: [
    AddressDisplayComponent,
    AddressLookupComponent,
    AddressOvernightComponent
  ]
})
export class AddressModule {
}
