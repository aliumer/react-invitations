import { FormControl } from '@angular/forms';

export class AddressLookupValidators {
  static noSpecialCharactersExceptWhitespace(control: FormControl) {
    const noSpecialCharactersExceptWhitespaceRegExp = /^(\d|\w)+$/;

    if (control.value) {
      const value = control.value.replace(/ /g, '');
      if (!noSpecialCharactersExceptWhitespaceRegExp.test(value)) {
        return {noSpecialCharactersExceptWhitespace: true};
      }
    }

    return null;
  }

  static validPostcode(control: FormControl) {
    const postcodeRegex = /([Gg][Ii][Rr] 0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?))))\s?[0-9][A-Za-z]{2})$/;

    if (!postcodeRegex.test(control.value)) {
      return {invalidPostcode: true};
    }

    return null;
  }

  static verifyPostcode(value: boolean) {
    return (control: FormControl) => {
      if (control.value) {
        if (!value) {
          return {nonVerifiedPostcode: true};
        }
      }
      return null;
    };
  }
}
