import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { DlgWalrusModule } from 'dlg-angular-components';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DlgWalrusModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  exports: [
    CommonModule,
    DlgWalrusModule,
    FormsModule,
    ReactiveFormsModule,
  ]
})
export class CoreUiModule { }
