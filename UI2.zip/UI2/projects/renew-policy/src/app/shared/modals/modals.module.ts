import { NgModule } from '@angular/core';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';
import { AlertsModule } from '@ren/shared/alerts/alerts.module';

import { ConfirmRemoveModalComponent } from '@ren/shared/modals/components/confirm-remove-modal/confirm-remove-modal.component';
import { ErrorModalComponent } from '@ren/shared/modals/components/error-modal/error-modal.component';
import { RejectQuoteModalComponent } from './components/reject-quote-modal/reject-quote-modal.component';



@NgModule({
  declarations: [ConfirmRemoveModalComponent, ErrorModalComponent, RejectQuoteModalComponent],
  imports: [
    CoreUiModule,
    AlertsModule
  ],
  exports: [
    ConfirmRemoveModalComponent
  ]
})
export class ModalsModule { }
