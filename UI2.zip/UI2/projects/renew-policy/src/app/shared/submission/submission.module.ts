import { NgModule } from '@angular/core';

import { SubmissionServicesModule } from '@ren/shared/submission/services/submission-services.module';

@NgModule({
  imports: [
    SubmissionServicesModule
  ],
  exports: [SubmissionServicesModule]
})
export class SubmissionModule { }
