import { NgModule } from '@angular/core';

import { CoreUiModule } from '@ren/shared/core-ui/core-ui.module';

import { SingleAlertComponent } from './components/single-alert/single-alert.component';



@NgModule({
  declarations: [SingleAlertComponent],
  imports: [
    CoreUiModule
  ],
  exports: [
    SingleAlertComponent
  ]
})
export class AlertsModule { }
