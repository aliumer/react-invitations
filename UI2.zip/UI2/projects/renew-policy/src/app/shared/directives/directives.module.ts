import { NgModule } from '@angular/core';

import { TitleCaseDirective } from '@ren/shared/directives/title-case/title-case.directive';

@NgModule({
  declarations: [
    TitleCaseDirective
  ],
  exports: [
    TitleCaseDirective
  ]
})
export class DirectivesModule {
}
