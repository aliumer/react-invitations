export enum ControlTypesEnum {
  Group = 0,
  Array = 1,
  DateArray = 2,
  SortCodeArray = 3,
  Control = 4,
  None = 5
}
