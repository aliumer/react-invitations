export enum Brand {
  Churchill = 'churchill',
  DirectLine = 'directline',
  Privilege = 'privilege'
}

export enum BrandName {
  Churchill = 'Churchill',
  DirectLine = 'Direct Line',
  Privilege = 'Privilege'
}

export enum BrandCAPCode {
  churchill = 'CHU',
  directline = 'DLI',
  privilege = 'PRV'
}