export enum AmountFormat {
  Simple = 'simple',
  Split = 'split'
}
