export enum PaymentOptionEnum {
  PayImmediate = 'payimmediate',
  SpreadOverInstalments = 'spreadoverinstalments'
}

export enum PaymentPlansEnum {
  PayAnnual = 'Single Payment',
  PayMonthlyDeposit = 'Monthly - Deposit and 10 Instalments',
  PayMonthly = 'Monthly - 12 Instalments'
}

export enum PaymentBillingIdEnum {
  PayAnnual = 'dlg_payment_plan:1',           // 'Single Payment',
  PayMonthlyDeposit = 'dlg_payment_plan:2',   // 'Monthly - Deposit and 10 Instalments',
  PayMonthly = 'dlg_payment_plan:3'           // 'Monthly - 12 Instalments'
}
