export enum CoverageTypeEnum {
  Comp = 'Comp',
  CompPlus = 'CompPlus',
  TPFT = 'TPFT',
  Drivexpert = 'DriveXpert'
}

export enum CoverageTypeEnumSimple {
  Comp = 'comp',
  CompPlus = 'compplus',
  TPFT = 'tpft',
  Drivexpert = 'drivexpert'
}

export enum CoverageTypeNames {
  Comp = 'Comprehensive',
  CompPlus = 'Comprehensive Plus',
  TPFT = 'Third Party, Fire and Theft',
  Drivexpert = 'DriveXpert'
}

export enum CoverageTypeNamesSimple {
  comp = 'Comprehensive',
  compplus = 'Comprehensive Plus',
  tpft = 'Third Party, Fire and Theft',
  drivexpert = 'DriveXpert'
}

export enum CoverageBookletTypes {
  Comp = 'Comp',
  CompPlus = 'Compplus',
  TPFT = 'TPFT',
  Drivexpert = 'Telematics'
}