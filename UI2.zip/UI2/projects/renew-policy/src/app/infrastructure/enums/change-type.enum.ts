export enum ChangeTypeEnum {
  Permanent = 'permanent',
  Temporary = 'temporary'
}
