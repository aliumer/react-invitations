export enum ExcessType {
  compulsoryExcess = 'Accidental damage',
  noDriverPresent = 'No driver present',
  fireandTheftExcess = 'Fire and theft',
  windScreenRepair = 'Windscreen repair',
  windScreenReplace = 'Windscreen replacement'
}
