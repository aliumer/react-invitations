export enum DateNumbersEnum {
    hoursPerDay = 24,
    minutesPerHour = 60,
    secondsPerMinute = 60,
    millisecondsPerSecond = 1000
}
