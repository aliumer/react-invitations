export enum TelematicsTypeEnum {
  MOTTelematicsCovTelematicsApp = 'App',
  MOTTelematicsCovTelematicsDevice = 'Device',
  MOTTelematicsCovTelematicsHardWired = 'HardWired',
  MOTTelematicsCovTelematicsSelfInstalled = 'SelfInstalled'
}

export enum TelematicsTypeCapReadableEnum {
  App = 'MOTTelematicsCovTelematicsApp',
  Device = 'MOTTelematicsCovTelematicsDevice',
  HardWired = 'MOTTelematicsCovTelematicsHardWired',
  SelfInstalled = 'MOTTelematicsCovTelematicsSelfInstalled'
}

export enum TelematicsTypeReadableEnum  {
  App = 'App',
  HardWired = 'HardWired',
  SelfInstalled = 'SelfInstalled'
}
