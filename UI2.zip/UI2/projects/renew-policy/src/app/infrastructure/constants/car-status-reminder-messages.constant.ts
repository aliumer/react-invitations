import { KeyValueDict } from '@app/infrastructure/interfaces/key-value-dict';

export const CarStatusReminderMessages: KeyValueDict<string> = {
  noRegistration: `Remember, you'll need to give us your car registration to update your policy. The price we quote is subject to change until we have your full details.`,
  noPurchaseDate: `Remember, you can't update your policy until you've bought your car. Please let us know the purchase date. The price we quote is subject to change until we have your full details.`,
  both: `Remember, you can't update your policy until you've bought your car and given us your registration. The price we quote is subject to change until we have your full details.`
};
