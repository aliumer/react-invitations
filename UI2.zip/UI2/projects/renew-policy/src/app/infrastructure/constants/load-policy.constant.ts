export const LoadPolicyConstants = {
  BACK_TO_DASHBOARD: 'BACK_TO_DASHBOARD',
  TRY_AGAIN: 'TRY_AGAIN'
};
