export const MOT_LEGAL_COVER_COV = 'MOTLegalCoverCov';
export const MOT_GUARANTEED_HIRE_CAR_PLUS_COV = 'MOTGuaranteedHireCarPlusCov';
export const MOT_NO_CLAIM_DISC_COV = 'MOTNoClaimDiscCov';
