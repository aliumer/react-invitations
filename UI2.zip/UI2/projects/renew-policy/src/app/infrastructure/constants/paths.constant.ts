export const MY_ACCOUNT_POLICY_DASHBOARD_URL = '/my-dashboard#/dashboard/policies';

export const SESSION_TIMEOUT_URL = 'session-timeout';
export const TRANSACTION_FAILED_URL = 'transaction-failed';
export const TRANSACTION_REFUSED_URL = 'transaction-refused';
export const PAYMENT_CONTACT_CENTRE_URL = 'payment-contact-centre';
export const RENEWAL_DECLINED_URL = 'declined'
