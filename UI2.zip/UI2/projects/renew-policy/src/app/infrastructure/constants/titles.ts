export const projectArea = 'B4C';
export const projectTitle = 'Motor Renewal';
