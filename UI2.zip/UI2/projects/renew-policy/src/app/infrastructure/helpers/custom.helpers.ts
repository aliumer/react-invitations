import { v4 as uuidv4 } from 'uuid';
import { CoverageTypeEnumSimple, CoverageTypeNames } from '@ren/infrastructure/enums/coverage-type.enum';

import { environment } from '@ren-env/environment';
import { CoverageTypeToNamesMap, CoverageTypeToBookletNamesMap } from '@ren/infrastructure/configs/premium-cover.config';
import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';

export class CustomHelpers {

  static getDriverXpertBrandName = (coverName: CoverageTypeNames) => coverName === CoverageTypeNames.Drivexpert ? environment.brand_copy[coverName.toLowerCase()] : coverName;

  static lookupCoverageTypeToName = (coverType: CoverageTypeEnumSimple) => CustomHelpers.lookupByKeyFromMapper(CoverageTypeToNamesMap, coverType);

  static lookupCoverageTypeToBookletName = (coverType: CoverageTypeEnumSimple) => CustomHelpers.lookupByKeyFromMapper(CoverageTypeToBookletNamesMap, coverType);

  static redirectToExternalUrl(url: string) {
    const baseUrl = location.origin || `${location.protocol}//${location.hostname}${location.port ? ':' + location.port : ''}`;
    window.location.href = `${baseUrl}${url}`;
  }

  static redirectToRejectUrl() {
    window.location.href = `${location.href.split(location.pathname)[0]}/car/renew-policy/${JourneyFeaturesConfig.reviewInitial.path}`;
  }

  static appendEngineCapacityLabel(engineCapacity: string | number): string {
    const engineCapacityString = engineCapacity.toString() || '';
    return engineCapacityString + (engineCapacityString.indexOf('.') !== -1 || parseInt(engineCapacityString, 10) < 20 ? 'L' : 'CC');
  }

  static isEmptyObject(obj: any): boolean {
    return obj === null || obj === undefined || Array.isArray(obj) && obj.length === 0
      ? true
      : Object.entries(obj).length === 0 && obj.constructor === Object;
  }

  static removeNullEntries(obj: any): any {
    Object.entries(obj).forEach(([key, value]) =>
      (value && typeof value === 'object') && CustomHelpers.removeNullEntries(value) ||
      (value === null || value === '') && delete obj[key]);
    return obj;
  }

  static removeNullEntriesV2<T>(obj: T): T {
    const acc: Partial<T> = {};
    for (const key in obj) {
      if (obj[key] !== null) acc[key] = obj[key];
    }
    return acc as T;
    /*const temp = Object.entries(obj)
      .filter(([_, v]) => v != null)
      .map(([k, v]) => [k, v === Object(v) ? CustomHelpers.removeNullEntriesV2(v) : v]);
    console.log('temp', temp);
    return Object.fromEntries(
      temp
    );*/
  }

  static getUniqueId(length = 9, isAllowSeparators = false): string {
    let uniqueId = uuidv4();
    if (!isAllowSeparators) {
      uniqueId = uniqueId.replace('-', '');
    }
    if (length) {
      uniqueId = uniqueId.substr(0, length);
    }
    return uniqueId;
  }

  private static lookupByKeyFromMapper<K, V>(mapper: Map<K, V>, key: K): V {
    return mapper.get(key) || null;
  }
}
