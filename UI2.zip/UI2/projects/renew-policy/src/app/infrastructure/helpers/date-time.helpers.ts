import { DateTime, Duration } from 'luxon';
import { YearFormat } from '@app/features/your-drivers/models/year-format';

export class DateTimeHelpers {
  static toFormat(
    dateObject: number[] | { day?: number, month: number, year: number },
    isShortYearFormat = false,
    delimiter: string = '/'): string {
    if (Array.isArray(dateObject)) {
      const [day, month, year] = dateObject.filter(v => +v !== undefined);
      dateObject = day ? {day, month, year} : {month, year};
    }
    return isShortYearFormat ?
      DateTime.fromObject(dateObject).toFormat(`dd${delimiter}MM${delimiter}yy`) :
      DateTime.fromObject(dateObject).toFormat(`dd${delimiter}MM${delimiter}yyyy`);
  }

  static lastDayOfMonth(date: Date | string[]): number {
    if (Array.isArray(date)) {
      return new Date(+date[2], +date[1], 0).getDate();
    }
    return new Date(date.getFullYear(), date.getMonth(), 0).getDate();
  }

  static getShortMonth(paramMonthIdx: number): any {
    const monthIdx = paramMonthIdx - 1;
    const shortMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return shortMonths[monthIdx];
  }

  static getYearFormat(yearRange: number): YearFormat {
    const currentTime = new Date();
    const currentYear = currentTime.getFullYear();
    return {
      years:
        {
          min: currentYear - yearRange,
          max: currentYear
        }
    };
  }

  static differenceInMonths(dateFrom, dateTo): number {
    return dateTo.getMonth() - dateFrom.getMonth() +
      (12 * (dateTo.getFullYear() - dateFrom.getFullYear()));
  }

  static differenceInDays(dateFrom: Date, dateTo: Date): number {
    return DateTime.fromJSDate(dateFrom).diff(DateTime.fromJSDate(dateTo), ['days']).days;
  }

  static diffNow(
    date: number[] | { day?: number, month: number, year: number }): Duration {
    return DateTimeHelpers.createDateTimeObject(date).diffNow(['days', 'months', 'years']);
  }

  static getDifferenceInYears(date1: string[], date2: string[]): number {
    // Return 0 if there are any null, undefined, or empty values in the date parameters
    if (this.checkDateForEmptyValue(date1) || this.checkDateForEmptyValue(date2)) {
      return 0;
    }

    const sortedDates: any[] = this.sortDates([date1, date2]);
    const sortedDate1: number[] = this.formatDateTypeToNumber(sortedDates[0]);
    const sortedDate2: number[] = this.formatDateTypeToNumber(sortedDates[1]);

    let yearsDifference: number = sortedDate2[2] - sortedDate1[2];
    const months: number = sortedDate2[1] - sortedDate1[1];
    if (months < 0 || (months === 0 && sortedDate2[0] < sortedDate1[0])) {
      yearsDifference--;
    }
    return yearsDifference;
  }

  private static createDateTimeObject(
    dateObject: number[] | { day?: number, month: number, year: number }
  ): DateTime {
    if (Array.isArray(dateObject)) {
      const [day, month, year] = dateObject.filter(v => v);
      dateObject = day ? {day, month, year} : {month, year};
    }
    return DateTime.fromObject(dateObject);
  }

  private static checkDateForEmptyValue(date: string[]): boolean {
    return date.filter(d => !d).length > 0;
  }

  private static sortDates(dates: Array<string[]>, descending?: boolean): any[] {
    const sortedArray = dates.map((date) => {
      const year = date[2] && (Number(date[2]) < 10) && date[2].length < 2 ? '0' + date[2] : date[2];
      const month = date[1] && (Number(date[1]) < 10) && date[1].length < 2 ? '0' + date[1] : date[1];
      const day = date[0] && (Number(date[0]) < 10) && date[0].length < 2 ? '0' + date[0] : date[0];
      return [year, month, day];
    }).sort().map((date) => {
      const year = date[0] && date[0].charAt(0) === '0' ? date[0].substr(1) : date[0];
      const month = date[1] && date[1].charAt(0) === '0' ? date[1].substr(1) : date[1];
      const day = date[2] && date[2].charAt(0) === '0' ? date[2].substr(1) : date[2];
      return [day, month, year];
    });
    return descending ? sortedArray.reverse() : sortedArray;
  }

  private static formatDateTypeToNumber(date: string[]): number[] {
    return date.map(d => d ? +d : d === undefined ? undefined : null);
  }
}
