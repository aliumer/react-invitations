import { CardType } from '@ren/infrastructure/data/card-type.data';

export class PaymentHelpers {
  static getHiddenAccountNumber(accountNumber: string): string {
    return accountNumber ? '******' + accountNumber.toString().substr(-2) : '';
  }

  static getHiddenCardNumber(cardNumber: string): string {
    return cardNumber ? cardNumber === 'NA' ? cardNumber : '************' + cardNumber.substr(-4) : '';
  }

  static getFormattedSortCode(sortCode: string): string {
    return sortCode ? sortCode.slice(0, 2) + '-' + sortCode.slice(2, 4) + '-' + sortCode.slice(4) : '';
  }

  static getCardTypeLabel(cardType: string): string {
    return CardType.find(item => item.key === cardType)?.value;
  }

  static getCardExpiryDateDisplay(expDate: string): string {
    if(!expDate) {
      return 'NA';
    }
    return `${expDate.substring(0, 2)}/${expDate.substring(2)}`;
  }
}
