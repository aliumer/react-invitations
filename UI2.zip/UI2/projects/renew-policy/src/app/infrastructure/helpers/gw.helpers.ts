import { TextHelpers } from '@ren/infrastructure/helpers/text.helpers';

interface GwDate {
  day: number;
  month: number;
  year: number;
}

export class GwHelpers {
  static convertTitleForDisplay(title: string): string {
    return title !== 'miss_dlg' ? TextHelpers.convertToTitleCase(title) : 'Miss';
  }

  static convertTitleForPayload(title: string): string {
    return title !== 'Miss' ? title.toLowerCase() : 'miss_dlg';
  }

  static convertToGwDateObject([day, month, year]): GwDate {
    return {
      day: day ? +day : 1,
      month: +month - 1,
      year: +year
    };
  }

  static convertGwDateToDate({day, month, year}: GwDate): Date {
    return new Date(year, month, day);
  }

  static convertGwDateToDlgDate({day, month, year}: GwDate): number[] {
    return [day , month + 1, year];
  }

  static convertToBoolean(value: any): boolean {
    return value === undefined ? false :
      typeof value === 'boolean' ? value :
        (value as string).toLowerCase() === 'yes';
  }

  static getGender(title: string, gender: string): string {
    if (gender) {
      return gender === 'Male' ? 'M' : 'F';
    }
    if (title) {
      return title.toLowerCase() === 'mr' ? 'M' : 'F';
    }
    return null;
  }
}
