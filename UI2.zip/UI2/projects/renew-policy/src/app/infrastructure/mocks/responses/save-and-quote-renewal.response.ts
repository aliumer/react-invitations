export const SaveAndQuoteRenewalResponse = {
  result: {
    quoteID: '0002996621',
    quoteRef_dlg: 'PRV20000014059',
    baseData: {
      accountNumber: '4052076343',
      accountHolder: {
        emailAddress1: 'success+jfiogi31@simulator.amazonses.com',
        publicID: 'rc3e2ett4:2640',
        displayName: 'Tod Altenwerth',
        primaryPhoneType: 'other_Dlg',
        workNumber: '01622200331',
        subtype: 'Person',
        primaryAddress: {
          publicID: 'rc3e2ett4:2508',
          displayName: 'Churchill Court, Masons Hill, BROMLEY, Kent, BR1 1DP',
          addressLine1: 'Churchill Court',
          addressLine2: 'Masons Hill',
          city: 'BROMLEY',
          postalCode: 'BR1 1DP',
          country: 'GB',
          addressType: 'home',
          uPRN_dlg: '10003627976',
          county_dlg: 'Kent',
          xcordinate_dlg: '540351',
          ycordinate_dlg: '168591',
          latitude_dlg: '51.3989963',
          longitude_dlg: '.0161911',
          uDPRN_dlg: '0000000000000000'
        },
        accountHolder: true,
        dateOfBirth: {
          year: 1972,
          month: 9,
          day: 3
        },
        gender: 'M',
        firstName: 'Tod',
        lastName: 'Altenwerth',
        prefix: 'mr',
        maritalStatus: 'S',
        brand_dlg: 'privilege',
        isCorrespondAdSameAsPrimAd_dlg: true,
        employmentStatus_dlg: 'employedfulltime',
        occupation_dlg: 'A60',
        businessType_dlg: '001',
        largePrint_dlg: false,
        braille_dlg: false,
        audioCD_dlg: false,
        audioTape_dlg: false,
        mp3OnUSBStick_dlg: false,
        oktaid_dlg: '00uu02uw9meaIceEe0h7',
        customerPref_dlg: 'portal',
        goneAwayFlag_dlg: false,
        deceasedFlag_dlg: false
      },
      policyAddress: {
        publicID: 'rc3e2ett4:2508',
        displayName: 'Churchill Court, Masons Hill, BROMLEY, Kent, BR1 1DP',
        addressLine1: 'Churchill Court',
        addressLine2: 'Masons Hill',
        city: 'BROMLEY',
        postalCode: 'BR1 1DP',
        country: 'GB',
        addressType: 'home',
        uPRN_dlg: '10003627976',
        county_dlg: 'Kent',
        xcordinate_dlg: '540351',
        ycordinate_dlg: '168591',
        latitude_dlg: '51.3989963',
        longitude_dlg: '.0161911',
        uDPRN_dlg: '0000000000000000'
      },
      productCode: 'Combined',
      sfProductName_dlg: 'Motor',
      productName: 'Personal Combined',
      periodStartDate: {
        year: 2020,
        month: 10,
        day: 23
      },
      periodEndDate: {
        year: 2021,
        month: 10,
        day: 22
      },
      termType: '12months_Dlg',
      periodStatus: 'Quoted',
      channel_dlg: 'digital',
      source_dlg: 'directdigital',
      isChildrenUnder16_dlg: false,
      ownHome_dlg: true,
      noOfVehiclesInHome_dlg: '1',
      paymentType_dlg: 'infull',
      anotherBrandInd_dlg: false,
      cancelByInsurerInd_dlg: false,
      quoteExpiryDate_dlg: {
        year: 2020,
        month: 11,
        day: 22
      },
      transactionType_Dlg: 'Submission',
      periodStartTime_dlg: {
        hour: 0,
        minute: 1,
        second: 0,
        millisecond: 0
      },
      isCorrespondAdSameAsPolAd_dlg: true,
      deviceDetails_dlg: {
        ipAddress: '52.17.105.22',
        geoCode: 'IE'
      },
      sameBrandInd_dlg: false,
      basicMultiCarInd_dlg: false,
      motorBookletVersion_dlg: 'B4C PRIV M PB 0121',
      rescueBookletVersion_dlg: 'B4C GF LR PB 0121',
      motorIPIDVersion_dlg: 'B4C PRIV M COMP IPID 0121',
      accDamageCovInd: true
    },
    lobData: {
      mOTLine_Ext: {
        coverables: {
          drivers: [
            {
              fixedId: 4026,
              publicID: 'rc3e2ett4:4026',
              person: {
                publicID: 'rc3e2ett4:2640',
                displayName: 'Tod Altenwerth',
                firstName: 'Tod',
                lastName: 'Altenwerth',
                prefix: 'mr',
                primaryPhoneType: 'other_Dlg',
                workNumber: '01622200331',
                maritalStatus: 'S',
                dateOfBirth: {
                  year: 1972,
                  month: 9,
                  day: 3
                },
                gender: 'M'
              },
              gender: 'M',
              isPolicyHolder: true,
              residentInUkFromBirth: true,
              typeOfDrivingLicense: 'fulluk',
              lengthOfDrivingLicHeldYear: '9plus',
              employmentStatus_dlg: 'employedfulltime',
              occupation_dlg: 'A60',
              businessType_dlg: '001',
              yearInUK_dlg: {
                year: 1972,
                month: 9,
                day: 3
              },
              convictionDetails: [
                {
                  convictionCode: 'AC10',
                  convictionDate: {
                    year: 2017,
                    month: 4,
                    day: 1
                  },
                  convictionPoint: '0',
                  convictionBanLength: 0
                },
                {
                  convictionCode: 'CU40',
                  convictionDate: {
                    year: 2017,
                    month: 5,
                    day: 1
                  },
                  convictionPoint: '0',
                  convictionBanLength: 0
                }
              ],
              claimsDetails: [
                {
                  incidentDate: {
                    year: 2018,
                    month: 0,
                    day: 1
                  },
                  incidentType: 'Accident',
                  accidentDetailsType: 'No other vehicle involved',
                  claimMade: false
                }
              ],
              driverStartDate: {
                year: 2020,
                month: 10,
                day: 23
              },
              driverEndDate: {
                year: 2021,
                month: 10,
                day: 22
              },
              driverType: 'permanent',
              permanentUKResident: true,
              isLicenceVerified: false,
              isLicenceExpired: false,
              isLicenceUsed: false
            }
          ],
          motVehicles: [
            {
              fixedId: 2234,
              publicID: 'rc3e2ett4:2234',
              vehicle: {
                fixedId: 2238,
                publicID: 'rc3e2ett4:2238',
                vehicleNumber: 1,
                year: 2003,
                make: 'BMW',
                model: 'Z SERIES',
                vin: 'WBABT32050LS20227',
                annualMileage: 2000,
                primaryUse: 'sdpexclcomm_dlg',
                costNew: {
                  amount: 2700,
                  currency: 'gbp'
                },
                displayName: 'BMW Z SERIES 2003',
                color: 'BLACK',
                bodyType: 'CONVERTIBLE',
                vRNLookupResp: {
                  dateOfFirstRegistrationUK: '2003-06-19T23:00:00Z',
                  cherishedTransferDate: '2014-10-25T23:00:00Z',
                  dateOfManufacture: '2003-06-19T23:00:00Z',
                  marketSegment: 'SPECIALIST SPORTS',
                  vIN_Verified: 'WBABT32050LS20227',
                  colourCurrent: 'BLACK',
                  lengthMM: 4091,
                  widthMM: 1781,
                  heightMM: 1299,
                  numberOfPreviousKeepers: 3,
                  startDateOfCurrentKeeper: '2019-09-06T23:00:00Z',
                  importMarker: false,
                  scrappingMarker: 0,
                  scrappedRemovedMarker: false,
                  modelSeries: 'E85',
                  modelYear: '2003',
                  introductionDateToUK: '2003-03-01T00:00:00Z',
                  terminationdate: '2004-02-01T00:00:00Z',
                  aspiration: 'NATURALLY ASPIRATED',
                  combined_ForwardGears: 5,
                  arrangementOfCylinders: 'IN LINE',
                  numberOfCylinders: 6,
                  driveAxle: 'REAR',
                  engineLocation: 'FRONT',
                  delivery: 'FUEL INJECTION',
                  maximumTorqueNM: 245.0,
                  maximumPowerInKW: 142.0,
                  fuelConsumptionExtraUrbanMPG: 38.7,
                  fuelConsumptionExtraUrban_Ltr100km: 7.3,
                  fuelConsumptionUrbanCold_Ltr100km: 13.5,
                  maximumSpeedMPH: 141,
                  accelerationTo100KPHSecs: 7.5,
                  euroStatus: 'E3',
                  cO2: 231,
                  grossWeight: 1590,
                  seats: 2,
                  kerbWeightMin: 1335,
                  abi1: '07030102',
                  driveType: '4X2',
                  abi2_50: '41A',
                  carwebIndicativeValue: 2700,
                  refID: '21898',
                  closestMatchABI: 'N'
                },
                registrationNumber: 'OX03YBG',
                variant: 'Z4 ROADSTER',
                engineSize: '2494',
                bhp: '189.1',
                fuelType: 'PETROL',
                transmission: 'AUTOMATIC',
                noOfDoors: 2,
                isVehicleModified: false,
                modifications: [],
                isVehiclePurchased: true,
                purchaseDate: {
                  year: 2016,
                  month: 1,
                  day: 1
                },
                registeredOwner: 'you',
                garageNightPostcode: 'BR1 1DP',
                isVehicleGarageAtHome: true,
                ncdOwnerInUse: 'rc3e2ett4:4026',
                yearsNoClaim: '1',
                monthsNoClaim: '0',
                ncdEarn: 'withthisvehorprevveh',
                vehicleEndorsement: [],
                vehicleStartDate: {
                  year: 2020,
                  month: 10,
                  day: 23
                },
                vehicleEndDate: {
                  year: 2021,
                  month: 10,
                  day: 22
                },
                typeOfVehicle: 'permanent',
                travellingInd: false,
                schItems: []
              }
            }
          ],
          vehicleDrivers: [
            {
              driversID: [
                'rc3e2ett4:4026'
              ],
              vehicleID: 'rc3e2ett4:2238',
              mainDriverID: 'rc3e2ett4:4026'
            }
          ]
        },
        offerings: [
          {
            branchName: 'CUSTOM',
            periodPublicId_dlg: 'rc3e2ett4:2298-comp',
            offeringCode_dlg: 'comp',
            coverages: {
              vehicleCoverages: [
                {
                  publicID: 'rc3e2ett4:2238',
                  fixedId: 2238,
                  vehicleName: '2003 BMW Z SERIES (OX03YBG)',
                  typeOfVehicle: 'permanent',
                  automaticAppliedPromos_dlg: [
                    {
                      code: '50\u00a3OFF',
                      descriptions: [
                        '\u00a350 off Motor Prem - 1 year only'
                      ],
                      userSelectable: false
                    }
                  ],
                  coverages: [
                    {
                      name: 'Guaranteed Hire Car Plus',
                      codeIdentifier_dlg: 'MOTGuaranteedHireCarPlusCov',
                      selected: false,
                      required: false,
                      description: 'Guaranteed Hire Car Plus',
                      amount: {
                        amount: 20.16,
                        currency: 'gbp'
                      },
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Electable',
                      monthlyAmount_dlg: {
                        amount: 1.9,
                        currency: 'gbp'
                      }
                    },
                    {
                      name: 'Accidental Damage',
                      codeIdentifier_dlg: 'MOTAccidentalDamageCov',
                      selected: true,
                      required: true,
                      description: 'Accidental Damage',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Windscreen',
                      codeIdentifier_dlg: 'MOTWindScreenCov',
                      selected: true,
                      required: true,
                      description: 'Windscreen',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Uninsured Drivers Promise',
                      codeIdentifier_dlg: 'MOTUninsuredDriversPromiseCov',
                      selected: true,
                      required: true,
                      description: 'Uninsured Drivers Promise',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Theft',
                      codeIdentifier_dlg: 'MOTTheftCov',
                      selected: true,
                      required: true,
                      description: 'Theft',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Personal Benefits',
                      codeIdentifier_dlg: 'MOTPersonalBenefitsCov',
                      selected: true,
                      required: true,
                      description: 'Personal Benefits',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Fire',
                      codeIdentifier_dlg: 'MOTFireCov',
                      selected: true,
                      required: true,
                      description: 'Fire',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Courtesy Car',
                      codeIdentifier_dlg: 'MOTCourtesyCarCov',
                      selected: true,
                      required: true,
                      description: 'Courtesy Car',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Third Party Liability',
                      codeIdentifier_dlg: 'MOTThirdPartyLiabCov',
                      selected: true,
                      required: true,
                      description: 'Third Party Liability',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Motor Legal Cover',
                      codeIdentifier_dlg: 'MOTLegalCoverCov',
                      selected: false,
                      required: false,
                      description: 'Motor Legal Cover',
                      amount: {
                        amount: 28.0,
                        currency: 'gbp'
                      },
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Electable',
                      monthlyAmount_dlg: {
                        amount: 2.63,
                        currency: 'gbp'
                      }
                    },
                    {
                      name: 'Driving Other Cars',
                      codeIdentifier_dlg: 'MOTDrivingOtherCarsCov',
                      selected: true,
                      required: true,
                      description: 'Driving Other Cars',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Guaranteed Repairs',
                      codeIdentifier_dlg: 'MOTRepairsCov',
                      selected: true,
                      required: true,
                      description: 'Guaranteed Repairs',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    }
                  ],
                  rescueCoverages_dlg: [
                    {
                      covName: 'fulluk',
                      coverages: [
                        {
                          name: 'Personal Cover',
                          codeIdentifier_dlg: 'RESPersonalCov',
                          description: 'Personal Cover',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Caravan and Trailer Cover',
                          codeIdentifier_dlg: 'RESCaravanandTrailerCvrCov',
                          description: 'Caravan and Trailer Cover',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Specialist Equipment',
                          codeIdentifier_dlg: 'RESSpecialistEquipmentCov',
                          description: 'Specialist Equipment',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Onward Travel Options',
                          codeIdentifier_dlg: 'RESOnwardTravelOptsCov',
                          description: 'Onward Travel Options',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'National Recovery',
                          codeIdentifier_dlg: 'RESNationalRecoveryCov',
                          description: 'National Recovery',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Roadside Assistance',
                          codeIdentifier_dlg: 'RESRoadsideAssistanceCov',
                          description: 'Roadside Assistance',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Home Breakdown',
                          codeIdentifier_dlg: 'RESHomeBreakdownCov',
                          description: 'Home Breakdown',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        }
                      ],
                      amount: {
                        amount: 88.88,
                        currency: 'gbp'
                      },
                      monthlyAmount: {
                        amount: 8.3,
                        currency: 'gbp'
                      },
                      selected: false
                    },
                    {
                      covName: 'roadsidehome',
                      coverages: [
                        {
                          name: 'Personal Cover',
                          codeIdentifier_dlg: 'RESPersonalCov',
                          description: 'Personal Cover',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Caravan and Trailer Cover',
                          codeIdentifier_dlg: 'RESCaravanandTrailerCvrCov',
                          description: 'Caravan and Trailer Cover',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Specialist Equipment',
                          codeIdentifier_dlg: 'RESSpecialistEquipmentCov',
                          description: 'Specialist Equipment',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Roadside Assistance',
                          codeIdentifier_dlg: 'RESRoadsideAssistanceCov',
                          description: 'Roadside Assistance',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Home Breakdown',
                          codeIdentifier_dlg: 'RESHomeBreakdownCov',
                          description: 'Home Breakdown',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        }
                      ],
                      amount: {
                        amount: 63.03,
                        currency: 'gbp'
                      },
                      monthlyAmount: {
                        amount: 5.9,
                        currency: 'gbp'
                      },
                      selected: false
                    },
                    {
                      covName: 'roadside',
                      coverages: [
                        {
                          name: 'Personal Cover',
                          codeIdentifier_dlg: 'RESPersonalCov',
                          description: 'Personal Cover',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Caravan and Trailer Cover',
                          codeIdentifier_dlg: 'RESCaravanandTrailerCvrCov',
                          description: 'Caravan and Trailer Cover',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Specialist Equipment',
                          codeIdentifier_dlg: 'RESSpecialistEquipmentCov',
                          description: 'Specialist Equipment',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Roadside Assistance',
                          codeIdentifier_dlg: 'RESRoadsideAssistanceCov',
                          description: 'Roadside Assistance',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        }
                      ],
                      amount: {
                        amount: 29.54,
                        currency: 'gbp'
                      },
                      monthlyAmount: {
                        amount: 2.77,
                        currency: 'gbp'
                      },
                      selected: false
                    }
                  ],
                  vehicleExcess_dlg: {
                    compulsoryExcess: 200.0,
                    voluntaryExcess: [
                      0,
                      25,
                      50,
                      75,
                      100,
                      125,
                      150,
                      175,
                      200,
                      225,
                      250,
                      275,
                      300,
                      325,
                      350,
                      375,
                      400,
                      425,
                      450,
                      475,
                      500
                    ],
                    selectedVoluntaryExcess: 250.0,
                    driverExcess: 0.0,
                    totalExcess: 450.0,
                    fireandTheftExcess: 450,
                    windScreenRepair: 10.0,
                    windScreenReplace: 75.0,
                    nonApprovedRepairerExcess: 200.0
                  }
                }
              ]
            },
            versionGroupId_dlg: 1,
            driverExcess_dlg: [
              {
                publicID: 'rc3e2ett4:2732',
                name: 'Tod Altenwerth',
                mainDriver: true,
                compulsoryExcess: 200.0,
                voluntaryExcess: 250.0,
                fireandTheftExcess: 200.0,
                fireandTheftTotalExcess: 450,
                driverExcess: 0.0,
                totalExcess: 450.0,
                windScreenRepair: 10.0,
                windScreenReplace: 75.0,
                vehicleID: 'rc3e2ett4:2238',
                driverID: 'rc3e2ett4:4026',
                nonApprovedRepairerExcess: 200.0
              }
            ],
            noClaimDiscountApplied_dlg: false
          },
          {
            branchName: 'CUSTOM',
            periodPublicId_dlg: 'rc3e2ett4:2298-drivexpert',
            offeringCode_dlg: 'drivexpert',
            versionGroupId_dlg: 1
          },
          {
            branchName: 'CUSTOM',
            periodPublicId_dlg: 'rc3e2ett4:2298-tpft',
            offeringCode_dlg: 'tpft',
            versionGroupId_dlg: 1
          },
          {
            branchName: 'CUSTOM',
            periodPublicId_dlg: 'rc3e2ett4:2298-compplus',
            offeringCode_dlg: 'compplus',
            versionGroupId_dlg: 1
          }
        ]
      }
    },
    quoteData: {
      offeredQuotes: [
        {
          publicID: 'rc3e2ett4:2298-comp',
          branchName: 'CUSTOM',
          branchCode: 'comp',
          isCustom: true,
          premium: {
            total: {
              amount: 1822.48,
              currency: 'gbp'
            },
            monthlyPremium: {
              amount: 170.1,
              currency: 'gbp'
            },
            termMonths: 12,
            taxes: {
              amount: 195.26,
              currency: 'gbp'
            },
            totalBeforeTaxes: {
              amount: 1627.22,
              currency: 'gbp'
            },
            offeringPremium_dlg: {
              amount: 1822.48,
              currency: 'gbp'
            }
          }
        },
        {
          publicID: 'rc3e2ett4:2298-drivexpert',
          branchName: 'CUSTOM',
          branchCode: 'drivexpert',
          isCustom: false,
          premium: {
            total: {
              amount: 1822.48,
              currency: 'gbp'
            },
            termMonths: 12,
            taxes: {
              amount: 195.26,
              currency: 'gbp'
            },
            totalBeforeTaxes: {
              amount: 1627.22,
              currency: 'gbp'
            },
            offeringPremium_dlg: {
              amount: 1822.48,
              currency: 'gbp'
            }
          }
        },
        {
          publicID: 'rc3e2ett4:2298-tpft',
          branchName: 'CUSTOM',
          branchCode: 'tpft',
          isCustom: false,
          premium: {
            total: {
              amount: 1629.56,
              currency: 'gbp'
            },
            termMonths: 12,
            taxes: {
              amount: 174.59,
              currency: 'gbp'
            },
            totalBeforeTaxes: {
              amount: 1454.97,
              currency: 'gbp'
            },
            offeringPremium_dlg: {
              amount: 1629.56,
              currency: 'gbp'
            }
          }
        },
        {
          publicID: 'rc3e2ett4:2298-compplus',
          branchName: 'CUSTOM',
          branchCode: 'compplus',
          isCustom: false,
          premium: {
            total: {
              amount: 1872.32,
              currency: 'gbp'
            },
            termMonths: 12,
            taxes: {
              amount: 200.6,
              currency: 'gbp'
            },
            totalBeforeTaxes: {
              amount: 1671.72,
              currency: 'gbp'
            },
            offeringPremium_dlg: {
              amount: 1872.32,
              currency: 'gbp'
            }
          }
        }
      ]
    },
    bindData: {
      accountNumber: '4052076343',
      chosenQuote: 'rc3e2ett4:2298-comp',
      offeredPaymentPlans_dlg: [
        {
          periodPublicId: 'rc3e2ett4:2298-comp',
          branchName: 'comp',
          paymentPlans: [
            {
              name: 'Single Payment',
              downPayment: {
                amount: 0.0,
                currency: 'gbp'
              },
              total: {
                amount: 1822.48,
                currency: 'gbp'
              },
              installment: {
                amount: 0.0,
                currency: 'gbp'
              },
              billingId: 'dlg_payment_plan:1',
              firstInstallment_dlg: {
                amount: 0.0,
                currency: 'gbp'
              },
              remainingInstallment_dlg: {
                amount: 1822.48,
                currency: 'gbp'
              },
              installmentPercentage_dlg: 0,
              installmentCharge_dlg: {
                amount: 0.0,
                currency: 'gbp'
              },
              aPR_dlg: 0
            },
            {
              name: 'Monthly - Deposit and 10 Instalments',
              downPayment: {
                amount: 303.68,
                currency: 'gbp'
              },
              total: {
                amount: 2004.68,
                currency: 'gbp'
              },
              installment: {
                amount: 170.1,
                currency: 'gbp'
              },
              billingId: 'dlg_payment_plan:2',
              firstInstallment_dlg: {
                amount: 170.1,
                currency: 'gbp'
              },
              remainingInstallment_dlg: {
                amount: 1518.8,
                currency: 'gbp'
              },
              installmentPercentage_dlg: 12.0,
              installmentCharge_dlg: {
                amount: 182.2,
                currency: 'gbp'
              },
              aPR_dlg: 28.6
            }
          ]
        }
      ],
      contactPhone: '01622200331',
      contactEmail: 'success+jfiogi31@simulator.amazonses.com',
      confirmToProceedInd_dlg: false,
      driversEmail_dlg: [
        {
          publicID: 'rc3e2ett4:4026',
          emailAddress: 'success+jfiogi31@simulator.amazonses.com'
        }
      ],
      promoFullFilment_dlg: []
    },
    selectedPeriodPublicId_dlg: 'rc3e2ett4:2298-comp',
    defaultOfferingPublicId_dlg: 'rc3e2ett4:2298-comp'
  },
  jsonrpc: '2.0'
};

