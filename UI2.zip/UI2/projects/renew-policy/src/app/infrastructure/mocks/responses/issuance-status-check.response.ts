export const IssuanceStatusCheck = {
  result: {
    quoteID: '0109249669',
    quoteRef_dlg: 'DLI20000014708',
    baseData: {
      accountNumber: '2656314320',
      accountHolder: {
        emailAddress1: 'sitttdlannualonlyauto@getnada.com',
        publicID: 'r1c3sittt:5740',
        displayName: 'Dl Aajbg',
        primaryPhoneType: 'other_Dlg',
        workNumber: '01234567898',
        subtype: 'Person',
        primaryAddress: {
          publicID: 'r1c3sittt:13309',
          displayName: 'Churchill Court, Masons Hill, BROMLEY, Kent, BR1 1DP',
          addressLine1: 'Churchill Court',
          addressLine2: 'Masons Hill',
          city: 'BROMLEY',
          postalCode: 'BR1 1DP',
          country: 'GB',
          addressType: 'home',
          uPRN_dlg: '10003627976',
          county_dlg: 'Kent',
          xcordinate_dlg: '540351',
          ycordinate_dlg: '168591',
          latitude_dlg: '51.3989963',
          longitude_dlg: '.0161911',
          uDPRN_dlg: '0000000000000000'
        },
        accountHolder: true,
        dateOfBirth: {
          year: 1951,
          month: 4,
          day: 29
        },
        gender: 'M',
        firstName: 'Dl',
        lastName: 'Aajbg',
        prefix: 'mr',
        maritalStatus: 'M',
        brand_dlg: 'directline',
        isCorrespondAdSameAsPrimAd_dlg: true,
        employmentStatus_dlg: 'employedfulltime',
        occupation_dlg: 'C890',
        largePrint_dlg: false,
        braille_dlg: false,
        audioCD_dlg: false,
        audioTape_dlg: false,
        mp3OnUSBStick_dlg: false,
        oktaid_dlg: '00u1iz3c8ngAmIfo00x7',
        customerPref_dlg: 'portal',
        sfid_dlg: '00126000018ZEBbAAO',
        goneAwayFlag_dlg: false,
        deceasedFlag_dlg: false
      },
      policyAddress: {
        publicID: 'r1c3sittt:13309',
        displayName: 'Churchill Court, Masons Hill, BROMLEY, Kent, BR1 1DP',
        addressLine1: 'Churchill Court',
        addressLine2: 'Masons Hill',
        city: 'BROMLEY',
        postalCode: 'BR1 1DP',
        country: 'GB',
        addressType: 'home',
        uPRN_dlg: '10003627976',
        county_dlg: 'Kent',
        xcordinate_dlg: '540351',
        ycordinate_dlg: '168591',
        latitude_dlg: '51.3989963',
        longitude_dlg: '.0161911',
        uDPRN_dlg: '0000000000000000'
      },
      productCode: 'Combined',
      sfProductName_dlg: 'Motor',
      productName: 'Personal Combined',
      periodStartDate: {
        year: 2022,
        month: 4,
        day: 12
      },
      periodEndDate: {
        year: 2023,
        month: 4,
        day: 11
      },
      termType: '12months_Dlg',
      periodStatus: 'Bound',
      channel_dlg: 'digital',
      source_dlg: 'directdigital',
      isChildrenUnder16_dlg: false,
      ownHome_dlg: true,
      noOfVehiclesInHome_dlg: '1',
      paymentType_dlg: 'infull',
      anotherBrandInd_dlg: false,
      cancelByInsurerInd_dlg: false,
      quoteExpiryDate_dlg: {
        year: 2022,
        month: 5,
        day: 8
      },
      transactionType_Dlg: 'Renewal',
      periodStartTime_dlg: {
        hour: 0,
        minute: 1,
        second: 0,
        millisecond: 0
      },
      isCorrespondAdSameAsPolAd_dlg: true,
      deviceDetails_dlg: {},
      sameBrandInd_dlg: false,
      basicMultiCarInd_dlg: false,
      termNumber_dlg: 2,
      motorBookletVersion_dlg: 'B4C DL M PB 0121',
      rescueBookletVersion_dlg: 'B4C GF LR PB 0121',
      motorIPIDVersion_dlg: 'B4C DL M TPFT IPID 0121',
      rescueIPIDVersion_dlg: 'B4C GF LR UK/EURO IPID 0121',
      accDamageCovInd: false
    },
    lobData: {
      mOTLine_Ext: {
        coverables: {
          drivers: [
            {
              fixedId: 33435,
              publicID: 'r1c3sittt:42039',
              person: {
                publicID: 'r1c3sittt:5740',
                displayName: 'Dl Aajbg',
                firstName: 'Dl',
                lastName: 'Aajbg',
                prefix: 'mr',
                primaryPhoneType: 'other_Dlg',
                workNumber: '01234567898',
                maritalStatus: 'M',
                dateOfBirth: {
                  year: 1951,
                  month: 4,
                  day: 29
                },
                gender: 'M'
              },
              gender: 'M',
              isPolicyHolder: true,
              residentInUkFromBirth: true,
              employmentStatus_dlg: 'employedfulltime',
              occupation_dlg: 'C890',
              yearInUK_dlg: {
                year: 1951,
                month: 4,
                day: 29
              },
              driverStartDate: {
                year: 2022,
                month: 4,
                day: 12
              },
              driverEndDate: {
                year: 2023,
                month: 4,
                day: 11
              },
              driverType: 'permanent',
              permanentUKResident: true,
              isLicenceVerified: true,
              licenceNumber: 'AAJBG505291DL9EW',
              isLicenceExpired: false,
              isLicenceUsed: true
            }
          ],
          motVehicles: [
            {
              fixedId: 12279,
              publicID: 'r1c3sittt:14854',
              vehicle: {
                fixedId: 13014,
                publicID: 'r1c3sittt:15899',
                vehicleNumber: 1,
                year: 2019,
                make: 'MERCEDES',
                model: 'A-CLASS',
                vin: 'WDD1770442V019927',
                annualMileage: 4000,
                primaryUse: 'sdpbspolholder_dlg',
                costNew: {
                  amount: 22300,
                  currency: 'gbp'
                },
                displayName: 'MERCEDES A-CLASS 2019',
                color: 'WHITE',
                bodyType: 'HATCHBACK',
                vRNLookupResp: {
                  dateOfFirstRegistrationUK: '2019-01-24T00:00:00Z',
                  cherishedTransferDate: '2019-04-06T23:00:00Z',
                  dateOfManufacture: '2019-01-24T00:00:00Z',
                  colourCurrent: 'WHITE',
                  lengthMM: 4419,
                  widthMM: 1796,
                  heightMM: 1445,
                  numberOfPreviousKeepers: 1,
                  startDateOfCurrentKeeper: '2019-03-20T00:00:00Z',
                  importMarker: false,
                  scrappingMarker: 0,
                  scrappedRemovedMarker: false,
                  modelSeries: 'W177',
                  modelYear: '2018',
                  introductionDateToUK: '2018-07-31T23:00:00Z',
                  terminationdate: '2009-06-30T23:00:00Z',
                  aspiration: 'TURBO CHARGED',
                  combined_ForwardGears: 7,
                  arrangementOfCylinders: 'IN LINE',
                  numberOfCylinders: 4,
                  driveAxle: 'FRONT',
                  engineLocation: 'FRONT',
                  maximumTorqueNM: 350,
                  maximumPowerInKW: 140,
                  fuelConsumptionExtraUrbanMPG: 56.5,
                  maximumSpeedMPH: 149,
                  accelerationTo100KPHSecs: 6.9,
                  euroStatus: 'E6',
                  cO2: 141,
                  grossWeight: 1960,
                  seats: 5,
                  kerbWeightMin: 1450,
                  abi1: '32132822',
                  driveType: '4X2',
                  abi2_50: '28E',
                  carwebIndicativeValue: 22300,
                  refID: '675337',
                  closestMatchABI: 'N'
                },
                registrationNumber: 'AB12',
                engineSize: '1991',
                bhp: '187.7',
                fuelType: 'PETROL',
                transmission: 'AUTOMATIC',
                noOfDoors: 5,
                isVehicleModified: false,
                modifications: [],
                isVehiclePurchased: true,
                purchaseDate: {
                  year: 2020,
                  month: 0,
                  day: 1
                },
                registeredOwner: 'you',
                garageNightPostcode: 'BR1 1DP',
                isVehicleGarageAtHome: true,
                ncdOwnerInUse: 'r1c3sittt:42039',
                yearsNoClaim: '9plus',
                ncdEarn: 'withthisvehorprevveh',
                vehicleEndorsement: [
                  {
                    code: 'E0004',
                    name: 'No DOC',
                    description: 'There is no cover when driving another vehicle.'
                  }
                ],
                vehicleStartDate: {
                  year: 2022,
                  month: 4,
                  day: 12
                },
                vehicleEndDate: {
                  year: 2023,
                  month: 4,
                  day: 11
                },
                typeOfVehicle: 'permanent',
                travellingInd: false,
                schItems: []
              }
            }
          ],
          vehicleDrivers: [
            {
              driversID: [
                'r1c3sittt:42039'
              ],
              vehicleID: 'r1c3sittt:15899',
              mainDriverID: 'r1c3sittt:42039'
            }
          ]
        },
        offerings: [
          {
            branchName: 'Version #1',
            periodPublicId_dlg: 'r1c3sittt:12904-tpft',
            offeringCode_dlg: 'tpft',
            coverages: {
              vehicleCoverages: [
                {
                  publicID: 'r1c3sittt:15899',
                  fixedId: 13014,
                  vehicleName: '2019 MERCEDES A-CLASS (AB12)',
                  typeOfVehicle: 'permanent',
                  automaticAppliedPromos_dlg: [
                    {
                      code: 'MCD',
                      descriptions: [
                        'Multicar discount has been applied for this policy year'
                      ],
                      userSelectable: false
                    },
                    {
                      code: 'MTPOL',
                      descriptions: [
                        'Multi-policy discount has been applied for this policy year'
                      ],
                      userSelectable: false
                    }
                  ],
                  coverages: [
                    {
                      name: '7 Day Repair',
                      codeIdentifier_dlg: 'MOTSevenDayRepairCov',
                      updated: false,
                      selected: true,
                      required: true,
                      description: '7 Day Repair',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Fire',
                      codeIdentifier_dlg: 'MOTFireCov',
                      updated: false,
                      selected: true,
                      required: true,
                      description: 'Fire',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Motor Legal Cover',
                      codeIdentifier_dlg: 'MOTLegalCoverCov',
                      selected: false,
                      required: false,
                      description: 'Motor Legal Cover',
                      amount: {
                        amount: 22.4,
                        currency: 'gbp'
                      },
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Electable'
                    },
                    {
                      name: 'Third Party Liability',
                      codeIdentifier_dlg: 'MOTThirdPartyLiabCov',
                      updated: false,
                      selected: true,
                      required: true,
                      description: 'Third Party Liability',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Protected No Claim Discount',
                      codeIdentifier_dlg: 'MOTNoClaimDiscCov',
                      selected: false,
                      required: false,
                      description: 'Protected No Claim Discount',
                      amount: {
                        amount: 16.3,
                        currency: 'gbp'
                      },
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Electable'
                    },
                    {
                      name: 'Guaranteed Repairs',
                      codeIdentifier_dlg: 'MOTRepairsCov',
                      updated: false,
                      selected: true,
                      required: true,
                      description: 'Guaranteed Repairs',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Theft',
                      codeIdentifier_dlg: 'MOTTheftCov',
                      updated: false,
                      selected: true,
                      required: true,
                      description: 'Theft',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    }
                  ],
                  vehicleExcess_dlg: {
                    driverExcess: 0,
                    fireandTheftExcess: 50,
                    nonApprovedRepairerExcess: 0
                  }
                }
              ]
            },
            versionGroupId_dlg: 3,
            driverExcess_dlg: [
              {
                publicID: 'r1c3sittt:16003',
                name: 'Dl Aajbg',
                mainDriver: true,
                compulsoryExcess: 0,
                voluntaryExcess: 250,
                fireandTheftExcess: 50,
                fireandTheftTotalExcess: 50,
                driverExcess: 0,
                totalExcess: 250,
                vehicleID: 'r1c3sittt:15899',
                driverID: 'r1c3sittt:42039',
                nonApprovedRepairerExcess: 0
              }
            ],
            noClaimDiscountApplied_dlg: false
          }
        ]
      }
    },
    quoteData: {
      offeredQuotes: [
        {
          publicID: 'r1c3sittt:12904-tpft',
          branchName: 'Version #1',
          branchCode: 'tpft',
          isCustom: true,
          premium: {
            total: {
              amount: 7902.01,
              currency: 'gbp'
            },
            termMonths: 12,
            taxes: {
              amount: 846.64,
              currency: 'gbp'
            },
            totalBeforeTaxes: {
              amount: 7055.37,
              currency: 'gbp'
            },
            offeringPremium_dlg: {
              amount: 7840,
              currency: 'gbp'
            },
            previousTotalCost_dlg: {
              amount: 151.2,
              currency: 'gbp'
            }
          }
        }
      ]
    },
    bindData: {
      chosenQuote: 'r1c3sittt:12904-tpft',
      offeredPaymentPlans_dlg: [
        {
          periodPublicId: 'r1c3sittt:12904-tpft',
          paymentPlans: [
            {
              name: 'Single Payment',
              downPayment: {
                amount: 0,
                currency: 'gbp'
              },
              total: {
                amount: 7902.01,
                currency: 'gbp'
              },
              installment: {
                amount: 0,
                currency: 'gbp'
              },
              billingId: 'dlg_payment_plan:1'
            }
          ]
        }
      ],
      selectedPaymentPlan: 'dlg_payment_plan:1',
      policyNumber: '9000016411'
    },
    selectedPeriodPublicId_dlg: 'r1c3sittt:12904-tpft',
    policyNumber: '9000016411'
  },
  jsonrpc: '2.0'
};
