export const OttRetrieveQuoteResponse = {
  result: {
    quoteID: '0002492037',
    quoteRef_dlg: 'PRV10008770627',
    baseData: {
      accountNumber: '3529030065',
      accountHolder: {
        emailAddress1: '150615092020rc3e2e@getnada.com',
        publicID: 'r1c3e2e:89909',
        displayName: 'Claire Currin',
        primaryPhoneType: 'other_Dlg',
        workNumber: '07777777777',
        subtype: 'Person',
        primaryAddress: {
          publicID: 'r1c3e2e:439314',
          displayName: '306 Wilsthorpe Road, Long Eaton, NOTTINGHAM, Nottinghamshire, NG10 4AA',
          addressLine1: '306 Wilsthorpe Road',
          addressLine2: 'Long Eaton',
          city: 'NOTTINGHAM',
          postalCode: 'NG10 4AA',
          country: 'GB',
          addressType: 'home',
          uPRN_dlg: '100030162008',
          county_dlg: 'Nottinghamshire',
          xcordinate_dlg: '447721',
          ycordinate_dlg: '333447',
          latitude_dlg: '52.8963771',
          longitude_dlg: '-1.2920706',
          uDPRN_dlg: '0000000016518565'
        },
        accountHolder: true,
        dateOfBirth: {
          year: 1996,
          month: 0,
          day: 1
        },
        gender: 'F',
        firstName: 'Claire',
        lastName: 'Currin',
        prefix: 'mrs',
        maritalStatus: 'M',
        brand_dlg: 'privilege',
        isCorrespondAdSameAsPrimAd_dlg: true,
        employmentStatus_dlg: 'employedfulltime',
        occupation_dlg: 'A20',
        businessType_dlg: '001',
        largePrint_dlg: false,
        braille_dlg: false,
        audioCD_dlg: false,
        audioTape_dlg: false,
        mp3OnUSBStick_dlg: false,
        oktaid_dlg: '00uufq88maLLu30RO0h7',
        customerPref_dlg: 'portal',
        sfid_dlg: '00126000012TKU5AAO',
        goneAwayFlag_dlg: false,
        deceasedFlag_dlg: false
      },
      policyAddress: {
        publicID: 'r1c3e2e:348943',
        displayName: '300 Wilsthorpe Road, Long Eaton, NOTTINGHAM, Nottinghamshire, NG10 4AA',
        addressLine1: '300 Wilsthorpe Road',
        addressLine2: 'Long Eaton',
        city: 'NOTTINGHAM',
        postalCode: 'NG10 4AA',
        country: 'GB',
        addressType: 'home',
        uPRN_dlg: '100030162005',
        county_dlg: 'Nottinghamshire',
        xcordinate_dlg: '447761',
        ycordinate_dlg: '333376',
        latitude_dlg: '52.8957354',
        longitude_dlg: '-1.2914864',
        uDPRN_dlg: '0000000016518562'
      },
      productCode: 'Combined',
      sfProductName_dlg: 'Motor',
      productName: 'Personal Combined',
      periodStartDate: {
        year: 2021,
        month: 9,
        day: 22
      },
      periodEndDate: {
        year: 2022,
        month: 9,
        day: 21
      },
      termType: '12months_Dlg',
      periodStatus: 'Quoted',
      channel_dlg: 'pcw',
      source_dlg: 'gocompare',
      isChildrenUnder16_dlg: true,
      ownHome_dlg: false,
      noOfVehiclesInHome_dlg: '1',
      paymentType_dlg: 'monthly',
      anotherBrandInd_dlg: false,
      cancelByInsurerInd_dlg: false,
      quoteExpiryDate_dlg: {
        year: 2020,
        month: 10,
        day: 20
      },
      transactionType_Dlg: 'Renewal',
      periodStartTime_dlg: {
        hour: 0,
        minute: 1,
        second: 0,
        millisecond: 0
      },
      isCorrespondAdSameAsPolAd_dlg: true,
      deviceDetails_dlg: {},
      sameBrandInd_dlg: false,
      basicMultiCarInd_dlg: false,
      termNumber_dlg: 2,
      motorBookletVersion_dlg: 'B4C PRIV M PB 0121',
      rescueBookletVersion_dlg: 'B4C GF LR PB 0121',
      motorIPIDVersion_dlg: 'B4C PRIV M COMP IPID 0121',
      rescueIPIDVersion_dlg: 'B4C GF LR UK/EURO IPID 0121',
      accDamageCovInd: true
    },
    lobData: {
      mOTLine_Ext: {
        coverables: {
          drivers: [
            {
              fixedId: 1054775,
              publicID: 'r1c3e2e:1111312',
              person: {
                publicID: 'r1c3e2e:89909',
                displayName: 'Claire Currin',
                firstName: 'Claire',
                lastName: 'Currin',
                prefix: 'mr',
                primaryPhoneType: 'other_Dlg',
                workNumber: '07777777777',
                maritalStatus: 'S',
                dateOfBirth: {
                  year: 1996,
                  month: 0,
                  day: 1
                },
                gender: 'F'
              },
              gender: 'M',
              isPolicyHolder: true,
              residentInUkFromBirth: true,
              typeOfDrivingLicense: 'fulluk',
              lengthOfDrivingLicHeldYear: '5',
              employmentStatus_dlg: 'employedfulltime',
              occupation_dlg: 'S430',
              businessType_dlg: '140',
              yearInUK_dlg: {
                year: 1996,
                month: 0,
                day: 1
              },
              driverStartDate: {
                year: 2021,
                month: 9,
                day: 22
              },
              driverEndDate: {
                year: 2022,
                month: 9,
                day: 21
              },
              driverType: 'permanent',
              permanentUKResident: true,
              isLicenceVerified: false,
              isLicenceExpired: false,
              isLicenceUsed: false
            },
            {
              fixedId: 1054781,
              publicID: 'r1c3e2e:1111313',
              person: {
                publicID: 'r1c3e2e:93607',
                displayName: 'Tm Cfyyy',
                firstName: 'Tm',
                lastName: 'Cfyyy',
                prefix: 'mr',
                primaryPhoneType: 'other_Dlg',
                maritalStatus: 'S',
                dateOfBirth: {
                  year: 1944,
                  month: 10,
                  day: 29
                },
                gender: 'M'
              },
              gender: 'M',
              isPolicyHolder: false,
              relationToPolHolder: 'employee',
              residentInUkFromBirth: true,
              employmentStatus_dlg: 'employedfulltime',
              occupation_dlg: 'H60',
              businessType_dlg: '055',
              yearInUK_dlg: {
                year: 1944,
                month: 10,
                day: 29
              },
              driverStartDate: {
                year: 2021,
                month: 9,
                day: 22
              },
              driverEndDate: {
                year: 2022,
                month: 9,
                day: 21
              },
              driverType: 'permanent',
              permanentUKResident: true,
              isLicenceVerified: false,
              isLicenceExpired: false,
              isLicenceUsed: true
            }
          ],
          motVehicles: [
            {
              fixedId: 357923,
              publicID: 'r1c3e2e:378332',
              vehicle: {
                fixedId: 414323,
                publicID: 'r1c3e2e:436233',
                vehicleNumber: 1,
                year: 2015,
                make: 'MINI',
                model: 'ROADSTER',
                vin: 'WMWSY920X0T495810',
                annualMileage: 21000,
                primaryUse: 'sdpexclcomm_dlg',
                costNew: {
                  amount: 2121,
                  currency: 'gbp'
                },
                displayName: 'MINI ROADSTER 2015',
                color: 'WHITE',
                bodyType: 'CONVERTIBLE',
                vRNLookupResp: {
                  dateOfFirstRegistrationUK: '2015-05-04T23:00:00Z',
                  dateOfManufacture: '2015-05-04T23:00:00Z',
                  marketSegment: 'SUPER MINI',
                  colourCurrent: 'WHITE',
                  lengthMM: 3758,
                  widthMM: 1683,
                  heightMM: 1391,
                  numberOfPreviousKeepers: 1,
                  startDateOfCurrentKeeper: '2018-05-30T23:00:00Z',
                  importMarker: false,
                  scrappingMarker: 0,
                  scrappedRemovedMarker: false,
                  modelSeries: 'R59',
                  modelYear: '2012',
                  introductionDateToUK: '2012-07-01T23:00:00Z',
                  aspiration: 'TURBO CHARGED',
                  combined_ForwardGears: 6,
                  arrangementOfCylinders: 'IN LINE',
                  numberOfCylinders: 4,
                  driveAxle: 'FRONT',
                  engineLocation: 'FRONT',
                  maximumTorqueNM: 260,
                  maximumPowerInKW: 156,
                  fuelConsumptionExtraUrbanMPG: 51.4,
                  fuelConsumptionExtraUrban_Ltr100km: 5.5,
                  fuelConsumptionUrbanCold_Ltr100km: 10.4,
                  maximumSpeedMPH: 146,
                  accelerationTo100KPHSecs: 6.7,
                  euroStatus: 'E5',
                  cO2: 169,
                  grossWeight: 1695,
                  seats: 2,
                  kerbWeightMin: 1215,
                  abi1: '33815804',
                  driveType: '4X2',
                  abi2_50: '36E',
                  carwebIndicativeValue: 8700,
                  refID: '137212'
                },
                registrationNumber: 'PK15XGA',
                variant: 'JOHN COOPER WORKS',
                engineSize: '1598',
                bhp: '208',
                fuelType: 'PETROL',
                transmission: 'AUTOMATIC',
                noOfDoors: 2,
                isVehicleModified: false,
                modifications: [],
                isVehiclePurchased: true,
                purchaseDate: {
                  year: 2020,
                  month: 4,
                  day: 1
                },
                registeredOwner: 'you',
                garageNightPostcode: 'NG10 4AA',
                garageNightLocation: 'onthedriveway',
                isVehicleGarageAtHome: true,
                ncdOwnerInUse: 'r1c3e2e:1111312',
                yearsNoClaim: '5',
                ncdEarn: 'withthisvehorprevveh',
                carWebId: '137212',
                vehicleEndorsement: [],
                vehicleStartDate: {
                  year: 2021,
                  month: 9,
                  day: 22
                },
                vehicleEndDate: {
                  year: 2022,
                  month: 9,
                  day: 21
                },
                typeOfVehicle: 'permanent',
                travellingInd: false,
                schItems: []
              }
            }
          ],
          vehicleDrivers: [
            {
              driversID: [
                'r1c3e2e:1111313',
                'r1c3e2e:1111312'
              ],
              vehicleID: 'r1c3e2e:436233',
              mainDriverID: 'r1c3e2e:1111312'
            }
          ]
        },
        offerings: [
          {
            branchName: 'Version #1 (1)',
            periodPublicId_dlg: 'r1c3e2e:316022-comp',
            offeringCode_dlg: 'comp',
            coverages: {
              vehicleCoverages: [
                {
                  publicID: 'r1c3e2e:436233',
                  fixedId: 414323,
                  vehicleName: '2015 MINI ROADSTER (PK15XGA)',
                  typeOfVehicle: 'permanent',
                  automaticAppliedPromos_dlg: [
                    {
                      code: 'MC1',
                      descriptions: [
                        'Multicar Discount'
                      ],
                      userSelectable: false
                    }
                  ],
                  coverages: [
                    {
                      name: 'Windscreen',
                      codeIdentifier_dlg: 'MOTWindScreenCov',
                      selected: true,
                      required: true,
                      description: 'Windscreen',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Motor Legal Cover',
                      codeIdentifier_dlg: 'MOTLegalCoverCov',
                      selected: true,
                      required: false,
                      description: 'Motor Legal Cover',
                      amount: {
                        amount: 28,
                        currency: 'gbp'
                      },
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Electable',
                      monthlyAmount_dlg: {
                        amount: 2.63,
                        currency: 'gbp'
                      }
                    },
                    {
                      name: 'Guaranteed Hire Car Plus',
                      codeIdentifier_dlg: 'MOTGuaranteedHireCarPlusCov',
                      selected: true,
                      required: false,
                      description: 'Guaranteed Hire Car Plus',
                      amount: {
                        amount: 20.16,
                        currency: 'gbp'
                      },
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Electable',
                      monthlyAmount_dlg: {
                        amount: 1.9,
                        currency: 'gbp'
                      }
                    },
                    {
                      name: 'Guaranteed Repairs',
                      codeIdentifier_dlg: 'MOTRepairsCov',
                      selected: true,
                      required: true,
                      description: 'Guaranteed Repairs',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Fire',
                      codeIdentifier_dlg: 'MOTFireCov',
                      selected: true,
                      required: true,
                      description: 'Fire',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Theft',
                      codeIdentifier_dlg: 'MOTTheftCov',
                      selected: true,
                      required: true,
                      description: 'Theft',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Uninsured Drivers Promise',
                      codeIdentifier_dlg: 'MOTUninsuredDriversPromiseCov',
                      selected: true,
                      required: true,
                      description: 'Uninsured Drivers Promise',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Third Party Liability',
                      codeIdentifier_dlg: 'MOTThirdPartyLiabCov',
                      selected: true,
                      required: true,
                      description: 'Third Party Liability',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Driving Other Cars',
                      codeIdentifier_dlg: 'MOTDrivingOtherCarsCov',
                      selected: true,
                      required: true,
                      description: 'Driving Other Cars',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Personal Benefits',
                      codeIdentifier_dlg: 'MOTPersonalBenefitsCov',
                      selected: true,
                      required: true,
                      description: 'Personal Benefits',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Accidental Damage',
                      codeIdentifier_dlg: 'MOTAccidentalDamageCov',
                      selected: true,
                      required: true,
                      description: 'Accidental Damage',
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Required'
                    },
                    {
                      name: 'Protected No Claim Discount',
                      codeIdentifier_dlg: 'MOTNoClaimDiscCov',
                      selected: false,
                      required: false,
                      description: 'Protected No Claim Discount',
                      amount: {
                        amount: 139.65,
                        currency: 'gbp'
                      },
                      coverageCategoryCode: 'MOTVehicleStndGrp',
                      coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                      existanceType_dlg: 'Electable',
                      monthlyAmount_dlg: {
                        amount: 13.04,
                        currency: 'gbp'
                      }
                    }
                  ],
                  rescueCoverages_dlg: [
                    {
                      covName: 'roadsidehome',
                      coverages: [
                        {
                          name: 'Caravan and Trailer Cover',
                          codeIdentifier_dlg: 'RESCaravanandTrailerCvrCov',
                          description: 'Caravan and Trailer Cover',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Specialist Equipment',
                          codeIdentifier_dlg: 'RESSpecialistEquipmentCov',
                          description: 'Specialist Equipment',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Roadside Assistance',
                          codeIdentifier_dlg: 'RESRoadsideAssistanceCov',
                          description: 'Roadside Assistance',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Personal Cover',
                          codeIdentifier_dlg: 'RESPersonalCov',
                          description: 'Personal Cover',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Home Breakdown',
                          codeIdentifier_dlg: 'RESHomeBreakdownCov',
                          description: 'Home Breakdown',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        }
                      ],
                      amount: {
                        amount: 66.92,
                        currency: 'gbp'
                      },
                      monthlyAmount: {
                        amount: 6.25,
                        currency: 'gbp'
                      },
                      selected: false
                    },
                    {
                      covName: 'roadside',
                      coverages: [
                        {
                          name: 'Caravan and Trailer Cover',
                          codeIdentifier_dlg: 'RESCaravanandTrailerCvrCov',
                          description: 'Caravan and Trailer Cover',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Specialist Equipment',
                          codeIdentifier_dlg: 'RESSpecialistEquipmentCov',
                          description: 'Specialist Equipment',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Roadside Assistance',
                          codeIdentifier_dlg: 'RESRoadsideAssistanceCov',
                          description: 'Roadside Assistance',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Personal Cover',
                          codeIdentifier_dlg: 'RESPersonalCov',
                          description: 'Personal Cover',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        }
                      ],
                      amount: {
                        amount: 41.58,
                        currency: 'gbp'
                      },
                      monthlyAmount: {
                        amount: 3.89,
                        currency: 'gbp'
                      },
                      selected: true
                    },
                    {
                      covName: 'fulluk',
                      coverages: [
                        {
                          name: 'Caravan and Trailer Cover',
                          codeIdentifier_dlg: 'RESCaravanandTrailerCvrCov',
                          description: 'Caravan and Trailer Cover',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Specialist Equipment',
                          codeIdentifier_dlg: 'RESSpecialistEquipmentCov',
                          description: 'Specialist Equipment',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'National Recovery',
                          codeIdentifier_dlg: 'RESNationalRecoveryCov',
                          description: 'National Recovery',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Roadside Assistance',
                          codeIdentifier_dlg: 'RESRoadsideAssistanceCov',
                          description: 'Roadside Assistance',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Onward Travel Options',
                          codeIdentifier_dlg: 'RESOnwardTravelOptsCov',
                          description: 'Onward Travel Options',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Personal Cover',
                          codeIdentifier_dlg: 'RESPersonalCov',
                          description: 'Personal Cover',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        },
                        {
                          name: 'Home Breakdown',
                          codeIdentifier_dlg: 'RESHomeBreakdownCov',
                          description: 'Home Breakdown',
                          coverageCategoryCode: 'RESVehicleStndGrp',
                          coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                        }
                      ],
                      amount: {
                        amount: 94.46,
                        currency: 'gbp'
                      },
                      monthlyAmount: {
                        amount: 8.83,
                        currency: 'gbp'
                      },
                      selected: false
                    },
                    {
                      covName: 'RESEuroBrkdownLongTermCov',
                      amount: {
                        amount: 84.98,
                        currency: 'gbp'
                      },
                      monthlyAmount: {
                        amount: 7.94,
                        currency: 'gbp'
                      },
                      selected: true
                    }
                  ],
                  vehicleExcess_dlg: {
                    compulsoryExcess: 200,
                    voluntaryExcess: [
                      0,
                      25,
                      50,
                      75,
                      100,
                      125,
                      150,
                      175,
                      200,
                      225,
                      250,
                      275,
                      300,
                      325,
                      350,
                      375,
                      400,
                      425,
                      450,
                      475,
                      500
                    ],
                    selectedVoluntaryExcess: 250,
                    driverExcess: 0,
                    totalExcess: 450,
                    fireandTheftExcess: 450,
                    windScreenRepair: 10,
                    windScreenReplace: 75,
                    nonApprovedRepairerExcess: 0
                  }
                }
              ]
            },
            versionGroupId_dlg: 1,
            driverExcess_dlg: [
              {
                publicID: 'r1c3e2e:470229',
                name: 'Tm Cfyyy',
                compulsoryExcess: 200,
                voluntaryExcess: 250,
                fireandTheftExcess: 200,
                fireandTheftTotalExcess: 450,
                driverExcess: 0,
                totalExcess: 450,
                windScreenRepair: 10,
                windScreenReplace: 75,
                vehicleID: 'r1c3e2e:436233',
                driverID: 'r1c3e2e:1111313',
                nonApprovedRepairerExcess: 0
              },
              {
                publicID: 'r1c3e2e:470230',
                name: 'Claire Currin',
                mainDriver: true,
                compulsoryExcess: 200,
                voluntaryExcess: 250,
                fireandTheftExcess: 200,
                fireandTheftTotalExcess: 450,
                driverExcess: 0,
                totalExcess: 450,
                windScreenRepair: 10,
                windScreenReplace: 75,
                vehicleID: 'r1c3e2e:436233',
                driverID: 'r1c3e2e:1111312',
                nonApprovedRepairerExcess: 0
              }
            ],
            noClaimDiscountApplied_dlg: false
          },
          {
            branchName: 'Version #1 (1)',
            periodPublicId_dlg: 'r1c3e2e:316022-compplus',
            offeringCode_dlg: 'compplus',
            versionGroupId_dlg: 1
          }
        ]
      }
    },
    quoteData: {
      offeredQuotes: [
        {
          publicID: 'r1c3e2e:316022-comp',
          branchName: 'Version #1 (1)',
          branchCode: 'comp',
          isCustom: true,
          premium: {
            total: {
              amount: 1571.34,
              currency: 'gbp'
            },
            termMonths: 12,
            taxes: {
              amount: 168.34,
              currency: 'gbp'
            },
            totalBeforeTaxes: {
              amount: 1403,
              currency: 'gbp'
            },
            offeringPremium_dlg: {
              amount: 1396.62,
              currency: 'gbp'
            },
            previousTotalCost_dlg: {
              amount: 1566.63,
              currency: 'gbp'
            }
          }
        },
        {
          publicID: 'r1c3e2e:316022-compplus',
          branchName: 'Version #1 (1)',
          branchCode: 'compplus',
          isCustom: false,
          premium: {
            total: {
              amount: 1488.04,
              currency: 'gbp'
            },
            termMonths: 12,
            taxes: {
              amount: 159.42,
              currency: 'gbp'
            },
            totalBeforeTaxes: {
              amount: 1328.62,
              currency: 'gbp'
            },
            offeringPremium_dlg: {
              amount: 1488.04,
              currency: 'gbp'
            }
          }
        }
      ]
    },
    bindData: {
      accountNumber: '3529030065',
      chosenQuote: 'r1c3e2e:316022-comp',
      offeredPaymentPlans_dlg: [
        {
          periodPublicId: 'r1c3e2e:316022-comp',
          branchName: 'comp',
          paymentPlans: [
            {
              name: 'Single Payment',
              downPayment: {
                amount: 0,
                currency: 'gbp'
              },
              total: {
                amount: 1571.34,
                currency: 'gbp'
              },
              installment: {
                amount: 0,
                currency: 'gbp'
              },
              billingId: 'dlg_payment_plan:1',
              firstInstallment_dlg: {
                amount: 0,
                currency: 'gbp'
              },
              installmentPercentage_dlg: 0,
              installmentCharge_dlg: {
                amount: 0,
                currency: 'gbp'
              },
              aPR_dlg: 0
            },
            {
              name: 'Monthly - 12 Instalments',
              downPayment: {
                amount: 0,
                currency: 'gbp'
              },
              total: {
                amount: 1759.9,
                currency: 'gbp'
              },
              installment: {
                amount: 146.75,
                currency: 'gbp'
              },
              billingId: 'dlg_payment_plan:3',
              firstInstallment_dlg: {
                amount: 146.75,
                currency: 'gbp'
              },
              remainingInstallment_dlg: {
                amount: 146.65,
                currency: 'gbp'
              },
              installmentPercentage_dlg: 12,
              installmentCharge_dlg: {
                amount: 188.56,
                currency: 'gbp'
              },
              aPR_dlg: 28.5
            }
          ]
        }
      ],
      selectedPaymentPlan: 'dlg_payment_plan:3',
      contactPhone: '07777777777',
      contactEmail: '150615092020rc3e2e@getnada.com',
      directDebitDetails_dlg: {
        publicID: 'r1c3e2e:82301',
        isPolicyHolderPayerInd: true,
        sameNameAndAddressInd: true,
        isTelephoneSignUpRequired: true,
        bankValidationPassedInd: true,
        numberOfSignatures: 1,
        person: {
          publicID: 'r1c3e2e:89909',
          displayName: 'Claire Currin',
          firstName: 'Claire',
          lastName: 'Currin',
          prefix: 'mrs',
          primaryPhoneType: 'other_Dlg',
          workNumber: '07777777777',
          maritalStatus: 'M',
          dateOfBirth: {
            year: 1996,
            month: 0,
            day: 1
          },
          gender: 'F'
        },
        billingAddres: {
          publicID: 'r1c3e2e:439314',
          displayName: '306 Wilsthorpe Road, Long Eaton, NOTTINGHAM, Nottinghamshire, NG10 4AA',
          addressLine1: '306 Wilsthorpe Road',
          addressLine2: 'Long Eaton',
          city: 'NOTTINGHAM',
          postalCode: 'NG10 4AA',
          country: 'GB',
          addressType: 'home',
          uPRN_dlg: '100030162008',
          county_dlg: 'Nottinghamshire',
          xcordinate_dlg: '447721',
          ycordinate_dlg: '333447',
          latitude_dlg: '52.8963771',
          longitude_dlg: '-1.2920706',
          uDPRN_dlg: '0000000016518565'
        },
        bankDetails: {
          sortCode: '000002',
          accountNumber: '12345677',
          institutionName: '000002 Short Name---'
        }
      },
      confirmCarRegAndStartDateInd_dlg: true,
      confirmCommunicationPrefInd_dlg: false,
      confirmToProceedInd_dlg: false,
      preferredPaymentDate_dlg: 22,
      autoRenewInd_dlg: true,
      creditCardDetails_dlg: {
        publicID: 'r1c3e2e:93812',
        cardHolderName: 'Claire Currin',
        person: {
          publicID: 'r1c3e2e:89909',
          displayName: 'Claire Currin',
          firstName: 'Claire',
          lastName: 'Currin',
          prefix: 'mrs',
          primaryPhoneType: 'other_Dlg',
          workNumber: '07777777777',
          maritalStatus: 'M',
          dateOfBirth: {
            year: 1996,
            month: 0,
            day: 1
          },
          gender: 'F'
        },
        billingAddres: {
          publicID: 'r1c3e2e:439314',
          displayName: '306 Wilsthorpe Road, Long Eaton, NOTTINGHAM, Nottinghamshire, NG10 4AA',
          addressLine1: '306 Wilsthorpe Road',
          addressLine2: 'Long Eaton',
          city: 'NOTTINGHAM',
          postalCode: 'NG10 4AA',
          country: 'GB',
          addressType: 'home',
          uPRN_dlg: '100030162008',
          county_dlg: 'Nottinghamshire',
          xcordinate_dlg: '447721',
          ycordinate_dlg: '333447',
          latitude_dlg: '52.8963771',
          longitude_dlg: '-1.2920706',
          uDPRN_dlg: '0000000016518565'
        },
        isPolicyHolderPayerInd: true,
        isCardAuthorityInd: true,
        sameNameAndAddressInd: true,
        consentToReuseCardInd: true,
        cardType: 'mastercard',
        orderNumber: 'CPC6001_0002492037_R1C3E2E',
        merchantId: 'B4CTESTWEB',
        authenticatedShopperId: '3529030065CurrinBT189FL'
      },
      driversEmail_dlg: [
        {
          publicID: 'r1c3e2e:1111312',
          emailAddress: '150615092020rc3e2e@getnada.com'
        }
      ],
      promoFullFilment_dlg: [],
      renewThisVersionInd_dlg: true
    },
    selectedPeriodPublicId_dlg: 'r1c3e2e:316022-comp',
    defaultOfferingPublicId_dlg: 'r1c3e2e:316022-comp',
    policyNumber: '8000314230'
  },
  jsonrpc: '2.0'
};

/*export const OttRetrieveQuoteResponse = {
  result: {
    quoteID: '0001040748',
    quoteRef_dlg: 'DLI30000040502',
    baseData: {
      accountNumber: '5044627085',
      accountHolder: {
        emailAddress1: 'walterr1ce2e@getnada.com',
        publicID: 'r1cloc:6312',
        displayName: 'Nikks Walter',
        primaryPhoneType: 'mobile',
        workNumber: '07845784441',
        subtype: 'Person',
        primaryAddress: {
          publicID: 'r1cloc:9127',
          displayName: 'Blacklaws, BATHGATE, West Lothian, EH47 8AA',
          addressLine1: 'Blacklaws',
          city: 'BATHGATE',
          postalCode: 'EH47 8AA',
          country: 'GB',
          addressType: 'home',
          county_dlg: 'West Lothian',
          latitude_dlg: '55.8519130',
          longitude_dlg: '-3.6666971'
        },
        accountHolder: true,
        cellNumber: '07485425245',
        dateOfBirth: {
          year: 2005,
          month: 10,
          day: 11
        },
        gender: 'F',
        firstName: 'Nikks',
        lastName: 'Walter',
        prefix: 'ms',
        maritalStatus: 'S',
        brand_dlg: 'directline',
        correspondenceAddress_dlg: {
          publicID: 'r1c3dev:12605',
          displayName: 'Churchill Court, Masons Hill, BROMLEY, Kent, BR1 1DP',
          addressLine1: 'Churchill Court',
          addressLine2: 'Masons Hill',
          city: 'BROMLEY',
          postalCode: 'BR1 1DP',
          country: 'GB',
          addressType: 'correspondence_Dlg',
          uPRN_dlg: '10003627976',
          county_dlg: 'Kent',
          xcordinate_dlg: '540351',
          ycordinate_dlg: '168591',
          latitude_dlg: '51.3989963',
          longitude_dlg: '.0161911',
          uDPRN_dlg: '0000000000000000'
        },
        isCorrespondAdSameAsPrimAd_dlg: false,

        employmentStatus_dlg: 'employedfulltime',
        occupation_dlg: 'P875',
        largePrint_dlg: false,
        braille_dlg: false,
        audioCD_dlg: false,
        audioTape_dlg: false,
        mp3OnUSBStick_dlg: false,
        oktaid_dlg: '00unv94kyTkjgfqHt0x6',
        customerPref_dlg: 'portal',
        sfid_dlg: '0011j00000jXq3vAAC',
        goneAwayFlag_dlg: false,
        deceasedFlag_dlg: false
      },
      policyAddress: {
        publicID: 'r1cloc:9127',
        displayName: 'Blacklaws, BATHGATE, West Lothian, EH47 8AA',
        addressLine1: 'Blacklaws',
        city: 'BATHGATE',
        postalCode: 'EH47 8AA',
        country: 'GB',
        addressType: 'home',
        county_dlg: 'West Lothian',
        latitude_dlg: '55.8519130',
        longitude_dlg: '-3.6666971'
      },
      productCode: 'Combined',
      sfProductName_dlg: 'Motor',
      productName: 'Personal Combined',
      periodStartDate: {
        year: 2039,
        month: 4,
        day: 25
      },
      periodEndDate: {
        year: 2040,
        month: 4,
        day: 24
      },
      termType: '12months_Dlg',
      periodStatus: 'Quoted',
      channel_dlg: 'contactcentre',
      source_dlg: 'contactcentre',
      isChildrenUnder16_dlg: false,
      ownHome_dlg: true,
      noOfVehiclesInHome_dlg: '1',
      paymentType_dlg: 'infull',
      anotherBrandInd_dlg: false,
      cancelByInsurerInd_dlg: false,
      quoteExpiryDate_dlg: {
        year: 2038,
        month: 5,
        day: 23
      },
      transactionType_Dlg: 'Renewal',
      periodStartTime_dlg: {
        hour: 0,
        minute: 1,
        second: 0,
        millisecond: 0
      },
      sameBrandInd_dlg: false,
      termNumber_dlg: 2,
      motorBookletVersion_dlg: 'B4C PRIV M PB 0121',
      rescueBookletVersion_dlg: 'B4C GF LR PB 0121',
      motorIPIDVersion_dlg: 'B4C PRIV M COMP IPID 0121',
      rescueIPIDVersion_dlg: 'B4C GF LR EURO IPID 0121',
      isCorrespondAdSameAsPolAd_dlg: false,
      polCorrespondenceAddress_dlg: {
        publicID: 'r1c3dev:12607',
        displayName: 'Churchill Court, Masons Hill, BROMLEY, Kent, BR1 1DP',
        addressLine1: 'Churchill Court',
        addressLine2: 'Masons Hill',
        city: 'BROMLEY',
        postalCode: 'BR1 1DP',
        country: 'GB',
        addressType: 'correspondence_Dlg',
        uPRN_dlg: '10003627976',
        county_dlg: 'Kent',
        xcordinate_dlg: '540351',
        ycordinate_dlg: '168591'
      }
    },
    lobData: {
      mOTLine_Ext: {
        coverables: {
          drivers: [{
            fixedId: 23321,
            publicID: 'r1cloc:23352',
            person: {
              publicID: 'r1cloc:6312',
              displayName: 'Nikks Walter',
              firstName: 'Nikks',
              lastName: 'Walter',
              prefix: 'ms',
              primaryPhoneType: 'mobile',
              workNumber: '07845784441',
              cellNumber: '07485425245',
              maritalStatus: 'S',
              dateOfBirth: {
                year: 2005,
                month: 10,
                day: 11
              }
            },
            gender: 'F',
            isPolicyHolder: true,
            residentInUkFromBirth: true,
            typeOfDrivingLicense: 'fulluk',
            lengthOfDrivingLicHeldYear: '4',
            employmentStatus_dlg: 'employedfulltime',
            occupation_dlg: 'P875',
            yearInUK_dlg: {
              year: 2005,
              month: 10,
              day: 11
            },
            driverStartDate: {
              year: 2039,
              month: 4,
              day: 25
            },
            driverEndDate: {
              year: 2040,
              month: 4,
              day: 24
            },
            driverType: 'permanent',
            permanentUKResident: true,
            isLicenceVerified: true,
            licenceNumber: 'AAAPY459037VB9SV',
            isLicenceExpired: false,
            isLicenceUsed: false,
            dvlaDrvID: '00unv94kyTkjgfqHt0x6'
          }],
          motVehicles: [{
            fixedId: 14111,
            publicID: 'r1cloc:14123',
            vehicle: {
              fixedId: 14511,
              publicID: 'r1cloc:14524',
              vehicleNumber: 1,
              year: 2016,
              make: 'VOLVO',
              model: 'V60',
              vin: 'YV1FW78C0G1322089',
              annualMileage: 12000,
              leaseOrRent: false,
              primaryUse: 'sdpinccomm_dlg',
              costNew: {
                amount: 20000,
                currency: 'gbp'
              },
              displayName: 'VOLVO V60 2016',
              color: 'GREY',
              bodyType: 'ESTATE',
              vRNLookupResp: {
                dateOfFirstRegistrationUK: '2016-07-27T23:00:00Z',
                cherishedTransferDate: '2017-03-06T00:00:00Z',
                dateOfManufacture: '2016-07-27T23:00:00Z',
                marketSegment: 'UPPER MEDIUM',
                colourCurrent: 'GREY',
                lengthMM: 4635,
                widthMM: 2097,
                heightMM: 1484,
                numberOfPreviousKeepers: 1,
                startDateOfCurrentKeeper: '2017-02-28T00:00:00Z',
                importMarker: false,
                scrappingMarker: 0,
                scrappedRemovedMarker: false,
                modelSeries: 'MK1 (155)',
                modelYear: '2015',
                introductionDateToUK: '2015-04-30T23:00:00Z',
                aspiration: 'TURBO CHARGED',
                combined_ForwardGears: 6,
                arrangementOfCylinders: 'IN LINE',
                numberOfCylinders: 4,
                driveAxle: 'FRONT',
                engineLocation: 'FRONT',
                maximumTorqueNM: 280.0,
                maximumPowerInKW: 88.0,
                fuelConsumptionExtraUrbanMPG: 70.6,
                fuelConsumptionExtraUrban_Ltr100km: 4.0,
                fuelConsumptionUrbanCold_Ltr100km: 4.7,
                maximumSpeedMPH: 121,
                accelerationTo100KPHSecs: 11.7,
                euroStatus: 'E6',
                cO2: 111,
                seats: 5,
                kerbWeightMin: 1649,
                abi1: '54682640',
                driveType: '4X2',
                abi2_50: '22E',
                refID: '161369'
              },
              registrationNumber: 'A3',
              variant: 'D2 R-DESIGN NAV',
              engineSize: '1969',
              bhp: '118',
              fuelType: 'DIESEL',
              transmission: 'AUTOMATIC',
              noOfDoors: 5,
              isVehicleModified: false,
              modifications: [],
              isVehiclePurchased: true,
              purchaseDate: {
                year: 2035,
                month: 1,
                day: 1
              },
              registeredOwner: 'you',
              garageNightPostcode: 'EH47 8AA',
              isVehicleGarageAtHome: true,
              ncdOwnerInUse: 'r1cloc:23352',
              yearsNoClaim: '1',
              ncdEarn: 'withthisvehorprevveh',
              vehicleEndorsement: [{
                code: 'E0004',
                name: 'No DOC',
                description: 'There is no cover when driving another vehicle.'
              }],
              vehicleStartDate: {
                year: 2039,
                month: 4,
                day: 25
              },
              vehicleEndDate: {
                year: 2040,
                month: 4,
                day: 24
              },
              typeOfVehicle: 'permanent',
              travellingInd: false,
              schItems: []
            }
          }],
          vehicleDrivers: [{
            driversID: ['r1cloc:23352'],
            vehicleID: 'r1cloc:14524',
            mainDriverID: 'r1cloc:23352'
          }]
        },
        offerings: [{
          branchName: 'Version #1',
          periodPublicId_dlg: 'r1cloc:10015-tpft',
          offeringCode_dlg: 'tpft',
          coverages: {
            vehicleCoverages: [{
              publicID: 'r1cloc:14524',
              fixedId: 14511,
              vehicleName: '2016 VOLVO V60 (A3)',
              typeOfVehicle: 'permanent',
              automaticAppliedPromos_dlg: [],
              coverages: [{
                name: 'Windscreen',
                codeIdentifier_dlg: 'MOTWindScreenCov',
                selected: true,
                required: true,
                description: 'Windscreen',
                coverageCategoryCode: 'MOTVehicleStndGrp',
                coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                existanceType_dlg: 'Required'
              }, {
                name: 'Theft',
                codeIdentifier_dlg: 'MOTTheftCov',
                selected: true,
                required: true,
                description: 'Theft',
                coverageCategoryCode: 'MOTVehicleStndGrp',
                coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                existanceType_dlg: 'Required'
              }, {
                name: 'Fire',
                codeIdentifier_dlg: 'MOTFireCov',
                selected: true,
                required: true,
                description: 'Fire',
                coverageCategoryCode: 'MOTVehicleStndGrp',
                coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                existanceType_dlg: 'Required'
              }, {
                name: '7 Day Repair',
                codeIdentifier_dlg: 'MOTSevenDayRepairCov',
                selected: true,
                required: true,
                description: '7 Day Repair',
                coverageCategoryCode: 'MOTVehicleStndGrp',
                coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                existanceType_dlg: 'Required'
              }, {
                name: 'Third Party Liability',
                codeIdentifier_dlg: 'MOTThirdPartyLiabCov',
                selected: true,
                required: true,
                description: 'Third Party Liability',
                coverageCategoryCode: 'MOTVehicleStndGrp',
                coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                existanceType_dlg: 'Required'
              }, {
                name: 'Motor Legal Cover',
                codeIdentifier_dlg: 'MOTLegalCoverCov',
                selected: false,
                required: false,
                description: 'Motor Legal Cover',
                amount: {
                  amount: 28.0,
                  currency: 'gbp'
                },
                coverageCategoryCode: 'MOTVehicleStndGrp',
                coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                existanceType_dlg: 'Electable',
                monthlyAmount_dlg: {
                  amount: 2.58,
                  currency: 'gbp'
                }
              }, {
                name: 'Guaranteed Repairs',
                codeIdentifier_dlg: 'MOTRepairsCov',
                selected: true,
                required: true,
                description: 'Guaranteed Repairs',
                coverageCategoryCode: 'MOTVehicleStndGrp',
                coverageCategoryDisplayName: 'Motor Vehicle Level Standard Coverages',
                existanceType_dlg: 'Required'
              }],
              rescueCoverages_dlg: [{
                covName: 'fulluk',
                coverages: [{
                  name: 'Roadside Assistance',
                  codeIdentifier_dlg: 'RESRoadsideAssistanceCov',
                  description: 'Roadside Assistance',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'National Recovery',
                  codeIdentifier_dlg: 'RESNationalRecoveryCov',
                  description: 'National Recovery',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'Personal Cover',
                  codeIdentifier_dlg: 'RESPersonalCov',
                  description: 'Personal Cover',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'Caravan and Trailer Cover',
                  codeIdentifier_dlg: 'RESCaravanandTrailerCvrCov',
                  description: 'Caravan and Trailer Cover',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'Home Breakdown',
                  codeIdentifier_dlg: 'RESHomeBreakdownCov',
                  description: 'Home Breakdown',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'Specialist Equipment',
                  codeIdentifier_dlg: 'RESSpecialistEquipmentCov',
                  description: 'Specialist Equipment',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'Onward Travel Options',
                  codeIdentifier_dlg: 'RESOnwardTravelOptsCov',
                  description: 'Onward Travel Options',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }],
                amount: {
                  amount: 117.14,
                  currency: 'gbp'
                },
                monthlyAmount: {
                  amount: 10.75,
                  currency: 'gbp'
                },
                selected: false
              }, {
                covName: 'roadsidehome',
                coverages: [{
                  name: 'Roadside Assistance',
                  codeIdentifier_dlg: 'RESRoadsideAssistanceCov',
                  description: 'Roadside Assistance',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'Personal Cover',
                  codeIdentifier_dlg: 'RESPersonalCov',
                  description: 'Personal Cover',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'Caravan and Trailer Cover',
                  codeIdentifier_dlg: 'RESCaravanandTrailerCvrCov',
                  description: 'Caravan and Trailer Cover',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'Home Breakdown',
                  codeIdentifier_dlg: 'RESHomeBreakdownCov',
                  description: 'Home Breakdown',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'Specialist Equipment',
                  codeIdentifier_dlg: 'RESSpecialistEquipmentCov',
                  description: 'Specialist Equipment',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }],
                amount: {
                  amount: 85.01,
                  currency: 'gbp'
                },
                monthlyAmount: {
                  amount: 7.8,
                  currency: 'gbp'
                },
                selected: false
              }, {
                covName: 'roadside',
                coverages: [{
                  name: 'Roadside Assistance',
                  codeIdentifier_dlg: 'RESRoadsideAssistanceCov',
                  description: 'Roadside Assistance',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'Personal Cover',
                  codeIdentifier_dlg: 'RESPersonalCov',
                  description: 'Personal Cover',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'Caravan and Trailer Cover',
                  codeIdentifier_dlg: 'RESCaravanandTrailerCvrCov',
                  description: 'Caravan and Trailer Cover',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }, {
                  name: 'Specialist Equipment',
                  codeIdentifier_dlg: 'RESSpecialistEquipmentCov',
                  description: 'Specialist Equipment',
                  coverageCategoryCode: 'RESVehicleStndGrp',
                  coverageCategoryDisplayName: 'Rescue Vehicle Level Standard Coverages'
                }],
                amount: {
                  amount: 51.41,
                  currency: 'gbp'
                },
                monthlyAmount: {
                  amount: 4.72,
                  currency: 'gbp'
                },
                selected: false
              }],
              vehicleExcess_dlg: {
                driverExcess: 0.0,
                fireandTheftExcess: 50.0,
                windScreenRepair: 10.0,
                windScreenReplace: 75.0
              }
            }]
          },
          versionGroupId_dlg: 1,
          driverExcess_dlg: [{
            publicID: 'r1cloc:12017',
            name: 'Nikks Walter',
            mainDriver: true,
            compulsoryExcess: 0.0,
            voluntaryExcess: 250.0,
            fireandTheftExcess: 50.0,
            fireandTheftTotalExcess: 50.0,
            driverExcess: 0.0,
            totalExcess: 250.0,
            windScreenRepair: 10.0,
            windScreenReplace: 75.0,
            vehicleID: 'r1cloc:14524',
            driverID: 'r1cloc:23352'
          }],
          noClaimDiscountApplied_dlg: false
        }, {
          branchName: 'Version #1',
          periodPublicId_dlg: 'r1cloc:10015-compplus',
          offeringCode_dlg: 'compplus',
          versionGroupId_dlg: 1
        }, {
          branchName: 'Version #1',
          periodPublicId_dlg: 'r1cloc:10015-comp',
          offeringCode_dlg: 'comp',
          versionGroupId_dlg: 1
        }]
      }
    },
    quoteData: {
      offeredQuotes: [{
        publicID: 'r1cloc:10015-tpft',
        branchName: 'Version #1',
        branchCode: 'tpft',
        isCustom: true,
        premium: {
          total: {
            amount: 2297.93,
            currency: 'gbp'
          },
          termMonths: 12,
          taxes: {
            amount: 246.2,
            currency: 'gbp'
          },
          totalBeforeTaxes: {
            amount: 2051.73,
            currency: 'gbp'
          },
          offeringPremium_dlg: {
            amount: 2297.93,
            currency: 'gbp'
          },
          previousTotalCost_dlg: {
            amount: 2616.19,
            currency: 'gbp'
          }
        }
      }, {
        publicID: 'r1cloc:10015-compplus',
        branchName: 'Version #1',
        branchCode: 'compplus',
        isCustom: false,
        premium: {
          total: {
            amount: 2780.1,
            currency: 'gbp'
          },
          termMonths: 12,
          taxes: {
            amount: 297.86,
            currency: 'gbp'
          },
          totalBeforeTaxes: {
            amount: 2482.24,
            currency: 'gbp'
          },
          offeringPremium_dlg: {
            amount: 2780.1,
            currency: 'gbp'
          }
        }
      }, {
        publicID: 'r1cloc:10015-comp',
        branchName: 'Version #1',
        branchCode: 'comp',
        isCustom: false,
        premium: {
          total: {
            amount: 2730.26,
            currency: 'gbp'
          },
          termMonths: 12,
          taxes: {
            amount: 292.52,
            currency: 'gbp'
          },
          totalBeforeTaxes: {
            amount: 2437.74,
            currency: 'gbp'
          },
          offeringPremium_dlg: {
            amount: 2730.26,
            currency: 'gbp'
          }
        }
      }]
    },
    bindData: {
      accountNumber: '5044627085',
      chosenQuote: 'r1cloc:10015-tpft',
      offeredPaymentPlans_dlg: [{
        periodPublicId: 'r1cloc:10015-tpft',
        branchName: 'tpft',
        paymentPlans: [{
          name: 'Single Payment',
          downPayment: {
            amount: 0.0,
            currency: 'gbp'
          },
          total: {
            amount: 2297.93,
            currency: 'gbp'
          },
          installment: {
            amount: 0.0,
            currency: 'gbp'
          },
          billingId: 'dlg_payment_plan:1',
          firstInstallment_dlg: {
            amount: 0.0,
            currency: 'gbp'
          },
          installmentPercentage_dlg: 0,
          installmentCharge_dlg: {
            amount: 0.0,
            currency: 'gbp'
          },
          aPR_dlg: 0
        }, {
          name: 'Monthly - 12 Instalments',
          downPayment: {
            amount: 0.0,
            currency: 'gbp'
          },
          total: {
            amount: 2527.72,
            currency: 'gbp'
          },
          installment: {
            amount: 210.79,
            currency: 'gbp'
          },
          billingId: 'dlg_payment_plan:3',
          firstInstallment_dlg: {
            amount: 210.79,
            currency: 'gbp'
          },
          remainingInstallment_dlg: {
            amount: 210.63,
            currency: 'gbp'
          },
          installmentPercentage_dlg: 10.0,
          installmentCharge_dlg: {
            amount: 229.79,
            currency: 'gbp'
          },
          aPR_dlg: 23.2
        }]
      }],
      selectedPaymentPlan: 'dlg_payment_plan:3',
      contactPhone: '07485425245',
      contactEmail: 'walterr1ce2e@getnada.com',
      directDebitDetails_dlg: {
        publicID: 'r1cloc:7404',
        isPolicyHolderPayerInd: true,
        sameNameAndAddressInd: true,
        isTelephoneSignUpRequired: true,
        bankValidationPassedInd: true,
        numberOfSignatures: 1,
        person: {
          publicID: 'r1cloc:6312',
          displayName: 'Nikks Walter',
          firstName: 'Nikks',
          lastName: 'Walter',
          prefix: 'ms',
          primaryPhoneType: 'mobile',
          workNumber: '07845784441',
          cellNumber: '07485425245',
          maritalStatus: 'S',
          dateOfBirth: {
            year: 2005,
            month: 10,
            day: 11
          }
        },
        billingAddres: {
          publicID: 'r1cloc:9127',
          displayName: 'Blacklaws, BATHGATE, West Lothian, EH47 8AA',
          addressLine1: 'Blacklaws',
          city: 'BATHGATE',
          postalCode: 'EH47 8AA',
          country: 'GB',
          addressType: 'home',
          county_dlg: 'West Lothian',
          latitude_dlg: '55.8519130',
          longitude_dlg: '-3.6666971'
        },
        bankDetails: {
          sortCode: '000002',
          accountNumber: '12345678',
          institutionName: '000002 Short Name---'
        }
      },
      confirmCarRegAndStartDateInd_dlg: true,
      confirmCommunicationPrefInd_dlg: true,
      confirmToProceedInd_dlg: true,
      preferredPaymentDate_dlg: 25,
      autoRenewInd_dlg: true,
      creditCardDetails_dlg: {
        publicID: 'r1cloc:7403',
        cardHolderName: 'Nikks Walter',
        person: {
          publicID: 'r1cloc:6312',
          displayName: 'Nikks Walter',
          firstName: 'Nikks',
          lastName: 'Walter',
          prefix: 'ms',
          primaryPhoneType: 'mobile',
          workNumber: '07845784441',
          cellNumber: '07485425245',
          maritalStatus: 'S',
          dateOfBirth: {
            year: 2005,
            month: 10,
            day: 11
          }
        },
        billingAddres: {
          publicID: 'r1cloc:9127',
          displayName: 'Blacklaws, BATHGATE, West Lothian, EH47 8AA',
          addressLine1: 'Blacklaws',
          city: 'BATHGATE',
          postalCode: 'EH47 8AA',
          country: 'GB',
          addressType: 'home',
          county_dlg: 'West Lothian',
          latitude_dlg: '55.8519130',
          longitude_dlg: '-3.6666971'
        },
        isPolicyHolderPayerInd: true,
        sameNameAndAddressInd: true,
        consentToReuseCardInd: true,
        cardType: 'amex',
        orderNumber: 'CPC6000_0000708917_R1CE2E',
        merchantId: 'B4CTESTWEB',
        authenticatedShopperId: '5044627085WalterEH478AA'
      },
      driversEmail_dlg: [{
        publicID: 'r1cloc:23352',
        emailAddress: 'walterr1ce2e@getnada.com'
      }],
      availableCreditCardDetails_dlg: [{
        cardHolderName: 'Nikks Walter',
        person: {
          publicID: 'r1bloc:35005',
          displayName: 'Nikks Walter',
          firstName: 'Nikks',
          lastName: 'Walter',
          prefix: 'ms',
          dateOfBirth: {
            year: 2005,
            month: 11,
            day: 11
          }
        },
        billingAddres: {
          displayName: 'Blacklaws, BATHGATE, EH47 8AA',
          addressLine1: 'Blacklaws',
          city: 'BATHGATE',
          postalCode: 'EH47 8AA',
          country: 'GB'
        },
        isPolicyHolderPayerInd: true,
        sameNameAndAddressInd: true,
        consentToReuseCardInd: true,
        cardType: 'amex',
        isSelected_dlg: true
      }, {
        cardHolderName: 'Nikks Walter',
        person: {
          publicID: 'r1bloc:35005',
          displayName: 'Nikks Walter',
          firstName: 'Nikks',
          lastName: 'Walter',
          prefix: 'ms',
          dateOfBirth: {
            year: 2005,
            month: 11,
            day: 11
          }
        },
        billingAddres: {
          displayName: 'Blacklaws, BATHGATE, EH47 8AA',
          addressLine1: 'Blacklaws',
          city: 'BATHGATE',
          postalCode: 'EH47 8AA',
          country: 'GB'
        },
        isPolicyHolderPayerInd: true,
        sameNameAndAddressInd: true,
        consentToReuseCardInd: true,
        cardType: 'amex',
        cardNumber: '343434******3434',
        expDate: '022026',
        token: 'D3D2P8A2W2Y4W8D'
      }],
      prevTermAutoRenewInd_dlg: false,
      availableDirectDebitDetails_dlg: [{
        isPolicyHolderPayerInd: true,
        sameNameAndAddressInd: true,
        isTelephoneSignUpRequired: true,
        bankValidationPassedInd: true,
        numberOfSignatures: 1,
        person: {
          displayName: 'Nikks Walter',
          firstName: 'Nikks',
          lastName: 'Walter',
          prefix: 'ms'
        },
        billingAddres: {
          displayName: 'Blacklaws, BATHGATE, EH47 8AA',
          addressLine1: 'Blacklaws',
          city: 'BATHGATE',
          postalCode: 'EH47 8AA',
          country: 'GB'
        },
        bankDetails: {
          sortCode: '000002',
          accountNumber: '12345678',
          institutionName: '000002 Short Name---'
        }
      }, {
        isPolicyHolderPayerInd: true,
        sameNameAndAddressInd: true,
        isTelephoneSignUpRequired: true,
        bankValidationPassedInd: true,
        numberOfSignatures: 1,
        person: {
          displayName: 'Nikks Walter',
          firstName: 'Nikks',
          lastName: 'Walter',
          prefix: 'ms'
        },
        billingAddres: {
          displayName: 'Blacklaws, BATHGATE, EH47 8AA',
          addressLine1: 'Blacklaws',
          city: 'BATHGATE',
          postalCode: 'EH47 8AA',
          country: 'GB'
        },
        bankDetails: {
          sortCode: '000002',
          accountNumber: '12345678',
          institutionName: '000002 Short Name---'
        }
      }, {
        sameNameAndAddressInd: true,
        isTelephoneSignUpRequired: true,
        bankValidationPassedInd: true,
        numberOfSignatures: 1,
        person: {
          displayName: 'Nikks Walter',
          firstName: 'Nikks',
          lastName: 'Walter',
          prefix: 'ms'
        },
        billingAddres: {
          displayName: 'Blacklaws, BATHGATE, EH47 8AA',
          addressLine1: 'Blacklaws',
          city: 'BATHGATE',
          postalCode: 'EH47 8AA',
          country: 'GB'
        },
        bankDetails: {
          sortCode: '000006',
          accountNumber: '12345676',
          institutionName: '000006 Short Name'
        }
      }, {
        isPolicyHolderPayerInd: true,
        sameNameAndAddressInd: true,
        isTelephoneSignUpRequired: true,
        bankValidationPassedInd: true,
        numberOfSignatures: 1,
        person: {
          displayName: 'Nikks Walter',
          firstName: 'Nikks',
          lastName: 'Walter',
          prefix: 'ms'
        },
        billingAddres: {
          displayName: 'Blacklaws, BATHGATE, EH47 8AA',
          addressLine1: 'Blacklaws',
          city: 'BATHGATE',
          postalCode: 'EH47 8AA',
          country: 'GB'
        },
        bankDetails: {
          sortCode: '000002',
          accountNumber: '12345678',
          institutionName: '000002 Short Name---'
        }
      }],
      eligiblePaymentMethods: ['Card', 'DirectDebit'],
      selectedPaymentMethod: 'DirectDebit',
      recvRenewalNoticeInd_dlg: true,
      useAltCardInd_dlg: false
    },
    selectedPeriodPublicId_dlg: 'r1cloc:10015-tpft',
    defaultOfferingPublicId_dlg: 'r1cloc:10015-tpft',
    policyNumber: '5100002905'
  },
  jsonrpc: '2.0'
}*/

