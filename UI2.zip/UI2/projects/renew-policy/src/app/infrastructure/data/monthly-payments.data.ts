export const MonthlyPayments = {
  downPayment: 'Initial payment by card',
  installment: 'Remaining 12 instalments',
  remainingInstallment_dlg: 'Total amount of credit',
  total: 'Total amount payable',
  installmentPercentage_dlg: 'Interest rate fixed',
  aPR_dlg: 'Representative APR',
  policyCashPrice: 'Policy cash price',
  billingId: 'Agreement term'
};
