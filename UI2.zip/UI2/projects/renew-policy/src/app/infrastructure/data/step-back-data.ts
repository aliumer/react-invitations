export interface StepBack {
  brand: string;
  channel: string;
  source: string;
  product: string;
  numYearsNCD: string;
  oneClaimWithoutProtection: number;
  twoClaimsWithoutProtection: number;
  threeClaimsPlusWithoutProtection: number;
  oneClaimWithProtection: number;
  twoClaimsWithProtection: number;
  threeClaimsWithProtection: number;
  fourClaimsWithProtection: number;
  fiveClaimsPlusWithProtection: number;
  effectiveDate: string;
  expirationDate: string;
}

export const StepBackData: StepBack[] = [
  {
    brand: 'All',
    channel: 'All',
    source: 'All',
    product: 'Personal Combined',
    numYearsNCD: '0',
    oneClaimWithoutProtection: 0,
    twoClaimsWithoutProtection: 0,
    threeClaimsPlusWithoutProtection: 0,
    oneClaimWithProtection: 0,
    twoClaimsWithProtection: 0,
    threeClaimsWithProtection: 0,
    fourClaimsWithProtection: 0,
    fiveClaimsPlusWithProtection: 0,
    effectiveDate: '',
    expirationDate: ''
  },
  {
    brand: 'All',
    channel: 'All',
    source: 'All',
    product: 'Personal Combined',
    numYearsNCD: '1',
    oneClaimWithoutProtection: 0,
    twoClaimsWithoutProtection: 0,
    threeClaimsPlusWithoutProtection: 0,
    oneClaimWithProtection: 0,
    twoClaimsWithProtection: 0,
    threeClaimsWithProtection: 0,
    fourClaimsWithProtection: 0,
    fiveClaimsPlusWithProtection: 0,
    effectiveDate: '',
    expirationDate: ''
  },
  {
    brand: 'All',
    channel: 'All',
    source: 'All',
    product: 'Personal Combined',
    numYearsNCD: '2',
    oneClaimWithoutProtection: 0,
    twoClaimsWithoutProtection: 0,
    threeClaimsPlusWithoutProtection: 0,
    oneClaimWithProtection: 0,
    twoClaimsWithProtection: 0,
    threeClaimsWithProtection: 0,
    fourClaimsWithProtection: 0,
    fiveClaimsPlusWithProtection: 0,
    effectiveDate: '',
    expirationDate: ''
  },
  {
    brand: 'All',
    channel: 'All',
    source: 'All',
    product: 'Personal Combined',
    numYearsNCD: '3',
    oneClaimWithoutProtection: 1,
    twoClaimsWithoutProtection: 0,
    threeClaimsPlusWithoutProtection: 0,
    oneClaimWithProtection: 0,
    twoClaimsWithProtection: 0,
    threeClaimsWithProtection: 0,
    fourClaimsWithProtection: 0,
    fiveClaimsPlusWithProtection: 0,
    effectiveDate: '',
    expirationDate: ''
  },
  {
    brand: 'All',
    channel: 'All',
    source: 'All',
    product: 'Personal Combined',
    numYearsNCD: '4',
    oneClaimWithoutProtection: 2,
    twoClaimsWithoutProtection: 0,
    threeClaimsPlusWithoutProtection: 0,
    oneClaimWithProtection: 4,
    twoClaimsWithProtection: 4,
    threeClaimsWithProtection: 2,
    fourClaimsWithProtection: 0,
    fiveClaimsPlusWithProtection: 0,
    effectiveDate: '',
    expirationDate: ''
  },
  {
    brand: 'All',
    channel: 'All',
    source: 'All',
    product: 'Personal Combined',
    numYearsNCD: '5',
    oneClaimWithoutProtection: 3,
    twoClaimsWithoutProtection: 1,
    threeClaimsPlusWithoutProtection: 0,
    oneClaimWithProtection: 5,
    twoClaimsWithProtection: 5,
    threeClaimsWithProtection: 3,
    fourClaimsWithProtection: 1,
    fiveClaimsPlusWithProtection: 0,
    effectiveDate: '',
    expirationDate: ''
  },
  {
    brand: 'All',
    channel: 'All',
    source: 'All',
    product: 'Personal Combined',
    numYearsNCD: '6',
    oneClaimWithoutProtection: 3,
    twoClaimsWithoutProtection: 1,
    threeClaimsPlusWithoutProtection: 0,
    oneClaimWithProtection: 6,
    twoClaimsWithProtection: 6,
    threeClaimsWithProtection: 3,
    fourClaimsWithProtection: 1,
    fiveClaimsPlusWithProtection: 0,
    effectiveDate: '',
    expirationDate: ''
  },
  {
    brand: 'All',
    channel: 'All',
    source: 'All',
    product: 'Personal Combined',
    numYearsNCD: '7',
    oneClaimWithoutProtection: 3,
    twoClaimsWithoutProtection: 1,
    threeClaimsPlusWithoutProtection: 0,
    oneClaimWithProtection: 7,
    twoClaimsWithProtection: 7,
    threeClaimsWithProtection: 3,
    fourClaimsWithProtection: 1,
    fiveClaimsPlusWithProtection: 0,
    effectiveDate: '',
    expirationDate: ''
  },
  {
    brand: 'All',
    channel: 'All',
    source: 'All',
    product: 'Personal Combined',
    numYearsNCD: '8',
    oneClaimWithoutProtection: 3,
    twoClaimsWithoutProtection: 1,
    threeClaimsPlusWithoutProtection: 0,
    oneClaimWithProtection: 8,
    twoClaimsWithProtection: 8,
    threeClaimsWithProtection: 3,
    fourClaimsWithProtection: 1,
    fiveClaimsPlusWithProtection: 0,
    effectiveDate: '',
    expirationDate: ''
  },
  {
    brand: 'All',
    channel: 'All',
    source: 'All',
    product: 'Personal Combined',
    numYearsNCD: '9',
    oneClaimWithoutProtection: 3,
    twoClaimsWithoutProtection: 1,
    threeClaimsPlusWithoutProtection: 0,
    oneClaimWithProtection: 9,
    twoClaimsWithProtection: 9,
    threeClaimsWithProtection: 3,
    fourClaimsWithProtection: 1,
    fiveClaimsPlusWithProtection: 0,
    effectiveDate: '',
    expirationDate: ''
  }
];
