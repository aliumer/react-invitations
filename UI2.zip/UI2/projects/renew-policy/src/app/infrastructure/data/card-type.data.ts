import { KeyValue } from '@angular/common';

export const CardType: KeyValue<string, string>[] = [
  {key: 'visadebit', value: 'Visa Debit'},
  {key: 'visacredit', value: 'Visa Credit'},
  {key: 'amex', value: 'American Express'},
  {key: 'mastercard', value: 'Mastercard'},
  {key: 'visaelectron', value: 'Visa Electron'},
  {key: 'maestro', value: 'Maestro'}
];
