export const VehicleLocationQuestions = [
  {key: 'ontheroad', value: 'On the road'},
  {key: 'onthedriveway', value: 'On the driveway'},
  {key: 'ondrivewaybehelecgates', value: 'On the driveway behind electric gates'},
  {key: 'inagarage', value: 'In a garage'},
  {key: 'ingrgwithmonitalarm', value: 'In a garage with a monitored alarm'},
  {key: 'inapvtugcarpark', value: 'In a private underground car park'},
  {key: 'inamannedcarpark', value: 'In a manned car park'},
  {key: 'inunmannedcarpark', value: 'In an unmanned car park'},
];
