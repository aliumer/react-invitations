import { KeyValue } from '@angular/common';

export const VehicleUseOptions: KeyValue<string, string>[] = [
  {key: 'sdpinccomm_dlg', value: 'Social, Domestic and Pleasure including commuting'},
  {key: 'sdpexclcomm_dlg', value: 'Social, Domestic and Pleasure excluding commuting'},
  {key: 'sdpbsinsspou_dlg', value: 'Social, Domestic and Pleasure plus Business use for both insured and spouse'},
  {key: 'sdpbspolholder_dlg', value: 'Social, Domestic and Pleasure plus Business use for policyholder only'},
  {key: 'sdpbsspoupartner_dlg', value: 'Social, Domestic and Pleasure plus Business use for spouse/partner only'},
  {key: 'sdpbsdrivph_dlg', value: 'Social, Domestic and Pleasure plus Business use for all drivers for business of the ph'},
  {key: 'sdpbsdrivownbs_dlg', value: 'Social, Domestic and Pleasure plus Business use for all drivers on their own businesses'}
];

export const NcdEarnedYears: KeyValue<string, string>[] = [
  {key: '1', value: '1'},
  {key: '2', value: '2'},
  {key: '3', value: '3'},
  {key: '4', value: '4'},
  {key: '5', value: '5'},
  {key: '6', value: '6'},
  {key: '7', value: '7'},
  {key: '8', value: '8'},
  {key: '9plus', value: '9+'},
  {key: 'UnderOneYear', value: 'Under 1 year'},
  {key: 'NoNcd', value: 'No NCD'}
];

export const NcdEarnedMonths: KeyValue<string, string>[] = [
  {key: '1', value: '1'},
  {key: '2', value: '2'},
  {key: '3', value: '3'},
  {key: '4', value: '4'},
  {key: '5', value: '5'},
  {key: '6', value: '6'},
  {key: '7', value: '7'},
  {key: '8', value: '8'},
  {key: '9', value: '9'},
  {key: '10', value: '10'},
  {key: '11', value: '11'},
  {key: '0', value: 'Less than 1 month'}
];

export const NcdEarnedOn: KeyValue<string, string>[] = [
  {key: 'withthisvehorprevveh', value: 'On this or a previous vehicle'},
  {key: 'withcompanyvehicle', value: 'With a company vehicle'},
  {key: 'oncommericalfleetpolicy', value: 'On a commercial / fleet policy'},
  {key: 'onamotabilityscheme', value: 'On a Motability scheme'},
  {key: 'onanothervehicle', value: 'On Another Vehicle'},
  {key: 'withmotorbike', value: 'With Motor Bike'},
  {key: 'asanameddriver', value: 'As a named driver'},
  {key: 'inanothercountry', value: 'In Another Country'}
];
