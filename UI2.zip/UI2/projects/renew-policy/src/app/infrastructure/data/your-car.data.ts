import { KeyValue } from '@angular/common';

export const RegisteredKeeper: KeyValue<string, string>[] = [
  { key: 'you', value: 'You (proposer)'},
  { key: 'spouse', value: 'Spouse (husband/wife)'},
  { key: 'civilpartner', value: 'Civil partner'},
  { key: 'commonlawpartner', value: 'Common law partner'},
  { key: 'parent', value: 'Parent'},
  { key: 'sonordaughter', value: 'Son/daughter'},
  { key: 'otherfamilymember', value: 'Other family member'},
  { key: 'businesspartner', value: 'Business partner'},
  { key: 'leasedprivate', value: 'Leased – private'},
  { key: 'leasedcompany', value: 'Leased – company'},
  { key: 'company', value: 'Company'},
  { key: 'societyorclub', value: 'Society or club'},
  { key: 'other', value: 'Other'}
];

export const RegisteredKeeperFull: KeyValue<string, string>[] = [
  { key: 'testdrive', value: 'Test Drive'},
  { key: 'hirecarcompanyhirecar', value: 'Hire Car Company - Hire car'},
  { key: 'courtesycarthroughdlg', value: 'Courtesy Car through DLG'},
  { key: 'courtesycarothergarage', value: 'Courtesy Car from other garage'},
  { key: 'enhancedcourtesycar', value: 'Enhanced Courtesy Car'},
  ...RegisteredKeeper
];
