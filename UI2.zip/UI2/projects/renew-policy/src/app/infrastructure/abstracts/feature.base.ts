import { FormGroup } from '@angular/forms';
import { OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { takeWhile } from 'rxjs/operators';

import { JourneyNavigationActions, RenewActions } from '@ren/main/state/actions';

import { selectJourneyPath } from '@ren/main/state/selectors/journey.selectors';

import { JourneyPath } from '@ren/main/interfaces/journey-path-state';
import { KeyValueDict } from '@ren/infrastructure/interfaces/key-value-dict';

import { JourneyFeaturesConfig } from '@ren/infrastructure/configs/journey-features.config';



export abstract class FeatureBase implements OnInit, OnDestroy {

  containerForm: FormGroup;
  isShowGatewayTimeoutWarning$: Observable<boolean>;

  protected isComponentActive = true;

  protected constructor(
    protected router: Router,
    protected store: Store,
    protected featureName: string
  ) {
  }

  ngOnInit(): void {
    this.observeOnData();
    this.observeOnError();
    this.setupNavigation();
    this.handleNavigation();
  }

  ngOnDestroy(): void {
    this.isComponentActive = false;
  }

  protected abstract handleNavigation();
  protected abstract observeOnError();
  protected abstract observeOnData();

  protected onNext(next: string) {
    this.store.dispatch(JourneyNavigationActions.resetButtons());
    this.store.dispatch(JourneyNavigationActions.setNavDirection({navDirection: 1}));
    if(next) {
      this.router.navigate([`/${next}`]);
    }
  }

  protected onBack(prev: string) {
    this.store.dispatch(JourneyNavigationActions.resetButtons());
    this.store.dispatch(JourneyNavigationActions.setNavDirection({navDirection: -1}));
    if(prev) {
      this.router.navigate([`/${prev}`]);
    }
  }

  protected onCancel() {
    this.store.dispatch(JourneyNavigationActions.resetButtons());
    this.store.dispatch(RenewActions.cancelChanges());
    this.router.navigate([JourneyFeaturesConfig.dashboard.path]);
  }

  private setupNavigation() {
    this.store.pipe(
      select(selectJourneyPath),
      takeWhile(() => this.isComponentActive)
    ).subscribe((pathDetails: JourneyPath) => {
      this.store.dispatch(JourneyNavigationActions.setupNavigation({navCommands: this.computeNavInfo(pathDetails)}));
    });
  }

  private computeNavInfo(journeyPath: JourneyPath): KeyValueDict<string> {
    const currentIndex = journeyPath.path.indexOf(this.featureName);

    const prevVal = currentIndex > 0 ? JourneyFeaturesConfig[journeyPath.path[currentIndex - 1]]?.path : null;
    const nextVal = JourneyFeaturesConfig[journeyPath.path[currentIndex + 1]]?.path;
    return {
      prev: prevVal,
      next: nextVal
    };
  }
}
