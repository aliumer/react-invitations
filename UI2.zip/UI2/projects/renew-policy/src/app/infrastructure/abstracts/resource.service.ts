import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Environment } from '@ren/infrastructure/models/environment';


export abstract class ResourceService<T> {

  protected readonly url: string;
  protected readonly httpOptions: { headers: HttpHeaders };

  protected constructor(
    protected httpClient: HttpClient,
    protected env: Environment,
    protected endpoint?: string,
  ) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'x-api-key': env.apiKey
      })
    };
    this.url = env.apiUrl;
  }

  static parseSsoUrl(url: string): string {
    const [scheme, ...rest] = url.split(':');
    return [scheme, rest.join(':').split('/').filter(w => w)[0]].join('://');
  }

  create(item: T, isSso = false): Observable<T> {
    const url = isSso ? ResourceService.parseSsoUrl(this.url) : this.url;
    return this.httpClient
      .post<T>(`${url}/${this.endpoint}`, item, this.httpOptions)
      .pipe(
        map(data => data as T)
      );
  }

  read(id: number | string, isSso = false): Observable<T> {
    const url = isSso ? ResourceService.parseSsoUrl(this.url) : this.url;
    return this.httpClient
      .get(`${url}/${this.endpoint}/${id}`, this.httpOptions)
      .pipe(
        map((data: any) => data as T)
      );
  }

  list(listPropName: string = null): Observable<T[]> {
    return this.httpClient
      .get(`${this.url}/${this.endpoint}`, this.httpOptions)
      .pipe(
        map((data: any) => listPropName !== null ? data[listPropName] : data)
      );
  }

  update(item: T): Observable<T> {
    return this.httpClient
      .post<T>(`${this.url}/${this.endpoint}`, item, this.httpOptions)
      .pipe(
        map(data => data as T)
      );
  }

  delete(id: number): Observable<T> {
    return this.httpClient
      .delete(`${this.url}/${this.endpoint}/${id}`)
      .pipe(
        map(data => data as T)
      );
  }

}
