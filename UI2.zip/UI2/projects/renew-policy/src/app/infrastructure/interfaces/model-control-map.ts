import { ModelControl } from '@ren/infrastructure/interfaces/model-control';


export interface ModelControlMap {
  [key: string]: ModelControl;
}
