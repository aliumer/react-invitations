import { ValidatorFn } from '@angular/forms';
import { KeyValue } from '@angular/common';

import { ControlTypesEnum } from '@ren/infrastructure/enums/control-types.enum';
import { KeyValueDict } from '@ren/infrastructure/interfaces/key-value-dict';

export interface ModelControl {
  name: string;
  effectiveDate?: Date | null;
  label?: string;
  controlType: ControlTypesEnum;
  controls?: { [key: string]: ModelControl };
  validators?: ValidatorFn[];
  hint?: KeyValueDict<string>;
  displayValue?: string;
  options?: string[] | KeyValue<string | number, string | any>[];
  display?: any;
  validationMessages?: any;
  placeholder?: string;
  defaultValue?: string | number | KeyValue<string, string> | boolean;
}

