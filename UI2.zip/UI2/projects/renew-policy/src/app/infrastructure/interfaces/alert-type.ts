export interface AlertType {
  alertType: 'success' | 'warning' | 'error' | 'decline' | 'loading';
}
