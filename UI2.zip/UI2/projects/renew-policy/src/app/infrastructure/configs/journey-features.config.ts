export const JourneyFeaturesConfig = {
  retrieveQuote: {
    name: 'retrieveQuote',
    path: 'retrieve'
  },
  loadQuote: {
    name: 'loadQuote',
    path: 'load'
  },
  lapsedRenewal: {
    name: 'lapsedRenewal',
    path: 'lapsed-renewal'
  },
  dashboard: {
    name: 'dashboard',
    path: 'dashboard'
  },
  yourCar: {
    name: 'yourCar',
    path: 'your-car'
  },
  yourAddress: {
    name: 'yourAddress',
    path: 'your-address'
  },
  yourCorrespondenceAddress: {
    name: 'yourCorrespondenceAddress',
    path: 'your-correspondence-address'
  },
  yourDrivers: {
    name: 'yourDrivers',
    path: 'your-drivers'
  },
  yourDriversList: {
    name: 'yourDriversList',
    path: 'your-drivers/list'
  },
  addDriverPersonalDetails: {
    name: 'addDriverPersonalDetails',
    path: 'your-drivers/add/personal-details'
  },
  addDriverDln: {
    name: 'addDriverDln',
    path: 'your-drivers/add/driving-license-number'
  },
  addDriverDrivingHistory: {
    name: 'addDriverDrivingHistory',
    path: 'your-drivers/add/driving-history'
  },
  editDriverPersonalDetails: {
    name: 'editDriverPersonalDetails',
    path: 'your-drivers/edit/personal-details'
  },
  editDriverDln: {
    name: 'editDriverDln',
    path: 'your-drivers/edit/driving-license-number'
  },
  editDriverDrivingHistory: {
    name: 'editDriverDrivingHistory',
    path: 'your-drivers/edit/driving-history'
  },
  premium: {
    name: 'premium',
    path: 'premium'
  },
  review: {
    name: 'review',
    path: 'review'
  },
  reviewInitial: {
    name: 'reviewInitial',
    path: 'review/initial'
  },
  reviewEdit: {
    name: 'reviewEdit',
    path: 'review/edit'
  },
  payment: {
    name: 'payment',
    path: 'payment'
  },
  paymentList: {
    name: 'paymentList',
    path: 'payment/list'
  },
  directDebitNew: {
    name: 'directDebitNew',
    path: 'payment/direct-debit/new'
  },
  directDebitEdit: {
    name: 'directDebitEdit',
    path: 'payment/direct-debit/edit'
  },
  directDebitReview: {
    name: 'directDebitReview',
    path: 'payment/direct-debit/review'
  },
  creditCardNew: {
    name: 'creditCardNew',
    path: 'payment/credit-card/new'
  },
  creditCardEdit: {
    name: 'creditCardEdit',
    path: 'payment/credit-card/edit'
  },
  confirm: {
    name: 'confirm',
    path: 'confirm'
  },
  confirmAutoRenew: {
    name: 'confirmAutoRenew',
    path: 'confirm/auto-renew'
  },
  confirmPaymentSuccess: {
    name: 'confirmPaymentSuccess',
    path: 'confirm/payment-success'
  },
  errors: {
    name: 'errors',
    path: 'errors'
  }
}
