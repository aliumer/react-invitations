import { KeyValueDict } from '@ren/infrastructure/interfaces/key-value-dict';
import { CoverageTypeEnumSimple, CoverageTypeNames, CoverageBookletTypes } from '@ren/infrastructure/enums/coverage-type.enum';

export const BreakdownCoverMapSimple: KeyValueDict<string> = {
  fulluk: 'fulluk',
  roadsidehome: 'roadsidehome',
  roadside: 'roadside',
  recovery: 'recovery',
  RESEuroBrkdownLongTermCov: 'RESEuroBrkdownLongTermCov',
  RESPersonalCov: 'RESPersonalCov'
}
export const BreakdownFullNameCoverMap: KeyValueDict<string> = {
  fulluk: 'Full UK Breakdown Cover',
  roadsidehome: 'Roadside home Breakdown Cover',
  roadside: 'Roadside Breakdown Cover',
  recovery: 'Recovery',
  RESEuroBrkdownLongTermCov: 'European Breakdown Cover',
  RESPersonalCov: 'Personal Cover'
};

export const BreakdownCoverMap: KeyValueDict<string> = {
  fulluk: 'Full UK',
  roadsidehome: 'Roadside home',
  roadside: 'Roadside',
  recovery: 'Recovery',
  RESEuroBrkdownLongTermCov: 'European',
  RESPersonalCov: 'Personal Cover'
};

export const CoverageTypeToNamesMap = new Map<CoverageTypeEnumSimple, CoverageTypeNames>([
  [CoverageTypeEnumSimple.Comp, CoverageTypeNames.Comp],
  [CoverageTypeEnumSimple.CompPlus, CoverageTypeNames.CompPlus],
  [CoverageTypeEnumSimple.TPFT, CoverageTypeNames.TPFT],
  [CoverageTypeEnumSimple.Drivexpert, CoverageTypeNames.Drivexpert]
]);

export const CoverageTypeToBookletNamesMap = new Map<CoverageTypeEnumSimple, CoverageBookletTypes>([
  [CoverageTypeEnumSimple.Comp, CoverageBookletTypes.Comp],
  [CoverageTypeEnumSimple.CompPlus, CoverageBookletTypes.CompPlus],
  [CoverageTypeEnumSimple.TPFT, CoverageBookletTypes.TPFT],
  [CoverageTypeEnumSimple.Drivexpert, CoverageBookletTypes.Drivexpert]
]);

export const DlgCoverCodeMap: KeyValueDict<string> = {
  RESRoadsideAssistanceCov: 'Roadside assistance',
  RESHomeBreakdownCov: 'Home breakdown',
  RESNationalRecoveryCov: 'National recovery',
  RESOnwardTravelOptsCov: 'Onward travel options',
  RESCaravanandTrailerCvrCov: 'Caravan and trailer cover',
  RESSpecialistEquipmentCov: 'Specialist equipment',
  RESEuroBrkdownLongTermCov: 'European Breakdown Cover',
  RESPersonalCov: 'Personal Cover'
};

