import { FormControl } from '@angular/forms';

export class NumberValidators {
  static minValue(value: number) {
    return (control: FormControl) => {
      const numberEntered = parseInt(control.value, 10);

      if (numberEntered < value) {
        return {minValue: true};
      }

      return null;
    };
  }

  static maxValue(value: number) {
    return (control: FormControl) => {

      const numberEntered = parseInt(control.value, 10);

      if (numberEntered > value) {
        return {maxValue: true};
      }

      return null;
    };
  }

  static validNumber(control: FormControl) {
    // Validate input to only allow numbers

    // Numeric Regex
    const numberRegExp = /^[0-9]*$/;

    if (control.value) {
      if (!numberRegExp.test(control.value)) {
        return {validNumber: true};
      }
    }

    return null;
  }
}
