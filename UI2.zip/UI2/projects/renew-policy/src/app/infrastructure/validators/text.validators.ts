import { FormControl } from '@angular/forms';

export class TextValidators {
  static noSpecialCharactersExceptWhitespace(control: FormControl) {
    // Positive Number Regex (no leading zero)
    const noSpecialCharactersExceptWhitespaceRegExp = /^(\d|\w)+$/;
    if (control.value) {
      const value = control.value.replace(/ /g, '');
      if (!noSpecialCharactersExceptWhitespaceRegExp.test(value)) {
        return {noSpecialCharactersExceptWhitespace: true};
      }
    }
    return null;
  }

  static noLeadingTrailingWhiteSpaces(control: FormControl) {
    // Validate input to avoid leading and trailing whitespaces
    const noLeadingTrailingWhiteSpacesRegExp = /^\s+|\s+$/g;
    if (control.value) {
      if (noLeadingTrailingWhiteSpacesRegExp.test(control.value)) {
        return {noLeadingTrailingWhiteSpaces: true};
      }
    }
    return null;
  }

  static validName(control: FormControl) {

    const value = control.value;
    const invalidCharRegExp = /^[a-zA-Z'\-\s]*$/;
    const invalidBeginEndLetterRegExp = /^[a-zA-Z]{1}.*[a-zA-Z]{1}$/;
    const moreThanOneSpaceRegExp = /^([a-zA-Z-']+\s)*[a-zA-Z-']+$/;
    const consecutiveSpecialCharsRegExp = /['-]{2,}/;

    if (value === '') {
      return null;
    }

    if (!invalidCharRegExp.test(control.value)) {
      return {invalidCharacter: true};
    }

    if (!invalidBeginEndLetterRegExp.test(control.value)) {
      return {invalidBeginEndLetter: true};
    }

    if (!moreThanOneSpaceRegExp.test(control.value)) {
      return {moreThanOneSpace: true};
    }

    if (consecutiveSpecialCharsRegExp.test(control.value)) {
      return {consecutiveSpecialChars: true};
    }
    return null;
  }
}
