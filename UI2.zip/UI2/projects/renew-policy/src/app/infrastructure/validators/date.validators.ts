import { FormArray } from '@angular/forms';

import { DateTimeHelpers } from '@app/infrastructure/helpers/date-time-helpers';

export class DateValidators {
  static dateRequired(dateTypesToSkip?: any) {
    return (controlArray: FormArray) => {

      if (controlArray.value) {

        let errorFlag = false;

        const newDate: Array<any> = [];


        controlArray.value.forEach(value => {
          newDate.push(value);
        });

        if (dateTypesToSkip) {
          for (const type of dateTypesToSkip) {
            // day is always first so use shift to remove from array
            if (type === 'no-day') {
              newDate.shift();
            }

            // position of month can change depending if day has been removed or not
            if (type === 'no-month') {
              if (newDate.length === 3) {
                newDate.splice(1, 1);
              } else {
                newDate.splice(0, 1);
              }
            }

            // year is always last so use pop to remove from array
            if (type === 'no-year') {
              newDate.pop();
            }
          }
        }

        // Loop through new filtered array values to check if any are empty
        newDate.some((value) => {
          // If value is blank set error flag to true and exit loop
          if (value === '' || value === false) {
            errorFlag = true;
          }

          // exit if true
          return errorFlag;
        });

        if (errorFlag) {
          return {dateRequired: true};
        }
      }

      return null;
    };
  }

  static validDate(controlArray: FormArray) {

    const tempValue: string[] = [];

    if (controlArray && controlArray.value.length) {

      controlArray.value.forEach((value) => {
        value = (value === '' || value === null) ? '1' : value;
        tempValue.push(value);
      });

      const valueString: string = tempValue.join('/');

      // tslint:disable:max-line-length
      const dateRegExp = /(^(((0?[1-9]|1[0-9]|2[0-8])[\/](0?[1-9]|1[012]))|((29|30|31)[\/](0?[13578]|1[02]))|((29|30)[\/](0?[4,6,9]|11)))[\/](19|18|[2-9][0-9])\d\d$)|(^29[\/]0?2[\/](19|[2-9][0-9])(00|04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)$)/;
      // tslint:enable:max-line-length

      if (!dateRegExp.test(valueString)) {
        return {invalidDate: true};
      }
    }

    return null;
  }

  static maxAge(age: number, currentDate: Date) {

    return (controlArray: FormArray) => {

      const formatControls: string = controlArray.value.slice().reverse().join('/');
      const enteredDate: any = new Date(formatControls);
      const maxDate: any = new Date(currentDate.getFullYear() - age - 1, currentDate.getMonth(), currentDate.getDate());
      if (enteredDate.getTime() <= maxDate.getTime()) {
        return {maxAge: true};
      }

      return null;
    };
  }

  static minAge(age: number, currentDate: Date) {
    return (controlArray: FormArray) => {

      const formatControls: string = controlArray.value.slice().reverse().join('/');
      const enteredDate: any = new Date(formatControls);
      const minDate: any = new Date(currentDate.getFullYear() - age, currentDate.getMonth(), currentDate.getDate());
      if (enteredDate.getTime() > minDate.getTime()) {
        return {minAge: true};
      }

      return null;
    };
  }

  static noFutureDate(isPurchaseDate = false) {
    return (controlArray: FormArray) => {
      const currentDate = new Date((new Date()).setHours(0, 0, 0, 0));
      // Appending 1 since Safari and IE are unable to take the default date as 1
      const formatControls: string = isPurchaseDate ? controlArray.value.slice().reverse().join('/').concat('1') : controlArray.value.slice().reverse().join('/');
      const enteredDate: any = new Date(formatControls);

      if (enteredDate.getTime() > currentDate.getTime()) {
        return {noFutureDate: true};
      }

      return null;
    };
  }

  static minDateFull(dateArray: string[] | number[]) {
    return (control: FormArray) => {
      if (dateArray && !DateValidators.validDate(control)) {
        if (control.value.length === 3) {
          const enteredDateArr = [DateTimeHelpers.lastDayOfMonth(control.value), ...control.value.slice(1)];
          const enteredDate: any = new Date(enteredDateArr.reverse().join('/'));
          const minDate: any = new Date(dateArray.slice().reverse().join('/'));

          if (enteredDate.getTime() < minDate.getTime()) {
            return {minMonthYear: true};
          }
        }
      }

      return null;
    };
  }
}
