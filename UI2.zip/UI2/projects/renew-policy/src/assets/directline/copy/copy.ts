export const brandCopy = {
  brand: 'Direct Line',
  serviceUserNumber: '290696',
  brandSimple: 'directline',
  dvlaSearchCode: 'DLI',
  phoneNumber: '0345 878 5578',
  drivexpert: 'DrivePlus',
  drivexpertSimple: 'driveplus',
  cookieUrl: 'https://www.directline.com/cookies-notice',
  premium: {
    benefitsList: {
      comp: {
        courtesyCar: 'Guaranteed Car Hire'
      }
    },
    excess: {
      accidentalDamageCopy: `Excess for accidental damage varies from driver to driver, depending on age and driving experience.`
    }
  },
  review: {
    cancellationsFee: '48.16',
    mta: 'Mid-term adjustments to, or requests for duplicate documents of your car insurance policy do not incur an administration fee. However, an additional premium may apply as a result of the amendment.'
  },
  telematics: {
    selfInstalledText: `We will send you a telematics 'black box' device for you to install in your vehicle once you have purchased your policy.`,
    hardwiredText: `We will arrange installation of your telematics 'black box' by our technicians once you have purchased your policy.`
  },
  footer: [
    {
      label: 'Accessibility',
      url: 'https://www.directline.com/accessibility',
      ariaLabel: 'Our accessibility information opens in a new window'
    },
    {
      label: 'About us',
      url: 'https://www.directline.com/about-us',
      ariaLabel: 'Our about us information opens in a new window'
    },
    {
      label: 'Legal',
      url: 'https://www.directline.com/legal/terms',
      ariaLabel: 'Our legal information opens in a new window'
    },
    {
      label: 'Privacy',
      url: 'https://u-k-insurance.co.uk/brands-policy.html',
      ariaLabel: 'Our security and privacy information opens in a new window'
    },
    {
      label: 'Telematics privacy',
      url: 'https://www.directline.com/car-insurance/telematics/black-box/privacy',
      ariaLabel: 'Our telematics privacy information opens in a new window'
    },
    {
      label: 'Site map',
      url: 'https://www.directline.com/site-map',
      ariaLabel: 'Our site map opens in a new window'
    }
  ]
};
