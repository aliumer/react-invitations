import { defaultCopy } from './../privilege/copy/copy';

export const brandCopy = defaultCopy;
